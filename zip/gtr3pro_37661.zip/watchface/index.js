﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 81,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'adobe_percent.png',
              unit_tc: 'adobe_percent.png',
              unit_en: 'adobe_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 325,
              y: 80,
              image_array: ["cell_1.png","cell_2.png","cell_3.png","cell_4.png","cell_5.png","cell_6.png","cell_7.png","cell_8.png","cell_9.png","cell_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 20,
              year_startY: 225,
              year_sc_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              year_tc_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              year_en_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              year_zero: 0,
              year_space: 0,
              year_unit_sc: 'weather_minus.png',
              year_unit_tc: 'weather_minus.png',
              year_unit_en: 'weather_minus.png',
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 365,
              src: 'xiaomi_bluetooth.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 255,
              src: 'xiaomi_calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 385,
              y: 325,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 365,
              src: 'xiaomi_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 415,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 435,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'adobe_km.png',
              unit_tc: 'adobe_km.png',
              unit_en: 'adobe_km.png',
              dot_image: 'adobe_decimal.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 255,
              src: 'xiaomi_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 325,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 325,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'microsoft_slash.png',
              unit_tc: 'microsoft_slash.png',
              unit_en: 'microsoft_slash.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 255,
              src: 'xiaomi_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 325,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 325,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'microsoft_slash.png',
              unit_tc: 'microsoft_slash.png',
              unit_en: 'microsoft_slash.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 255,
              src: 'xiaomi_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 325,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 115,
              y: 225,
              week_en: ["regular_script_week1.png","regular_script_week2.png","regular_script_week3.png","regular_script_week4.png","regular_script_week5.png","regular_script_week6.png","regular_script_week7.png"],
              week_tc: ["regular_script_week1.png","regular_script_week2.png","regular_script_week3.png","regular_script_week4.png","regular_script_week5.png","regular_script_week6.png","regular_script_week7.png"],
              week_sc: ["regular_script_week1.png","regular_script_week2.png","regular_script_week3.png","regular_script_week4.png","regular_script_week5.png","regular_script_week6.png","regular_script_week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 225,
              day_sc_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              day_tc_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              day_en_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 50,
              month_startY: 225,
              month_sc_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              month_tc_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              month_en_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              month_zero: 0,
              month_space: 0,
              month_unit_sc: 'weather_minus.png',
              month_unit_tc: 'weather_minus.png',
              month_unit_en: 'weather_minus.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 365,
              src: 'xiaomi_sleep_clock_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 150,
              font_array: ["weather_small0.png","weather_small1.png","weather_small2.png","weather_small3.png","weather_small4.png","weather_small5.png","weather_small6.png","weather_small7.png","weather_small8.png","weather_small9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_degrees.png',
              unit_tc: 'weather_degrees.png',
              unit_en: 'weather_degrees.png',
              negative_image: 'weather_minus.png',
              invalid_image: 'weather_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 100,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 30,
              hour_array: ["time0.png","time1.png","time2.png","time3.png","time4.png","time5.png","time6.png","time7.png","time8.png","time9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 170,
              minute_startY: 140,
              minute_array: ["time0.png","time1.png","time2.png","time3.png","time4.png","time5.png","time6.png","time7.png","time8.png","time9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 365,
              src: 'xiaomi_bluetooth_quietly.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 365,
              src: 'xiaomi_bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 300,
              y: 365,
              src: 'xiaomi_sleep_clock_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 30,
              hour_array: ["time0.png","time1.png","time2.png","time3.png","time4.png","time5.png","time6.png","time7.png","time8.png","time9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 170,
              minute_startY: 140,
              minute_array: ["time0.png","time1.png","time2.png","time3.png","time4.png","time5.png","time6.png","time7.png","time8.png","time9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 30,
              w: 150,
              h: 105,
              src: '1pix.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 90,
              w: 100,
              h: 50,
              src: '1pix.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 150,
              w: 100,
              h: 50,
              src: '1pix.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 255,
              w: 100,
              h: 100,
              src: '1pix.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 255,
              w: 100,
              h: 100,
              src: '1pix.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 365,
              w: 100,
              h: 100,
              src: '1pix.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 140,
              w: 150,
              h: 105,
              src: '1pix.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 365,
              w: 50,
              h: 100,
              src: '1pix.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 365,
              w: 50,
              h: 100,
              src: '1pix.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
