﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_day_text_font = ''
        let normal_battery_text_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 135,
              w: 150,
              h: 38,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 107,
              w: 150,
              h: 34,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 310,
              font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
              padding: true,
              h_space: 2,
              unit_sc: 'Power_unit.png',
              unit_tc: 'Power_unit.png',
              unit_en: 'Power_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "an",
              anim_fps: 15,
              anim_size: 75,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0006.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 16,
              hour_posY: 116,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0005.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 191,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0007.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 18,
              second_posY: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 453,
              y: 230,
              src: '0008.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 7,
              y: 230,
              src: '0009.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 174,
              y: 104,
              w: 155,
              h: 54,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 155,
              y: 143,
              w: 193,
              h: 68,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 117,
              y: 138,
              w: 276,
              h: 200,
              text_size: 60,
              char_space: 2,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 2,
              // unit_end: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 217,
              y: 0,
              w: 41,
              h: 41,
              src: '0003.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 219,
              w: 41,
              h: 41,
              src: '0003.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 194,
              w: 103,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0003.png',
              normal_src: '0003.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 212,
              y: 447,
              w: 52,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0003.png',
              normal_src: '0003.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 110,
              w: 82,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0003.png',
              normal_src: '0003.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 297,
              w: 82,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0003.png',
              normal_src: '0003.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = idle_HourMinStr + ' PM';
                  else idle_HourMinStr = idle_HourMinStr + ' AM';
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}