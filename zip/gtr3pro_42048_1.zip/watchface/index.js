﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_uvi_text_text_img = ''
        let idle_altitude_target_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 173,
              month_startY: 86,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 86,
              week_en: ["Giorno_Sett_01.png","Giorno_Sett_02.png","Giorno_Sett_03.png","Giorno_Sett_04.png","Giorno_Sett_05.png","Giorno_Sett_06.png","Giorno_Sett_07.png"],
              week_tc: ["Giorno_Sett_01.png","Giorno_Sett_02.png","Giorno_Sett_03.png","Giorno_Sett_04.png","Giorno_Sett_05.png","Giorno_Sett_06.png","Giorno_Sett_07.png"],
              week_sc: ["Giorno_Sett_01.png","Giorno_Sett_02.png","Giorno_Sett_03.png","Giorno_Sett_04.png","Giorno_Sett_05.png","Giorno_Sett_06.png","Giorno_Sett_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 248,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 192,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 346,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_15.png',
              unit_tc: 'Sistema_15.png',
              unit_en: 'Sistema_15.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 388,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 388,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 53,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              negative_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 346,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 147,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 261,
              day_startY: 86,
              day_sc_array: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png","Giorno_10.png"],
              day_tc_array: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png","Giorno_10.png"],
              day_en_array: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png","Giorno_10.png"],
              day_zero: 1,
              day_space: -8,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 344,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 301,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_14.png',
              imperial_unit_tc: 'Sistema_14.png',
              imperial_unit_en: 'Sistema_14.png',
              negative_image: 'Sistema_12.png',
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 302,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_14.png',
              imperial_unit_tc: 'Sistema_14.png',
              imperial_unit_en: 'Sistema_14.png',
              negative_image: 'Sistema_12.png',
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 302,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_14.png',
              imperial_unit_tc: 'Sistema_14.png',
              imperial_unit_en: 'Sistema_14.png',
              negative_image: 'Sistema_12.png',
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 147,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 78,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png","Passi_11.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 190,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 210,
              minute_startY: 190,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 334,
              second_startY: 190,
              second_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 190,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 317,
              y: 190,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Livello 10.png',
              // center_x: 240,
              // center_y: 240,
              // x: 17,
              // y: 240,
              // start_angle: 180,
              // end_angle: -180,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 17,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'Livello 10.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 173,
              month_startY: 86,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 86,
              week_en: ["Giorno_Sett_01.png","Giorno_Sett_02.png","Giorno_Sett_03.png","Giorno_Sett_04.png","Giorno_Sett_05.png","Giorno_Sett_06.png","Giorno_Sett_07.png"],
              week_tc: ["Giorno_Sett_01.png","Giorno_Sett_02.png","Giorno_Sett_03.png","Giorno_Sett_04.png","Giorno_Sett_05.png","Giorno_Sett_06.png","Giorno_Sett_07.png"],
              week_sc: ["Giorno_Sett_01.png","Giorno_Sett_02.png","Giorno_Sett_03.png","Giorno_Sett_04.png","Giorno_Sett_05.png","Giorno_Sett_06.png","Giorno_Sett_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 248,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 192,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 346,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_15.png',
              unit_tc: 'Sistema_15.png',
              unit_en: 'Sistema_15.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 388,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 388,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 53,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              negative_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 346,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 147,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 261,
              day_startY: 86,
              day_sc_array: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png","Giorno_10.png"],
              day_tc_array: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png","Giorno_10.png"],
              day_en_array: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png","Giorno_10.png"],
              day_zero: 1,
              day_space: -8,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 344,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 301,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_14.png',
              imperial_unit_tc: 'Sistema_14.png',
              imperial_unit_en: 'Sistema_14.png',
              negative_image: 'Sistema_12.png',
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 302,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_14.png',
              imperial_unit_tc: 'Sistema_14.png',
              imperial_unit_en: 'Sistema_14.png',
              negative_image: 'Sistema_12.png',
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 302,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_14.png',
              imperial_unit_tc: 'Sistema_14.png',
              imperial_unit_en: 'Sistema_14.png',
              negative_image: 'Sistema_12.png',
              invalid_image: 'Sistema_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 147,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 78,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png","Passi_11.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 190,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 210,
              minute_startY: 190,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 190,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Livello 10.png',
              // center_x: 240,
              // center_y: 240,
              // x: 17,
              // y: 240,
              // start_angle: 180,
              // end_angle: -180,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 17,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'Livello 10.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = -360;
                let normal_angle_hour = 180 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = -360;
                let idle_angle_hour = 180 + idle_fullAngle_hour*idle_hour/24 + (idle_fullAngle_hour/24)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}