﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_circle_scale_mirror = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 20;
        let normal_calorie_TextCircle_img_height = 25;
        let normal_calorie_TextCircle_error_img_width = 21;
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_circle_scale_mirror = ''
        let normal_fat_burning_TextCircle = new Array(3);
        let normal_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextCircle_img_width = 20;
        let normal_fat_burning_TextCircle_img_height = 25;
        let normal_fat_burning_TextCircle_error_img_width = 21;
        let normal_spo2_TextCircle = new Array(3);
        let normal_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let normal_spo2_TextCircle_img_width = 20;
        let normal_spo2_TextCircle_img_height = 25;
        let normal_spo2_TextCircle_error_img_width = 21;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 20;
        let normal_distance_TextCircle_img_height = 25;
        let normal_distance_TextCircle_dot_width = 10;
        let normal_distance_TextCircle_error_img_width = 21;
        let normal_step_circle_scale = ''
        let normal_step_circle_scale_mirror = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 20;
        let normal_step_TextCircle_img_height = 25;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_circle_scale_mirror = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 20;
        let normal_heart_rate_TextCircle_img_height = 25;
        let normal_heart_rate_TextCircle_error_img_width = 21;
        let normal_battery_circle_scale = ''
        let normal_battery_circle_scale_mirror = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 20;
        let normal_battery_TextCircle_img_height = 25;
        let normal_battery_TextCircle_error_img_width = 21;
        let normal_city_name_text = ''
        let normal_low_TextRotate = new Array(4);
        let normal_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_low_TextRotate_img_width = 70;
        let normal_low_TextRotate_dot_width = 41;
        let normal_low_TextRotate_error_img_width = 21;
        let normal_high_TextRotate = new Array(4);
        let normal_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_high_TextRotate_img_width = 70;
        let normal_high_TextRotate_dot_width = 41;
        let normal_high_TextRotate_error_img_width = 21;
        let normal_weather_image_progress_img_level = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 85;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_month_TextRotate = new Array(2);
        let normal_month_TextRotate_ASCIIARRAY = new Array(10);
        let normal_month_TextRotate_img_width = 70;
        let normal_date_img_date_month_img = ''
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 70;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 87;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 87;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 85;
        let idle_background_bg_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 173;
        let idle_timerTextUpdate = undefined;
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 173;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 168;
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bk01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 110,
              // end_angle: 160,
              // radius: 245,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFFC4BA09,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 110,
              end_angle: 160,
              radius: 240,
              line_width: 10,
              corner_flag: 2,
              color: 0xFFC4BA09,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 110,
              end_angle: 60,
              radius: 240,
              line_width: 10,
              corner_flag: 1,
              color: 0xFFC4BA09,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 235,
              // angle: 135,
              // char_space_angle: 0,
              // error_image: '102.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 220,
              // end_angle: 240,
              // radius: 245,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF12BAB1,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 220,
              end_angle: 240,
              radius: 240,
              line_width: 10,
              corner_flag: 2,
              color: 0xFF12BAB1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 220,
              end_angle: 200,
              radius: 240,
              line_width: 10,
              corner_flag: 1,
              color: 0xFF12BAB1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 235,
              // angle: 220,
              // char_space_angle: 0,
              // error_image: '102.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_fat_burning_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 235,
              // angle: 93,
              // char_space_angle: 0,
              // error_image: '102.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_spo2_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_spo2_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
            spo2.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 210,
              // angle: -43,
              // char_space_angle: 0,
              // dot_image: '100.png',
              // error_image: '102.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 - 235,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -70,
              // end_angle: -20,
              // radius: 245,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF7979FF,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -70,
              end_angle: -20,
              radius: 240,
              line_width: 10,
              corner_flag: 2,
              color: 0xFF7979FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -70,
              end_angle: -120,
              radius: 240,
              line_width: 10,
              corner_flag: 1,
              color: 0xFF7979FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 210,
              // angle: -100,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 - 235,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 40,
              // end_angle: 60,
              // radius: 244,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFFE83400,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 40,
              end_angle: 60,
              radius: 239,
              line_width: 10,
              corner_flag: 2,
              color: 0xFFE83400,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 40,
              end_angle: 20,
              radius: 239,
              line_width: 10,
              corner_flag: 1,
              color: 0xFFE83400,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 210,
              // angle: 40,
              // char_space_angle: 0,
              // error_image: '102.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 235,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 180,
              // end_angle: 200,
              // radius: 244,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF006A00,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 180,
              end_angle: 200,
              radius: 239,
              line_width: 10,
              corner_flag: 2,
              color: 0xFF006A00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 180,
              end_angle: 160,
              radius: 239,
              line_width: 10,
              corner_flag: 1,
              color: 0xFF006A00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["090.png","091.png","092.png","093.png","094.png","095.png","096.png","097.png","098.png","099.png"],
              // radius: 235,
              // angle: 180,
              // char_space_angle: 0,
              // error_image: '102.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '090.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '091.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '092.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '093.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '094.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '095.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '096.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '097.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '098.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '099.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: '090.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 58,
              w: 200,
              h: 25,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFD8B0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 383,
              // y: 201,
              // font_array: ["050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -30,
              // angle: -30,
              // invalid_image: '102.png',
              // dot_image: '101.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextRotate_ASCIIARRAY[0] = '050.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[1] = '051.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[2] = '052.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[3] = '053.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[4] = '054.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[5] = '055.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[6] = '056.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[7] = '057.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[8] = '058.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[9] = '059.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 383,
                center_y: 201,
                pos_x: 383,
                pos_y: 201,
                angle: -30,
                src: '050.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 385,
              // y: 163,
              // font_array: ["050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -30,
              // angle: -30,
              // invalid_image: '102.png',
              // dot_image: '101.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextRotate_ASCIIARRAY[0] = '050.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[1] = '051.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[2] = '052.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[3] = '053.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[4] = '054.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[5] = '055.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[6] = '056.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[7] = '057.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[8] = '058.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[9] = '059.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 385,
                center_y: 163,
                pos_x: 385,
                pos_y: 163,
                angle: -30,
                src: '050.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 90,
              image_array: ["wen01.png","wen02.png","wen03.png","wen04.png","wen05.png","wen06.png","wen07.png","wen08.png","wen09.png","wen10.png","wen11.png","wen12.png","wen13.png","wen14.png","wen15.png","wen16.png","wen17.png","wen18.png","wen19.png","wen20.png","wen21.png","wen22.png","wen23.png","wen24.png","wen25.png","wen26.png","wen27.png","wen28.png","wen29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 97,
              // y: 242,
              // font_array: ["080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png","088.png","089.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '080.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '081.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '082.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '083.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '084.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '085.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '086.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '087.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '088.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '089.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 97,
                center_y: 242,
                pos_x: 97,
                pos_y: 242,
                angle: 30,
                src: '080.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 260,
              week_en: ["den01.png","den02.png","den03.png","den04.png","den05.png","den06.png","den07.png"],
              week_tc: ["den01.png","den02.png","den03.png","den04.png","den05.png","den06.png","den07.png"],
              week_sc: ["den01.png","den02.png","den03.png","den04.png","den05.png","den06.png","den07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 114,
              // y: 134,
              // font_array: ["060.png","061.png","062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -30,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextRotate_ASCIIARRAY[0] = '060.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[1] = '061.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[2] = '062.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[3] = '063.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[4] = '064.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[5] = '065.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[6] = '066.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[7] = '067.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[8] = '068.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[9] = '069.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 114,
                center_y: 134,
                pos_x: 114,
                pos_y: 134,
                angle: 30,
                src: '060.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 60,
              month_startY: 162,
              month_sc_array: ["men01.png","men02.png","men03.png","men04.png","men05.png","men06.png","men07.png","men08.png","men09.png","men10.png","men11.png","men12.png"],
              month_tc_array: ["men01.png","men02.png","men03.png","men04.png","men05.png","men06.png","men07.png","men08.png","men09.png","men10.png","men11.png","men12.png"],
              month_en_array: ["men01.png","men02.png","men03.png","men04.png","men05.png","men06.png","men07.png","men08.png","men09.png","men10.png","men11.png","men12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 148,
              // y: 116,
              // font_array: ["060.png","061.png","062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -30,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '060.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '061.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '062.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '063.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '064.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '065.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '066.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '067.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '068.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '069.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 148,
                center_y: 116,
                pos_x: 148,
                pos_y: 116,
                angle: 30,
                src: '060.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 128,
              // y: 227,
              // font_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: -46,
              // angle: -28,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '010.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '011.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '012.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '013.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '014.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '015.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '016.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '017.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '018.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '019.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 128,
                center_y: 227,
                pos_x: 128,
                pos_y: 227,
                angle: -28,
                src: '010.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 206,
              // y: 222,
              // font_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = '030.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = '031.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = '032.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = '033.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = '034.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = '035.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = '036.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = '037.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = '038.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = '039.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 206,
                center_y: 222,
                pos_x: 206,
                pos_y: 222,
                angle: 30,
                src: '030.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 245,
              // y: 166,
              // font_array: ["020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '020.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '021.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '022.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '023.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '024.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '025.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '026.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '027.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '028.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '029.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 245,
                center_y: 166,
                pos_x: 245,
                pos_y: 166,
                angle: 30,
                src: '020.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bk00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 18,
              // y: 203,
              // font_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: -90,
              // angle: -30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = '110.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = '111.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = '112.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = '113.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = '114.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = '115.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = '116.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = '117.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = '118.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = '119.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 18,
                center_y: 203,
                pos_x: 18,
                pos_y: 203,
                angle: -30,
                src: '110.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 160,
              // y: 199,
              // font_array: ["130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -85,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = '130.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = '131.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = '132.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = '133.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = '134.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = '135.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = '136.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = '137.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = '138.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = '139.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 160,
                center_y: 199,
                pos_x: 160,
                pos_y: 199,
                angle: 30,
                src: '130.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 240,
              // y: 78,
              // font_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -85,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = '120.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = '121.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = '122.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = '123.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = '124.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = '125.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = '126.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = '127.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = '128.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = '129.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 78,
                pos_x: 240,
                pos_y: 78,
                angle: 30,
                src: '120.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bk02.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();
              normal_calorie_circle_string = normal_calorie_circle_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 315;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 235));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_circle_string = parseInt(valueFatBurning).toString();
              normal_fat_burning_circle_string = normal_fat_burning_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 400;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_circle_string.length > 0 && normal_fat_burning_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_fat_burning_TextCircle_img_angle = 0;
                  let normal_fat_burning_TextCircle_dot_img_angle = 0;
                  normal_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_img_width/2, 235));
                  // alignment = CENTER_H
                  let normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_img_angle * (normal_fat_burning_circle_string.length - 1);
                  normal_fat_burning_TextCircle_angleOffset = -normal_fat_burning_TextCircle_angleOffset;
                  char_Angle -= normal_fat_burning_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_fat_burning_TextCircle_img_width / 2);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_fat_burning_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_fat_burning_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_fat_burning_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_fat_burning_TextCircle_error_img_width / 2);
                  normal_fat_burning_TextCircle[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_fat_burning_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle spo2_SPO2');
              let valueSpO2 = spo2.current;
              let normal_spo2_circle_string = parseInt(valueSpO2).toString();
              normal_spo2_circle_string = normal_spo2_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 273;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && normal_spo2_circle_string.length > 0 && normal_spo2_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_spo2_TextCircle_img_angle = 0;
                  let normal_spo2_TextCircle_dot_img_angle = 0;
                  normal_spo2_TextCircle_img_angle = toDegree(Math.atan2(normal_spo2_TextCircle_img_width/2, 235));
                  // alignment = CENTER_H
                  let normal_spo2_TextCircle_angleOffset = normal_spo2_TextCircle_img_angle * (normal_spo2_circle_string.length - 1);
                  normal_spo2_TextCircle_angleOffset = -normal_spo2_TextCircle_angleOffset;
                  char_Angle -= normal_spo2_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_spo2_TextCircle_img_width / 2);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, normal_spo2_TextCircle_ASCIIARRAY[charCode]);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_spo2_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_spo2_TextCircle_error_img_width / 2);
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);
              normal_distance_circle_string = normal_distance_circle_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -43;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 210));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 210));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, '100.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();
              normal_step_circle_string = normal_step_circle_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -100;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 210));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_circle_string = normal_heart_rate_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 40;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 210));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();
              normal_battery_circle_string = normal_battery_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 360;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 235));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate low_forecastData');
              let temperatureLow = undefined;
              let normal_low_rotate_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_rotate_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_rotate_string.length > 0 && normal_low_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_low_TextRotate_posOffset = normal_low_TextRotate_img_width * normal_low_rotate_string.length;
                  normal_low_TextRotate_posOffset = normal_low_TextRotate_posOffset + -30 * (normal_low_rotate_string.length - 1);
                  img_offset -= normal_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 383 + img_offset);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_low_TextRotate_img_width + -30;
                      index++;
                    }  // end if digit
                    else { 
                      normal_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 383 + img_offset);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.SRC, '101.png');
                      normal_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_low_TextRotate_dot_width + -30;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 383 - normal_low_TextRotate_error_img_width / 2);
                  normal_low_TextRotate[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate high_forecastData');
              let temperatureHigh = undefined;
              let normal_high_rotate_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_rotate_string = String(high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_rotate_string.length > 0 && normal_high_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_high_TextRotate_posOffset = normal_high_TextRotate_img_width * normal_high_rotate_string.length;
                  normal_high_TextRotate_posOffset = normal_high_TextRotate_posOffset + -30 * (normal_high_rotate_string.length - 1);
                  img_offset -= normal_high_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 385 + img_offset);
                      normal_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_high_TextRotate_img_width + -30;
                      index++;
                    }  // end if digit
                    else { 
                      normal_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 385 + img_offset);
                      normal_high_TextRotate[index].setProperty(hmUI.prop.SRC, '101.png');
                      normal_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_high_TextRotate_dot_width + -30;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 385 - normal_high_TextRotate_error_img_width / 2);
                  normal_high_TextRotate[0].setProperty(hmUI.prop.SRC, '102.png');
                  normal_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 97 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let valueMonth = timeNaw.month;
              let normal_month_rotate_string = parseInt(valueMonth).toString();
              normal_month_rotate_string = normal_month_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_rotate_string.length > 0 && normal_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 114 + img_offset);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.SRC, normal_month_TextRotate_ASCIIARRAY[charCode]);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_month_TextRotate_img_width + -30;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_rotate_string = parseInt(valueYear % 100).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 148 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width + -30;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 128 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeNaw.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 206 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 245 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 18 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -90;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 160 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width + -85;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 240 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -85;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 110,
                      end_angle: 160,
                      radius: 240,
                      line_width: 10,
                      corner_flag: 2,
                      color: 0xFFC4BA09,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_calorie_circle_scale_mirror) {
                    normal_calorie_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 110,
                      end_angle: 60,
                      radius: 240,
                      line_width: 10,
                      corner_flag: 1,
                      color: 0xFFC4BA09,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 220,
                      end_angle: 240,
                      radius: 240,
                      line_width: 10,
                      corner_flag: 2,
                      color: 0xFF12BAB1,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_fat_burning_circle_scale_mirror) {
                    normal_fat_burning_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 220,
                      end_angle: 200,
                      radius: 240,
                      line_width: 10,
                      corner_flag: 1,
                      color: 0xFF12BAB1,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -70,
                      end_angle: -20,
                      radius: 240,
                      line_width: 10,
                      corner_flag: 2,
                      color: 0xFF7979FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_step_circle_scale_mirror) {
                    normal_step_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -70,
                      end_angle: -120,
                      radius: 240,
                      line_width: 10,
                      corner_flag: 1,
                      color: 0xFF7979FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 40,
                      end_angle: 60,
                      radius: 239,
                      line_width: 10,
                      corner_flag: 2,
                      color: 0xFFE83400,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_heart_rate_circle_scale_mirror) {
                    normal_heart_rate_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 40,
                      end_angle: 20,
                      radius: 239,
                      line_width: 10,
                      corner_flag: 1,
                      color: 0xFFE83400,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 180,
                      end_angle: 200,
                      radius: 239,
                      line_width: 10,
                      corner_flag: 2,
                      color: 0xFF006A00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_battery_circle_scale_mirror) {
                    normal_battery_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 180,
                      end_angle: 160,
                      radius: 239,
                      line_width: 10,
                      corner_flag: 1,
                      color: 0xFF006A00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}