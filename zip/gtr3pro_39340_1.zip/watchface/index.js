﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start
let colornumber_main = 1
        let totalcolors_main = 10
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");																											 
         
        }
        
// Start background change
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Orbity WŁ'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Orbity WYŁ'});
        }

        //Handclock on
        function UpdateElementeOne(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        //handclock off
        function UpdateElementeTwo(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 154,
              src: 'bt_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 190,
              src: 'alarm_off.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 55,
              font_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'symb_2.png',
              unit_tc: 'symb_2.png',
              unit_en: 'symb_2.png',
              negative_image: 'symb_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 409,
              font_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'symb_3.png',
              unit_tc: 'symb_3.png',
              unit_en: 'symb_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 229,
              font_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 59,
              y: 203,
              src: 'i_steps_pl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 229,
              font_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'salt_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 248,
              src: 'i_dist_pl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 258,
              month_startY: 362,
              month_sc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              month_tc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              month_en_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 194,
              day_startY: 362,
              day_sc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              day_tc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              day_en_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'salt_dot.png',
              day_unit_tc: 'salt_dot.png',
              day_unit_en: 'salt_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 88,
              week_en: ["dw_pl_00.png","dw_pl_01.png","dw_pl_02.png","dw_pl_03.png","dw_pl_04.png","dw_pl_05.png","dw_pl_06.png"],
              week_tc: ["dw_pl_00.png","dw_pl_01.png","dw_pl_02.png","dw_pl_03.png","dw_pl_04.png","dw_pl_05.png","dw_pl_06.png"],
              week_sc: ["dw_pl_00.png","dw_pl_01.png","dw_pl_02.png","dw_pl_03.png","dw_pl_04.png","dw_pl_05.png","dw_pl_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hours.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minuts2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 122,
              hour_array: ["bigalt_00.png","bigalt_01.png","bigalt_02.png","bigalt_03.png","bigalt_04.png","bigalt_05.png","bigalt_06.png","bigalt_07.png","bigalt_08.png","bigalt_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 176,
              minute_startY: 259,
              minute_array: ["bigalt_00.png","bigalt_01.png","bigalt_02.png","bigalt_03.png","bigalt_04.png","bigalt_05.png","bigalt_06.png","bigalt_07.png","bigalt_08.png","bigalt_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 225,
              second_startY: 229,
              second_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 111,
              y: 211,
              src: 'sep_sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 154,
              src: 'bt_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 190,
              src: 'alarm_off.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 409,
              font_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'symb_3.png',
              unit_tc: 'symb_3.png',
              unit_en: 'symb_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 258,
              month_startY: 362,
              month_sc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              month_tc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              month_en_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 194,
              day_startY: 362,
              day_sc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              day_tc_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              day_en_array: ["salt_00.png","salt_01.png","salt_02.png","salt_03.png","salt_04.png","salt_05.png","salt_06.png","salt_07.png","salt_08.png","salt_09.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'salt_dot.png',
              day_unit_tc: 'salt_dot.png',
              day_unit_en: 'salt_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 88,
              week_en: ["dw_pl_00.png","dw_pl_01.png","dw_pl_02.png","dw_pl_03.png","dw_pl_04.png","dw_pl_05.png","dw_pl_06.png"],
              week_tc: ["dw_pl_00.png","dw_pl_01.png","dw_pl_02.png","dw_pl_03.png","dw_pl_04.png","dw_pl_05.png","dw_pl_06.png"],
              week_sc: ["dw_pl_00.png","dw_pl_01.png","dw_pl_02.png","dw_pl_03.png","dw_pl_04.png","dw_pl_05.png","dw_pl_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 122,
              hour_array: ["bigalt_00.png","bigalt_01.png","bigalt_02.png","bigalt_03.png","bigalt_04.png","bigalt_05.png","bigalt_06.png","bigalt_07.png","bigalt_08.png","bigalt_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 176,
              minute_startY: 259,
              minute_array: ["bigalt_00.png","bigalt_01.png","bigalt_02.png","bigalt_03.png","bigalt_04.png","bigalt_05.png","bigalt_06.png","bigalt_07.png","bigalt_08.png","bigalt_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 356,
              w: 110,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 196,
              y: 50,
              w: 90,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 215,
              w: 90,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 215,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_elemente(); 
vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 439,
              w: 250,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}