﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_date_img_date_week_img = ''
        let normal_stress_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_pai_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_stand_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 159,
              y: 425,
              week_en: ["day-funky_colors_0001.png","day-funky_colors_0002.png","day-funky_colors_0003.png","day-funky_colors_0004.png","day-funky_colors_0005.png","day-funky_colors_0006.png","day-funky_colors_0007.png"],
              week_tc: ["day-funky_colors_0001.png","day-funky_colors_0002.png","day-funky_colors_0003.png","day-funky_colors_0004.png","day-funky_colors_0005.png","day-funky_colors_0006.png","day-funky_colors_0007.png"],
              week_sc: ["day-funky_colors_0001.png","day-funky_colors_0002.png","day-funky_colors_0003.png","day-funky_colors_0004.png","day-funky_colors_0005.png","day-funky_colors_0006.png","day-funky_colors_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 58,
              y: 426,
              src: 'Picture64.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 364,
              src: 'framePicture66.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 389,
              y: 213,
              src: 'StPicture1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 385,
              y: 215,
              src: 'Picture64.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 401,
              y: 208,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -29,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 385,
              y: 214,
              src: 'steps comPicture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: -358,
              src: '12steps comPicture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 0,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -27,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 11,
              src: 'heartPicture125.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 404,
              day_sc_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              day_tc_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              day_en_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              day_zero: 1,
              day_space: -38,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -27,
              am_y: 242,
              am_sc_path: 'Picture40am.png',
              am_en_path: 'Picture40am.png',
              pm_x: -27,
              pm_y: 242,
              pm_sc_path: 'Picture41pm.png',
              pm_en_path: 'Picture41pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 61,
              hour_array: ["funky_colors_0001.png","funky_colors_0002.png","funky_colors_0003.png","funky_colors_0004.png","funky_colors_0005.png","funky_colors_0006.png","funky_colors_0007.png","funky_colors_0008.png","funky_colors_0009.png","funky_colors_0010.png"],
              hour_zero: 1,
              hour_space: -39,
              hour_align: hmUI.align.LEFT,

              minute_startX: 69,
              minute_startY: 190,
              minute_array: ["funky_colors_0001.png","funky_colors_0002.png","funky_colors_0003.png","funky_colors_0004.png","funky_colors_0005.png","funky_colors_0006.png","funky_colors_0007.png","funky_colors_0008.png","funky_colors_0009.png","funky_colors_0010.png"],
              minute_zero: 1,
              minute_space: -39,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -13,
              second_startY: 209,
              second_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              second_zero: 1,
              second_space: -36,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -135,
              y: 213,
              src: 'steps comPicture1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 0,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -25,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 14,
              src: 'chargePicture113.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 57,
              hour_array: ["aob-funky_colors_0001.png","aob-funky_colors_0002.png","aob-funky_colors_0003.png","aob-funky_colors_0004.png","aob-funky_colors_0005.png","aob-funky_colors_0006.png","aob-funky_colors_0007.png","aob-funky_colors_0008.png","aob-funky_colors_0009.png","aob-funky_colors_0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 91,
              minute_startY: 218,
              minute_array: ["aob-funky_colors_0001.png","aob-funky_colors_0002.png","aob-funky_colors_0003.png","aob-funky_colors_0004.png","aob-funky_colors_0005.png","aob-funky_colors_0006.png","aob-funky_colors_0007.png","aob-funky_colors_0008.png","aob-funky_colors_0009.png","aob-funky_colors_0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 435,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 0,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -25,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 14,
              src: 'chargePicture113.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -42,
              y: -16,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
