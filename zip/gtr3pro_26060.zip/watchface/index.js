/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_digital_clock_img_hour = '';
		let normal_digital_clock_img_minute = '';
		let normal_digital_clock_img_second = '';
		let normal_date_img_date_week_img = '';
		let normal_date_current_date_monthday = '';
		let normal_date_img_date_month = '';
		let normal_battery_current_circle = '';
		let normal_background_bg_img1 = '';
		let normal_steps_current_circle = '';
		let normal_background_bg_img2 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 125,
					hour_startY: 97,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 124,
					minute_startY: 229,
					minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.RIGHT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 361,
					second_startY: 207,
					second_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.RIGHT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 95,
					y: 73,
					week_en: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
					week_tc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
					week_sc: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 247,
					day_startY: 62,
					day_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 307,
					month_startY: 73,
					month_sc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_tc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_en_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
					month_is_character: true,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_current_circle = hmUI.createWidget(hmUI.widget.ARC);
				}

				const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
				battery.addEventListener(hmSensor.event.CHANGE, function() {
					scale_call();
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 241,
					y: 1,
					w: 15,
					h: 19,
					src: '0062.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_steps_current_circle = hmUI.createWidget(hmUI.widget.ARC);
				}

				const step = hmSensor.createSensor(hmSensor.id.STEP);
				step.addEventListener(hmSensor.event.CHANGE, function() {
					scale_call();
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 207,
					y: 445,
					w: 26,
					h: 35,
					src: '0063.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function scale_call() {
					console.log('update BATTERY circle');
					let valueBattery = battery.current;
					let targetBattery = 100;
					let progressBattery = valueBattery / targetBattery;

					if (progressBattery > 1) {
						progressBattery = 1;
					}

					let progress_cs_normal_battery = progressBattery;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						let start_angle_normal_battery = -83;
						let end_angle_normal_battery = 87;
						let center_x_normal_battery = 240;
						let center_y_normal_battery = 240;
						let radius_normal_battery = 240;
						let line_width_cs_normal_battery = 18;
						let color_cs_normal_battery = 0xF552AD6D;

						// calculated parameters
						let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
						let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
						let CircleWidth_normal_battery = 2 * radius_normal_battery;
						let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
						angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
						let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;

						normal_battery_current_circle.setProperty(hmUI.prop.MORE, {
							x: arcX_normal_battery,
							y: arcY_normal_battery,
							w: CircleWidth_normal_battery,
							h: CircleWidth_normal_battery,
							start_angle: start_angle_normal_battery,
							end_angle: end_angle_normal_battery_draw,
							color: color_cs_normal_battery,
							line_width: line_width_cs_normal_battery,
						});
					};

					console.log('update STEP circle');
					let valueStep = step.current;
					let targetStep = step.target;
					let progressStep = valueStep / targetStep;

					if (progressStep > 1) {
						progressStep = 1;
					}

					let progress_cs_normal_step = progressStep;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						let start_angle_normal_step = -257;
						let end_angle_normal_step = -94;
						let center_x_normal_step = 240;
						let center_y_normal_step = 240;
						let radius_normal_step = 240;
						let line_width_cs_normal_step = 18;
						let color_cs_normal_step = 0xFFFFFFFF;

						// calculated parameters
						let arcX_normal_step = center_x_normal_step - radius_normal_step;
						let arcY_normal_step = center_y_normal_step - radius_normal_step;
						let CircleWidth_normal_step = 2 * radius_normal_step;
						let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
						angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
						let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;

						normal_steps_current_circle.setProperty(hmUI.prop.MORE, {
							x: arcX_normal_step,
							y: arcY_normal_step,
							w: CircleWidth_normal_step,
							h: CircleWidth_normal_step,
							start_angle: start_angle_normal_step,
							end_angle: end_angle_normal_step_draw,
							color: color_cs_normal_step,
							line_width: line_width_cs_normal_step,
						});
					};

				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						scale_call();
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destory invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}