﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 276,
              year_startY: 427,
              year_sc_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              year_tc_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              year_en_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 199,
              y: 445,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 422,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 425,
              day_sc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_tc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_en_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 190,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 251,
              y: 226,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 126,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 3,
              y: 170,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 262,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 275,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 277,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 220,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Action_fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 168,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 146,
              y: 69,
              image_array: ["Steps_icons_01.png","Steps_icons_02.png","Steps_icons_03.png","Steps_icons_04.png","Steps_icons_05.png","Steps_icons_06.png","Steps_icons_07.png","Steps_icons_08.png","Steps_icons_09.png","Steps_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 293,
              y: 34,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 81,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_fonts_11.png',
              unit_tc: 'Weather_fonts_11.png',
              unit_en: 'Weather_fonts_11.png',
              negative_image: 'Weather_fonts_12.png',
              invalid_image: 'Weather_fonts_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 357,
              y: 76,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 427,
              am_y: 209,
              am_sc_path: 'Time_icon_AM.png',
              am_en_path: 'Time_icon_AM.png',
              pm_x: 427,
              pm_y: 209,
              pm_sc_path: 'Time_icon_PM.png',
              pm_en_path: 'Time_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 292,
              hour_startY: 130,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 279,
              minute_startY: 225,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 291,
              second_startY: 334,
              second_array: ["Time_font_S_01.png","Time_font_S_02.png","Time_font_S_03.png","Time_font_S_04.png","Time_font_S_05.png","Time_font_S_06.png","Time_font_S_07.png","Time_font_S_08.png","Time_font_S_09.png","Time_font_S_10.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 196,
              w: 56,
              h: 56,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 294,
              y: 327,
              w: 73,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 222,
              w: 36,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 31,
              w: 52,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 77,
              w: 54,
              h: 33,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 267,
              w: 54,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 275,
              w: 92,
              h: 99,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 161,
              w: 132,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 276,
              year_startY: 427,
              year_sc_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              year_tc_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              year_en_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 199,
              y: 445,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 422,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 425,
              day_sc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_tc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_en_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 190,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 251,
              y: 226,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 126,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 3,
              y: 170,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 262,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 275,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 277,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 220,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Action_fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 168,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 146,
              y: 69,
              image_array: ["Steps_icons_01.png","Steps_icons_02.png","Steps_icons_03.png","Steps_icons_04.png","Steps_icons_05.png","Steps_icons_06.png","Steps_icons_07.png","Steps_icons_08.png","Steps_icons_09.png","Steps_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 293,
              y: 34,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 81,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_fonts_11.png',
              unit_tc: 'Weather_fonts_11.png',
              unit_en: 'Weather_fonts_11.png',
              negative_image: 'Weather_fonts_12.png',
              invalid_image: 'Weather_fonts_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 357,
              y: 76,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 427,
              am_y: 209,
              am_sc_path: 'Time_icon_AM.png',
              am_en_path: 'Time_icon_AM.png',
              pm_x: 427,
              pm_y: 209,
              pm_sc_path: 'Time_icon_PM.png',
              pm_en_path: 'Time_icon_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 292,
              hour_startY: 130,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 279,
              minute_startY: 225,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 291,
              second_startY: 334,
              second_array: ["Time_font_S_01.png","Time_font_S_02.png","Time_font_S_03.png","Time_font_S_04.png","Time_font_S_05.png","Time_font_S_06.png","Time_font_S_07.png","Time_font_S_08.png","Time_font_S_09.png","Time_font_S_10.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  