﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'vlcsnap-2023-07-16-09h52m19s405.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 405,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 405,
              src: 'sleep.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 138,
              y: 405,
              src: 'phone.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 405,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 352,
              src: 'battery_0000s_0000_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 62,
              // start_y: 379,
              // color: 0xFFFFFFFF,
              // lenght: -21,
              // line_width: 12,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 355,
              font_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 104,
              month_startY: 316,
              month_sc_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_tc_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_en_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 315,
              day_sc_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              day_tc_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              day_en_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 102,
              y: 60,
              week_en: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              week_tc: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              week_sc: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 170,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 170,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 199,
              src: 'separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 196,
              w: 133,
              h: 100,
              src: '113.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 188,
              w: 139,
              h: 127,
              src: '113.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 315,
              day_sc_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              day_tc_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              day_en_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 111,
              week_en: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              week_tc: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              week_sc: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 100,
              month_startY: 315,
              month_sc_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_tc_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_en_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 196,
              hour_array: ["h_0000_0-.png","h_0001_1.png","h_0002_2.png","h_0003_3.png","h_0004_4.png","h_0005_5.png","h_0006_6.png","h_0007_7.png","h_0008_8.png","h_0009_9.png"],
              hour_zero: 0,
              hour_space: 5,
              hour_unit_sc: 'separator.png',
              hour_unit_tc: 'separator.png',
              hour_unit_en: 'separator.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["m_0000_0-.png","m_0001_1.png","m_0002_2.png","m_0003_3.png","m_0004_4.png","m_0005_5.png","m_0006_6.png","m_0007_7.png","m_0008_8.png","m_0009_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 62;
                  let start_y_normal_battery = 379;
                  let lenght_ls_normal_battery = -21;
                  let line_width_ls_normal_battery = 12;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  