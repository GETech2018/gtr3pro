﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '20220903_233037[1].png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 274,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 383,
              y: 222,
              image_array: ["Wea01.png","Wea02.png","Wea03.png","Wea04.png","Wea05.png","Wea06.png","Wea07.png","Wea08.png","Wea09.png","Wea10.png","Wea11.png","Wea12.png","Wea13.png","Wea14.png","Wea15.png","Wea16.png","Wea17.png","Wea18.png","Wea19.png","Wea20.png","Wea21.png","Wea22.png","Wea23.png","Wea24.png","Wea25.png","Wea26.png","Wea27.png","Wea28.png","Wea29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 311,
              image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 385,
              day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '77.png',
              center_x: 119,
              center_y: 240,
              x: 13,
              y: 75,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 274,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '77.png',
              center_x: 240,
              center_y: 118,
              x: 13,
              y: 74,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 84,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore-0000.png',
              hour_centerX: 241,
              hour_centerY: 234,
              hour_posX: 16,
              hour_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-0000.png',
              minute_centerX: 240,
              minute_centerY: 236,
              minute_posX: 16,
              minute_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 202,
              hour_startY: 274,
              hour_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 274,
              minute_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '20220903_180816[1].png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 274,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 383,
              y: 222,
              image_array: ["Wea01.png","Wea02.png","Wea03.png","Wea04.png","Wea05.png","Wea06.png","Wea07.png","Wea08.png","Wea09.png","Wea10.png","Wea11.png","Wea12.png","Wea13.png","Wea14.png","Wea15.png","Wea16.png","Wea17.png","Wea18.png","Wea19.png","Wea20.png","Wea21.png","Wea22.png","Wea23.png","Wea24.png","Wea25.png","Wea26.png","Wea27.png","Wea28.png","Wea29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 311,
              image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 385,
              day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '77.png',
              center_x: 119,
              center_y: 240,
              x: 13,
              y: 75,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 274,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '77.png',
              center_x: 240,
              center_y: 118,
              x: 13,
              y: 74,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 84,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore-0000.png',
              hour_centerX: 241,
              hour_centerY: 234,
              hour_posX: 16,
              hour_posY: 237,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-0000.png',
              minute_centerX: 240,
              minute_centerY: 236,
              minute_posX: 16,
              minute_posY: 237,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 202,
              hour_startY: 274,
              hour_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 274,
              minute_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  