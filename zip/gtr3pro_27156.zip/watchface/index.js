﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
		let MainTimer= null;
		let now = hmSensor.createSensor(hmSensor.id.TIME);
		let Pendulum;
		
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''		

	function PaintMain(){
		 // We've got 60 frames for a full pendulum travel, let's try 30 fps, so:
		 let frames=60;
		 let fps=60;
		 let mod=1000*(frames/fps);
		 let a=(now.utc % mod)/mod; // 0..0.9999
		 let nFrame=(Math.floor(a*frames)+15) % frames;
		 Pendulum.setProperty(hmUI.prop.MORE, {
              src: 'SPEN' + parseInt(nFrame) + '.png',
			  x:72,
			  y:240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	}
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fongdo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			Pendulum= hmUI.createWidget(hmUI.widget.IMG, {
				  x: 72, // 336
				  y: 240,
				  src: 'SPEN0.png',
				  show_level: hmUI.show_level.ONLY_NORMAL
				});

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 357,
              day_startY: 230,
              day_sc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_tc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_en_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 315,
              y: 228,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 114,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 83,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 82,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 188,
              y: 83,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'XXHour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 143,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'XXMin.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'XXSec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 11,
              second_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 64,
              src: 'BatBK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 65,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fongdo.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 357,
              day_startY: 230,
              day_sc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_tc_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_en_array: ["SN0.png","SN1.png","SN2.png","SN3.png","SN4.png","SN5.png","SN6.png","SN7.png","SN8.png","SN9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 315,
              y: 228,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 114,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 83,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 82,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 188,
              y: 83,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'XXHour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 143,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'XXMin.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 202,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'XXSec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 11,
              second_posY: 213,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 64,
              src: 'BatBK.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 65,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });
				
				
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
					PaintMain();
              }),
            });

			MainTimer = timer.createTimer(10, 10, PaintMain, {}); // Watchface timer

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
  			timer.stopTimer(MainTimer);
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  