﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let timeSensor = ''

//Start background change
        let btnbackground = ''
        let backgroundnumber = 0
        let totalpictures = 3

        function click_Background() {
            if(backgroundnumber==totalpictures) {
            backgroundnumber=0;
                UpdateBackground();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==1) {
                  UpdateBackground();
                }
				if(backgroundnumber==2) {
                  UpdateBackground();
                }
                if(backgroundnumber==3) {
                  UpdateBackground();
                }
            }
            {
                 if(backgroundnumber==1) hmUI.showToast({text: 'HERITAGE BLUE'});
				 if(backgroundnumber==2) hmUI.showToast({text: 'REVERSE PANDA'});
                 if(backgroundnumber==3) hmUI.showToast({text: 'SILVER RACING'});
            }
            if(backgroundnumber==0) hmUI.showToast({text: 'JET BLACK'});
        }


        function UpdateBackground(){

                normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(backgroundnumber) + ".png");
				call_change_Hands();
        }
//END background change
//START SMOOTH SECOND
        let btnsecondhand = ''
        let lsecondhand = false
        let countsecondhand = 0
        function click_Secondhand(){
                lsecondhand=true
                stopSecAnim();
                countsecondhand=countsecondhand+1;
                if(countsecondhand==1) {
                  animFps = 6;
                }
                if(countsecondhand==2) {
                  animFps = 25;
                }
                if(countsecondhand==3) {
                  lsecondhand=false
                  countsecondhand = 0;
                }
                if(!lsecondhand) {
                               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                               normal_analog_clock_time_pointer_second_classic.setProperty(hmUI.prop.VISIBLE, true);
                               hmUI.showToast({text: "Secondhand Speed Normal"});
                }
                else {
                      normal_analog_clock_time_pointer_second_classic.setProperty(hmUI.prop.VISIBLE, false);
                      startSecHandTimer();
                      normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                      if (animFps==25) { hmUI.showToast({text: "Secondhand Speed Smooth"});
                      } else { hmUI.showToast({text: "Secondhand Speed " + parseInt(animFps) }); }
                }
        }

		/**
         * SMOOTH SECONDS SCRIPTS
         */
        let now;
        let lastTime = 0;
        let animTimer;
        const animDuration = 5000;
        let animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion

        function setSec() {
          const screenType = hmSetting.getScreenType();
          if (screenType === hmSetting.screen_type.AOD) {
           return stopSecAnim();
          }
          if (!now) {
            now = hmSensor.createSensor(hmSensor.id.TIME);
          }
        }

        function startSecAnim(sec) {
          const secAnim = {
            anim_rate: 'linear',
            anim_duration: animDuration,
            anim_from: sec,
            anim_to: sec + animDuration * 6 / 1000,
            repeat_count: 1,
            anim_fps: animFps,
            anim_key: "angle",
            anim_status: 1,
          }

          normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()
         */
        function stopSecAnim() {
          if (animTimer) {
            timer.stopTimer(animTimer);
            animTimer = undefined;
          }
        }

        // start secondhand
        function startSecHandTimer() {
              if (animTimer) return;

              let duration = 0;
              const diffTime = now.utc - lastTime;
              if (diffTime < animDuration) {
                duration = animDuration - diffTime;
              }

              animTimer = timer.createTimer(duration, animDuration, (function (option) {
                lastTime = now.utc;
                startSecAnim(now.second * 6);

              }));
        }
//END SMOOTH SECOND
//Change hands called by backgroundcolor
        function call_change_Hands() {
              if(backgroundnumber==1) {
                ChangeHands(1);
              } else if(backgroundnumber==2) {
                ChangeHands(2);
              } else if(backgroundnumber==3) {
                ChangeHands(3);
              } else if(backgroundnumber==0) {
                ChangeHands(0);
              }
        }
		
//Change hands	
		let btnchangehands = ''
        let handsnumber = 0
        let totalhands = 3

        function click_ChangeHands() {
          handsnumber=handsnumber+1;
          switch (handsnumber) {
            case 1:
              ChangeHands(1); break;
			case 2:
              ChangeHands(2); break;
			case 3:
              ChangeHands(3); break;
            default:
              ChangeHands(0); handsnumber=0;
          }
          if(handsnumber==1) hmUI.showToast({text: 'LIGHT RED'});
		  if(handsnumber==2) hmUI.showToast({text: 'LIGHT BLUE'});
		  if(handsnumber==3) hmUI.showToast({text: 'SILVER & AOD'});
		  if(handsnumber==0) hmUI.showToast({text: 'DARK RED'});
        }
		
		 function ChangeHands(number) {
           if(number==1) {
				  pointstring='point1.png';
                  secstring='sec1.png';
             } else if(number==2) {
                  pointstring='point2.png';
                  secstring='sec2.png';
             } else if(number==3) {
                  pointstring='point3.png';
                  secstring='sec3.png';
             } else {
                  pointstring='point0.png';
                  secstring='sec0.png';
             }
              
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointstring,
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: pointstring,
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });
			
			// idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
              // src: pointstring,
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });
			
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: pointstring,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second_classic.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
               x: 0,
               y: 0,
               w: 480,
               h: 480,
               pos_x: 480 / 2 - 240,
               pos_y: 480 / 2 - 240,
               center_x: 240,
               center_y: 240,
               src: secstring,
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
        }
//END hands change
//START AOD CHANGE

        let btn_aod = ''
		let curAODmode = 0;		
								
        let AODmodes = ["Display OFF", "DARKENED", "JET BLACK", "HERIATAGE", "REVERSE", "RACING"];
        let AODmodeCaption;

        function toggleAODmode() {
            curAODmode = (curAODmode + 1) % AODmodes.length;
            hmFS.SysProSetInt('parkur_aod', curAODmode);

            switch (curAODmode) {
                case 0:
                    AODmodeCaption = "Display OFF";
                    break;
                case 1:
                    AODmodeCaption = "DARKENED";
                    break;
                case 2:
                    AODmodeCaption = "JET BLACK";
                    break;
				case 3:
                    AODmodeCaption = "HERIATAGE";
                    break;
                case 4:
                    AODmodeCaption = "REVERSE";
                    break;
                case 5:
                    AODmodeCaption = "RACING";
                    break;
                default:
                    AODmodeCaption = "";
                    break;
            }

            hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
        }

        function makeAOD() {

            let mode = hmFS.SysProGetInt('parkur_aod');
			
            if (mode == 1) {    // Full Hybrid

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point3.png',
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'point3.png',
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 232,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 232,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'point3.png',
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: 'point3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_path: 'aod_overlay.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            }

            if (mode == 2) {	// JET BLACK

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point0.png',
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'point0.png',
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 232,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 232,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'point3.png',
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: 'point0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            }
			
			if (mode == 3) {    // HERITAGE

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point1.png',
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'point1.png',
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 232,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 232,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'point3.png',
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: 'point1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            }
			
			if (mode == 4) {    // REVERSE

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point2.png',
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'point2.png',
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 232,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 232,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'point3.png',
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: 'point2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            }); 

            }
			
			if (mode == 5) {    // RACING

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point3.png',
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'point3.png',
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 232,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 232,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'point3.png',
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: 'point3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            }

        }

        function loadSettings() {
            if (hmFS.SysProGetInt('parkur_aod') === undefined) {
                curAODmode = 1;
                hmFS.SysProSetInt('parkur_aod', curAODmode);
            } else {
                curAODmode = hmFS.SysProGetInt('parkur_aod');
            }
        }
//END AOD CHANGE
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point0.png',
              center_x: 240,
              center_y: 73,
              x: 239,
              y: 239,
              start_angle: 240,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'point0.png',
              center_x: 140,
              center_y: 240,
              posX: 239,
              posY: 239,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 232,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 232,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'point0.png',
              // center_x: 240,
              // center_y: 337,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 337 - 239,
              center_x: 240,
              center_y: 337,
              src: 'point0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second_classic = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec0.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 480,
               h: 480,
               pos_x: 480 / 2 - 240,
               pos_y: 480 / 2 - 240,
               center_x: 240,
               center_y: 240,
               src: "sec0.png",
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
            setSec();
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 289,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 195,
              w: 90,
              h: 90,
              src: 'blank.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
// Change secondhand shortcut start
            btnsecondhand = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 190,
              text: '',
              w: 80,
              h: 100,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Secondhand();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnsecondhand.setProperty(hmUI.prop.VISIBLE, true);
// Change secondhand shortcut end
           
            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 190,
              w: 100,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START AOD Button (left)
			btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 0,
              y: 190,
              text: '',
              w: 70,
              h: 100,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
                toggleAODmode();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btn_aod.setProperty(hmUI.prop.VISIBLE, true);
//END AOD Button
//START background shortcut start (top)
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 0,
              text: '',
              w: 100,
              h: 60,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Background();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
//END background shortcut end
//START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 190,
              w: 100,
              h: 100,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });
//END Calendar Shortcut 
//START Hands Button (below)
			btnchangehands = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190,
              y: 410,
              text: '',
              w: 100,
              h: 70,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
                click_ChangeHands();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnchangehands.setProperty(hmUI.prop.VISIBLE, true);
//END Hands Button			
//START Battery Shortcut            
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 65,
              w: 100,
              h: 75,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
            });
//END Battery Shortcut

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/24 + (idle_fullAngle_hour/24)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                checkConnection();
                stopVibro();
				if(lsecondhand) {
                  startSecHandTimer();
               }
              }),
              pause_call: (function () {
                stopVibro();
				if(lsecondhand) {
                  stopSecAnim();
               }
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
				const currentScreenType = hmSetting.getScreenType();
                switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;

                  default:
                      break;
              }
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}