﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 78,
              font_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 94,
              image_array: ["b_digital1_0.png","b_digital1_1.png","b_digital1_2.png","b_digital1_3.png","b_digital1_4.png","b_digital1_5.png","b_digital1_6.png","b_digital1_7.png","b_digital1_8.png","b_digital1_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 208,
              font_array: ["digital4_00.png","digital4_01.png","digital4_02.png","digital4_03.png","digital4_04.png","digital4_05.png","digital4_06.png","digital4_07.png","digital4_08.png","digital4_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital6_11.png',
              unit_tc: 'digital6_11.png',
              unit_en: 'digital6_11.png',
              negative_image: 'digital4_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 100,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 71,
              day_startY: 245,
              day_sc_array: ["digital4_00.png","digital4_01.png","digital4_02.png","digital4_03.png","digital4_04.png","digital4_05.png","digital4_06.png","digital4_07.png","digital4_08.png","digital4_09.png"],
              day_tc_array: ["digital4_00.png","digital4_01.png","digital4_02.png","digital4_03.png","digital4_04.png","digital4_05.png","digital4_06.png","digital4_07.png","digital4_08.png","digital4_09.png"],
              day_en_array: ["digital4_00.png","digital4_01.png","digital4_02.png","digital4_03.png","digital4_04.png","digital4_05.png","digital4_06.png","digital4_07.png","digital4_08.png","digital4_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital4_12.png',
              day_unit_tc: 'digital4_12.png',
              day_unit_en: 'digital4_12.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 149,
              month_startY: 251,
              month_sc_array: ["digital7_00.png","digital7_01.png","digital7_02.png","digital7_03.png","digital7_04.png","digital7_05.png","digital7_06.png","digital7_07.png","digital7_08.png","digital7_09.png","digital7_10.png","digital7_11.png"],
              month_tc_array: ["digital7_00.png","digital7_01.png","digital7_02.png","digital7_03.png","digital7_04.png","digital7_05.png","digital7_06.png","digital7_07.png","digital7_08.png","digital7_09.png","digital7_10.png","digital7_11.png"],
              month_en_array: ["digital7_00.png","digital7_01.png","digital7_02.png","digital7_03.png","digital7_04.png","digital7_05.png","digital7_06.png","digital7_07.png","digital7_08.png","digital7_09.png","digital7_10.png","digital7_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 378,
              font_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 250,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 291,
              y: 115,
              image_array: ["digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 128,
              hour_startY: 311,
              hour_array: ["digital14_00.png","digital14_01.png","digital14_02.png","digital14_03.png","digital14_04.png","digital14_05.png","digital14_06.png","digital14_07.png","digital14_08.png","digital14_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'digital14_10.png',
              hour_unit_tc: 'digital14_10.png',
              hour_unit_en: 'digital14_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digital14_00.png","digital14_01.png","digital14_02.png","digital14_03.png","digital14_04.png","digital14_05.png","digital14_06.png","digital14_07.png","digital14_08.png","digital14_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'image15.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'image16.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'image17.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 17,
              second_posY: 210,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'image15.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 150,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'image16.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 213,
              minute_cover_path: 'image18.png',
              minute_cover_x: 231,
              minute_cover_y: 231,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  