﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 113;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 67;
        let normal_date_img_date_week_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 27;
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 78;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 47;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 378,
              font_array: ["data_0001.png","data_0002.png","data_0003.png","data_0004.png","data_0005.png","data_0006.png","data_0007.png","data_0008.png","data_0009.png","data_0010.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'data_0011.png',
              unit_tc: 'data_0011.png',
              unit_en: 'data_0011.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 428,
              image_array: ["bat_lev_0002.png","bat_lev_0003.png","bat_lev_0004.png","bat_lev_0005.png","bat_lev_0006.png","bat_lev_0007.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 327,
              font_array: ["data_0001.png","data_0002.png","data_0003.png","data_0004.png","data_0005.png","data_0006.png","data_0007.png","data_0008.png","data_0009.png","data_0010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 267,
              font_array: ["steps_0001.png","steps_0002.png","steps_0003.png","steps_0004.png","steps_0005.png","steps_0006.png","steps_0007.png","steps_0008.png","steps_0009.png","steps_0010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 268,
              font_array: ["dist_0001.png","dist_0002.png","dist_0003.png","dist_0004.png","dist_0005.png","dist_0006.png","dist_0007.png","dist_0008.png","dist_0009.png","dist_0010.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'dist_0012.png',
              unit_tc: 'dist_0012.png',
              unit_en: 'dist_0012.png',
              dot_image: 'dist_0011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 216,
              font_array: ["wind_0001.png","wind_0002.png","wind_0003.png","wind_0004.png","wind_0005.png","wind_0006.png","wind_0007.png","wind_0008.png","wind_0009.png","wind_0010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 159,
              font_array: ["temp_0001.png","temp_0002.png","temp_0003.png","temp_0004.png","temp_0005.png","temp_0006.png","temp_0007.png","temp_0008.png","temp_0009.png","temp_0010.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'temp_0011.png',
              unit_tc: 'temp_0011.png',
              unit_en: 'temp_0011.png',
              negative_image: 'temp_0012.png',
              invalid_image: 'temp_0013.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 64,
              y: 111,
              image_array: ["weather_0001.png","weather_0002.png","weather_0003.png","weather_0004.png","weather_0005.png","weather_0006.png","weather_0007.png","weather_0008.png","weather_0009.png","weather_0010.png","weather_0011.png","weather_0012.png","weather_0013.png","weather_0014.png","weather_0015.png","weather_0016.png","weather_0017.png","weather_0018.png","weather_0019.png","weather_0020.png","weather_0021.png","weather_0022.png","weather_0023.png","weather_0024.png","weather_0025.png","weather_0026.png","weather_0027.png","weather_0028.png","weather_0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 247,
              // y: -1,
              // font_array: ["hour_0001.png","hour_0002.png","hour_0003.png","hour_0004.png","hour_0005.png","hour_0006.png","hour_0007.png","hour_0008.png","hour_0009.png","hour_0010.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'hour_0001.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'hour_0002.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'hour_0003.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'hour_0004.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'hour_0005.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'hour_0006.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'hour_0007.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'hour_0008.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'hour_0009.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'hour_0010.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 247,
                center_y: -1,
                pos_x: 247,
                pos_y: -1,
                angle: 45,
                src: 'hour_0001.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 364,
              // y: 213,
              // font_array: ["min_0001.png","min_0002.png","min_0003.png","min_0004.png","min_0005.png","min_0006.png","min_0007.png","min_0008.png","min_0009.png","min_0010.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -3,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'min_0001.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'min_0002.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'min_0003.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'min_0004.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'min_0005.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'min_0006.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'min_0007.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'min_0008.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'min_0009.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'min_0010.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 364,
                center_y: 213,
                pos_x: 364,
                pos_y: 213,
                angle: 45,
                src: 'min_0001.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 366,
              y: 188,
              week_en: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_tc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_sc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 424,
              // y: 160,
              // font_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'date_0001.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'date_0002.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'date_0003.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'date_0004.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'date_0005.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'date_0006.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'date_0007.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'date_0008.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'date_0009.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'date_0010.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 424,
                center_y: 160,
                pos_x: 424,
                pos_y: 160,
                angle: 45,
                src: 'date_0001.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_0001.png',
              second_centerX: 239,
              second_centerY: 239,
              second_posX: 9,
              second_posY: 243,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 61,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 248,
              // y: 70,
              // font_array: ["aodh_0001.png","aodh_0002.png","aodh_0003.png","aodh_0004.png","aodh_0005.png","aodh_0006.png","aodh_0007.png","aodh_0008.png","aodh_0009.png","aodh_0010.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'aodh_0001.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'aodh_0002.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'aodh_0003.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'aodh_0004.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'aodh_0005.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'aodh_0006.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'aodh_0007.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'aodh_0008.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'aodh_0009.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'aodh_0010.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 248,
                center_y: 70,
                pos_x: 248,
                pos_y: 70,
                angle: 45,
                src: 'aodh_0001.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 334,
              // y: 213,
              // font_array: ["aodm_0001.png","aodm_0002.png","aodm_0003.png","aodm_0004.png","aodm_0005.png","aodm_0006.png","aodm_0007.png","aodm_0008.png","aodm_0009.png","aodm_0010.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'aodm_0001.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'aodm_0002.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'aodm_0003.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'aodm_0004.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'aodm_0005.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'aodm_0006.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'aodm_0007.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'aodm_0008.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'aodm_0009.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'aodm_0010.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 334,
                center_y: 213,
                pos_x: 334,
                pos_y: 213,
                angle: 45,
                src: 'aodm_0001.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Связь потеряна,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Связь потеряна"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 319,
              w: 185,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 255,
              w: 185,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 120,
              w: 120,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 70,
              w: 120,
              h: 130,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 380,
              y: 165,
              w: 70,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 333,
              y: 255,
              w: 80,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 247 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 364 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 424 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 248 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 334 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}