﻿
    /*
	AMetal (C) Magonegro 2022
    Thanks to CashaCX75 for his awesome tool: Watch_Face_Editor	3
	Graphics found on the net, rest of resources developed with several freeware apps.
	Thanks to the Amazfit team who developed these fantastic mini computer watches.
	All programming, development, headaches, sleepless nights and lack of health are my tributes to the cause.
	I developed this while in bed with a severe illness. Time spent playing with this toys have been a pleasant
	experience and have given me very good and funny moments that helped me to not becoming mad with my health.
	I encourage all of you developers to keep making those wonderful watchfaces that always keep me looking forward
	and wondering what this guys are capable of... Thanks to you all for your inspiration.
	Use this code as a sandbox, it is not very clean as it has been developed as an amusement,
	but it has been more than that at the end.
	
	Cheers.

	*/

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''

		
		let btnmenu
		let btncrono
		let btncounter
		let btnbackgroundP
		let btnbackgroundN
		let btnmusic
		let btnAbout
		let btnTools
		let btnRes2
		let currentmenu = 0
		let numerotest = 0
		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let Numfondo = 0
			
		let bigNumObject = new Array(8)
        let HoursObject = new Array(4)
		let flag = true
		let now = hmSensor.createSensor(hmSensor.id.TIME);
		let lastTime = 0
		let lastMark = 0
		let tmpMark = 0
		let diffTime
		let minutes
		let milis = 0
		let seconds
		let hours
		let hsTimer = null
		let green_red_btn
		let clear
		let TimeTimer = null

		let CounterObj = new Array(6)
		let CounterVal = new Array(3)
		let btnCAdd = new Array(3)
		let btnCSub = new Array(3)
		let resetCount
		let lResetPos = false
		let imgabout
		const music = hmSensor.createSensor(hmSensor.id.MUSIC)
		let lPlaying=false
		
		let MiniTime = new Array(8)
		let MiniTimeBack
		let lMiniTimeVisible = false
		
		let nLang = 0 // 0-ES 1-EN ... button selectable (I hope)
		let LowTimer
	
		let btnLang
	
	function PaintWeekDay(){
		let nDiatmp=now.week-1;
		if(nLang==0)
			normal_date_img_date_week_img.setProperty(hmUI.prop.SRC, "dia" + parseInt(nDiatmp) + ".png");
		if(nLang==1)
			normal_date_img_date_week_img.setProperty(hmUI.prop.SRC, "diaen" + parseInt(nDiatmp) + ".png");
	}

	function click_Lang(){
		click_Vibrate();
		nLang=(nLang+1) % 2
		PaintWeekDay();
		if(nLang==0) hmUI.showToast({text: 'Lang: 0-Spanish'});
		if(nLang==1) hmUI.showToast({text: 'Lang: 1-English'});
	}

	function ShowTools(lVisible){
		btnLang.setProperty(hmUI.prop.VISIBLE, lVisible);
		ShowMiniTime(lVisible);
	}
	
	function ShowRes2(lVisible){
		ShowMiniTime(lVisible);
	}
	
	function click_Tools(){
		click_Vibrate();
		ShowMenu(false);
		currentmenu=5;
		ShowTools(true);
	}

	function click_Res2(){
		click_Vibrate();
		ShowMenu(false);
		currentmenu=6;
		ShowRes2(true);
	}
	
	function PaintTime(){
		if(!lMiniTimeVisible) return;
		
		let h = now.hour;
		let m = now.minute;
		let s = now.second;
		
		MiniTime[6].setProperty(hmUI.prop.SRC, "LCDSm" + parseInt(s / 10) + ".png");
        MiniTime[7].setProperty(hmUI.prop.SRC, "LCDSm" + parseInt(s % 10) + ".png");
        MiniTime[3].setProperty(hmUI.prop.SRC, "LCDSm" + parseInt(m / 10) + ".png");
        MiniTime[4].setProperty(hmUI.prop.SRC, "LCDSm" + parseInt(m % 10) + ".png");
        MiniTime[0].setProperty(hmUI.prop.SRC, "LCDSm" + parseInt(h / 10) + ".png");
        MiniTime[1].setProperty(hmUI.prop.SRC, "LCDSm" + parseInt(h % 10) + ".png");
        MiniTime[2].setProperty(hmUI.prop.SRC, 'LCDSmSep.png');
        MiniTime[5].setProperty(hmUI.prop.SRC, 'LCDSmSep.png');
	}

	function ShowMiniTime(lVisible){
		MiniTimeBack.setProperty(hmUI.prop.VISIBLE, lVisible);
		for (let i = 0; i < 8; i += 1) {
			MiniTime[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		}
		lMiniTimeVisible=lVisible;
	}
	
	function CreateMiniTime(){
		MiniTimeBack = hmUI.createWidget(hmUI.widget.IMG,{
					x: 0,
					y: 0,
					src: 'LCDSmBack.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
		MiniTimeBack.setProperty(hmUI.prop.VISIBLE, false);
		
		for (let i = 0; i < 8; i += 1) {
			MiniTime[i]=hmUI.createWidget(hmUI.widget.IMG,{
					x: 0,
					y: 0,
					src: 'LCDSm0.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
			MiniTime[i].setProperty(hmUI.prop.VISIBLE, false);
		}
		lMiniTimeVisible=false;
	}
	
	function SetMiniTime(x,y){
		// font size: digits: 22x36, sep: 10*36
		let xx=x;
		MiniTimeBack.setProperty(hmUI.prop.MORE,{
					x: xx,
					y: y,
					src: 'LCDSmBack.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
					});

		for (let i = 0; i < 8; i += 1) {
			if(i==2 || i==5) {
				MiniTime[i].setProperty(hmUI.prop.MORE,{
					x: xx,
					y: y,
					src: 'LCDSmBack.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
			}
			else
				MiniTime[i].setProperty(hmUI.prop.MORE,{
					x: xx,
					y: y,
					src: 'LCDSm0.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
					});
					
			if(i==2 || i==5)
					xx=xx+10
				else
					xx=xx+22;
		}
	}

	function ShowMusic() {
 		if(lPlaying)
			btnmusic.setProperty(hmUI.prop.MORE, {
			  x: 320,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmusicon.png',
			  press_src: 'btnmusicon.png',
			  click_func: () => {
				click_Music() 
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnmusic.setProperty(hmUI.prop.MORE, {
			  x: 320,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmusic.png',
			  press_src: 'btnmusicon.png',
			  click_func: () => {
				click_Music() 
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
			UpdateMenu();
		}

	function click_Music() {
		click_Vibrate();
		if(music.isPlaying) {
			music.audPause()
			lPlaying=false;
		}
		else {
			music.audPlay();
			lPlaying=true;
		}
		ShowMusic();
	}	

	function ShowAbout(lVisible){
		imgabout.setProperty(hmUI.prop.VISIBLE, lVisible);
		//if(lVisible) SetMiniTime(164,18);
		ShowMiniTime(lVisible);
	}

	function click_About() {
		click_Vibrate();
		ShowMenu(false);
		currentmenu=4;
		ShowAbout(true);
	}	
		
	function click_BackgroundP() {
		click_Vibrate();
		if(Numfondo==0) 
			Numfondo=61;
		else
			Numfondo=Numfondo-1;

		normal_background_bg_img.setProperty(hmUI.prop.SRC, "Back" + parseInt(Numfondo) + ".png");
		StoreTempData();
		hmUI.showToast({text: 'Background: ' + parseInt(Numfondo)});
	}	

	function click_BackgroundN() {
		click_Vibrate();
		Numfondo=(Numfondo+1) % 62;
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "Back" + parseInt(Numfondo) + ".png");
		StoreTempData();
		hmUI.showToast({text: 'Background: ' + parseInt(Numfondo)});
	}	
		
	function StoreTempData() { // Data stored this way doesn't survive a watch reboot, but keeps data between wf changes
		hmFS.SysProSetInt('AMetal_Back_int', Numfondo);
		hmFS.SysProSetInt('AMetal_C1_int', CounterVal[0]);
		hmFS.SysProSetInt('AMetal_C2_int', CounterVal[1]);
		hmFS.SysProSetInt('AMetal_C3_int', CounterVal[2]);
		hmFS.SysProSetInt('AMetal_Lang_int',nLang);
	}
	
	function LoadTempData() {
		Numfondo = hmFS.SysProGetInt('AMetal_Back_int');
		if(Numfondo==NaN) Numfondo=0;
		if(Numfondo<0 || Numfondo>61) Numfondo=0;
		CounterVal[0]=hmFS.SysProGetInt('AMetal_C1_int');
		if(CounterVal[0]==NaN) CounterVal[0]=0;
		if(CounterVal[0]<0 || CounterVal[0]>99) CounterVal[0]=0;
		CounterVal[1]=hmFS.SysProGetInt('AMetal_C2_int');
		if(CounterVal[1]==NaN) CounterVal[1]=0;
		if(CounterVal[1]<0 || CounterVal[1]>99) CounterVal[1]=0;
		CounterVal[2]=hmFS.SysProGetInt('AMetal_C3_int');
		if(CounterVal[2]==NaN) CounterVal[2]=0;
		if(CounterVal[2]<0 || CounterVal[2]>99) CounterVal[2]=0;
		nLang=hmFS.SysProGetInt('AMetal_Lang_int');
		if(nLang==NaN) nLang0;
		if(nLang<0 || nLang>2) nLang=0;
	}

    function CalcTime(mark) {
		diffTime = (mark + lastMark) / 10;
      	milis = (diffTime % 100);
        diffTime = (diffTime - milis ) / 100; // segundos
        seconds= diffTime % 60;
        minutes= ((diffTime - seconds) / 60) % 60;
        hours = (diffTime - (minutes*60) - seconds) / 3600;
    }

	// Painting the data on screen on demand
    function PaintData(t) {
        bigNumObject[6].setProperty(hmUI.prop.SRC, "SilverSm" + parseInt(milis / 10) + ".png");
        bigNumObject[7].setProperty(hmUI.prop.SRC, "SilverSm" + parseInt(milis % 10) + ".png");
        bigNumObject[3].setProperty(hmUI.prop.SRC, "SilverNumbers" + parseInt(seconds / 10) + ".png")
        bigNumObject[4].setProperty(hmUI.prop.SRC, "SilverNumbers" + parseInt(seconds % 10) + ".png")
        bigNumObject[0].setProperty(hmUI.prop.SRC, "SilverNumbers" + parseInt(minutes / 10) + ".png")
        bigNumObject[1].setProperty(hmUI.prop.SRC, "SilverNumbers" + parseInt(minutes % 10) + ".png")
        bigNumObject[2].setProperty(hmUI.prop.SRC, 'SilverNumbersS.png');
        HoursObject[2].setProperty(hmUI.prop.SRC, "SmallN" + parseInt(hours % 10) + ".png")
        HoursObject[1].setProperty(hmUI.prop.SRC, "SmallN" + parseInt((hours/10) % 10) + ".png")
        HoursObject[0].setProperty(hmUI.prop.SRC, "SmallN" + parseInt((hours/100) % 10) + ".png")
		HoursObject[3].setProperty(hmUI.prop.SRC, 'Hours.png');
 	}

	// Convenient macro
    function DispData(t) {
		CalcTime(now.utc - lastTime)
		PaintData()
    }

	// Start up timers
    function timerSample() {
      hsTimer = timer.createTimer(10, 10, DispData, {})
    }
	
	function ShowAll(lVisible) {
		normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_lock_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_dnd_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, lVisible);
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, lVisible);
	}
	

	function UpdateMenu(){
		if(!flag || (CounterVal[0]>0 || CounterVal[1]>0 || CounterVal[2]>0) || lPlaying)
			btnmenu.setProperty(hmUI.prop.MORE,{
			  x: 190,
			  y: 380,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmenured.png',
			  press_src: 'btnmenupush.png',
			  click_func: () => {
				click_Menu();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btnmenu.setProperty(hmUI.prop.MORE,{
			  x: 190,
			  y: 380,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmenu.png',
			  press_src: 'btnmenupush.png',
			  click_func: () => {
				click_Menu();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
	}
	
	function ShowMenu(lVisible) {
		if(!flag)
			btncrono.setProperty(hmUI.prop.MORE, {
			  x: 60,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncronoon.png',
			  press_src: 'btncronoON.png',
			  click_func: () => {
				click_Crono();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			})
		else
			btncrono.setProperty(hmUI.prop.MORE, {
			  x: 60,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncrono.png',
			  press_src: 'btncronoON.png',
			  click_func: () => {
				click_Crono();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

		btncrono.setProperty(hmUI.prop.VISIBLE, lVisible);

		if (CounterVal[0]==0 && CounterVal[1]==0 && CounterVal[2]==0 )
			btncounter.setProperty(hmUI.prop.MORE, {
			  x: 190,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncounter.png',
			  press_src: 'btncounterON.png',
			  click_func: () => {
				click_Counter();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		else
			btncounter.setProperty(hmUI.prop.MORE, {
			  x: 190,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncounteron.png',
			  press_src: 'btncounterON.png',
			  click_func: () => {
				click_Counter();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		
		btncounter.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnbackgroundP.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnbackgroundN.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnmusic.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnAbout.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnTools.setProperty(hmUI.prop.VISIBLE, lVisible);
		btnRes2.setProperty(hmUI.prop.VISIBLE, lVisible);

		//if(lVisible) SetMiniTime(164,18)
		
		ShowMiniTime(lVisible);
		ShowMusic();
	}

	function ShowCrono(lVisible) {
		green_red_btn.setProperty(hmUI.prop.VISIBLE, lVisible);  
		bigNumObject[0].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[1].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[2].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[3].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[4].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[6].setProperty(hmUI.prop.VISIBLE, lVisible);
		bigNumObject[7].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[0].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[1].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[2].setProperty(hmUI.prop.VISIBLE, lVisible);
		HoursObject[3].setProperty(hmUI.prop.VISIBLE, lVisible);

		if (lVisible) 
			clear.setProperty(hmUI.prop.VISIBLE, flag)
		else
			clear.setProperty(hmUI.prop.VISIBLE, false);


		if(flag && lVisible) { // está apagado, repintar los numeros
			CalcTime(0)
			PaintData()
			}	
		//if(lVisible) SetMiniTime(164,18);
		ShowMiniTime(lVisible);
		}

	function CreateCounters(){
		let xoffNum = 180;
		let yoffNum = 64;
		let numWidth = 75;
		let numHeight = 105;
		let xoffBtnSub = 70;
		let yoffBtnSub = 25;
		let xoffBtnAdd = 0; 
		
		 btnCSub[0] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffBtnSub,
		  y: yoffNum+yoffBtnSub,
		  w: 80,
		  h: 80,
		  src: 'btnsuby.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCSub[0].setProperty(hmUI.prop.VISIBLE, false);
		btnCSub[0].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[0]>0) CounterVal[0]=CounterVal[0]-1;
			PaintCounters();
		}));
		 btnCAdd[0] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffNum+numWidth*2+xoffBtnAdd,
		  y: yoffNum+yoffBtnSub,
		  w: 80,
		  h: 80,
		  src: 'btnaddy.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCAdd[0].setProperty(hmUI.prop.VISIBLE, false);
		btnCAdd[0].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[0]<99) CounterVal[0]=CounterVal[0]+1;
			PaintCounters();
		}));

		 CounterObj[0] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum,
			  y: yoffNum,
			  src: 'BigN0.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[0].setProperty(hmUI.prop.VISIBLE, false);
		 CounterObj[1] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum+numWidth,
			  y: yoffNum,
			  src: 'BigN0.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[1].setProperty(hmUI.prop.VISIBLE, false);
		
		 btnCSub[1] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffBtnSub,
		  y: yoffNum+yoffBtnSub+numHeight,
		  w: 80,
		  h: 80,
		  src: 'btnsubg.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCSub[1].setProperty(hmUI.prop.VISIBLE, false);
		btnCSub[1].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[1]>0) CounterVal[1]=CounterVal[1]-1;
			PaintCounters();
		}));
		 btnCAdd[1] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffNum+numWidth*2+xoffBtnAdd,
		  y: yoffNum+yoffBtnSub+numHeight,
		  w: 80,
		  h: 80,
		  src: 'btnaddg.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCAdd[1].setProperty(hmUI.prop.VISIBLE, false);
		btnCAdd[1].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[1]<99) CounterVal[1]=CounterVal[1]+1;
			PaintCounters();
		}));


		 CounterObj[2] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum,
			  y: yoffNum+numHeight,
			  src: 'BigN0.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[2].setProperty(hmUI.prop.VISIBLE, false);
		 CounterObj[3] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum+numWidth,
			  y: yoffNum+numHeight,
			  src: 'BigN0.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[3].setProperty(hmUI.prop.VISIBLE, false);


		 btnCSub[2] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffBtnSub,
		  y: yoffNum+yoffBtnSub+numHeight*2,
		  w: 80,
		  h: 80,
		  src: 'btnsubb.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCSub[2].setProperty(hmUI.prop.VISIBLE, false);
		btnCSub[2].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[2]>0) CounterVal[2]=CounterVal[2]-1;
			PaintCounters();
		}));
		 btnCAdd[2] = hmUI.createWidget(hmUI.widget.IMG, {
		  x: xoffNum+numWidth*2+xoffBtnAdd,
		  y: yoffNum+yoffBtnSub+numHeight*2,
		  w: 80,
		  h: 80,
		  src: 'btnaddb.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		btnCAdd[2].setProperty(hmUI.prop.VISIBLE, false);
		btnCAdd[2].addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			lResetPos=false;
			SetResetPos();
			if (CounterVal[2]<99) CounterVal[2]=CounterVal[2]+1;
			PaintCounters();
		}));



		 CounterObj[4] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum,
			  y: yoffNum+numHeight*2,
			  src: 'BigN0.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[4].setProperty(hmUI.prop.VISIBLE, false);
		 CounterObj[5] = hmUI.createWidget(hmUI.widget.IMG, {
			  x: xoffNum+numWidth,
			  y: yoffNum+numHeight*2,
			  src: 'BigN0.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
		 CounterObj[5].setProperty(hmUI.prop.VISIBLE, false);

		resetCount = hmUI.createWidget(hmUI.widget.IMG, {
		  x: 100,
		  y: 400,
		  w: 40,
		  h: 40,
		  src: 'Clearmini.png',
		  show_level: hmUI.show_level.ONLY_NORMAL
		});
		resetCount.setProperty(hmUI.prop.VISIBLE, false);
		resetCount.addEventListener(hmUI.event.CLICK_UP, (function (info) {
			click_Vibrate();
			if(!lResetPos) {
				lResetPos=true;
				SetResetPos();
				return;
			}
			for (let i = 0; i < 3; i += 1) CounterVal[i]=0;
			PaintCounters();
			lResetPos=false;
			SetResetPos();
		}));

	}

		
    function PaintCounters() {
        CounterObj[0].setProperty(hmUI.prop.SRC, "BigN" + parseInt(CounterVal[0] / 10) + ".png");
        CounterObj[1].setProperty(hmUI.prop.SRC, "BigN" + parseInt(CounterVal[0] % 10) + ".png");
        CounterObj[2].setProperty(hmUI.prop.SRC, "BigN" + parseInt(CounterVal[1] / 10) + ".png");
        CounterObj[3].setProperty(hmUI.prop.SRC, "BigN" + parseInt(CounterVal[1] % 10) + ".png");
        CounterObj[4].setProperty(hmUI.prop.SRC, "BigN" + parseInt(CounterVal[2] / 10) + ".png");
        CounterObj[5].setProperty(hmUI.prop.SRC, "BigN" + parseInt(CounterVal[2] % 10) + ".png");
		UpdateMenu();
		StoreTempData();
	}
	
	function SetResetPos(){
		if(lResetPos)
			resetCount.setProperty(hmUI.prop.MORE, {
			  x: 480-100-40,
			  y: 400,
			  w: 40,
			  h: 40,
			  src: 'Clearmini.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			})
		else
			resetCount.setProperty(hmUI.prop.MORE, {
			  x: 100,
			  y: 400,
			  w: 40,
			  h: 40,
			  src: 'Clearmini.png',
			  show_level: hmUI.show_level.ONLY_NORMAL
			});
	}
	
	function ShowCounter(lVisible) {
		  for (let i = 0; i < 6; i += 1) CounterObj[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		  for (let i = 0; i < 3; i += 1) btnCAdd[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		  for (let i = 0; i < 3; i += 1) btnCSub[i].setProperty(hmUI.prop.VISIBLE, lVisible);
		  lResetPos=false;
		  resetCount.setProperty(hmUI.prop.VISIBLE, lVisible);
		  if(lVisible) SetResetPos();
		  if (lVisible) PaintCounters();
		  //if(lVisible) SetMiniTime(164,18);
		  ShowMiniTime(lVisible);
	}

	function click_Crono() {
		click_Vibrate();
		ShowMenu(false);
		currentmenu=2;
		ShowCrono(true);

	}
	
	function click_Counter() {
		click_Vibrate();
		ShowMenu(false);
		ShowCounter(true);
		currentmenu=3;
	}

	function click_Menu(){ // menu button always visible, used to return to main screen too
		click_Vibrate();
		if(currentmenu==0) {
			ShowAll(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==1) {
			ShowMenu(false);
			ShowAll(true);
			currentmenu=0;
			return;
		}
		if(currentmenu==2) {
			ShowCrono(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==3) {
			ShowCounter(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==4) {
			ShowAbout(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==5) {
			ShowTools(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
		if(currentmenu==6) {
			ShowRes2(false);
			ShowMenu(true);
			currentmenu=1;
			return;
		}
	}

	// Button feedback
	function click_Vibrate() {
		vibrate.stop();
		vibrate.scene = 24;
		vibrate.start();
	}

	function CreateWatch(){
			normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_background_bg_img.setProperty(hmUI.prop.SRC, "Back" + parseInt(Numfondo) + ".png");
            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 387,
              font_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 112,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 371,
              y: 110,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 108,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 346,
              y: 113,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG, {
				x: 297,
				y: 383,
				src: 'dia0.png',
				show_level: hmUI.show_level.ONLY_NORMAL
			});

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 375,
              month_startY: 338,
              month_sc_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              month_tc_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              month_en_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 303,
              day_startY: 338,
              day_sc_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              day_tc_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              day_en_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'SSilverSmMenos.png',
              day_unit_tc: 'SSilverSmMenos.png',
              day_unit_en: 'SSilverSmMenos.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 99,
              font_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'punto.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 340,
              font_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 341,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 34,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 49,
              font_array: ["SSilverSm0.png","SSilverSm1.png","SSilverSm2.png","SSilverSm3.png","SSilverSm4.png","SSilverSm5.png","SSilverSm6.png","SSilverSm7.png","SSilverSm8.png","SSilverSm9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Grados.png',
              unit_tc: 'Grados.png',
              unit_en: 'Grados.png',
              negative_image: 'SSilverSmMenos.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 10,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 168,
              hour_array: ["SilverNumbers0.png","SilverNumbers1.png","SilverNumbers2.png","SilverNumbers3.png","SilverNumbers4.png","SilverNumbers5.png","SilverNumbers6.png","SilverNumbers7.png","SilverNumbers8.png","SilverNumbers9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 168,
              minute_array: ["SilverNumbers0.png","SilverNumbers1.png","SilverNumbers2.png","SilverNumbers3.png","SilverNumbers4.png","SilverNumbers5.png","SilverNumbers6.png","SilverNumbers7.png","SilverNumbers8.png","SilverNumbers9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 196,
              second_startY: 316,
              second_array: ["SilverSm0.png","SilverSm1.png","SilverSm2.png","SilverSm3.png","SilverSm4.png","SilverSm5.png","SilverSm6.png","SilverSm7.png","SilverSm8.png","SilverSm9.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 160,
              src: 'SilverNumbersS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 112,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 371,
              y: 110,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 108,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 346,
              y: 113,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 168,
              hour_array: ["SilverNumbers0.png","SilverNumbers1.png","SilverNumbers2.png","SilverNumbers3.png","SilverNumbers4.png","SilverNumbers5.png","SilverNumbers6.png","SilverNumbers7.png","SilverNumbers8.png","SilverNumbers9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 170,
              minute_array: ["SilverNumbers0.png","SilverNumbers1.png","SilverNumbers2.png","SilverNumbers3.png","SilverNumbers4.png","SilverNumbers5.png","SilverNumbers6.png","SilverNumbers7.png","SilverNumbers8.png","SilverNumbers9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 160,
              src: 'SilverNumbersS.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });
	}		

	
        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
  			for (let i = 0; i < 3; i += 1) CounterVal[i]=0;
			music.audInit();
			LoadTempData();
			CreateWatch();

	imgabout = hmUI.createWidget(hmUI.widget.IMG, {
          x: (480-350)/2,
          y: (480-238)/2,
          src: 'about.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     imgabout.setProperty(hmUI.prop.VISIBLE, false);


	HoursObject[0] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 150,
          y: 60,
          src: 'SmallN0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[0].setProperty(hmUI.prop.VISIBLE, false);
	HoursObject[1] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 200,
          y: 60,
          src: 'SmallN0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[1].setProperty(hmUI.prop.VISIBLE, false);
	HoursObject[2] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 250,
          y: 60,
          src: 'SmallN0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[2].setProperty(hmUI.prop.VISIBLE, false);
	HoursObject[3] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 295,
          y: 60,
          src: 'Hours.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     HoursObject[3].setProperty(hmUI.prop.VISIBLE, false);

     bigNumObject[2] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 224,
          y: 160,
          src: 'SilverNumbersS.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[2].setProperty(hmUI.prop.VISIBLE, false);

     bigNumObject[0] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 46,
          y: 168,
          src: 'SilverNumbers0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[0].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[1] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 46+80+10,
          y: 168,
          src: 'SilverNumbers0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[1].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[3] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 260,
          y: 168,
          src: 'SilverNumbers0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[3].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[4] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 260+80+10,
          y: 168,
          src: 'SilverNumbers0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[4].setProperty(hmUI.prop.VISIBLE, false);

     bigNumObject[6] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 196,
          y: 316,
          src: 'SilverSm0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[6].setProperty(hmUI.prop.VISIBLE, false);
     bigNumObject[7] = hmUI.createWidget(hmUI.widget.IMG, {
          x: 196+43+5,
          y: 316,
          src: 'SilverSm0.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
     bigNumObject[7].setProperty(hmUI.prop.VISIBLE, false);

	
			btnmenu = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190,
			  y: 380,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmenu.png',
			  press_src: 'btnmenupush.png',
			  click_func: () => {
				click_Menu();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			// layout: 60-100-30-100-30-100-60
			btncrono = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncrono.png',
			  press_src: 'btncronoON.png',
			  click_func: () => {
				click_Crono();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btncrono.setProperty(hmUI.prop.VISIBLE, false);

			btncounter = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btncounter.png',
			  press_src: 'btncounterON.png',
			  click_func: () => {
				click_Counter();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btncounter.setProperty(hmUI.prop.VISIBLE, false);

			btnmusic = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnmusic.png',
			  press_src: 'btnmusicon.png',
			  click_func: () => {
				click_Music();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			btnmusic.setProperty(hmUI.prop.VISIBLE, false);

			btnbackgroundP = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60,
			  y: 190,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'backgroundP.png',
			  press_src: 'backgroundP.png',
			  click_func: () => {
				click_BackgroundP();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnbackgroundP.setProperty(hmUI.prop.VISIBLE, false);
			btnbackgroundN = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 190,
			  y: 190,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'backgroundN.png',
			  press_src: 'backgroundN.png',
			  click_func: () => {
				click_BackgroundN();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnbackgroundN.setProperty(hmUI.prop.VISIBLE, false);

			btnAbout = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
			  y: 190,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnReserved.png',
			  press_src: 'btnReserved.png',
			  click_func: () => {
				click_About();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnAbout.setProperty(hmUI.prop.VISIBLE, false);

			btnTools = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60,
			  y: 300,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnTools.png',
			  press_src: 'btnTools.png',
			  click_func: () => {
				click_Tools();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnTools.setProperty(hmUI.prop.VISIBLE, false);

			btnLang = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 60,
			  y: 80,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnLang.png',
			  press_src: 'btnLang.png',
			  click_func: () => {
				click_Lang();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnLang.setProperty(hmUI.prop.VISIBLE, false);

			btnRes2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
			  y: 300,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnBlue.png',
			  press_src: 'btnBlue.png',
			  click_func: () => {
				click_Res2();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			btnRes2.setProperty(hmUI.prop.VISIBLE, false);

			clear = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 328,
			  y: 334,
			  src: 'clear.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			clear.setProperty(hmUI.prop.VISIBLE, false);
			clear.addEventListener(hmUI.event.CLICK_UP, (function (info) {
				click_Vibrate();
				if (!flag) {
					timer.stopTimer(hsTimer);
					//animate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP)
					//animate.setProperty(hmUI.prop.VISIBLE, false);
					}
				flag=true
				green_red_btn.setProperty(hmUI.prop.SRC, "green.png"); 
				lastMark=0
				lastTime=0
				CalcTime(lastTime)
				PaintData()
				UpdateMenu();
			}));


			green_red_btn = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 72,
			  y: 334,
			  src: 'green.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			green_red_btn.setProperty(hmUI.prop.VISIBLE, false);
			green_red_btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
				click_Vibrate();
			  flag = !flag
			  if (flag) {
				timer.stopTimer(hsTimer);
				//animate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP)
				//animate.setProperty(hmUI.prop.VISIBLE, false);
				green_red_btn.setProperty(hmUI.prop.SRC, "green.png"); 
				tmpMark = now.utc - lastTime
				CalcTime(tmpMark)
				PaintData()
				lastMark = lastMark + tmpMark;
				clear.setProperty(hmUI.prop.VISIBLE, true);
			  } else {
				green_red_btn.setProperty(hmUI.prop.SRC, "red.png");
				lastTime=now.utc;
				timerSample()
				//animate.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START)
				//animate.setProperty(hmUI.prop.VISIBLE, true);
				clear.setProperty(hmUI.prop.VISIBLE, false);
			  }
				UpdateMenu();
			}));

			CreateCounters();
			PaintCounters();
			CreateMiniTime();
			SetMiniTime(164,18);
			PaintWeekDay();
			TimeTimer = timer.createTimer(100, 100, PaintTime, {});
			LowTimer = timer.createTimer(1000, 1000, PaintWeekDay, {}); // Low priority timer for background tasks
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
			vibrate.stop();
			timer.stopTimer(TimeTimer);
			timer.stopTimer(LowTimer);
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  