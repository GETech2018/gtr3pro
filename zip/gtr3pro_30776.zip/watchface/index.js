﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 427,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'dig_sm_11.png',
              unit_tc: 'dig_sm_11.png',
              unit_en: 'dig_sm_11.png',
              negative_image: 'dig_sm_10.png',
              invalid_image: 'dig_sm_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 423,
              image_array: ["weater_1.png","weater_2.png","weater_3.png","weater_4.png","weater_5.png","weater_6.png","weater_7.png","weater_8.png","weater_9.png","weater_10.png","weater_11.png","weater_12.png","weater_13.png","weater_14.png","weater_15.png","weater_16.png","weater_17.png","weater_18.png","weater_19.png","weater_20.png","weater_21.png","weater_22.png","weater_23.png","weater_24.png","weater_25.png","weater_26.png","weater_27.png","weater_28.png","weater_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 317,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'dig_sm_16.png',
              unit_tc: 'dig_sm_16.png',
              unit_en: 'dig_sm_16.png',
              dot_image: 'dig_sm_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 133,
              month_sc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              month_tc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              month_en_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 109,
              y: 132,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 133,
              day_sc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              day_tc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              day_en_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              day_zero: 1,
              day_space: -4,
              day_unit_sc: 'dig_sm_14.png',
              day_unit_tc: 'dig_sm_14.png',
              day_unit_en: 'dig_sm_14.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 21,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 88,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 329,
              // center_y: 371,
              // start_angle: -145,
              // end_angle: 148,
              // radius: 49,
              // line_width: 4,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 365,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 350,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 187,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 260,
              minute_startY: 185,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 428,
              second_startY: 222,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 329,
              // center_y: 109,
              // start_angle: 326,
              // end_angle: 31,
              // radius: 49,
              // line_width: 4,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 92,
              font_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 198,
              src: 'stat_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 252,
              src: 'stat_2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 427,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'dig_sm_11.png',
              unit_tc: 'dig_sm_11.png',
              unit_en: 'dig_sm_11.png',
              negative_image: 'dig_sm_10.png',
              invalid_image: 'dig_sm_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 423,
              image_array: ["weater_1.png","weater_2.png","weater_3.png","weater_4.png","weater_5.png","weater_6.png","weater_7.png","weater_8.png","weater_9.png","weater_10.png","weater_11.png","weater_12.png","weater_13.png","weater_14.png","weater_15.png","weater_16.png","weater_17.png","weater_18.png","weater_19.png","weater_20.png","weater_21.png","weater_22.png","weater_23.png","weater_24.png","weater_25.png","weater_26.png","weater_27.png","weater_28.png","weater_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 317,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'dig_sm_16.png',
              unit_tc: 'dig_sm_16.png',
              unit_en: 'dig_sm_16.png',
              dot_image: 'dig_sm_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 133,
              month_sc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              month_tc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              month_en_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 109,
              y: 132,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 133,
              day_sc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              day_tc_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              day_en_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              day_zero: 1,
              day_space: -4,
              day_unit_sc: 'dig_sm_14.png',
              day_unit_tc: 'dig_sm_14.png',
              day_unit_en: 'dig_sm_14.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 21,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 88,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 329,
              // center_y: 371,
              // start_angle: -145,
              // end_angle: 148,
              // radius: 49,
              // line_width: 4,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 365,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 350,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 187,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 260,
              minute_startY: 185,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 428,
              second_startY: 222,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 329,
              // center_y: 109,
              // start_angle: 326,
              // end_angle: 31,
              // radius: 49,
              // line_width: 4,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 92,
              font_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 198,
              src: 'stat_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 252,
              src: 'stat_2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -235;
                  let end_angle_normal_step = 58;
                  let center_x_normal_step = 329;
                  let center_y_normal_step = 371;
                  let radius_normal_step = 49;
                  let line_width_cs_normal_step = 4;
                  let color_cs_normal_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 236;
                  let end_angle_normal_battery = -59;
                  let center_x_normal_battery = 329;
                  let center_y_normal_battery = 109;
                  let radius_normal_battery = 49;
                  let line_width_cs_normal_battery = 4;
                  let color_cs_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -235;
                  let end_angle_idle_step = 58;
                  let center_x_idle_step = 329;
                  let center_y_idle_step = 371;
                  let radius_idle_step = 49;
                  let line_width_cs_idle_step = 4;
                  let color_cs_idle_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = 236;
                  let end_angle_idle_battery = -59;
                  let center_x_idle_battery = 329;
                  let center_y_idle_battery = 109;
                  let radius_idle_battery = 49;
                  let line_width_cs_idle_battery = 4;
                  let color_cs_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
