﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_stand_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let idle_stand_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: '1.png', path: 'main_yellow.png' },
                { id: 2, preview: '2.png', path: 'main_red.png' },
                { id: 3, preview: '3.png', path: 'main_purp.png' },
                { id: 4, preview: '4.png', path: 'main_apple.png' },
                { id: 5, preview: '5.png', path: 'main_yellow_orange.png' },
                { id: 6, preview: '6.png', path: 'main_yellow_green.png' },
                { id: 7, preview: '7.png', path: 'main_yellow_cam.png' },
                { id: 8, preview: '8.png', path: 'main_yellow_hac.png' },
                { id: 9, preview: '9.png', path: 'main_yellow_cam.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 403,
              font_array: ["Numbers_little4_00.png","Numbers_little4_01.png","Numbers_little4_02.png","Numbers_little4_03.png","Numbers_little4_04.png","Numbers_little4_05.png","Numbers_little4_06.png","Numbers_little4_07.png","Numbers_little4_08.png","Numbers_little4_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 405,
              image_array: ["Batterie_1.png","Batterie_2.png","Batterie_3.png","Batterie_4.png","Batterie_5.png","Batterie_6.png","Batterie_7.png","Batterie_8.png","Batterie_9.png","Batterie_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 133,
              font_array: ["Numbers_little5_00.png","Numbers_little5_01.png","Numbers_little5_02.png","Numbers_little5_03.png","Numbers_little5_04.png","Numbers_little5_05.png","Numbers_little5_06.png","Numbers_little5_07.png","Numbers_little5_08.png","Numbers_little5_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 77,
              font_array: ["Numbers_little5_00.png","Numbers_little5_01.png","Numbers_little5_02.png","Numbers_little5_03.png","Numbers_little5_04.png","Numbers_little5_05.png","Numbers_little5_06.png","Numbers_little5_07.png","Numbers_little5_08.png","Numbers_little5_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 133,
              font_array: ["Numbers_little5_00.png","Numbers_little5_01.png","Numbers_little5_02.png","Numbers_little5_03.png","Numbers_little5_04.png","Numbers_little5_05.png","Numbers_little5_06.png","Numbers_little5_07.png","Numbers_little5_08.png","Numbers_little5_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Numbers_little5_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 77,
              font_array: ["Numbers_little5_00.png","Numbers_little5_01.png","Numbers_little5_02.png","Numbers_little5_03.png","Numbers_little5_04.png","Numbers_little5_05.png","Numbers_little5_06.png","Numbers_little5_07.png","Numbers_little5_08.png","Numbers_little5_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 106,
              day_startY: 323,
              day_sc_array: ["Numbers_little1_00.png","Numbers_little1_01.png","Numbers_little1_02.png","Numbers_little1_03.png","Numbers_little1_04.png","Numbers_little1_05.png","Numbers_little1_06.png","Numbers_little1_07.png","Numbers_little1_08.png","Numbers_little1_09.png"],
              day_tc_array: ["Numbers_little1_00.png","Numbers_little1_01.png","Numbers_little1_02.png","Numbers_little1_03.png","Numbers_little1_04.png","Numbers_little1_05.png","Numbers_little1_06.png","Numbers_little1_07.png","Numbers_little1_08.png","Numbers_little1_09.png"],
              day_en_array: ["Numbers_little1_00.png","Numbers_little1_01.png","Numbers_little1_02.png","Numbers_little1_03.png","Numbers_little1_04.png","Numbers_little1_05.png","Numbers_little1_06.png","Numbers_little1_07.png","Numbers_little1_08.png","Numbers_little1_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 323,
              week_en: ["weekday0_01.png","weekday0_02.png","weekday0_03.png","weekday0_04.png","weekday0_05.png","weekday0_6.png","weekday0_07.png"],
              week_tc: ["weekday0_01.png","weekday0_02.png","weekday0_03.png","weekday0_04.png","weekday0_05.png","weekday0_6.png","weekday0_07.png"],
              week_sc: ["weekday0_01.png","weekday0_02.png","weekday0_03.png","weekday0_04.png","weekday0_05.png","weekday0_6.png","weekday0_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 356,
              month_sc_array: ["Monat0_01.png","Monat0_02.png","Monat0_03.png","Monat0_04.png","Monat0_05.png","Monat0_06.png","Monat0_07.png","Monat0_08.png","Monat0_09.png","Monat0_10.png","Monat0_11.png","Monat0_12.png"],
              month_tc_array: ["Monat0_01.png","Monat0_02.png","Monat0_03.png","Monat0_04.png","Monat0_05.png","Monat0_06.png","Monat0_07.png","Monat0_08.png","Monat0_09.png","Monat0_10.png","Monat0_11.png","Monat0_12.png"],
              month_en_array: ["Monat0_01.png","Monat0_02.png","Monat0_03.png","Monat0_04.png","Monat0_05.png","Monat0_06.png","Monat0_07.png","Monat0_08.png","Monat0_09.png","Monat0_10.png","Monat0_11.png","Monat0_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 176,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 221,
              minute_startY: 176,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 369,
              second_startY: 255,
              second_array: ["Numbers_little3_0.png","Numbers_little3_1.png","Numbers_little3_2.png","Numbers_little3_3.png","Numbers_little3_4.png","Numbers_little3_5.png","Numbers_little3_6.png","Numbers_little3_7.png","Numbers_little3_8.png","Numbers_little3_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 370,
              am_y: 200,
              am_sc_path: 'TZ_0.png',
              am_en_path: 'TZ_0.png',
              pm_x: 370,
              pm_y: 225,
              pm_sc_path: 'TZ_1.png',
              pm_en_path: 'TZ_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 15,
              second_posY: 241,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 26,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'MAIN_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 27,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 172,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 172,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 195,
              w: 57,
              h: 83,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 46,
              w: 106,
              h: 75,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 302,
              w: 116,
              h: 77,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 196,
              w: 159,
              h: 79,
              src: 'click_e.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 196,
              w: 151,
              h: 80,
              src: 'click_e.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}