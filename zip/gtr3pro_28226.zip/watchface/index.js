﻿    try {
      (() => {
        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
        'use strict';

        let normal_background_bg_img = ''
		let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
		
        let idle_back1
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
		
		let now = hmSensor.createSensor(hmSensor.id.TIME);
		let WFTimeObj = new Array(6) //HHMMSS
		let WFTimePrev = new Array(6)
		let WFTimeNow = new Array(6)
		let WFTimeAnim = new Array(6)
		let xx,yy,nspc;
		let FontSizesX = new Array(125, 106,  88,  69, 50, 38, 25, 12,  6) // 9 incremental size fonts
		let FontSizesY = new Array(200, 170, 140, 110, 80, 60, 40, 20, 10)
		let MainTimer; 
		let btnmenu;
		let nBackGround=6;
		
		function click_BKG(){
			nBackGround=(nBackGround + 1) % 6;
			normal_background_bg_img.setProperty(hmUI.prop.SRC, "Back" + parseInt(nBackGround) + ".png");
		}
		
		function GetTime(){
			let h = now.hour;
			let m = now.minute; 
			let s = now.second;
			WFTimeNow[0]=parseInt(h / 10);
			WFTimeNow[1]=parseInt(h % 10);
			WFTimeNow[2]=parseInt(m / 10);
			WFTimeNow[3]=parseInt(m % 10);
			WFTimeNow[4]=parseInt(s / 10);
			WFTimeNow[5]=parseInt(s % 10);
		}

		function PushTime(){
			for(let i=0;i<6;i++) WFTimePrev[i]=WFTimeNow[i];
		}

		function StopAnim(){
			for(let i=0;i<6;i++) WFTimeAnim[i]=0;
		}

		function ClearPrev(){
			for(let i=0;i<6;i++) WFTimePrev[i]=-1;
		}
		
		function CalcAnim(){
			for(let i=0;i<6;i++)
				if(WFTimeNow[i]!=WFTimePrev[i] && WFTimeAnim[i]==0) 
				{
				if(i>3) 
					WFTimeAnim[i]=5; // 5 stages for seconds
				else
					WFTimeAnim[i]=6; // 8 stages for big digits
				}
		}

		function DecAnim(){
			for(let i=0;i<6;i++)
				if(WFTimeAnim[i]>0) WFTimeAnim[i]-=1;
		}

		
		function PaintData(){
			GetTime();
			CalcAnim();

			xx=118;
			yy=26;
			nspc=0;
			// Hours, check anim and center digit
			xx+=(FontSizesX[0]-FontSizesX[WFTimeAnim[0]])/2;
			yy+=(FontSizesY[0]-FontSizesY[WFTimeAnim[0]])/2;
			WFTimeObj[0].setProperty(hmUI.prop.MORE, {
					x: xx, y: yy,
					src: "Num" + parseInt(WFTimeAnim[0]+1) + "_" + WFTimeNow[0] + ".png",
					show_level: hmUI.show_level.ONLY_NORMAL});
			xx=118+FontSizesX[0];
			yy=26;
			nspc=0;
			xx+=(FontSizesX[0]-FontSizesX[WFTimeAnim[1]])/2;
			yy+=(FontSizesY[0]-FontSizesY[WFTimeAnim[1]])/2;
			WFTimeObj[1].setProperty(hmUI.prop.MORE, {
					x: xx, y: yy,
					src: "Num" + parseInt(WFTimeAnim[1]+1) + "_" + WFTimeNow[1] + ".png",
					show_level: hmUI.show_level.ONLY_NORMAL});
					
			xx=118;
			yy=186;
			nspc=0;
			// Minutes, check anim and center digit
			xx+=(FontSizesX[0]-FontSizesX[WFTimeAnim[2]])/2;
			yy+=(FontSizesY[0]-FontSizesY[WFTimeAnim[2]])/2;
			WFTimeObj[2].setProperty(hmUI.prop.MORE, {
					x: xx, y: yy,
					src: "Num" + parseInt(WFTimeAnim[2]+1) + "_" + WFTimeNow[2] + ".png",
					show_level: hmUI.show_level.ONLY_NORMAL});
			xx=118+FontSizesX[0];
			yy=186;
			nspc=0;
			xx+=(FontSizesX[0]-FontSizesX[WFTimeAnim[3]])/2;
			yy+=(FontSizesY[0]-FontSizesY[WFTimeAnim[3]])/2;
			WFTimeObj[3].setProperty(hmUI.prop.MORE, {
					x: xx, y: yy,
					src: "Num" + parseInt(WFTimeAnim[3]+1) + "_" + WFTimeNow[3] + ".png",
					show_level: hmUI.show_level.ONLY_NORMAL});
					
			xx=172;
			yy=358;
			nspc=0;
			// Seconds, check anim and center digit
			xx+=(FontSizesX[3]-FontSizesX[WFTimeAnim[4]+3])/2;
			yy+=(FontSizesY[3]-FontSizesY[WFTimeAnim[4]+3])/2;
			WFTimeObj[4].setProperty(hmUI.prop.MORE, {
					x: xx, y: yy,
					src: "Num" + parseInt(WFTimeAnim[4]+4) + "_" + WFTimeNow[4] + ".png",
					show_level: hmUI.show_level.ONLY_NORMAL});
			xx=172+FontSizesX[3];
			yy=358;
			nspc=0;
			xx+=(FontSizesX[3]-FontSizesX[WFTimeAnim[5]+3])/2;
			yy+=(FontSizesY[3]-FontSizesY[WFTimeAnim[5]+3])/2;
			WFTimeObj[5].setProperty(hmUI.prop.MORE, {
					x: xx, y: yy,
					src: "Num" + parseInt(WFTimeAnim[5]+4) + "_" + WFTimeNow[5] + ".png",
					show_level: hmUI.show_level.ONLY_NORMAL});
			DecAnim(); // Degrade animations
			PushTime();
		}

	function CreateAOD(){
           idle_back = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back4.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 356,
              font_array: ["NumP_0.png","NumP_1.png","NumP_2.png","NumP_3.png","NumP_4.png","NumP_5.png","NumP_6.png","NumP_7.png","NumP_8.png","NumP_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Step.png',
              unit_tc: 'Step.png',
              unit_en: 'Step.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 384,
              font_array: ["NumP_0.png","NumP_1.png","NumP_2.png","NumP_3.png","NumP_4.png","NumP_5.png","NumP_6.png","NumP_7.png","NumP_8.png","NumP_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 48,
              y: 90,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 144,
              src: 'heart.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 378,
              y: 169,
              font_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 382,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 120,
              month_startY: 346,
              month_sc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              month_tc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              month_en_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 62,
              day_startY: 346,
              day_sc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              day_tc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              day_en_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              day_zero: 1,
              day_space: -3,
              day_unit_sc: 'Minus2.png',
              day_unit_tc: 'Minus2.png',
              day_unit_en: 'Minus2.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 378,
              y: 98,
              src: 'BatBK.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 114,
              font_array: ["NumP_0.png","NumP_1.png","NumP_2.png","NumP_3.png","NumP_4.png","NumP_5.png","NumP_6.png","NumP_7.png","NumP_8.png","NumP_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 99,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 438,
              y: 228,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 403,
              y: 228,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 174,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 368,
              y: 228,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 270,
              font_array: ["Num6_0.png","Num6_1.png","Num6_2.png","Num6_3.png","Num6_4.png","Num6_5.png","Num6_6.png","Num6_7.png","Num6_8.png","Num6_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'Degrees.png',
              unit_tc: 'Degrees.png',
              unit_en: 'Degrees.png',
              negative_image: 'Minus.png',
              invalid_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 168,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 26,
              hour_array: ["Num1_0.png","Num1_1.png","Num1_2.png","Num1_3.png","Num1_4.png","Num1_5.png","Num1_6.png","Num1_7.png","Num1_8.png","Num1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 118,
              minute_startY: 186,
              minute_array: ["Num1_0.png","Num1_1.png","Num1_2.png","Num1_3.png","Num1_4.png","Num1_5.png","Num1_6.png","Num1_7.png","Num1_8.png","Num1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 173,
              second_startY: 358,
              second_array: ["Num4_0.png","Num4_1.png","Num4_2.png","Num4_3.png","Num4_4.png","Num4_5.png","Num4_6.png","Num4_7.png","Num4_8.png","Num4_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });
			

		
	}


        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
            
			let screenType = hmSetting.getScreenType();
			if(screenType==hmSetting.screen_type.AOD) {
				CreateAOD();
				return;
				}			  
			  
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 378,
              y: 270,
              src: 'btnBlue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 356,
              font_array: ["NumP_0.png","NumP_1.png","NumP_2.png","NumP_3.png","NumP_4.png","NumP_5.png","NumP_6.png","NumP_7.png","NumP_8.png","NumP_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Step.png',
              unit_tc: 'Step.png',
              unit_en: 'Step.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 384,
              font_array: ["NumP_0.png","NumP_1.png","NumP_2.png","NumP_3.png","NumP_4.png","NumP_5.png","NumP_6.png","NumP_7.png","NumP_8.png","NumP_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 48,
              y: 90,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 144,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 378,
              y: 169,
              font_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 382,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 120,
              month_startY: 346,
              month_sc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              month_tc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              month_en_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 62,
              day_startY: 346,
              day_sc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              day_tc_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              day_en_array: ["Num7_0.png","Num7_1.png","Num7_2.png","Num7_3.png","Num7_4.png","Num7_5.png","Num7_6.png","Num7_7.png","Num7_8.png","Num7_9.png"],
              day_zero: 1,
              day_space: -3,
              day_unit_sc: 'Minus2.png',
              day_unit_tc: 'Minus2.png',
              day_unit_en: 'Minus2.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 378,
              y: 98,
              src: 'BatBK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 114,
              font_array: ["NumP_0.png","NumP_1.png","NumP_2.png","NumP_3.png","NumP_4.png","NumP_5.png","NumP_6.png","NumP_7.png","NumP_8.png","NumP_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 99,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 438,
              y: 228,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 403,
              y: 228,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 174,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 368,
              y: 228,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 270,
              font_array: ["Num6_0.png","Num6_1.png","Num6_2.png","Num6_3.png","Num6_4.png","Num6_5.png","Num6_6.png","Num6_7.png","Num6_8.png","Num6_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'Degrees.png',
              unit_tc: 'Degrees.png',
              unit_en: 'Degrees.png',
              negative_image: 'Minus.png',
              invalid_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 168,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 



			xx=118;
			yy=26;
			nspc=0;
			// 125x200 font
			WFTimeObj[0]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*125, y: yy, src: 'Num1_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFTimeObj[1]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*125+nspc, y: yy, src: 'Num1_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL});

			xx=118;
			yy=186;
			nspc=0;
			WFTimeObj[2]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*125, y: yy, src: 'Num1_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFTimeObj[3]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*125+nspc, y: yy, src: 'Num1_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL});

			xx=172;
			yy=358;
			nspc=0; // 69*110 font
			WFTimeObj[4]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+0*69, y: yy, src: 'Num4_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL});
			WFTimeObj[5]=hmUI.createWidget(hmUI.widget.IMG, {
					x: xx+1*69+nspc, y: yy, src: 'Num4_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL});
			

			nBackGround=2; // Force Fresnel, background 3
			click_BKG();
			btnmenu = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 378,
			  y: 270,
			  text: '',
			  w: -1,
			  h: -1,
			  normal_src: 'btnBlue.png',
			  press_src: 'btnBlueP.png',
			  click_func: () => {
				click_BKG();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			StopAnim();
			ClearPrev();
			MainTimer = timer.createTimer(25, 25, PaintData, {}); // Watchface timer
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				    StopAnim(); // Clear anims
					ClearPrev(); // Show anims from start, nice wake effect 8-)
					PaintData();
              }),
              pause_call: (function () {
				
             }),
            });					
					
          },

          onInit() {
            console.log('index page.js on init invoke')
            this.init_view()
          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  