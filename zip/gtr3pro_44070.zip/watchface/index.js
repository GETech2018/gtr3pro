﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_altimeter_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_sun_image_progress_img_level = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_high_TextCircle = new Array(4);
        let normal_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_high_TextCircle_img_width = 21;
        let normal_high_TextCircle_img_height = 22;
        let normal_high_TextCircle_unit = null;
        let normal_high_TextCircle_unit_width = 12;
        let normal_high_TextCircle_dot_width = 15;
        let normal_high_TextCircle_error_img_width = 15;
        let normal_low_TextCircle = new Array(4);
        let normal_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_low_TextCircle_img_width = 21;
        let normal_low_TextCircle_img_height = 22;
        let normal_low_TextCircle_unit = null;
        let normal_low_TextCircle_unit_width = 12;
        let normal_low_TextCircle_dot_width = 15;
        let normal_low_TextCircle_error_img_width = 15;
        let normal_moon_image_progress_img_level = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg013.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 440,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 182,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 11,
              y: 260,
              src: 'alon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 349,
              day_startY: 182,
              day_sc_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              day_tc_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              day_en_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: '0116.png',
              day_unit_tc: '0116.png',
              day_unit_en: '0116.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 395,
              month_startY: 182,
              month_sc_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              month_tc_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              month_en_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 412,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 122,
              image_array: ["uvilvl_1.png","uvilvl_2.png","uvilvl_3.png","uvilvl_4.png","uvilvl_5.png","uvilvl_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 412,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 386,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 384,
              y: 75,
              image_array: ["humilvl_1.png","humilvl_2.png","humilvl_3.png","humilvl_4.png","humilvl_5.png","humilvl_6.png","humilvl_7.png","humilvl_8.png","humilvl_9.png","humilvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 334,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 245,
              y: 318,
              week_en: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 407,
              y: 303,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 303,
              image_array: ["battlvl_1.png","battlvl_2.png","battlvl_3.png","battlvl_4.png","battlvl_5.png","battlvl_6.png","battlvl_7.png","battlvl_8.png","battlvl_9.png","battlvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 306,
              image_array: ["Wind1.png","Wind2.png","Wind3.png","Wind4.png","Wind5.png","Wind6.png","Wind7.png","Wind8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 334,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ms.png',
              unit_tc: 'ms.png',
              unit_en: 'ms.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 202,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 204,
              minute_startY: 202,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 346,
              second_startY: 234,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: -8,
              image_array: ["sun_1.png","sun_2.png","sun_3.png"],
              image_length: 3,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 240,
              center_y: 235,
              x: 34,
              y: 221,
              start_angle: -62,
              end_angle: 66,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 3,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'fu.png',
              invalid_image: 'fu.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 177,
              image_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 213,
              // angle: 27,
              // char_space_angle: 0,
              // unit: 'du1.png',
              // dot_image: 'fu.png',
              // error_image: 'fu.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_high_TextCircle_img_width / 2,
                pos_y: 240 - 235,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_high_TextCircle_unit_width / 2,
              pos_y: 240 - 235,
              src: 'du1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 213,
              // angle: -28,
              // char_space_angle: 0,
              // unit: 'du1.png',
              // dot_image: 'fu.png',
              // error_image: 'fu.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_low_TextCircle_img_width / 2,
                pos_y: 240 - 235,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_low_TextCircle_unit_width / 2,
              pos_y: 240 - 235,
              src: 'du1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 237,
              y: 75,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 100,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 370,
              src: 'alarmon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 276,
              year_startY: 135,
              year_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              year_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              year_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 214,
              month_startY: 135,
              month_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot.png',
              month_unit_tc: 'dot.png',
              month_unit_en: 'dot.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 152,
              day_startY: 135,
              day_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 330,
              week_en: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_tc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_sc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 199,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 199,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'colon.png',
              minute_unit_tc: 'colon.png',
              minute_unit_en: 'colon.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 340,
              second_startY: 199,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 385,
              w: 100,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 385,
              w: 80,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 6,
              w: 100,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 138,
              y: 333,
              w: 75,
              h: 40,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 200,
              w: 70,
              h: 85,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 225,
              w: 70,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 200,
              w: 70,
              h: 85,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 66,
              w: 150,
              h: 80,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 295,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'buttons.png',
              normal_src: 'buttons.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 136,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'buttons.png',
              normal_src: 'buttons.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle high_forecastData');
              let temperatureHigh = undefined;
              let normal_high_circle_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_circle_string = String(high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 27;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_circle_string.length > 0 && normal_high_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_high_TextCircle_img_angle = 0;
                  let normal_high_TextCircle_dot_img_angle = 0;
                  let normal_high_TextCircle_unit_angle = 0;
                  normal_high_TextCircle_img_angle = toDegree(Math.atan2(normal_high_TextCircle_img_width/2, 213));
                  normal_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_high_TextCircle_dot_width/2, 213));
                  normal_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_high_TextCircle_unit_width/2, 213));
                  // alignment = CENTER_H
                  let normal_high_TextCircle_angleOffset = normal_high_TextCircle_img_angle * (normal_high_circle_string.length - 1);
                  normal_high_TextCircle_angleOffset = normal_high_TextCircle_angleOffset + (normal_high_TextCircle_img_angle + normal_high_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_high_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_high_TextCircle_img_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_high_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_high_TextCircle_dot_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'fu.png');
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_high_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_high_TextCircle_unit_angle;
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_high_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_high_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_high_TextCircle_error_img_width / 2);
                  normal_high_TextCircle[0].setProperty(hmUI.prop.SRC, 'fu.png');
                  normal_high_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle low_forecastData');
              let temperatureLow = undefined;
              let normal_low_circle_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_circle_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -28;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_circle_string.length > 0 && normal_low_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_low_TextCircle_img_angle = 0;
                  let normal_low_TextCircle_dot_img_angle = 0;
                  let normal_low_TextCircle_unit_angle = 0;
                  normal_low_TextCircle_img_angle = toDegree(Math.atan2(normal_low_TextCircle_img_width/2, 213));
                  normal_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_low_TextCircle_dot_width/2, 213));
                  normal_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_low_TextCircle_unit_width/2, 213));
                  // alignment = CENTER_H
                  let normal_low_TextCircle_angleOffset = normal_low_TextCircle_img_angle * (normal_low_circle_string.length - 1);
                  normal_low_TextCircle_angleOffset = normal_low_TextCircle_angleOffset + (normal_low_TextCircle_img_angle + normal_low_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_low_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_low_TextCircle_img_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_low_TextCircle_dot_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'fu.png');
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_low_TextCircle_unit_angle;
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_low_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_low_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_low_TextCircle_error_img_width / 2);
                  normal_low_TextCircle[0].setProperty(hmUI.prop.SRC, 'fu.png');
                  normal_low_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}