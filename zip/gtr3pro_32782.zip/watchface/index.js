﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''

        let bot_circle_btn = ''
        let step_cal_state = 0 // 0 - месяц, 1 - пульс, 2 - шаги
        let step_cal_state_txt = ''

        function step_cal_Switcher() {

          let step_cal_state_total = 4;
  
          step_cal_state = (step_cal_state + 1) % step_cal_state_total;
  
          switch (step_cal_state) {
  
              case 0:
              
              normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.VISIBLE, true);
              normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
              normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_pointer_progress_img_pointer .setProperty(hmUI.prop.VISIBLE, false);
              step_cal_state_txt = 'Month';
                  break;
  
              case 1:
                normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_pointer_progress_img_pointer .setProperty(hmUI.prop.VISIBLE, false);
  
                step_cal_state_txt = 'Step';
                      break;
  
              case 2:
                normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_pointer_progress_img_pointer .setProperty(hmUI.prop.VISIBLE, false);
  
                step_cal_state_txt = 'Pulse';
                    break;

              case 3:
                normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_uvi_pointer_progress_img_pointer .setProperty(hmUI.prop.VISIBLE, true);
        
                step_cal_state_txt = 'UVI';
                break;
      
              default:
                  break;
          }
  
          hmUI.showToast({ text: step_cal_state_txt });
        }
  
        // смена безеля
        let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 2
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Bezel> " + parseInt(bezel_num) });
            normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(bezel_num) + ".png");
        }

        // смена маски
        let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 9
     
        function click_mask() {
            if(mask_num>=mask_all) {mask_num=1;}
            else { mask_num=mask_num+1;}
            hmUI.showToast({text: "<Mask> " + parseInt(mask_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(mask_num) + ".png");
        }

        //let bot_circle_btn = ''
        let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       // задержка между кликами в мс 

      //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------		
      function checkClicks() {

        switch(clicks) {
          case 1:
           click_mask();
         break;
          case 2:
            click_Bezel(); // функции на двойной клик
         break;
          case 3:
            click_bot_ssmoth_Switcher() ;// функции на тройной клик
         break;
         // case 4:
           // функции на 4-ной клик
         //break;
          default:
         break;
       }
        
       timer.stopTimer(delay_Timer);
       clicks = 0;

      }
        
    
 
     function getClick() {		
  
        clicks++;
        if(delay_Timer) timer.stopTimer(delay_Timer);
        delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
  
     }

      //let sec_smoth_btn = ''
      let sec_smoth_state = 0 // 0 - тип 1, 1 - тип 2
      let sec_smoth_state_txt = ''

      function click_bot_ssmoth_Switcher() {

        let bot_sec_state_total = 2;

        sec_smoth_state = (sec_smoth_state + 1) % bot_sec_state_total;

        switch (sec_smoth_state) {

            case 0:
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
      
              sec_smoth_state_txt = 'Normal';
                break;

            case 1:

              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

              sec_smoth_state_txt = 'Smooth';
                break;

            default:
                break;
        }

        hmUI.showToast({ text: sec_smoth_state_txt });
      }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 280,
              y: 393,
              src: '0112.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 393,
              src: '0113.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            //  x: 103,
            //  y: 246,
            //  week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
            //  week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
            //  week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
            //  show_level: hmUI.show_level.ONLY_NORMAL,
            //});

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 384,
              day_sc_array: ["dtw_1.png","dtw_2.png","dtw_3.png","dtw_4.png","dtw_5.png","dtw_6.png","dtw_7.png","dtw_8.png","dtw_9.png","dtw_10.png"],
              day_tc_array: ["dtw_1.png","dtw_2.png","dtw_3.png","dtw_4.png","dtw_5.png","dtw_6.png","dtw_7.png","dtw_8.png","dtw_9.png","dtw_10.png"],
              day_en_array: ["dtw_1.png","dtw_2.png","dtw_3.png","dtw_4.png","dtw_5.png","dtw_6.png","dtw_7.png","dtw_8.png","dtw_9.png","dtw_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'str_1.png',
              center_x: 119,
              center_y: 239,
              posX: 12,
              posY: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 158,
              src: 'str_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 106,
              y: 193,
              image_array: ["pu_0.png","pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 251,
              font_array: ["dtw_1.png","dtw_2.png","dtw_3.png","dtw_4.png","dtw_5.png","dtw_6.png","dtw_7.png","dtw_8.png","dtw_9.png","dtw_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_1.png',
              center_x: 119,
              center_y: 239,
              x: 12,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 158,
              src: 'str_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 251,
              font_array: ["dtw_1.png","dtw_2.png","dtw_3.png","dtw_4.png","dtw_5.png","dtw_6.png","dtw_7.png","dtw_8.png","dtw_9.png","dtw_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 192,
              image_array: ["step.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_1.png',
              center_x: 119,
              center_y: 239,
              x: 12,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 158,
              src: 'str_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 251,
              font_array: ["dtw_1.png","dtw_2.png","dtw_3.png","dtw_4.png","dtw_5.png","dtw_6.png","dtw_7.png","dtw_8.png","dtw_9.png","dtw_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 190,
              src: 'UVI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_1.png',
              center_x: 119,
              center_y: 239,
              x: 12,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_1.png',
              center_x: 356,
              center_y: 237,
              x: 12,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 35,
              hour_posY: 175,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 239,
              minute_centerY: 239,
              minute_posX: 31,
              minute_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 27,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 27,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 27,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 's_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  getClick();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);

              normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_pointer_progress_img_pointer .setProperty(hmUI.prop.VISIBLE, false);


              btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 80,
              text: '',
              w: 100,
              h: 50,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  step_cal_Switcher();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             btn_bezel.setProperty(hmUI.prop.VISIBLE, true);


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 239,
              hour_centerY: 239,
              hour_posX: 33,
              hour_posY: 175,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 239,
              minute_centerY: 239,
              minute_posX: 31,
              minute_posY: 237,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Нет связи,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Подключено,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Disconnect"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connect"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 185,
              w: 103,
              h: 103,
              src: 'null.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 185,
              w: 103,
              h: 103,
              src: 'null.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 185,
              w: 103,
              h: 103,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 185,
              w: 103,
              h: 103,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}