﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
    
        function click_zona1() {
          zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({
              text: 'Луна'
            });
          };
    
          if (zona1_num == 1) {
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true); 
            hmUI.showToast({
              text: 'Погода'
            });
          };
        }

        let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
    
        function click_zona2() {
          zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {
            normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({
              text: 'Заряд'
            });
          };
    
          if (zona2_num == 1) {
            normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({
              text: 'Пульс'
            });
          };

          if (zona2_num == 2) {
            normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
            hmUI.showToast({
              text: 'Путь'
            });
          };
        }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bezlel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 76,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 326,
              src: 'Pulse_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 365,
              font_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 326,
              font_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              padding: false,
              h_space: 0,
              dot_image: '0059.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 365,
              src: 'Dist_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 412,
              src: '0069.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 412,
              src: '0070.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 132,
              font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0063.png',
              unit_tc: '0063.png',
              unit_en: '0063.png',
              negative_image: '0064.png',
              invalid_image: '0064.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 85,
              image_array: ["wz_0.png","wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 371,
              src: 'BtIcon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 334,
              font_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 398,
              day_startY: 222,
              day_sc_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              day_tc_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              day_en_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 313,
              y: 222,
              week_en: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              week_tc: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              week_sc: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 220,
              font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'cl_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 10,
              hour_posY: 143,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'cl_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 12,
              minute_posY: 211,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'cl_3.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 8,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195, //x кнопки
              y: 0, //y кнопки
              text: '',
              w: 100, //ширина кнопки
              h: 34, //высота кнопки
              normal_src: 'null.png',
              press_src: 'mull.png',
              click_func: () => {
                click_zona1();
                click_Vibrate(); //имя вызываемой функции
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
      
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195, //x кнопки
              y: 315, //y кнопки
              text: '',
              w: 100, //ширина кнопки
              h: 100, //высота кнопки
              normal_src: 'null.png',
              press_src: 'mull.png',
              click_func: () => {
                click_zona2();
                click_Vibrate(); //имя вызываемой функции
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);

            normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      
            // календарь
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 390,
              y: 195,
              text: '',
              w: 100,
              h: 100,
      			  normal_src: 'null.png',
			        press_src: 'null.png',
			        click_func: () => {
      				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			        },
			        show_level: hmUI.show_level.ONLY_NORMAL,
			      });
            
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'cl_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 10,
              hour_posY: 143,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'cl_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 12,
              minute_posY: 211,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 342,
              hour_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 342,
              minute_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 348,
              src: '0099.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Отключено !,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Подключено !,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Отключено !"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Подключено !"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 195,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 74,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 195,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
