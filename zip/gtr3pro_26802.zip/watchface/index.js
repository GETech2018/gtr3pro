﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 166,
              month_startY: 30,
              month_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png"],
              month_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png"],
              month_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 394,
              src: '023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 380,
              font_array: ["056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png","065.png"],
              padding: false,
              h_space: -24,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 339,
              src: '021.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 322,
              font_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              padding: false,
              h_space: -23,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 128,
              y: 279,
              src: '020.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 264,
              font_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              padding: false,
              h_space: -23,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 116,
              day_startY: 88,
              day_sc_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              day_tc_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              day_en_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              day_zero: 1,
              day_space: -24,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 226,
              y: 88,
              week_en: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              week_tc: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              week_sc: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 150,
              hour_array: ["046.png","047.png","048.png","049.png","050.png","051.png","052.png","053.png","054.png","055.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 151,
              minute_startY: 150,
              minute_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              minute_zero: 1,
              minute_space: -24,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 241,
              second_startY: 201,
              second_array: ["036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png","045.png"],
              second_zero: 1,
              second_space: -24,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 150,
              src: '012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '022.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 34,
              second_posY: 260,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 394,
              src: '023.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 380,
              font_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              padding: false,
              h_space: -24,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 150,
              hour_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 151,
              minute_startY: 150,
              minute_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              minute_zero: 1,
              minute_space: -24,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 150,
              src: '012.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  