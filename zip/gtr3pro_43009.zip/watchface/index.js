    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FOND01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 404,
              font_array: ["L-00.png","L-01.png","L-02.png","L-03.png","L-04.png","L-05.png","L-06.png","L-07.png","L-08.png","L-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'L-12.png',
              unit_tc: 'L-12.png',
              unit_en: 'L-12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 404,
              font_array: ["L-00.png","L-01.png","L-02.png","L-03.png","L-04.png","L-05.png","L-06.png","L-07.png","L-08.png","L-09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 404,
              font_array: ["L-00.png","L-01.png","L-02.png","L-03.png","L-04.png","L-05.png","L-06.png","L-07.png","L-08.png","L-09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 83,
              y: 281,
              src: 'BT1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 282,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 394,
              year_startY: 285,
              year_sc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              year_tc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              year_en_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 351,
              month_startY: 285,
              month_sc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              month_tc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              month_en_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'k-11.png',
              month_unit_tc: 'k-11.png',
              month_unit_en: 'k-11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 313,
              day_startY: 285,
              day_sc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              day_tc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              day_en_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'k-11.png',
              day_unit_tc: 'k-11.png',
              day_unit_en: 'k-11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 282,
              week_en: ["d_day_01.png","d_day_02.png","d_day_03.png","d_day_04.png","d_day_05.png","d_day_06.png","d_day_07.png"],
              week_tc: ["d_day_01.png","d_day_02.png","d_day_03.png","d_day_04.png","d_day_05.png","d_day_06.png","d_day_07.png"],
              week_sc: ["d_day_01.png","d_day_02.png","d_day_03.png","d_day_04.png","d_day_05.png","d_day_06.png","d_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 159,
              image_array: ["ENER_01.png","ENER_02.png","ENER_03.png","ENER_04.png","ENER_05.png","ENER_06.png","ENER_07.png","ENER_08.png","ENER_09.png","ENER_10.png","ENER_11.png","ENER_12.png","ENER_13.png","ENER_14.png","ENER_15.png","ENER_16.png","ENER_17.png","ENER_18.png","ENER_19.png","ENER_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 24,
              y: 252,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: true,
              h_space: 1,
              unit_sc: 'MINI13.png',
              unit_tc: 'MINI13.png',
              unit_en: 'MINI13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 116,
              font_array: ["M-00.png","M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png"],
              padding: true,
              h_space: 1,
              unit_sc: 'M-12.png',
              unit_tc: 'M-12.png',
              unit_en: 'M-12.png',
              dot_image: 'M-11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 81,
              font_array: ["M-00.png","M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 117,
              font_array: ["M-00.png","M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'M-11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 19,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 26,
              font_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'k-14.png',
              unit_tc: 'k-14.png',
              unit_en: 'k-14.png',
              negative_image: 'k-13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 157,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 268,
              minute_startY: 157,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 390,
              second_startY: 157,
              second_array: ["j-00.png","j-01.png","j-02.png","j-03.png","j-04.png","j-05.png","j-06.png","j-07.png","j-08.png","j-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 157,
              src: 'G-10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'SECONDE3.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 298,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 298,
              center_x: 240,
              center_y: 240,
              src: 'SECONDE3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 282,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 319,
              year_startY: 285,
              year_sc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              year_tc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              year_en_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 280,
              month_startY: 285,
              month_sc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              month_tc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              month_en_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'k-11.png',
              month_unit_tc: 'k-11.png',
              month_unit_en: 'k-11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 242,
              day_startY: 285,
              day_sc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              day_tc_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              day_en_array: ["k-00.png","k-01.png","k-02.png","k-03.png","k-04.png","k-05.png","k-06.png","k-07.png","k-08.png","k-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'k-11.png',
              day_unit_tc: 'k-11.png',
              day_unit_en: 'k-11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 94,
              y: 285,
              week_en: ["d_day_01.png","d_day_02.png","d_day_03.png","d_day_04.png","d_day_05.png","d_day_06.png","d_day_07.png"],
              week_tc: ["d_day_01.png","d_day_02.png","d_day_03.png","d_day_04.png","d_day_05.png","d_day_06.png","d_day_07.png"],
              week_sc: ["d_day_01.png","d_day_02.png","d_day_03.png","d_day_04.png","d_day_05.png","d_day_06.png","d_day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 157,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 268,
              minute_startY: 157,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 390,
              second_startY: 157,
              second_array: ["j-00.png","j-01.png","j-02.png","j-03.png","j-04.png","j-05.png","j-06.png","j-07.png","j-08.png","j-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 157,
              src: 'G-10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH  OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH  ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH  OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH  ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 219,
              y: 76,
              w: 195,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 104,
              w: 150,
              h: 43,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 26,
              y: 277,
              w: 45,
              h: 45,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 0,
              w: 100,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O-empty.png',
              normal_src: 'O-empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 8,
              y: 165,
              w: 100,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O-empty.png',
              normal_src: 'O-empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 282,
              w: 266,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O-empty.png',
              normal_src: 'O-empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 106,
              y: 386,
              w: 80,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O-empty.png',
              normal_src: 'O-empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 386,
              w: 80,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O-empty.png',
              normal_src: 'O-empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 386,
              w: 80,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O-empty.png',
              normal_src: 'O-empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				autoToggleWeatherIcons();
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}