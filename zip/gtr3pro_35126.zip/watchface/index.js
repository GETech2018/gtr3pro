﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_stand_circle_scale = ''
        let normal_stand_TextCircle = new Array(5);
        let normal_stand_TextCircle_ASCIIARRAY = new Array(10);
        let normal_stand_TextCircle_img_width = 22;
        let normal_stand_TextCircle_img_height = 29;
        let normal_step_circle_scale = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 22;
        let normal_step_TextCircle_img_height = 29;
        let normal_step_TextCircle_unit = null;
        let normal_step_TextCircle_unit_width = 11;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 22;
        let normal_distance_TextCircle_img_height = 29;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 30;
        let normal_distance_TextCircle_dot_width = 4;
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(5);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 22;
        let normal_battery_TextCircle_img_height = 29;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 19;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_TextCircle = new Array(5);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 22;
        let normal_heart_rate_TextCircle_img_height = 29;
        let normal_heart_rate_TextCircle_unit = null;
        let normal_heart_rate_TextCircle_unit_width = 11;
        let normal_spo2_TextCircle = new Array(5);
        let normal_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let normal_spo2_TextCircle_img_width = 22;
        let normal_spo2_TextCircle_img_height = 29;
        let normal_spo2_TextCircle_unit = null;
        let normal_spo2_TextCircle_unit_width = 19;
        let normal_pai_total_TextCircle = new Array(5);
        let normal_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let normal_pai_total_TextCircle_img_width = 22;
        let normal_pai_total_TextCircle_img_height = 29;
        let normal_pai_total_TextCircle_unit = null;
        let normal_pai_total_TextCircle_unit_width = 11;
        let normal_pai_icon_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_stand_TextCircle = new Array(5);
        let idle_stand_TextCircle_ASCIIARRAY = new Array(10);
        let idle_stand_TextCircle_img_width = 22;
        let idle_stand_TextCircle_img_height = 29;
        let idle_spo2_TextCircle = new Array(5);
        let idle_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let idle_spo2_TextCircle_img_width = 22;
        let idle_spo2_TextCircle_img_height = 29;
        let idle_spo2_TextCircle_unit = null;
        let idle_spo2_TextCircle_unit_width = 19;
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 22;
        let idle_step_TextCircle_img_height = 29;
        let idle_step_TextCircle_unit = null;
        let idle_step_TextCircle_unit_width = 11;
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 22;
        let idle_distance_TextCircle_img_height = 29;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 30;
        let idle_distance_TextCircle_dot_width = 4;
        let idle_battery_TextCircle = new Array(5);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 22;
        let idle_battery_TextCircle_img_height = 29;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 19;
        let idle_heart_rate_TextCircle = new Array(5);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 22;
        let idle_heart_rate_TextCircle_img_height = 29;
        let idle_heart_rate_TextCircle_unit = null;
        let idle_heart_rate_TextCircle_unit_width = 11;
        let idle_pai_total_TextCircle = new Array(5);
        let idle_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let idle_pai_total_TextCircle_img_width = 22;
        let idle_pai_total_TextCircle_img_height = 29;
        let idle_pai_total_TextCircle_unit = null;
        let idle_pai_total_TextCircle_unit_width = 11;
        let idle_pai_icon_img = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Fond_Rond_33.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 118,
              src: 'BTRond.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 84,
              y: 134,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 226,
              month_sc_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
              month_tc_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
              month_en_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 193,
              day_startY: 221,
              day_sc_array: ["Petitorange00.png","petitorange01.png","petitorange02.png","petitorange03.png","petitorange04.png","petitorange05.png","petitorange06.png","petitorange07.png","petitorange08.png","petitorange09.png"],
              day_tc_array: ["Petitorange00.png","petitorange01.png","petitorange02.png","petitorange03.png","petitorange04.png","petitorange05.png","petitorange06.png","petitorange07.png","petitorange08.png","petitorange09.png"],
              day_en_array: ["Petitorange00.png","petitorange01.png","petitorange02.png","petitorange03.png","petitorange04.png","petitorange05.png","petitorange06.png","petitorange07.png","petitorange08.png","petitorange09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 226,
              week_en: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              week_tc: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              week_sc: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 54,
              hour_array: ["GR0.png","GR1.png","GR2.png","GR3.png","GR4.png","GR5.png","GR6.png","GR7.png","GR8.png","GR9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 158,
              minute_startY: 265,
              minute_array: ["GR0.png","GR1.png","GR2.png","GR3.png","GR4.png","GR5.png","GR6.png","GR7.png","GR8.png","GR9.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 360,
              // end_angle: 271,
              // radius: 240,
              // line_width: 43,
              // line_cap: Rounded,
              // color: 0xFF00C4C4,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 271,
              radius: 219,
              line_width: 43,
              corner_flag: 0,
              color: 0xFF00C4C4,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_stand_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: -32,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_stand_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_stand_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 180,
              // end_angle: 269,
              // radius: 240,
              // line_width: 43,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 180,
              end_angle: 269,
              radius: 219,
              line_width: 43,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 230,
              // char_space_angle: 0,
              // unit: 'Separator.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_step_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 224,
              // char_space_angle: 0,
              // unit: 'Km.png',
              // dot_image: 'point.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 180,
              // end_angle: 91,
              // radius: 240,
              // line_width: 43,
              // line_cap: Rounded,
              // color: 0xFF008ACC,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 180,
              end_angle: 91,
              radius: 219,
              line_width: 43,
              corner_flag: 0,
              color: 0xFF008ACC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 146,
              // char_space_angle: 0,
              // unit: 'Pcent.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Pcent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 1,
              // end_angle: 89,
              // radius: 240,
              // line_width: 43,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 1,
              end_angle: 89,
              radius: 219,
              line_width: 43,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 44,
              // char_space_angle: 0,
              // unit: 'Separator.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: 'Separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 49,
              // char_space_angle: 0,
              // unit: 'Pcent.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_spo2_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_spo2_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_spo2_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_spo2_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: 'Pcent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
            spo2.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: -37,
              // char_space_angle: 0,
              // unit: 'Separator.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_total_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_pai_total_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_pai_total_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_pai_total_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: 'Separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Fond_Rond_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 273,
              year_startY: 227,
              year_sc_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              year_tc_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              year_en_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 118,
              src: 'BTRond.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 84,
              y: 134,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 227,
              month_sc_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_tc_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_en_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Separator.png',
              month_unit_tc: 'Separator.png',
              month_unit_en: 'Separator.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 165,
              day_startY: 227,
              day_sc_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              day_tc_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              day_en_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Separator.png',
              day_unit_tc: 'Separator.png',
              day_unit_en: 'Separator.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 54,
              hour_array: ["GR0.png","GR1.png","GR2.png","GR3.png","GR4.png","GR5.png","GR6.png","GR7.png","GR8.png","GR9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 158,
              minute_startY: 265,
              minute_array: ["GR0.png","GR1.png","GR2.png","GR3.png","GR4.png","GR5.png","GR6.png","GR7.png","GR8.png","GR9.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: -32,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_stand_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_stand_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_stand_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 49,
              // char_space_angle: 0,
              // unit: 'Pcent.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_spo2_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_spo2_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_spo2_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_spo2_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: 'Pcent.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 230,
              // char_space_angle: 0,
              // unit: 'Separator.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_step_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_step_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Separator.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 224,
              // char_space_angle: 0,
              // unit: 'Km.png',
              // dot_image: 'point.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_distance_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Km.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 146,
              // char_space_angle: 0,
              // unit: 'Pcent.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Pcent.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: 44,
              // char_space_angle: 0,
              // unit: 'Separator.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: 'Separator.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              // radius: 204,
              // angle: -37,
              // char_space_angle: 0,
              // unit: 'Separator.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_total_TextCircle_ASCIIARRAY[0] = '0029.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[1] = '0030.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[2] = '0031.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[3] = '0032.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[4] = '0033.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[5] = '0034.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[6] = '0035.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[7] = '0036.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[8] = '0037.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[9] = '0038.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_pai_total_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0029.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_pai_total_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_pai_total_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: 'Separator.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 76,
              w: 330,
              h: 330,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {

              console.log('update text circle STAND');
              let valueStand = stand.current;
              let normal_stand_circle_string = parseInt(valueStand).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -32;
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_circle_string.length > 0 && normal_stand_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_stand_TextCircle_img_angle = 0;
                  let normal_stand_TextCircle_dot_img_angle = 0;
                  normal_stand_TextCircle_img_angle = toDegree(Math.atan2(normal_stand_TextCircle_img_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_stand_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_stand_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_stand_TextCircle_img_width / 2);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.SRC, normal_stand_TextCircle_ASCIIARRAY[charCode]);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_stand_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 410;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  let normal_step_TextCircle_unit_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 204));
                  normal_step_TextCircle_unit_angle = toDegree(Math.atan2(normal_step_TextCircle_unit_width/2, 204));
                  // alignment = RIGHT
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + (normal_step_TextCircle_img_angle + normal_step_TextCircle_unit_angle + 0) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_step_TextCircle_unit_angle;
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 404;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 204));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 204));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'point.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 326;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 204));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 44;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  let normal_heart_rate_TextCircle_unit_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 204));
                  normal_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_unit_width/2, 204));
                  // alignment = RIGHT
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + (normal_heart_rate_TextCircle_img_angle + normal_heart_rate_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= 2 * normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_heart_rate_TextCircle_unit_angle;
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle SPO2');
              let valueSpO2 = spo2.current;
              let normal_spo2_circle_string = parseInt(valueSpO2).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 49;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && normal_spo2_circle_string.length > 0 && normal_spo2_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_spo2_TextCircle_img_angle = 0;
                  let normal_spo2_TextCircle_dot_img_angle = 0;
                  let normal_spo2_TextCircle_unit_angle = 0;
                  normal_spo2_TextCircle_img_angle = toDegree(Math.atan2(normal_spo2_TextCircle_img_width/2, 204));
                  normal_spo2_TextCircle_unit_angle = toDegree(Math.atan2(normal_spo2_TextCircle_unit_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_spo2_TextCircle_img_width / 2);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, normal_spo2_TextCircle_ASCIIARRAY[charCode]);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_spo2_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_spo2_TextCircle_unit_angle;
                  normal_spo2_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle PAI');
              let totalPAI = pai.totalpai;
              let normal_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -37;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_circle_string.length > 0 && normal_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_pai_total_TextCircle_img_angle = 0;
                  let normal_pai_total_TextCircle_dot_img_angle = 0;
                  let normal_pai_total_TextCircle_unit_angle = 0;
                  normal_pai_total_TextCircle_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_img_width/2, 204));
                  normal_pai_total_TextCircle_unit_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_unit_width/2, 204));
                  // alignment = RIGHT
                  let normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_img_angle * (normal_pai_total_circle_string.length - 1);
                  normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_angleOffset + (normal_pai_total_TextCircle_img_angle + normal_pai_total_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= 2 * normal_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_pai_total_TextCircle_img_width / 2);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_pai_total_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_pai_total_TextCircle_unit_angle;
                  normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle STAND');
              let idle_stand_circle_string = parseInt(valueStand).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -32;
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && idle_stand_circle_string.length > 0 && idle_stand_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_stand_TextCircle_img_angle = 0;
                  let idle_stand_TextCircle_dot_img_angle = 0;
                  idle_stand_TextCircle_img_angle = toDegree(Math.atan2(idle_stand_TextCircle_img_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_stand_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_stand_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_stand_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_stand_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_stand_TextCircle_img_width / 2);
                      idle_stand_TextCircle[index].setProperty(hmUI.prop.SRC, idle_stand_TextCircle_ASCIIARRAY[charCode]);
                      idle_stand_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_stand_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle SPO2');
              let idle_spo2_circle_string = parseInt(valueSpO2).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 49;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && idle_spo2_circle_string.length > 0 && idle_spo2_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_spo2_TextCircle_img_angle = 0;
                  let idle_spo2_TextCircle_dot_img_angle = 0;
                  let idle_spo2_TextCircle_unit_angle = 0;
                  idle_spo2_TextCircle_img_angle = toDegree(Math.atan2(idle_spo2_TextCircle_img_width/2, 204));
                  idle_spo2_TextCircle_unit_angle = toDegree(Math.atan2(idle_spo2_TextCircle_unit_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_spo2_TextCircle_img_width / 2);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, idle_spo2_TextCircle_ASCIIARRAY[charCode]);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_spo2_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_spo2_TextCircle_unit_angle;
                  idle_spo2_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 410;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  let idle_step_TextCircle_unit_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 204));
                  idle_step_TextCircle_unit_angle = toDegree(Math.atan2(idle_step_TextCircle_unit_width/2, 204));
                  // alignment = RIGHT
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  idle_step_TextCircle_angleOffset = idle_step_TextCircle_angleOffset + (idle_step_TextCircle_img_angle + idle_step_TextCircle_unit_angle + 0) / 2;
                  idle_step_TextCircle_angleOffset = -idle_step_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_step_TextCircle_unit_angle;
                  idle_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 404;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 204));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 204));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'point.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 326;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 204));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 204));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 44;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  let idle_heart_rate_TextCircle_unit_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 204));
                  idle_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_unit_width/2, 204));
                  // alignment = RIGHT
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + (idle_heart_rate_TextCircle_img_angle + idle_heart_rate_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= 2 * idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_heart_rate_TextCircle_unit_angle;
                  idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle PAI');
              let idle_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -37;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && idle_pai_total_circle_string.length > 0 && idle_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_pai_total_TextCircle_img_angle = 0;
                  let idle_pai_total_TextCircle_dot_img_angle = 0;
                  let idle_pai_total_TextCircle_unit_angle = 0;
                  idle_pai_total_TextCircle_img_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_img_width/2, 204));
                  idle_pai_total_TextCircle_unit_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_unit_width/2, 204));
                  // alignment = RIGHT
                  let idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_img_angle * (idle_pai_total_circle_string.length - 1);
                  idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_angleOffset + (idle_pai_total_TextCircle_img_angle + idle_pai_total_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= 2 * idle_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_pai_total_TextCircle_img_width / 2);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, idle_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_pai_total_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_pai_total_TextCircle_unit_angle;
                  idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_pai_total_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 271,
                      radius: 219,
                      line_width: 43,
                      corner_flag: 0,
                      color: 0xFF00C4C4,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 180,
                      end_angle: 269,
                      radius: 219,
                      line_width: 43,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 180,
                      end_angle: 91,
                      radius: 219,
                      line_width: 43,
                      corner_flag: 0,
                      color: 0xFF008ACC,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 1,
                      end_angle: 89,
                      radius: 219,
                      line_width: 43,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}