﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 225,
              y: 170,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "A",
              anim_fps: 1,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "A1",
              anim_fps: 2,
              anim_size: 4,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 223,
              src: '26.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 31,
              y: 0,
              src: '27.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 146,
              font_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 152,
              src: '15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 146,
              font_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 151,
              src: '14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 431,
              font_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: '13.png',
              unit_tc: '13.png',
              unit_en: '13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 58,
              image_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 371,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 318,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 318,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 371,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '8.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 318,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 66,
              y: 50,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 42,
              font_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10.png',
              unit_tc: '10.png',
              unit_en: '10.png',
              negative_image: '9.png',
              invalid_image: '9.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 370,
              y: 80,
              image_array: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 116,
              month_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 152,
              week_en: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              week_tc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              week_sc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 80,
              day_startY: 70,
              day_sc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_tc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_en_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 170,
              hour_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 263,
              minute_startY: 170,
              minute_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 407,
              second_startY: 182,
              second_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 392,
              y: 196,
              w: 100,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 223,
              src: '26.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 31,
              y: 0,
              src: '27.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 146,
              font_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 152,
              src: '15.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 146,
              font_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 151,
              src: '14.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 431,
              font_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: '13.png',
              unit_tc: '13.png',
              unit_en: '13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 58,
              image_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 371,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 318,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 318,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 371,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '8.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 318,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 66,
              y: 50,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 42,
              font_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10.png',
              unit_tc: '10.png',
              unit_en: '10.png',
              negative_image: '9.png',
              invalid_image: '9.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 370,
              y: 80,
              image_array: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 116,
              month_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 152,
              week_en: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              week_tc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              week_sc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 80,
              day_startY: 70,
              day_sc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_tc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_en_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 170,
              hour_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 263,
              minute_startY: 170,
              minute_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 407,
              second_startY: 182,
              second_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 178,
              src: '11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  