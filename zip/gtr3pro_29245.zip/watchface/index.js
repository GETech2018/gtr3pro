﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 183,
              src: '0041_Locked.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 87,
              y: 138,
              src: '0039_Bluetooth_Disabled.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 378,
              y: 138,
              src: '0040_Alarm_Enabled.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 243,
              // center_y: 445,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 20,
              // line_width: 2,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 436,
              font_array: ["0025_Battery_Sunrise_Sunset_Digit_0.png","0026_Battery_Sunrise_Sunset_Digit_1.png","0027_Battery_Sunrise_Sunset_Digit_2.png","0028_Battery_Sunrise_Sunset_Digit_3.png","0029_Battery_Sunrise_Sunset_Digit_4.png","0030_Battery_Sunrise_Sunset_Digit_5.png","0031_Battery_Sunrise_Sunset_Digit_6.png","0032_Battery_Sunrise_Sunset_Digit_7.png","0033_Battery_Sunrise_Sunset_Digit_8.png","0034_Battery_Sunrise_Sunset_Digit_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 320,
              src: '0044_Sunrise_Sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 379,
              font_array: ["0025_Battery_Sunrise_Sunset_Digit_0.png","0026_Battery_Sunrise_Sunset_Digit_1.png","0027_Battery_Sunrise_Sunset_Digit_2.png","0028_Battery_Sunrise_Sunset_Digit_3.png","0029_Battery_Sunrise_Sunset_Digit_4.png","0030_Battery_Sunrise_Sunset_Digit_5.png","0031_Battery_Sunrise_Sunset_Digit_6.png","0032_Battery_Sunrise_Sunset_Digit_7.png","0033_Battery_Sunrise_Sunset_Digit_8.png","0034_Battery_Sunrise_Sunset_Digit_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0023_Weather_Negative_Symbol.png',
              unit_tc: '0023_Weather_Negative_Symbol.png',
              unit_en: '0023_Weather_Negative_Symbol.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 379,
              font_array: ["0025_Battery_Sunrise_Sunset_Digit_0.png","0026_Battery_Sunrise_Sunset_Digit_1.png","0027_Battery_Sunrise_Sunset_Digit_2.png","0028_Battery_Sunrise_Sunset_Digit_3.png","0029_Battery_Sunrise_Sunset_Digit_4.png","0030_Battery_Sunrise_Sunset_Digit_5.png","0031_Battery_Sunrise_Sunset_Digit_6.png","0032_Battery_Sunrise_Sunset_Digit_7.png","0033_Battery_Sunrise_Sunset_Digit_8.png","0034_Battery_Sunrise_Sunset_Digit_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 243,
              y: 81,
              w: 159,
              h: 32,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 51,
              font_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0024_Weather_Unit.png',
              unit_tc: '0024_Weather_Unit.png',
              unit_en: '0024_Weather_Unit.png',
              negative_image: '0023_Weather_Negative_Symbol.png',
              invalid_image: '0037_Error_Icon_Main.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 59,
              image_array: ["0064_Weather_Icons_001.png","0065_Weather_Icons_002.png","0066_Weather_Icons_003.png","0067_Weather_Icons_004.png","0068_Weather_Icons_005.png","0069_Weather_Icons_006.png","0070_Weather_Icons_007.png","0071_Weather_Icons_008.png","0072_Weather_Icons_009.png","0073_Weather_Icons_010.png","0074_Weather_Icons_011.png","0075_Weather_Icons_012.png","0076_Weather_Icons_013.png","0077_Weather_Icons_014.png","0078_Weather_Icons_015.png","0079_Weather_Icons_016.png","0080_Weather_Icons_017.png","0081_Weather_Icons_018.png","0082_Weather_Icons_019.png","0083_Weather_Icons_020.png","0084_Weather_Icons_021.png","0085_Weather_Icons_022.png","0086_Weather_Icons_023.png","0087_Weather_Icons_024.png","0088_Weather_Icons_025.png","0089_Weather_Icons_026.png","0090_Weather_Icons_027.png","0091_Weather_Icons_028.png","0092_Weather_Icons_029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 325,
              font_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '0022_Distance_Separator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 363,
              src: '0043_Distance_Traveled.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 325,
              font_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: '0037_Error_Icon_Main.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 363,
              src: '0042_Heart_Rate.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 138,
              week_en: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              week_tc: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              week_sc: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 138,
              month_sc_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_tc_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_en_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 136,
              day_sc_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_tc_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_en_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 190,
              hour_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              hour_zero: 1,
              hour_space: 11,
              hour_unit_sc: '0011_Clock_Separator.png',
              hour_unit_tc: '0011_Clock_Separator.png',
              hour_unit_en: '0011_Clock_Separator.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 261,
              minute_startY: 190,
              minute_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              minute_zero: 1,
              minute_space: 11,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 138,
              week_en: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              week_tc: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              week_sc: ["0045_Weekdays_Monday.png","0046_Weekdays_Tuesday.png","0047_Weekdays_Wednesday.png","0048_Weekdays_Thursday.png","0049_Weekdays_Friday.png","0050_Weekdays_Saturday.png","0051_Weekdays_Sunday.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 138,
              month_sc_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_tc_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_en_array: ["0052_Months_January.png","0053_Months_February.png","0054_Months_March.png","0055_Months_April.png","0056_Months_May.png","0057_Months_June.png","0058_Months_July.png","0059_Months_August.png","0060_Months_September.png","0061_Months_October.png","0062_Months_November.png","0063_Months_December.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 136,
              day_sc_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_tc_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_en_array: ["0012_Day_Weather_Distance_Digit_0.png","0013_Day_Weather_Distance_Digit_1.png","0014_Day_Weather_Distance_Digit_2.png","0015_Day_Weather_Distance_Digit_3.png","0016_Day_Weather_Distance_Digit_4.png","0017_Day_Weather_Distance_Digit_5.png","0018_Day_Weather_Distance_Digit_6.png","0019_Day_Weather_Distance_Digit_7.png","0020_Day_Weather_Distance_Digit_8.png","0021_Day_Weather_Distance_Digit_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 190,
              hour_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              hour_zero: 1,
              hour_space: 11,
              hour_unit_sc: '0011_Clock_Separator.png',
              hour_unit_tc: '0011_Clock_Separator.png',
              hour_unit_en: '0011_Clock_Separator.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 261,
              minute_startY: 190,
              minute_array: ["0001_Clock_Digit_0.png","0002_Clock_Digit_1.png","0003_Clock_Digit_2.png","0004_Clock_Digit_3.png","0005_Clock_Digit_4.png","0006_Clock_Digit_5.png","0007_Clock_Digit_6.png","0008_Clock_Digit_7.png","0009_Clock_Digit_8.png","0010_Clock_Digit_9.png"],
              minute_zero: 1,
              minute_space: 11,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 243;
                  let center_y_normal_battery = 445;
                  let radius_normal_battery = 20;
                  let line_width_cs_normal_battery = 2;
                  let color_cs_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  