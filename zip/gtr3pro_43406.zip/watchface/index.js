﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_fat_burning_linear_scale = ''
        let normal_wind_icon_img = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_img = new Array(3);
        let normal_forecast_date_week_img_array = ['wd1.png', 'wd2.png', 'wd3.png', 'wd4.png', 'wd5.png', 'wd6.png', 'wd7.png'];
        let normal_forecast_high_low_text_img = new Array(3);
        let normal_forecast_image_progress_img_level = new Array(3);
        let normal_forecast_image_array = ['w_0.png', 'w_1.png', 'w_2.png', 'w_3.png', 'w_4.png', 'w_5.png', 'w_6.png', 'w_7.png', 'w_8.png', 'w_9.png', 'w_10.png', 'w_11.png', 'w_12.png', 'w_13.png', 'w_14.png', 'w_15.png', 'w_16.png', 'w_17.png', 'w_18.png', 'w_19.png', 'w_20.png', 'w_21.png', 'w_22.png', 'w_23.png', 'w_24.png', 'w_25.png', 'w_26.png', 'w_27.png', 'w_28.png'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_city_name_text = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg.png'];
        let backgroundToastList = ['Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_fat_burning_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_fat_burning_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 344,
              // start_y: 241,
              // color: 0xFFFF0000,
              // lenght: 114,
              // line_width: 3,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 423,
              src: ',02 (1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 425,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 417,
              src: ',02 (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 423,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_14.png',
              unit_tc: 'small_14.png',
              unit_en: 'small_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 173,
              y: 55,
              image_array: ["11111.png","11112.png","11113.png","11114.png","11115.png","11116.png","11117.png","11118.png","11119.png","11120.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 4,
              y: 213,
              image_array: ["ay01.png","ay02.png","ay03.png","ay04.png","ay05.png","ay06.png","ay07.png","ay08.png","ay09.png","ay10.png","ay11.png","ay12.png","ay13.png","ay14.png","ay15.png","ay16.png","ay17.png","ay18.png","ay19.png","ay20.png","ay21.png","ay22.png","ay23.png","ay24.png","ay25.png","ay26.png","ay27.png","ay28.png","ay29.png","ay30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 352,
              src: ',02 (3).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 356,
              font_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 374,
              src: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 389,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_10.png',
              unit_tc: 'small_10.png',
              unit_en: 'small_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 389,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 375,
              src: '0166.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 390,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 390,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'small_14.png',
              unit_tc: 'small_14.png',
              unit_en: 'small_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 419,
              image_array: ["0258.png","0259.png","0260.png","0261.png","0262.png","0263.png","0264.png","0265.png","0266.png","0267.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 126,
              // y: 230,
              // ColumnWidth: 105,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 126,
              y: 230,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 25,
              // y: 122,
              // image_array: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 25 + i*105,
                  y: 122,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_high_low_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: 17,
              // y: 1,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // padding: false,
              // h_space: 0,
              // unit_en: 'small_12.png',
              // imperial_unit_en: 'small_12.png',
              // negative_image: 'small_11.png',
              // invalid_image: 'small_13.png',
              // dot_image: 'small_11.png',
              // separator_image: 'small_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_high_low_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_high_low_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 17 + i*105,
                  y: 1,
                  font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'small_12.png',
                  unit_tc: 'small_12.png',
                  unit_en: 'small_12.png',
                  negative_image: 'small_11.png',
                  dot_image: 'small_10.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 16,
              // y: 18,
              // image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 16 + i*105,
                  y: 18,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 50,
              image_array: ["0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 47,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'small_12.png',
              unit_tc: 'small_12.png',
              unit_en: 'small_12.png',
              negative_image: 'small_11.png',
              invalid_image: 'small_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 97,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_12.png',
              unit_tc: 'small_12.png',
              unit_en: 'small_12.png',
              negative_image: 'small_11.png',
              invalid_image: 'small_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 97,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_12.png',
              unit_tc: 'small_12.png',
              unit_en: 'small_12.png',
              negative_image: 'small_11.png',
              invalid_image: 'small_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 194,
              y: 443,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 63,
              month_sc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_tc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_en_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_zero: 1,
              month_space: -2,
              month_unit_sc: 'num_11.png',
              month_unit_tc: 'num_11.png',
              month_unit_en: 'num_11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 47,
              month_startY: 161,
              month_sc_array: ["0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png","0233.png","0234.png"],
              month_tc_array: ["0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png","0233.png","0234.png"],
              month_en_array: ["0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png","0233.png","0234.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 316,
              y: 58,
              week_en: ["0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
              week_tc: ["0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
              week_sc: ["0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 225,
              day_startY: 63,
              day_sc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              day_tc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              day_en_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'num_11.png',
              day_unit_tc: 'num_11.png',
              day_unit_en: 'num_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 22,
              font_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'num_12.png',
              unit_tc: 'num_12.png',
              unit_en: 'num_12.png',
              imperial_unit_sc: 'num_13.png',
              imperial_unit_tc: 'num_13.png',
              imperial_unit_en: 'num_13.png',
              dot_image: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 190,
              font_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 239,
              // start_y: 240,
              // color: 0xFF0080FF,
              // lenght: 118,
              // line_width: 3,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 186,
              font_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 134,
              // start_y: 240,
              // color: 0xFFFF8C00,
              // lenght: 120,
              // line_width: 3,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 172,
              image_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 191,
              font_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 184,
              image_array: ["B-1.png","B-2.png","B-3.png","B-4.png","B-5.png","B-6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 27,
              y: 195,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 206,
              hour_startY: 87,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 326,
              minute_startY: 87,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 429,
              second_startY: 151,
              second_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 28,
              am_y: 147,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 28,
              pm_y: 147,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0167.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 37,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 390,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_14.png',
              unit_tc: 'small_14.png',
              unit_en: 'small_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 213,
              // start_y: 433,
              // color: 0xFFC0C0C0,
              // lenght: 51,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 426,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 266,
              year_startY: 68,
              year_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              year_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              year_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              year_zero: 0,
              year_space: -2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 68,
              month_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_zero: 1,
              month_space: -2,
              month_unit_sc: 'num_11.png',
              month_unit_tc: 'num_11.png',
              month_unit_en: 'num_11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 68,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'num_11.png',
              day_unit_tc: 'num_11.png',
              day_unit_en: 'num_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 194,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 194,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 194,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 27,
              y: 195,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 110,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 110,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT  Kapalı,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT Açık,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT  Kapalı"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT Açık"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 42,
              w: 100,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 361,
              y: 250,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 250,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 333,
              y: 97,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 219,
              y: 97,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 390,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 390,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 390,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 177,
              w: 113,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 177,
              w: 108,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 76,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 0,
              // y: 0,
              // w: 100,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // radius: 12,
              // press_color: 0xFFA0A0A0,
              // normal_color: 0xFF696969,
              // bg_list: bg,
              // toast_list: Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_MaxMin
                let max_min_Temperature_img = '-';
                if (i < forecastData.count) {
                  max_min_Temperature_img = forecastData.data[i].high.toString();
                  max_min_Temperature_img += '.';
                  max_min_Temperature_img += forecastData.data[i].low.toString();
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_low_text_img[i].setProperty(hmUI.prop.TEXT, max_min_Temperature_img);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_ls_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_linear_scale
                  // initial parameters
                  let start_x_normal_fat_burning = 344;
                  let start_y_normal_fat_burning = 241;
                  let lenght_ls_normal_fat_burning = 114;
                  let line_width_ls_normal_fat_burning = 3;
                  let color_ls_normal_fat_burning = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_fat_burning_draw = start_x_normal_fat_burning;
                  let start_y_normal_fat_burning_draw = start_y_normal_fat_burning;
                  lenght_ls_normal_fat_burning = lenght_ls_normal_fat_burning * progress_ls_normal_fat_burning;
                  let lenght_ls_normal_fat_burning_draw = line_width_ls_normal_fat_burning;
                  let line_width_ls_normal_fat_burning_draw = lenght_ls_normal_fat_burning;
                  if (lenght_ls_normal_fat_burning < 0){
                    line_width_ls_normal_fat_burning_draw = -lenght_ls_normal_fat_burning;
                    start_y_normal_fat_burning_draw = start_y_normal_fat_burning_draw - line_width_ls_normal_fat_burning_draw;
                  };
                  
                  normal_fat_burning_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_fat_burning_draw,
                    y: start_y_normal_fat_burning_draw,
                    w: lenght_ls_normal_fat_burning_draw,
                    h: line_width_ls_normal_fat_burning_draw,
                    radius: 1,
                    color: color_ls_normal_fat_burning,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 239;
                  let start_y_normal_calorie = 240;
                  let lenght_ls_normal_calorie = 118;
                  let line_width_ls_normal_calorie = 3;
                  let color_ls_normal_calorie = 0xFF0080FF;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    line_width_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_y_normal_calorie_draw = start_y_normal_calorie_draw - line_width_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    radius: 1,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 134;
                  let start_y_normal_step = 240;
                  let lenght_ls_normal_step = 120;
                  let line_width_ls_normal_step = 3;
                  let color_ls_normal_step = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 213;
                  let start_y_idle_battery = 433;
                  let lenght_ls_idle_battery = 51;
                  let line_width_ls_idle_battery = 21;
                  let color_ls_idle_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}