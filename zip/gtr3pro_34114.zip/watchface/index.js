﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let idle_background_bg = ''
        let editableTimePointers = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: '0000.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: '0000b.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: '0000c.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: '0143.png',
              tips_x: 180,
              tips_y: 25,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 265,
              src: '0017.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 393,
              y: 187,
              src: '0018.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 217,
              image_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 363,
              day_startY: 229,
              day_sc_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              day_tc_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              day_en_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 28,
                    posY: 208,
                    path: '0014.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 127,
                    path: '0012.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 178,
                    path: '0013.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 27,
                    posY: 224,
                    path: '0014b.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 127,
                    path: '0012b.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 221,
                    path: '0013b.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 16,
                    posY: 220,
                    path: '0014c.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 141,
                    path: '0012c.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 24,
                    posY: 187,
                    path: '0013c.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 215,
                    path: '0014d.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 117,
                    path: '0012d.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 27,
                    posY: 178,
                    path: '0013d.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_x: 179,
              tips_y: 179,
              tips_bg: '0143.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 366,
              y: 168,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 18,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 192,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 369,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}