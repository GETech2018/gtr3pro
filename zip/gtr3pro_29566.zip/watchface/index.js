﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 132,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_icon_symbo2.png',
              unit_tc: 'Weather_icon_symbo2.png',
              unit_en: 'Weather_icon_symbo2.png',
              negative_image: 'Weather_icon_symbo1.png',
              invalid_image: 'Weather_icon_symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 77,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 36,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 367,
              y: 38,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 327,
              y: 104,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 225,
              font_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 188,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 349,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 385,
              month_startY: 181,
              month_sc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              month_tc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              month_en_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 181,
              day_sc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_tc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_en_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Pointer2.png',
              center_x: 240,
              center_y: 359,
              posX: 23,
              posY: 69,
              start_angle: -30,
              end_angle: 181,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 240,
              center_y: 359,
              x: 21,
              y: 61,
              start_angle: 217,
              end_angle: 319,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 348,
              font_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'number_small_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 147,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 239,
              center_y: 114,
              x: 21,
              y: 61,
              start_angle: 180,
              end_angle: 539,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 330,
              am_y: 265,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 330,
              pm_y: 265,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 306,
              hour_startY: 227,
              hour_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 376,
              minute_startY: 227,
              minute_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 26,
              hour_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 26,
              minute_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // Smooth Seconds

 //           normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
//              second_path: 'Hand_S.png',
//              second_centerX: 227,
//              second_centerY: 227,
//              second_posX: 25,
//              second_posY: 189,
//              show_level: hmUI.show_level.ONLY_NORMAL,
//            });


            // take values from above. The 8 and 223 frome above, too.
            // set PNG name here

            // SMOOTH SECONDS Definition
            let second_centerX = 240;
            let second_centerY = 240;
            let second_posX = 26;
            let second_posY = 200;
            let second_path = "Hand_S.png";
            // ----------------------------
    	    let sec_pointer;
    	    let clock_timer;
	    let animAngle = 0;
            let animDelay = 0;                   
            const animFps = 60;                             // Frames per second 
            const animRepeat = 1000/animFps;                // then execute every <animRepeat>ms
            const deviceInfo = hmSetting.getDeviceInfo();
	    // SMOOTH SECONDS Definition End

            sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: deviceInfo.width / 2 - second_posX,
              pos_y: deviceInfo.height / 2 - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    console.log('ui resume');

                    clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
                            animAngle = (now.second*6) + (((now.utc % 1000)/1000)*6);
                            sec_pointer.setProperty(hmUI.prop.ANGLE, animAngle);
                    }));
		}),
                pause_call: (function () {
                    console.log('ui pause');
					timer.stopTimer(clock_timer);
                }),
            });
            // End Smooth Seconds





            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 225,
              w: 125,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 216,
              w: 56,
              h: 56,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 48,
              w: 96,
              h: 86,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 319,
              y: 96,
              w: 61,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 94,
              y: 81,
              w: 68,
              h: 70,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 299,
              w: 55,
              h: 135,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 333,
              w: 77,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 222,
              w: 118,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 132,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_icon_symbo2.png',
              unit_tc: 'Weather_icon_symbo2.png',
              unit_en: 'Weather_icon_symbo2.png',
              negative_image: 'Weather_icon_symbo1.png',
              invalid_image: 'Weather_icon_symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 77,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 36,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 367,
              y: 38,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 327,
              y: 104,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 225,
              font_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 188,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 349,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 385,
              month_startY: 181,
              month_sc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              month_tc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              month_en_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 181,
              day_sc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_tc_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_en_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Pointer2.png',
              center_x: 240,
              center_y: 359,
              posX: 23,
              posY: 69,
              start_angle: -30,
              end_angle: 181,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 240,
              center_y: 359,
              x: 21,
              y: 61,
              start_angle: 217,
              end_angle: 319,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 348,
              font_array: ["number_small_01.png","number_small_02.png","number_small_03.png","number_small_04.png","number_small_05.png","number_small_06.png","number_small_07.png","number_small_08.png","number_small_09.png","number_small_10.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'number_small_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 147,
              font_array: ["Batteru_font_01.png","Batteru_font_02.png","Batteru_font_03.png","Batteru_font_04.png","Batteru_font_05.png","Batteru_font_06.png","Batteru_font_07.png","Batteru_font_08.png","Batteru_font_09.png","Batteru_font_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 239,
              center_y: 114,
              x: 21,
              y: 61,
              start_angle: 180,
              end_angle: 539,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 330,
              am_y: 265,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 330,
              pm_y: 265,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 306,
              hour_startY: 227,
              hour_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 376,
              minute_startY: 227,
              minute_array: ["number_white_01.png","number_white_02.png","number_white_03.png","number_white_04.png","number_white_05.png","number_white_06.png","number_white_07.png","number_white_08.png","number_white_09.png","number_white_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 26,
              hour_posY: 200,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 26,
              minute_posY: 200,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 26,
              second_posY: 200,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  