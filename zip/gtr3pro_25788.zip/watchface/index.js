﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_step_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_year_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Mainnnn_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 377,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 354,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 331,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 113,
              y: 124,
              src: '054_fix.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 256,
              y: 16,
              image_array: ["cal_01.png","cal_02.png","cal_03.png","cal_04.png","cal_05.png","cal_06.png","cal_07.png","cal_08.png"],
              image_length: 8,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 109,
              font_array: ["power_001.png","power_002.png","power_003.png","power_004.png","power_005.png","power_006.png","power_007.png","power_008.png","power_009.png","power_010.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'power_000.png',
              unit_tc: 'power_000.png',
              unit_en: 'power_000.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 15,
              y: 137,
              image_array: ["batt_icon_01.png","batt_icon_02.png","batt_icon_03.png","batt_icon_04.png","batt_icon_05.png","batt_icon_06.png","batt_icon_07.png","batt_icon_08.png","batt_icon_09.png","batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 290,
              image_array: ["Moon_Fix_01.png","Moon_Fix_02.png","Moon_Fix_03.png","Moon_Fix_04.png","Moon_Fix_05.png","Moon_Fix_06.png","Moon_Fix_07.png","Moon_Fix_08.png","Moon_Fix_09.png","Moon_Fix_10.png","Moon_Fix_11.png","Moon_Fix_12.png","Moon_Fix_13.png","Moon_Fix_14.png","Moon_Fix_15.png","Moon_Fix_16.png","Moon_Fix_17.png","Moon_Fix_18.png","Moon_Fix_19.png","Moon_Fix_20.png"],
              image_length: 20,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 268,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: -2,
              dot_image: '089.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 394,
              y: 268,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: -2,
              dot_image: '089.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 369,
              y: 176,
              font_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'weather02.png',
              unit_tc: 'weather02.png',
              unit_en: 'weather02.png',
              negative_image: 'weather01.png',
              invalid_image: 'goal_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 329,
              y: 100,
              image_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png","079.png","080.png","081.png","082.png","083.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 294,
              y: 190,
              w: 150,
              h: 30,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 160,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 121,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ERROR.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '009.png',
              center_x: 239,
              center_y: 127,
              x: 17,
              y: 63,
              start_angle: 287,
              end_angle: 449,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 121,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 316,
              year_startY: 174,
              year_sc_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              year_tc_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              year_en_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '008.png',
              center_x: 240,
              center_y: 352,
              posX: 17,
              posY: 52,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 53,
              y: 162,
              week_en: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_tc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_sc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 95,
              day_startY: 221,
              day_sc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png"],
              day_tc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png"],
              day_en_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 201,
              am_y: 304,
              am_sc_path: 'system_AM.png',
              am_en_path: 'system_AM.png',
              pm_x: 201,
              pm_y: 304,
              pm_sc_path: 'system_PM.png',
              pm_en_path: 'system_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 295,
              hour_startY: 228,
              hour_array: ["011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 355,
              minute_startY: 228,
              minute_array: ["021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 237,
              second_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 232,
              src: '010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '088.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '087.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '086.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 30,
              second_posY: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 257,
              src: '054_AOD.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 23,
              font_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent_aod.png',
              unit_tc: 'procent_aod.png',
              unit_en: 'procent_aod.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 400,
              y: 184,
              week_en: ["digital5_aod_0.png","digital5_aod_1.png","digital5_aod_2.png","digital5_aod_3.png","digital5_aod_4.png","digital5_aod_5.png","digital5_aod_6.png"],
              week_tc: ["digital5_aod_0.png","digital5_aod_1.png","digital5_aod_2.png","digital5_aod_3.png","digital5_aod_4.png","digital5_aod_5.png","digital5_aod_6.png"],
              week_sc: ["digital5_aod_0.png","digital5_aod_1.png","digital5_aod_2.png","digital5_aod_3.png","digital5_aod_4.png","digital5_aod_5.png","digital5_aod_6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 363,
              day_startY: 185,
              day_sc_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              day_tc_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              day_en_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 310,
              month_startY: 185,
              month_sc_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              month_tc_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              month_en_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 185,
              src: 'power_AOD_011.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 222,
              year_startY: 185,
              year_sc_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              year_tc_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              year_en_array: ["power_AOD_001.png","power_AOD_002.png","power_AOD_003.png","power_AOD_004.png","power_AOD_005.png","power_AOD_006.png","power_AOD_007.png","power_AOD_008.png","power_AOD_009.png","power_AOD_010.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 185,
              src: 'power_AOD_011.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 212,
              hour_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 189,
              minute_startY: 212,
              minute_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 329,
              second_startY: 212,
              second_array: ["aod_0.png","aod_1.png","aod_2.png","aod_3.png","aod_4.png","aod_5.png","aod_6.png","aod_7.png","aod_8.png","aod_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 199,
              src: 'digital9_10_aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 199,
              src: 'digital9_10_aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  