﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber = 1
        let totalcolors = 6
        let namecolor = ''
        let Rootpath = ''
        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Yellow"
Rootpath = ''
}
if ( colornumber == 2) { namecolor = "Pink"
Rootpath = "Pink/"
}
if ( colornumber == 3) { namecolor = "Blue"
Rootpath = "Blue/"
}
if ( colornumber == 4) { namecolor = "Red"
Rootpath = "Red/"
}
if ( colornumber == 5) { namecolor = "Green"
Rootpath = "Green/"
}
if ( colornumber == 6) { namecolor = "Gray"
Rootpath = "Gray/"
}
hmUI.showToast({text: namecolor });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 262,
              minute_startY: 259,
              minute_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 262,
              hour_startY: 171,
              hour_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}


/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start Hour color change
        let colornumberH = 1
        let totalcolorsH = 6
        let namecolorH = ''
        function click_ColorH() {
            if(colornumberH >= totalcolorsH) {
            colornumberH=1;
                }
            else {
                colornumberH = colornumberH+1;
            }
if ( colornumberH == 1) { namecolorH = "Yellow"
Rootpath = ''
}
if ( colornumberH == 2) { namecolorH = "Pink"
Rootpath = "Pink/"
}
if ( colornumberH == 3) { namecolorH = "Blue"
Rootpath = "Blue/"
}
if ( colornumberH == 4) { namecolorH = "Red"
Rootpath = "Red/"
}
if ( colornumberH == 5) { namecolorH = "Green"
Rootpath = "Green/"
}
if ( colornumberH == 6) { namecolorH = "Gray"
Rootpath = "Gray/"
}
hmUI.showToast({text: namecolorH });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 262,
              minute_startY: 259,
              minute_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



}

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start Hour color change
        let colornumberM = 1
        let totalcolorsM = 6
        let namecolorM = ''
        function click_ColorM() {
            if(colornumberM >= totalcolorsM) {
            colornumberM=1;
                }
            else {
                colornumberM = colornumberM+1;
            }

if ( colornumberM == 1) { namecolorM = "Yellow"
Rootpath = ''
}
if ( colornumberM == 2) { namecolorM = "Pink"
Rootpath = "Pink/"
}
if ( colornumberM == 3) { namecolorM = "Blue"
Rootpath = "Blue/"
}
if ( colornumberM == 4) { namecolorM = "Red"
Rootpath = "Red/"
}
if ( colornumberM == 5) { namecolorM = "Green"
Rootpath = "Green/"
}
if ( colornumberM == 6) { namecolorM = "Gray"
Rootpath = "Gray/"
}
hmUI.showToast({text: namecolorM });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 262,
              hour_startY: 171,
              hour_array: [Rootpath+"Time_0.png",Rootpath+"Time_1.png",Rootpath+"Time_2.png",Rootpath+"Time_3.png",Rootpath+"Time_4.png",Rootpath+"Time_5.png",Rootpath+"Time_6.png",Rootpath+"Time_7.png",Rootpath+"Time_8.png",Rootpath+"Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let timer_anim_rotate_2_mirror = false;
        let normal_rotate_animation_param_2_mirror = null;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let timer_anim_rotate_3_mirror = false;
        let normal_rotate_animation_param_3_mirror = null;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let timer_anim_rotate_4_mirror = false;
        let normal_rotate_animation_param_4_mirror = null;
        let normal_rotate_animation_count_4 = 0;
        let normal_image_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 23;
        let normal_distance_TextCircle_img_height = 27;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 31;
        let normal_distance_TextCircle_dot_width = 11;
        let normal_distance_TextCircle_error_img_width = 31;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 23;
        let normal_calorie_TextCircle_img_height = 27;
        let normal_calorie_TextCircle_unit = null;
        let normal_calorie_TextCircle_unit_width = 31;
        let normal_calorie_TextCircle_error_img_width = 23;
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 23;
        let idle_distance_TextCircle_img_height = 27;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 31;
        let idle_distance_TextCircle_dot_width = 11;
        let idle_distance_TextCircle_error_img_width = 31;
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 23;
        let idle_calorie_TextCircle_img_height = 27;
        let idle_calorie_TextCircle_unit = null;
        let idle_calorie_TextCircle_unit_width = 31;
        let idle_calorie_TextCircle_error_img_width = 23;
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/circle0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 36000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'circle0.png',
              // anim_fps: 15,
              // anim_duration: 36000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 101,
              pos_y: 14,
              center_x: 240,
              center_y: 240,
              angle: 338,
              src: 'animation/Blue_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 800,
              anim_from: 338,
              anim_to: 366,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 800,
              anim_from: 366,
              anim_to: 338,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_2_mirror() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2_mirror);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();

            }; // end animation_mirror callback function

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 338,
              // end_angle: 366,
              // pos_x: 139,
              // pos_y: 226,
              // center_x: 240,
              // center_y: 240,
              // src: 'Blue_0.png',
              // anim_fps: 15,
              // anim_duration: 800,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 101,
              pos_y: 14,
              center_x: 240,
              center_y: 240,
              angle: 341,
              src: 'animation/Pink_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_rate: 'linear',
              anim_duration: 650,
              anim_from: 341,
              anim_to: 363,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 650,
              anim_from: 363,
              anim_to: 341,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_3_mirror() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3_mirror);
              normal_rotate_animation_lastTime_3 = now.utc;
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();

            }; // end animation_mirror callback function

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
              normal_rotate_animation_lastTime_3 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 341,
              // end_angle: 363,
              // pos_x: 139,
              // pos_y: 226,
              // center_x: 240,
              // center_y: 240,
              // src: 'Pink_0.png',
              // anim_fps: 15,
              // anim_duration: 650,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 101,
              pos_y: 14,
              center_x: 240,
              center_y: 240,
              angle: 332,
              src: 'animation/Yellow_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_rate: 'linear',
              anim_duration: 600,
              anim_from: 332,
              anim_to: 372,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_4_mirror = {
              anim_rate: 'linear',
              anim_duration: 600,
              anim_from: 372,
              anim_to: 332,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_4_mirror() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4_mirror);
              normal_rotate_animation_lastTime_4 = now.utc;
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();

            }; // end animation_mirror callback function

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
              normal_rotate_animation_lastTime_4 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 332,
              // end_angle: 372,
              // pos_x: 139,
              // pos_y: 226,
              // center_x: 240,
              // center_y: 240,
              // src: 'Yellow_0.png',
              // anim_fps: 15,
              // anim_duration: 600,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              // radius: 231,
              // angle: 150,
              // char_space_angle: 0,
              // unit: 'Dis_KM.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Act_Black_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'Act_Gray_Small_0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'Act_Gray_Small_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'Act_Gray_Small_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'Act_Gray_Small_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'Act_Gray_Small_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'Act_Gray_Small_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'Act_Gray_Small_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'Act_Gray_Small_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'Act_Gray_Small_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'Act_Gray_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: 'Act_Gray_Small_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              // radius: 231,
              // angle: 218,
              // char_space_angle: 0,
              // unit: 'cal_unit.png',
              // error_image: 'Act_Gray_Small_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'Act_Gray_Small_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'Act_Gray_Small_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'Act_Gray_Small_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'Act_Gray_Small_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'Act_Gray_Small_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'Act_Gray_Small_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'Act_Gray_Small_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'Act_Gray_Small_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'Act_Gray_Small_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'Act_Gray_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: 'Act_Gray_Small_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'cal_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 134,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 108,
              font_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 106,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 359,
              font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 393,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 161,
              y: 207,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 68,
              day_startY: 200,
              day_sc_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              day_tc_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              day_en_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 377,
              font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 275,
              font_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 410,
              y: 352,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 409,
              y: 319,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 241,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 221,
              pm_y: 241,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 396,
              second_startY: 263,
              second_array: ["Time_small_0.png","Time_small_1.png","Time_small_2.png","Time_small_3.png","Time_small_4.png","Time_small_5.png","Time_small_6.png","Time_small_7.png","Time_small_8.png","Time_small_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 262,
              minute_startY: 259,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 262,
              hour_startY: 171,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              // radius: 231,
              // angle: 150,
              // char_space_angle: 0,
              // unit: 'Dis_KM.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Act_Black_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = 'Act_Gray_Small_0.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = 'Act_Gray_Small_1.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = 'Act_Gray_Small_2.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = 'Act_Gray_Small_3.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = 'Act_Gray_Small_4.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = 'Act_Gray_Small_5.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = 'Act_Gray_Small_6.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = 'Act_Gray_Small_7.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = 'Act_Gray_Small_8.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = 'Act_Gray_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_distance_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: 'Act_Gray_Small_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              // radius: 231,
              // angle: 218,
              // char_space_angle: 0,
              // unit: 'cal_unit.png',
              // error_image: 'Act_Gray_Small_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = 'Act_Gray_Small_0.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = 'Act_Gray_Small_1.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = 'Act_Gray_Small_2.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = 'Act_Gray_Small_3.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = 'Act_Gray_Small_4.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = 'Act_Gray_Small_5.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = 'Act_Gray_Small_6.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = 'Act_Gray_Small_7.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = 'Act_Gray_Small_8.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = 'Act_Gray_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: 'Act_Gray_Small_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'cal_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 134,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 108,
              font_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 106,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 359,
              font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 393,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 161,
              y: 207,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 68,
              day_startY: 200,
              day_sc_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              day_tc_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              day_en_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 377,
              font_array: ["Act_Gray_Small_0.png","Act_Gray_Small_1.png","Act_Gray_Small_2.png","Act_Gray_Small_3.png","Act_Gray_Small_4.png","Act_Gray_Small_5.png","Act_Gray_Small_6.png","Act_Gray_Small_7.png","Act_Gray_Small_8.png","Act_Gray_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 275,
              font_array: ["Act_Black_0.png","Act_Black_1.png","Act_Black_2.png","Act_Black_3.png","Act_Black_4.png","Act_Black_5.png","Act_Black_6.png","Act_Black_7.png","Act_Black_8.png","Act_Black_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 410,
              y: 352,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 409,
              y: 319,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 241,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 221,
              pm_y: 241,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 396,
              second_startY: 263,
              second_array: ["Time_small_0.png","Time_small_1.png","Time_small_2.png","Time_small_3.png","Time_small_4.png","Time_small_5.png","Time_small_6.png","Time_small_7.png","Time_small_8.png","Time_small_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 262,
              minute_startY: 259,
              minute_array: ["Time_Gray_0.png","Time_Gray_1.png","Time_Gray_2.png","Time_Gray_3.png","Time_Gray_4.png","Time_Gray_5.png","Time_Gray_6.png","Time_Gray_7.png","Time_Gray_8.png","Time_Gray_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 262,
              hour_startY: 171,
              hour_array: ["Time_Gray_0.png","Time_Gray_1.png","Time_Gray_2.png","Time_Gray_3.png","Time_Gray_4.png","Time_Gray_5.png","Time_Gray_6.png","Time_Gray_7.png","Time_Gray_8.png","Time_Gray_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 231,
              w: 45,
              h: 47,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 398,
              y: 259,
              w: 59,
              h: 41,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 396,
              y: 311,
              w: 54,
              h: 54,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 123,
              w: 46,
              h: 51,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 104,
              w: 77,
              h: 47,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 394,
              w: 85,
              h: 75,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 382,
              w: 70,
              h: 32,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 333,
              w: 99,
              h: 37,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 271,
              w: 127,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 277,
              y: 418,
              w: 90,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 69,
              y: 196,
              w: 62,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 281,
              y: 360,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 169,
              y: 54,
              w: 130,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 296,
              y: 187,
              w: 81,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_ColorM();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 270,
              w: 81,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_ColorH();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 330;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 231));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 231));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 231));
                  // alignment = RIGHT
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 0) / 2;
                  normal_distance_TextCircle_angleOffset = -normal_distance_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_Black_0.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 398;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  let normal_calorie_TextCircle_unit_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 231));
                  normal_calorie_TextCircle_unit_angle = toDegree(Math.atan2(normal_calorie_TextCircle_unit_width/2, 231));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_calorie_TextCircle_unit_angle;
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_Gray_Small_0.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 330;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 231));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 231));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 231));
                  // alignment = RIGHT
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + (idle_distance_TextCircle_img_angle + idle_distance_TextCircle_unit_angle + 0) / 2;
                  idle_distance_TextCircle_angleOffset = -idle_distance_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_error_img_width / 2);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_Black_0.png');
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 398;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  let idle_calorie_TextCircle_unit_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 231));
                  idle_calorie_TextCircle_unit_angle = toDegree(Math.atan2(idle_calorie_TextCircle_unit_width/2, 231));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_calorie_TextCircle_unit_angle;
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_error_img_width / 2);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_Gray_Small_0.png');
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 36000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 800;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2*2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    if(timer_anim_rotate_2_mirror) {
                      anim_rotate_2_mirror()
                    } else {
                      anim_rotate_2_complete_call()
                    };
                    timer_anim_rotate_2_mirror = !timer_anim_rotate_2_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 650;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3*2) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    if(timer_anim_rotate_3_mirror) {
                      anim_rotate_3_mirror()
                    } else {
                      anim_rotate_3_complete_call()
                    };
                    timer_anim_rotate_3_mirror = !timer_anim_rotate_3_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 600;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4*2) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    if(timer_anim_rotate_4_mirror) {
                      anim_rotate_4_mirror()
                    } else {
                      anim_rotate_4_complete_call()
                    };
                    timer_anim_rotate_4_mirror = !timer_anim_rotate_4_mirror;
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}