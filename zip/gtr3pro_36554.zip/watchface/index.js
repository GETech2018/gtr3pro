﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_mirror = ''
        let normal_heart_rate_text_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 271,
              y: 28,
              src: 'can10.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 25,
              src: 'BT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 91,
              y: 133,
              src: 'alar8.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 210,
              month_sc_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_tc_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_en_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 249,
              day_startY: 204,
              day_sc_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              day_tc_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              day_en_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 210,
              week_en: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_tc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_sc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 198,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 259,
              font_array: ["numbers_weather_00.png","numbers_weather_01.png","numbers_weather_02.png","numbers_weather_03.png","numbers_weather_04.png","numbers_weather_05.png","numbers_weather_06.png","numbers_weather_07.png","numbers_weather_08.png","numbers_weather_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numbers_weather_C.png',
              unit_tc: 'numbers_weather_C.png',
              unit_en: 'numbers_weather_C.png',
              negative_image: 'negative.png',
              invalid_image: 'invalid.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 48,
              y: 175,
              image_array: ["clima01.png","clima02.png","clima03.png","clima04.png","clima05.png","clima06.png","clima07.png","clima08.png","clima09.png","clima10.png","clima11.png","clima12.png","clima13.png","clima14.png","clima15.png","clima16.png","clima17.png","clima18.png","clima19.png","clima20.png","clima21.png","clima22.png","clima23.png","clima24.png","clima25.png","clima26.png","clima27.png","clima28.png","clima29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 255,
              font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: 285,
              image_array: ["Battery_00.png","Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png","Battery_06.png","Battery_07.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 332,
              font_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Distance_dote.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 356,
              font_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 141,
              y: 296,
              image_array: ["steps_goal_00.png","steps_goal_01.png","steps_goal_02.png","steps_goal_03.png","steps_goal_04.png","steps_goal_05.png","steps_goal_06.png","steps_goal_07.png","steps_goal_08.png","steps_goal_09.png","steps_goal_9.png","steps_goal_10.png","steps_goal_11.png"],
              image_length: 13,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_heart_rate_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 121,
              // start_y: 361,
              // color: 0xFFCC0000,
              // lenght: 39,
              // line_width: 4,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 322,
              font_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 270,
              y: 122,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim_column",
              anim_fps: 8,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 115,
              hour_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 287,
              minute_startY: 115,
              minute_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0006.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 6,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 67,
              src: 'can10.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 247,
              y: 62,
              src: 'BT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 167,
              y: 67,
              src: 'alar8.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 207,
              month_sc_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_tc_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_en_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 249,
              day_startY: 205,
              day_sc_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              day_tc_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              day_en_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 207,
              week_en: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_tc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_sc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 198,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 255,
              font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 115,
              hour_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 287,
              minute_startY: 115,
              minute_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sharp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT DESC.,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT CONEC.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT DESC."});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT CONEC."});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 52,
              w: 60,
              h: 66,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 81,
              y: 129,
              w: 41,
              h: 41,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 367,
              y: 204,
              w: 103,
              h: 103,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 186,
              w: 103,
              h: 103,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 435,
              w: 103,
              h: 52,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 300,
              w: 103,
              h: 103,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 331,
              w: 103,
              h: 103,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 297,
              y: 50,
              w: 52,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 49,
              w: 52,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 134,
              y: 53,
              w: 52,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 121;
                  let start_y_normal_heart_rate = 361;
                  let lenght_ls_normal_heart_rate = 39;
                  let line_width_ls_normal_heart_rate = 4;
                  let color_ls_normal_heart_rate = 0xFFCC0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // normal_heart_rate_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_heart_rate_mirror = 121;
                  let start_y_normal_heart_rate_mirror = 361;
                  let lenght_ls_normal_heart_rate_mirror = -39;
                  let line_width_ls_normal_heart_rate_mirror =4;
                  let color_ls_normal_heart_rate_mirror = 0xFFCC0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw_mirror = start_x_normal_heart_rate_mirror;
                  let start_y_normal_heart_rate_draw_mirror = start_y_normal_heart_rate_mirror;
                  lenght_ls_normal_heart_rate_mirror = lenght_ls_normal_heart_rate_mirror * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw_mirror = lenght_ls_normal_heart_rate_mirror;
                  let line_width_ls_normal_heart_rate_draw_mirror = line_width_ls_normal_heart_rate_mirror;
                  if (lenght_ls_normal_heart_rate_mirror < 0){
                    lenght_ls_normal_heart_rate_draw_mirror = -lenght_ls_normal_heart_rate_mirror;
                    start_x_normal_heart_rate_draw_mirror = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw_mirror;
                  };
                  
                  normal_heart_rate_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw_mirror,
                    y: start_y_normal_heart_rate_draw_mirror,
                    w: lenght_ls_normal_heart_rate_draw_mirror,
                    h: line_width_ls_normal_heart_rate_draw_mirror,
                    color: color_ls_normal_heart_rate,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}