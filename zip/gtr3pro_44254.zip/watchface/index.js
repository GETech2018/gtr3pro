﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 344,
              y: 280,
              image_array: ["0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 289,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0151.png',
              unit_tc: '0151.png',
              unit_en: '0151.png',
              negative_image: 'MF_Small_Minus.png',
              invalid_image: 'MF_Small_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 120,
              month_startY: 133,
              month_sc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_tc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_en_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 304,
              y: 133,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 369,
              y: 353,
              src: '0016.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 359,
              src: '0017.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 150,
              day_sc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_tc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_en_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_zero: 1,
              day_space: 10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 298,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0015.png',
              center_x: 240,
              center_y: 341,
              x: 24,
              y: 74,
              start_angle: 272,
              end_angle: 448,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0014.png',
              center_x: 240,
              center_y: 341,
              x: 20,
              y: 97,
              start_angle: 271,
              end_angle: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 229,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 2,
              invalid_image: '0020.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 200,
              image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 270,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0033.png',
              unit_tc: '0033.png',
              unit_en: '0033.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0030.png',
              center_x: 111,
              center_y: 239,
              x: 19,
              y: 58,
              start_angle: 280,
              end_angle: 446,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0011.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 47,
              hour_posY: 158,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0012.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 44,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0013.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 49,
              second_posY: 252,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg030.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 344,
              y: 280,
              image_array: ["0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 289,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0151.png',
              unit_tc: '0151.png',
              unit_en: '0151.png',
              negative_image: 'MF_Small_Minus.png',
              invalid_image: 'MF_Small_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 120,
              month_startY: 133,
              month_sc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_tc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_en_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 304,
              y: 133,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 369,
              y: 353,
              src: '0016.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 359,
              src: '0017.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 150,
              day_sc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_tc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_en_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_zero: 1,
              day_space: 10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 298,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0015.png',
              center_x: 240,
              center_y: 341,
              x: 24,
              y: 74,
              start_angle: 272,
              end_angle: 448,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0014.png',
              center_x: 240,
              center_y: 341,
              x: 20,
              y: 97,
              start_angle: 271,
              end_angle: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 229,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 2,
              invalid_image: '0020.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 200,
              image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 270,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0033.png',
              unit_tc: '0033.png',
              unit_en: '0033.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0030.png',
              center_x: 111,
              center_y: 239,
              x: 19,
              y: 58,
              start_angle: 280,
              end_angle: 446,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0011.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 47,
              hour_posY: 158,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0012.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 44,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0013.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 49,
              second_posY: 252,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}