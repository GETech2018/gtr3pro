    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 19;
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 19;
        let normal_timerTextUpdate = undefined;
        let normal_month_TextRotate = new Array(2);
        let normal_month_TextRotate_ASCIIARRAY = new Array(10);
        let normal_month_TextRotate_img_width = 19;
        let normal_month_TextRotate_unit = null;
        let normal_month_TextRotate_unit_width = 4;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 19;
        let normal_day_TextRotate_unit = null;
        let normal_day_TextRotate_unit_width = 4;
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 67;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 67;
        let normal_digital_clock_img_time_AmPm = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_year_TextRotate = new Array(4);
        let idle_year_TextRotate_ASCIIARRAY = new Array(10);
        let idle_year_TextRotate_img_width = 19;
        let idle_timerTextUpdate = undefined;
        let idle_month_TextRotate = new Array(2);
        let idle_month_TextRotate_ASCIIARRAY = new Array(10);
        let idle_month_TextRotate_img_width = 19;
        let idle_month_TextRotate_unit = null;
        let idle_month_TextRotate_unit_width = 4;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 19;
        let idle_day_TextRotate_unit = null;
        let idle_day_TextRotate_unit_width = 4;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 67;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 67;
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 89,
              y: 392,
              src: 'alar10.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 359,
              y: 390,
              image_array: ["pwr_2.png","pwr_3.png","pwr_4.png","pwr_5.png","pwr_6.png","pwr_7.png","pwr_8.png","pwr_9.png","pwr_10.png","pwr_11.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 217,
              src: 'h_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 258,
              font_array: ["a10.png","a11.png","a12.png","a13.png","a14.png","a15.png","a16.png","a17.png","a18.png","a19.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 223,
              y: 217,
              image_array: ["h_01.png","h_02.png","h_03.png","h_04.png","h_05.png","h_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 406,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 340,
              // y: 328,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 15,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 340,
                center_y: 328,
                pos_x: 340,
                pos_y: 328,
                angle: 15,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 163,
              // y: 321,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -14,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 163,
                center_y: 321,
                pos_x: 163,
                pos_y: 321,
                angle: -14,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 120,
              // y: 334,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -14,
              // unit_en: 'point.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 120,
                center_y: 334,
                pos_x: 120,
                pos_y: 334,
                angle: -14,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_month_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 120,
              center_y: 334,
              pos_x: 120,
              pos_y: 334,
              angle: -14,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_month_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 75,
              // y: 345,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -14,
              // unit_en: 'point.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 75,
                center_y: 345,
                pos_x: 75,
                pos_y: 345,
                angle: -14,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 75,
              center_y: 345,
              pos_x: 75,
              pos_y: 345,
              angle: -14,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 124,
              font_array: ["a10.png","a11.png","a12.png","a13.png","a14.png","a15.png","a16.png","a17.png","a18.png","a19.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              negative_image: '0024.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 367,
              y: 103,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 80,
              // y: 198,
              // font_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -15,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '09.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 80,
                center_y: 198,
                pos_x: 80,
                pos_y: 198,
                angle: -15,
                src: '01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 403,
              // y: 197,
              // font_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 15,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '09.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 403,
                center_y: 197,
                pos_x: 403,
                pos_y: 197,
                angle: 15,
                src: '01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 278,
              am_y: 400,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 278,
              pm_y: 400,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 95,
              image_array: ["fase1.png","fase2.png","fase3.png","fase4.png","fase5.png","fase6.png","fase7.png","fase8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 193,
              y: 361,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 163,
              // y: 321,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -14,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 163,
                center_y: 321,
                pos_x: 163,
                pos_y: 321,
                angle: -14,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 120,
              // y: 334,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -14,
              // unit_en: 'point.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 120,
                center_y: 334,
                pos_x: 120,
                pos_y: 334,
                angle: -14,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_month_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 120,
              center_y: 334,
              pos_x: 120,
              pos_y: 334,
              angle: -14,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_month_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 75,
              // y: 345,
              // font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -14,
              // unit_en: 'point.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = '0114.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = '0115.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = '0116.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = '0117.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = '0118.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = '0119.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = '0120.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = '0121.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = '0122.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = '0123.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 75,
                center_y: 345,
                pos_x: 75,
                pos_y: 345,
                angle: -14,
                src: '0114.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_day_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 75,
              center_y: 345,
              pos_x: 75,
              pos_y: 345,
              angle: -14,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 143,
              // y: 194,
              // font_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -15,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = '01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = '02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = '03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = '04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = '05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = '06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = '07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = '08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = '09.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = '10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 143,
                center_y: 194,
                pos_x: 143,
                pos_y: 194,
                angle: -15,
                src: '01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 330,
              // y: 197,
              // font_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 15,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = '01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = '02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = '03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = '04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = '05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = '06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = '07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = '08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = '09.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = '10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 330,
                center_y: 197,
                pos_x: 330,
                pos_y: 197,
                angle: 15,
                src: '01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 290,
              am_y: 331,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 290,
              pm_y: 331,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Rush Off,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Rush On,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Rush Off"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Rush On"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 314,
              w: 142,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 393,
              w: 112,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 387,
              w: 112,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 322,
              w: 112,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 356,
              y: 200,
              w: 80,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 56,
              y: 200,
              w: 80,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 200,
              w: 80,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 112,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 112,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 340 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_rotate_string = parseInt(valueYear % 100).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_year_TextRotate_posOffset = normal_year_TextRotate_img_width * normal_year_rotate_string.length;
                  normal_year_TextRotate_posOffset = normal_year_TextRotate_posOffset + 1 * (normal_year_rotate_string.length - 1);
                  img_offset -= normal_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 163 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let valueMonth = timeNaw.month;
              let normal_month_rotate_string = parseInt(valueMonth).toString();
              normal_month_rotate_string = normal_month_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_month_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_rotate_string.length > 0 && normal_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_month_TextRotate_posOffset = normal_month_TextRotate_img_width * normal_month_rotate_string.length;
                  normal_month_TextRotate_posOffset = normal_month_TextRotate_posOffset + 1 * (normal_month_rotate_string.length - 1);
                  img_offset -= normal_month_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 120 + img_offset);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.SRC, normal_month_TextRotate_ASCIIARRAY[charCode]);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_month_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_month_TextRotate_unit.setProperty(hmUI.prop.POS_X, 120 + img_offset);
                  normal_month_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + 1 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 75 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_day_TextRotate_unit.setProperty(hmUI.prop.POS_X, 75 + img_offset);
                  normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + -4 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 80 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  normal_minute_TextRotate_posOffset = normal_minute_TextRotate_posOffset + -4 * (normal_minute_rotate_string.length - 1);
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 403 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let idle_year_rotate_string = parseInt(valueYear % 100).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_rotate_string.length > 0 && idle_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_year_TextRotate_posOffset = idle_year_TextRotate_img_width * idle_year_rotate_string.length;
                  idle_year_TextRotate_posOffset = idle_year_TextRotate_posOffset + 1 * (idle_year_rotate_string.length - 1);
                  img_offset -= idle_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 163 + img_offset);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.SRC, idle_year_TextRotate_ASCIIARRAY[charCode]);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_year_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let idle_month_rotate_string = parseInt(valueMonth).toString();
              idle_month_rotate_string = idle_month_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_month_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_rotate_string.length > 0 && idle_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_month_TextRotate_posOffset = idle_month_TextRotate_img_width * idle_month_rotate_string.length;
                  idle_month_TextRotate_posOffset = idle_month_TextRotate_posOffset + 1 * (idle_month_rotate_string.length - 1);
                  img_offset -= idle_month_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 120 + img_offset);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.SRC, idle_month_TextRotate_ASCIIARRAY[charCode]);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_month_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_month_TextRotate_unit.setProperty(hmUI.prop.POS_X, 120 + img_offset);
                  idle_month_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  idle_day_TextRotate_posOffset = idle_day_TextRotate_posOffset + 1 * (idle_day_rotate_string.length - 1);
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 75 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_day_TextRotate_unit.setProperty(hmUI.prop.POS_X, 75 + img_offset);
                  idle_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  idle_hour_TextRotate_posOffset = idle_hour_TextRotate_posOffset + -4 * (idle_hour_rotate_string.length - 1);
                  img_offset -= idle_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 143 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  idle_minute_TextRotate_posOffset = idle_minute_TextRotate_posOffset + -4 * (idle_minute_rotate_string.length - 1);
                  img_offset -= idle_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 330 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				autoToggleWeatherIcons();
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}