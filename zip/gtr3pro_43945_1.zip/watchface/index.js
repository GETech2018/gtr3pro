﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_font = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 343,
              year_startY: 220,
              year_sc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              year_tc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              year_en_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 99,
              y: 264,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 266,
              src: 'Sveglia_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 383,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 304,
              y: 304,
              image_array: ["Passi_00.png","Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 383,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 305,
              image_array: ["Cal_00.png","Cal_01.png","Cal_02.png","Cal_03.png","Cal_04.png","Cal_05.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 304,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: true,
              h_space: 3,
              dot_image: 'Sist_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 71,
              image_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 81,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Sist_13.png',
              unit_tc: 'Sist_13.png',
              unit_en: 'Sist_13.png',
              imperial_unit_sc: 'Sist_13.png',
              imperial_unit_tc: 'Sist_13.png',
              imperial_unit_en: 'Sist_13.png',
              negative_image: 'Sist_12.png',
              invalid_image: 'Sist_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 220,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 31,
              day_startY: 220,
              day_sc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              day_tc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              day_en_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 1,
              y: -4,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 102,
              y: 0,
              w: 302,
              h: 302,
              text_size: 20,
              char_space: 1,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -24,
              end_angle: 22,
              mode: 0,
              // radius: 151,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 306,
              y: 19,
              image_array: ["Batt_00.png","Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 2,
              w: 216,
              h: 216,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -21,
              end_angle: 99,
              mode: 0,
              // radius: 108,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 19,
              image_array: ["Cuore_00.png","Cuore_01.png","Cuore_02.png","Cuore_03.png","Cuore_04.png","Cuore_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 73,
              hour_startY: 118,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 266,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Lancetta_00.png',
              second_centerX: 377,
              second_centerY: 160,
              second_posX: 6,
              second_posY: 29,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 343,
              year_startY: 220,
              year_sc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              year_tc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              year_en_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 99,
              y: 264,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 266,
              src: 'Sveglia_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 383,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 304,
              y: 304,
              image_array: ["Passi_00.png","Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 383,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 305,
              image_array: ["Cal_00.png","Cal_01.png","Cal_02.png","Cal_03.png","Cal_04.png","Cal_05.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 304,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: true,
              h_space: 3,
              dot_image: 'Sist_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 71,
              image_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 81,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Sist_13.png',
              unit_tc: 'Sist_13.png',
              unit_en: 'Sist_13.png',
              imperial_unit_sc: 'Sist_13.png',
              imperial_unit_tc: 'Sist_13.png',
              imperial_unit_en: 'Sist_13.png',
              negative_image: 'Sist_12.png',
              invalid_image: 'Sist_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 220,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 31,
              day_startY: 220,
              day_sc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              day_tc_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              day_en_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 1,
              y: -4,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 102,
              y: 0,
              w: 302,
              h: 302,
              text_size: 20,
              char_space: 1,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -24,
              end_angle: 22,
              mode: 0,
              // radius: 151,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 306,
              y: 19,
              image_array: ["Batt_00.png","Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 2,
              w: 216,
              h: 216,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -21,
              end_angle: 99,
              mode: 0,
              // radius: 108,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 19,
              image_array: ["Cuore_00.png","Cuore_01.png","Cuore_02.png","Cuore_03.png","Cuore_04.png","Cuore_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 73,
              hour_startY: 118,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 266,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}