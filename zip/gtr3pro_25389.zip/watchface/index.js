﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 157,
              font_array: ["digital10_num_0.png","digital10_num_1.png","digital10_num_2.png","digital10_num_3.png","digital10_num_4.png","digital10_num_5.png","digital10_num_6.png","digital10_num_7.png","digital10_num_8.png","digital10_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital10_num_degree.png',
              unit_tc: 'digital10_num_degree.png',
              unit_en: 'digital10_num_degree.png',
              negative_image: 'digital10_num_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 17,
              image_array: ["w001.png","w002.png","w003.png","w004.png","w005.png","w006.png","w007.png","w008.png","w009.png","w010.png","w011.png","w012.png","w013.png","w014.png","w015.png","w016.png","w017.png","w018.png","w019.png","w020.png","w021.png","w022.png","w023.png","w024.png","w025.png","w026.png","w027.png","w028.png","w029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 24,
              y: 151,
              image_array: ["digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 20,
              y: 250,
              src: 'digital12_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 285,
              font_array: ["digital9_num_0.png","digital9_num_1.png","digital9_num_2.png","digital9_num_3.png","digital9_num_4.png","digital9_num_5.png","digital9_num_6.png","digital9_num_7.png","digital9_num_8.png","digital9_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 414,
              y: 254,
              src: 'battery5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 285,
              font_array: ["digital9_num_0.png","digital9_num_1.png","digital9_num_2.png","digital9_num_3.png","digital9_num_4.png","digital9_num_5.png","digital9_num_6.png","digital9_num_7.png","digital9_num_8.png","digital9_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital9_percent.png',
              unit_tc: 'digital9_percent.png',
              unit_en: 'digital9_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 423,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_06.png","weekday_07.png","weekday_05i.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_06.png","weekday_07.png","weekday_05i.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_06.png","weekday_07.png","weekday_05i.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 253,
              year_startY: 388,
              year_sc_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              year_tc_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              year_en_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              year_zero: 1,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 388,
              month_sc_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              month_tc_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              month_en_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'date_num_colon.png',
              month_unit_tc: 'date_num_colon.png',
              month_unit_en: 'date_num_colon.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 388,
              day_sc_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              day_tc_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              day_en_array: ["date_num_0.png","date_num_1.png","date_num_2.png","date_num_3.png","date_num_4.png","date_num_5.png","date_num_6.png","date_num_7.png","date_num_8.png","date_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'date_num_colon.png',
              day_unit_tc: 'date_num_colon.png',
              day_unit_en: 'date_num_colon.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 276,
              font_array: ["digital7_num_0.png","digital7_num_1.png","digital7_num_2.png","digital7_num_3.png","digital7_num_4.png","digital7_num_5.png","digital7_num_6.png","digital7_num_7.png","digital7_num_8.png","digital7_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 280,
              src: 'step4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 133,
              hour_startY: 328,
              hour_array: ["Hm_num_0.png","Hm_num_1.png","Hm_num_2.png","Hm_num_3.png","Hm_num_4.png","Hm_num_5.png","Hm_num_6.png","Hm_num_7.png","Hm_num_8.png","Hm_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'Hm_num_colon.png',
              hour_unit_tc: 'Hm_num_colon.png',
              hour_unit_en: 'Hm_num_colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Hm_num_0.png","Hm_num_1.png","Hm_num_2.png","Hm_num_3.png","Hm_num_4.png","Hm_num_5.png","Hm_num_6.png","Hm_num_7.png","Hm_num_8.png","Hm_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  