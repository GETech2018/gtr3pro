﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bgblack.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 180,
              year_startY: 132,
              year_sc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              year_tc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              year_en_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 36,
              y: 176,
              src: '0595.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 176,
              src: '0596.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 407,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 362,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'btmdata_101.png',
              unit_tc: 'btmdata_101.png',
              unit_en: 'btmdata_101.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 315,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 0,
              image_array: ["right_0.png","right_1.png","right_2.png","right_3.png","right_4.png","right_5.png","right_6.png","right_7.png","right_8.png","right_9.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 407,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 362,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'btmdata_102.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 315,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["left_0.png","left_1.png","left_2.png","left_3.png","left_4.png","left_5.png","left_6.png","left_7.png","left_8.png","left_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 130,
              month_startY: 132,
              month_sc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              month_tc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              month_en_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'updata_203.png',
              month_unit_tc: 'updata_203.png',
              month_unit_en: 'updata_203.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 80,
              day_startY: 132,
              day_sc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              day_tc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              day_en_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'updata_203.png',
              day_unit_tc: 'updata_203.png',
              day_unit_en: 'updata_203.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 66,
              y: 94,
              week_en: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              week_tc: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              week_sc: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 45,
              font_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'updata_202.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 45,
              font_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'updata_202.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 78,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 132,
              font_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'updata_201.png',
              unit_tc: 'updata_201.png',
              unit_en: 'updata_201.png',
              negative_image: 'updata_204.png',
              invalid_image: 'updata_204.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 132,
              font_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'updata_201.png',
              unit_tc: 'updata_201.png',
              unit_en: 'updata_201.png',
              negative_image: 'updata_204.png',
              invalid_image: 'updata_204.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 92,
              font_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'updata_201.png',
              unit_tc: 'updata_201.png',
              unit_en: 'updata_201.png',
              negative_image: 'updata_204.png',
              invalid_image: 'updata_204.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,
              y: 163,
              w: 160,
              h: 39,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 198,
              hour_array: ["hm_00.png","hm_01.png","hm_02.png","hm_03.png","hm_04.png","hm_05.png","hm_06.png","hm_07.png","hm_08.png","hm_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 198,
              minute_array: ["hm_00.png","hm_01.png","hm_02.png","hm_03.png","hm_04.png","hm_05.png","hm_06.png","hm_07.png","hm_08.png","hm_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 325,
              second_startY: 198,
              second_array: ["ss_00.png","ss_01.png","ss_02.png","ss_03.png","ss_04.png","ss_05.png","ss_06.png","ss_07.png","ss_08.png","ss_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 198,
              src: 'dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 296,
              y: 198,
              src: 'ss_101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 270,
              year_startY: 132,
              year_sc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              year_tc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              year_en_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 362,
              font_array: ["btmdata_00.png","btmdata_01.png","btmdata_02.png","btmdata_03.png","btmdata_04.png","btmdata_05.png","btmdata_06.png","btmdata_07.png","btmdata_08.png","btmdata_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'btmdata_101.png',
              unit_tc: 'btmdata_101.png',
              unit_en: 'btmdata_101.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 132,
              month_sc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              month_tc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              month_en_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'updata_203.png',
              month_unit_tc: 'updata_203.png',
              month_unit_en: 'updata_203.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 132,
              day_sc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              day_tc_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              day_en_array: ["updata_00.png","updata_01.png","updata_02.png","updata_03.png","updata_04.png","updata_05.png","updata_06.png","updata_07.png","updata_08.png","updata_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'updata_203.png',
              day_unit_tc: 'updata_203.png',
              day_unit_en: 'updata_203.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 154,
              y: 94,
              week_en: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              week_tc: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              week_sc: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 185,
              hour_array: ["hm_00.png","hm_01.png","hm_02.png","hm_03.png","hm_04.png","hm_05.png","hm_06.png","hm_07.png","hm_08.png","hm_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 185,
              minute_array: ["hm_00.png","hm_01.png","hm_02.png","hm_03.png","hm_04.png","hm_05.png","hm_06.png","hm_07.png","hm_08.png","hm_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 325,
              second_startY: 185,
              second_array: ["ss_00.png","ss_01.png","ss_02.png","ss_03.png","ss_04.png","ss_05.png","ss_06.png","ss_07.png","ss_08.png","ss_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 185,
              src: 'dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 296,
              y: 185,
              src: 'ss_101.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}