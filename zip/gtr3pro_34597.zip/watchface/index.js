﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let calendar_btn = ''
		let battery_btn = ''
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 7
		let btnchangehands = ''
        let handsnumber = 0
        let totalhands = 6

        function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
                 if(colornumber==2) hmUI.showToast({text: 'R E D'});
				 if(colornumber==3) hmUI.showToast({text: 'G R E E N'});
                 if(colornumber==4) hmUI.showToast({text: 'B L U E'});
				 if(colornumber==5) hmUI.showToast({text: 'Y E L L O W'});
                 if(colornumber==6) hmUI.showToast({text: 'O R A N G E'});
				 if(colornumber==7) hmUI.showToast({text: 'C O L O R L E S S'});
            }
            if(colornumber==1) hmUI.showToast({text: 'C Y A N'});
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber) + ".png");
			call_change_Hands();
        }

        function call_change_Hands() {
              if(colornumber==1) {
                ChangeHands(0);
              } else if(colornumber==2) {
                ChangeHands(1);
              } else if(colornumber==3) {
                ChangeHands(2);
              } else if(colornumber==4) {
                ChangeHands(3);
			  } else if(colornumber==5) {
                ChangeHands(4);
			  } else if(colornumber==6) {
                ChangeHands(5);
              } else if(colornumber==7) {
                ChangeHands(6);
              }
        }

        function click_Changehands() {
          handsnumber=handsnumber+1;
          switch (handsnumber) {
            case 1:
              ChangeHands(1); break;
            case 2:
              ChangeHands(2); break;
            case 3:
              ChangeHands(3); break;
            case 4:
              ChangeHands(4); break;
            case 5:
              ChangeHands(5); break;
			case 6:
              ChangeHands(6); break;
            default:
              ChangeHands(0); handsnumber=0;
          }
		  if(handsnumber==1) hmUI.showToast({text: 'Red Hands'});
		  if(handsnumber==2) hmUI.showToast({text: 'Green Hands'});
		  if(handsnumber==3) hmUI.showToast({text: 'Blue Hands'});
		  if(handsnumber==4) hmUI.showToast({text: 'Yellow Hands'});
		  if(handsnumber==5) hmUI.showToast({text: 'Orange Hands'});
		  if(handsnumber==6) hmUI.showToast({text: 'Colorless Hands'});
		  if(handsnumber==0) hmUI.showToast({text: 'Cyan Hands'});
        }

        // Give handsnumber. Must exist
        function ChangeHands(number) {
           if(number==0) {
                  hourstring='hand_hour1.png';
                  minutestring='hand_min1.png';
				  secondstring='hand_sec1.png';
             } else if(number==1) {
                  hourstring='hand_hour2.png';
                  minutestring='hand_min2.png';
				  secondstring='hand_sec2.png';
             } else if(number==2) {
                  hourstring='hand_hour3.png';
                  minutestring='hand_min3.png';
				  secondstring='hand_sec3.png';
             } else if(number==3) {
                  hourstring='hand_hour4.png';
                  minutestring='hand_min4.png';
				  secondstring='hand_sec4.png';
             } else if(number==4) {
                  hourstring='hand_hour5.png';
                  minutestring='hand_min5.png';
				  secondstring='hand_sec5.png';
			 } else if(number==5) {
                  hourstring='hand_hour6.png';
                  minutestring='hand_min6.png';
				  secondstring='hand_sec6.png';
             } else if(number==6) {
                  hourstring='hand_hour7.png';
                  minutestring='hand_min7.png';
				  secondstring='hand_sec7.png';
             }
				  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: hourstring,
				  hour_centerX: 240,
				  hour_centerY: 240,
				  hour_posX: 240,
				  hour_posY: 240,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				  });

				  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
				  minute_path: minutestring,
				  minute_centerX: 240,
                  minute_centerY: 240,
                  minute_posX: 240,
                  minute_posY: 240,
				  show_level: hmUI.show_level.ONLY_NORMAL,
				  });
				  
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
				  second_path: secondstring,
				  second_centerX: 240,
                  second_centerY: 240,
                  second_posX: 240,
                  second_posY: 240,
				  second_cover_path: 'top1.png',
                  second_cover_x: 0,
                  second_cover_y: 0,
				  show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 336,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'num_12.png',
              unit_tc: 'num_12.png',
              unit_en: 'num_12.png',
              negative_image: 'num_13.png',
              invalid_image: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 310,
              image_array: ["0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 318,
              month_startY: 228,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 403,
              day_startY: 228,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 424,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 380,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 228,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_cover_path: 'top1.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 222,
              am_y: 265,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 222,
              pm_y: 265,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 184,
              hour_startY: 225,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 225,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -37,
              second_startY: 222,
              second_array: ["time_10.png","time_11.png","time_12.png","time_13.png","time_14.png","time_15.png","time_16.png","time_17.png","time_18.png","time_19.png"],
              second_zero: 1,
              second_space: 250,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 424,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_path: 'aod_top.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 222,
              am_y: 265,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 222,
              pm_y: 265,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 184,
              hour_startY: 225,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 225,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 231,
              y: 221,
              src: 'time_12.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 325,
              w: 100,
              h: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 370,
              w: 100,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 220,
              w: 100,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 45,
              text: '',
              w: 100,
              h: 100,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btnchangehands = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Changehands();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 325,
              y: 220,
			  text: '',
              w: 120,
              h: 40,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 420,
			  text: '',
              w: 100,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}