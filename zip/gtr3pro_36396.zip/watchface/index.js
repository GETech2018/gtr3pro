﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 21;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_year_TextRotate = new Array(4);
        let idle_year_TextRotate_ASCIIARRAY = new Array(10);
        let idle_year_TextRotate_img_width = 21;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 393,
              y: 359,
              src: '0029.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 364,
              src: '0027.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 409,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 116,
              y: 410,
              src: '0093.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 345,
              // y: 368,
              // font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '0014.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '0015.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '0016.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '0017.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '0018.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '0019.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '0020.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '0021.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '0022.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '0023.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 345,
                center_y: 368,
                pos_x: 345,
                pos_y: 368,
                angle: 0,
                src: '0014.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 368,
              month_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 363,
              src: '0026.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 368,
              day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 363,
              src: '0026.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 356,
              week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 320,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0031.png',
              unit_tc: '0031.png',
              unit_en: '0031.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 320,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 320,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 320,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 320,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0034.png',
              unit_tc: '0034.png',
              unit_en: '0034.png',
              negative_image: '0033.png',
              invalid_image: '0025.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 227,
              am_y: 8,
              am_sc_path: '0042.png',
              am_en_path: '0042.png',
              pm_x: 227,
              pm_y: 8,
              pm_sc_path: '0043.png',
              pm_en_path: '0043.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 32,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 249,
              minute_startY: 31,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Segn6.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 66,
              second_posY: 287,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 345,
              // y: 368,
              // font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextRotate_ASCIIARRAY[0] = '0014.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[1] = '0015.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[2] = '0016.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[3] = '0017.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[4] = '0018.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[5] = '0019.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[6] = '0020.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[7] = '0021.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[8] = '0022.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[9] = '0023.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 345,
                center_y: 368,
                pos_x: 345,
                pos_y: 368,
                angle: 0,
                src: '0014.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 368,
              month_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 363,
              src: '0026.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 368,
              day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 363,
              src: '0026.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 356,
              week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 320,
              font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0031.png',
              unit_tc: '0031.png',
              unit_en: '0031.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 227,
              am_y: 8,
              am_sc_path: '0042.png',
              am_en_path: '0042.png',
              pm_x: 227,
              pm_y: 8,
              pm_sc_path: '0043.png',
              pm_en_path: '0043.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 32,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 249,
              minute_startY: 31,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 408,
              w: 111,
              h: 72,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 389,
              y: 148,
              w: 93,
              h: 206,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 144,
              w: 93,
              h: 206,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 143,
              w: 93,
              h: 206,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 148,
              w: 82,
              h: 201,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 144,
              w: 78,
              h: 205,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '01.png',
              normal_src: '01.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: 95,
              w: 67,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '01.png',
              normal_src: '01.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {

              console.log('update text rotate year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_year_TextRotate_posOffset = normal_year_TextRotate_img_width * normal_year_rotate_string.length;
                  img_offset -= normal_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 345 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let idle_year_rotate_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_rotate_string.length > 0 && idle_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_year_TextRotate_posOffset = idle_year_TextRotate_img_width * idle_year_rotate_string.length;
                  img_offset -= idle_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 345 + img_offset);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.SRC, idle_year_TextRotate_ASCIIARRAY[charCode]);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}