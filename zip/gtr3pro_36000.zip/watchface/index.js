﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 87;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 106;
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FondHalloween.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 285,
              week_en: ["J1.png","J2.png","J3.png","J4.png","J5.png","J6.png","J7.png"],
              week_tc: ["J1.png","J2.png","J3.png","J4.png","J5.png","J6.png","J7.png"],
              week_sc: ["J1.png","J2.png","J3.png","J4.png","J5.png","J6.png","J7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 330,
              day_sc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_tc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_en_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_zero: 1,
              day_space: -30,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 78,
              month_startY: 377,
              month_sc_array: ["Mois01.png","Mois02.png","Mois03.png","Mois04.png","Mois05.png","Mois06.png","Mois07.png","Mois08.png","Mois09.png","Mois10.png","Mois11.png","Mois12.png"],
              month_tc_array: ["Mois01.png","Mois02.png","Mois03.png","Mois04.png","Mois05.png","Mois06.png","Mois07.png","Mois08.png","Mois09.png","Mois10.png","Mois11.png","Mois12.png"],
              month_en_array: ["Mois01.png","Mois02.png","Mois03.png","Mois04.png","Mois05.png","Mois06.png","Mois07.png","Mois08.png","Mois09.png","Mois10.png","Mois11.png","Mois12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 212,
              // y: 96,
              // font_array: ["H2.0.png","H2.1.png","H2.2.png","H2.3.png","H2.4.png","H2.5.png","H2.6.png","H2.7.png","H2.8.png","H2.9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 309,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'H2.0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'H2.1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'H2.2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'H2.3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'H2.4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'H2.5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'H2.6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'H2.7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'H2.8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'H2.9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 212,
                center_y: 96,
                pos_x: 212,
                pos_y: 96,
                angle: 0,
                src: 'H2.0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 427,
              // y: 76,
              // font_array: ["M2.0.png","M2.1.png","M2.2.png","M2.3.png","M2.4.png","M2.5.png","M2.6.png","M2.7.png","M2.8.png","M2.9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 515,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'M2.0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'M2.1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'M2.2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'M2.3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'M2.4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'M2.5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'M2.6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'M2.7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'M2.8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'M2.9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 427,
                center_y: 76,
                pos_x: 427,
                pos_y: 76,
                angle: 0,
                src: 'M2.0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 83,
              hour_array: ["H1.0.png","H1.1.png","H1.2.png","H1.3.png","H1.4.png","H1.5.png","H1.6.png","H1.7.png","H1.8.png","H1.9.png"],
              hour_zero: 1,
              hour_space: 515,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 228,
              minute_startY: 147,
              minute_array: ["M1.0.png","M1.1.png","M1.2.png","M1.3.png","M1.4.png","M1.5.png","M1.6.png","M1.7.png","M1.8.png","M1.9.png"],
              minute_zero: 1,
              minute_space: 309,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["S0.png","S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png","S8.png","S9.png"],
              second_zero: 0,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function text_update() {

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + 309 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 212 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 309;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  normal_minute_TextRotate_posOffset = normal_minute_TextRotate_posOffset + 515 * (normal_minute_rotate_string.length - 1);
                  img_offset -= normal_minute_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 427 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 515;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}