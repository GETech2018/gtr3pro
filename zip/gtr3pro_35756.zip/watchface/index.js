﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        // start user_functions.js
		let colornumber_main = 1
        let totalcolors_main = 9
        let namecolor_main = ''
		let secstring = 't_sec1.png'
		let datestring = 'date1.png'
		let pointerstring = 'pointer1.png'

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "RED STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}


			if ( colornumber_main == 2) { namecolor_main = "CYAN STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 3) { namecolor_main = "ORANGE STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 4) { namecolor_main = " BLUE STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 5) { namecolor_main = "YELLOW STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 6) { namecolor_main = "FUCHSIA STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 7) { namecolor_main = "GREEN STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 8) { namecolor_main = "PURPLE STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 9) { namecolor_main = "COLORLESS"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main <= 9) { 
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: datestring,
              center_x: 239,
              center_y: 358,
              posX: 21,
              posY: 47,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 134,
              center_y: 229,
              x: 25,
              y: 68,
              start_angle: -15,
              end_angle: 107,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 345,
              center_y: 229,
              x: 25,
              y: 68,
              start_angle: -70,
              end_angle: 110,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			}

			hmUI.showToast({text: namecolor_main });
            normal_battery_icon_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
         
        }
		
		let modenumber_main = 1
        let totalmode_main = 2
        let namemode_main = ''
		
		function click_Mode() {
            if(modenumber_main>=totalmode_main) {
            modenumber_main=1;
                }
            else {
                modenumber_main=modenumber_main+1;
            }
			
			if ( modenumber_main == 1) { namemode_main = "LIGHT MODE"
			}

			if ( modenumber_main == 2) { namemode_main = "DARK MODE"
			}
			
			hmUI.showToast({text: namemode_main });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(modenumber_main) + ".png");
         
        }
		
		let colornumber = 1
        let totalcolors = 9
		
		function click_Line() {
            if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
                 if(colornumber==2) hmUI.showToast({text: 'RED LINES'});
				 if(colornumber==3) hmUI.showToast({text: 'LIGHT LINES'});
                 if(colornumber==4) hmUI.showToast({text: 'CYAN LINES'});
				 if(colornumber==5) hmUI.showToast({text: 'GREEN LINES'});
                 if(colornumber==6) hmUI.showToast({text: 'BLUE LINES'});
				 if(colornumber==7) hmUI.showToast({text: 'ORANGE LINES'});
				 if(colornumber==8) hmUI.showToast({text: 'PURPLE LINES'});
				 if(colornumber==9) hmUI.showToast({text: 'YELLOW LINES'});
            }
            if(colornumber==1) hmUI.showToast({text: 'DARK LINES'});
            normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "line" + parseInt(colornumber) + ".png");
        }
		
		
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 18;
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 18;
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_moon_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 369,
              // y: 357,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 369,
                center_y: 357,
                pos_x: 369,
                pos_y: 357,
                angle: 45,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'line1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 329,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date1.png',
              center_x: 239,
              center_y: 358,
              posX: 21,
              posY: 47,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 335,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 363,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 258,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer1.png',
              center_x: 134,
              center_y: 229,
              x: 25,
              y: 68,
              start_angle: -15,
              end_angle: 107,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 258,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer1.png',
              center_x: 345,
              center_y: 229,
              x: 25,
              y: 68,
              start_angle: -70,
              end_angle: 110,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 71,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 't_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color9.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 369,
              // y: 357,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 369,
                center_y: 357,
                pos_x: 369,
                pos_y: 357,
                angle: 45,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'line3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 329,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date9.png',
              center_x: 239,
              center_y: 358,
              posX: 21,
              posY: 47,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 335,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 363,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 258,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer9.png',
              center_x: 134,
              center_y: 229,
              x: 25,
              y: 68,
              start_angle: -15,
              end_angle: 107,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 258,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer9.png',
              center_x: 345,
              center_y: 229,
              x: 25,
              y: 68,
              start_angle: -70,
              end_angle: 110,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 71,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_t_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 205,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 159,
              w: 90,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 230,
              w: 90,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 159,
              w: 90,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 230,
              w: 90,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 320,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 345,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 345,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 65,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 76,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 5,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Mode();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 65,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Line();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            function text_update() {

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -1 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 369 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -1 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 369 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}