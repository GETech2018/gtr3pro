﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
        let colornumber_bezel = 1
        let totalcolors_bezel = 9
        let namecolor_bezel = ''
		
		function click_Bezel() {
            if(colornumber_bezel>=totalcolors_bezel) {
            colornumber_bezel=1;
                }
            else {
                colornumber_bezel=colornumber_bezel+1;
            }
			if ( colornumber_bezel == 1) { namecolor_bezel = "BEZEL 1/9"}
			if ( colornumber_bezel == 2) { namecolor_bezel = "BEZEL 2/9"}
			if ( colornumber_bezel == 3) { namecolor_bezel = "BEZEL 3/9"}
			if ( colornumber_bezel == 4) { namecolor_bezel = "BEZEL 4/9"}
			if ( colornumber_bezel == 5) { namecolor_bezel = "BEZEL 5/9"}
			if ( colornumber_bezel == 6) { namecolor_bezel = "BEZEL 6/9"}
			if ( colornumber_bezel == 7) { namecolor_bezel = "BEZEL 7/9"}
			if ( colornumber_bezel == 8) { namecolor_bezel = "BEZEL 8/9"}
			if ( colornumber_bezel == 9) { namecolor_bezel = "BEZEL 9/9"}

			hmUI.showToast({text: namecolor_bezel });
            normal_image_img.setProperty(hmUI.prop.SRC, "ring" + parseInt(colornumber_bezel) + ".png");
        }
		
		let colornumber_line = 1
        let totalcolors_line = 6
        let namecolor_line = ''
		
		function click_Lines() {
            if(colornumber_line>=totalcolors_line) {
            colornumber_line=1;
                }
            else {
                colornumber_line=colornumber_line+1;
            }
			if ( colornumber_line == 1) { namecolor_line = "LINES 1/6"}
			if ( colornumber_line == 2) { namecolor_line = "LINES 2/6"}
			if ( colornumber_line == 3) { namecolor_line = "LINES 3/6"}
			if ( colornumber_line == 4) { namecolor_line = "LINES 4/6"}
			if ( colornumber_line == 5) { namecolor_line = "LINES 5/6"}
			if ( colornumber_line == 6) { namecolor_line = "LINES 6/6"}

			hmUI.showToast({text: namecolor_line });
            normal_stress_icon_img.setProperty(hmUI.prop.SRC, "Lines" + parseInt(colornumber_line) + ".png");
        }

        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 3

        function click_Hands() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Smooth ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Smooth OFF'});
            if(elementnumber_1==3) hmUI.showToast({text: 'Hands OFF'});
        }

        // Smooth ON
        function UpdateElementeOne(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //Smooth OFF
        function UpdateElementeTwo(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //Turn OFF
        function UpdateElementeThree(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 10;
        let normal_sunrise_TextCircle_img_height = 14;
        let normal_sunrise_TextCircle_dot_width = 5;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 10;
        let normal_sunset_TextCircle_img_height = 14;
        let normal_sunset_TextCircle_dot_width = 5;
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_moon_icon_img = ''
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_TextCircle = new Array(2);
        let normal_month_TextCircle_ASCIIARRAY = new Array(10);
        let normal_month_TextCircle_img_width = 15;
        let normal_month_TextCircle_img_height = 19;
        let normal_timerTextUpdate = undefined;
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 15;
        let normal_day_TextCircle_img_height = 19;
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_stress_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 391,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              negative_image: 'small_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 391,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 186,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_km.png',
              unit_tc: 'num_km.png',
              unit_en: 'num_km.png',
              imperial_unit_sc: 'num_mil.png',
              imperial_unit_tc: 'num_mil.png',
              imperial_unit_en: 'num_mil.png',
              dot_image: 'num_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 222,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["steps_01.png","steps_02.png","steps_03.png","steps_04.png","steps_05.png","steps_06.png","steps_07.png","steps_08.png","steps_09.png","steps_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 158,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 135,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 222,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 186,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 158,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_12.png',
              unit_tc: 'num_12.png',
              unit_en: 'num_12.png',
              negative_image: 'num_11.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 112,
              y: 113,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 176,
              // angle: -16,
              // char_space_angle: 1,
              // dot_image: 'small_10.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 240 - 183,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 176,
              // angle: 16,
              // char_space_angle: 1,
              // dot_image: 'small_10.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 240 - 183,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weather_04.png',
              center_x: 240,
              center_y: 240,
              x: 23,
              y: 88,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 246,
              src: 'top_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'weather_29.png',
              center_x: 240,
              center_y: 240,
              x: 23,
              y: 88,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 92,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'wd.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: -7,
              end_angle: 45,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 126,
              // angle: 18,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_month_TextCircle_img_width / 2,
                pos_y: 240 - 135,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // radius: 126,
              // angle: -18,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_day_TextCircle_img_width / 2,
                pos_y: 240 - 135,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 293,
              hour_array: ["t_00.png","t_01.png","t_02.png","t_03.png","t_04.png","t_05.png","t_06.png","t_07.png","t_08.png","t_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 293,
              minute_array: ["t_00.png","t_01.png","t_02.png","t_03.png","t_04.png","t_05.png","t_06.png","t_07.png","t_08.png","t_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 311,
              second_startY: 293,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Lines1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hand_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 408,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'aod_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 293,
              hour_array: ["t_00.png","t_01.png","t_02.png","t_03.png","t_04.png","t_05.png","t_06.png","t_07.png","t_08.png","t_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 293,
              minute_array: ["t_00.png","t_01.png","t_02.png","t_03.png","t_04.png","t_05.png","t_06.png","t_07.png","t_08.png","t_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 265,
              w: 80,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 265,
              w: 80,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 340,
              w: 80,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 290,
              w: 80,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 90,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 0,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 400,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 400,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 0,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 140,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 260,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 260,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 140,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 50,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 50,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 350,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Lines();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 350,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Bezel();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Hands();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
		let cc = 0
			if (cc ==0 ){
			  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
		}
            // end user_script_end.js

            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -16;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 176));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 176));
                  // alignment = CENTER_H
                  let normal_sunrise_TextCircle_angleOffset = normal_sunrise_TextCircle_img_angle * (normal_sunrise_circle_string.length - 1);
                  normal_sunrise_TextCircle_angleOffset = normal_sunrise_TextCircle_angleOffset + 1 * (normal_sunrise_circle_string.length - 1) / 2;
                  char_Angle -= normal_sunrise_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'small_10.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 16;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 176));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 176));
                  // alignment = CENTER_H
                  let normal_sunset_TextCircle_angleOffset = normal_sunset_TextCircle_img_angle * (normal_sunset_circle_string.length - 1);
                  normal_sunset_TextCircle_angleOffset = normal_sunset_TextCircle_angleOffset + 1 * (normal_sunset_circle_string.length - 1) / 2;
                  char_Angle -= normal_sunset_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'small_10.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle month_TIME');
              let valueMonth = timeNaw.month;
              let normal_month_circle_string = parseInt(valueMonth).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 18;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_circle_string.length > 0 && normal_month_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_month_TextCircle_img_angle = 0;
                  let normal_month_TextCircle_dot_img_angle = 0;
                  normal_month_TextCircle_img_angle = toDegree(Math.atan2(normal_month_TextCircle_img_width/2, 126));
                  // alignment = CENTER_H
                  let normal_month_TextCircle_angleOffset = normal_month_TextCircle_img_angle * (normal_month_circle_string.length - 1);
                  normal_month_TextCircle_angleOffset = normal_month_TextCircle_angleOffset + -1 * (normal_month_circle_string.length - 1) / 2;
                  char_Angle -= normal_month_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_month_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_month_TextCircle_img_width / 2);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.SRC, normal_month_TextCircle_ASCIIARRAY[charCode]);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_month_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -18;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 126));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = normal_day_TextCircle_angleOffset + -1 * (normal_day_circle_string.length - 1) / 2;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}