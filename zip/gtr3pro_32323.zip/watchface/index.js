﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''

        let hands_toggle_btn = ''
        let hands_toggle_state = 0 // 0 - mini, 1 - maks
        let hands_state_txt = ''

        let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - smoth, 1 - normal
        let hands_smoth_state_txt = ''

        let bot_circle_btn = ''
        let bot_circle_state = 0 // 0 - батарея, 1 - влажность, 3- погода
        let bot_circle_state_txt = ''

        let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       // задержка между кликами в мс 
      
      //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------		
          function checkClicks() {

            switch(clicks) {
              case 1:
               //hmUI.showToast({ text: "Был 1 клик"});
               //click_Bezel();
               click_hands_Switcher();
             break;
              case 2:
                click_bot_hsmoth_Switcher(); // функции на двойной клик
             break;
             // case 3:
             //  toggleAODmode(); // функции на тройной клик
             //break;
             // case 4:
               // функции на 4-ной клик
             //break;
              default:
             break;
           }
            
           timer.stopTimer(delay_Timer);
           clicks = 0;

          }
            
        
      
              function getClick() {		
      
            clicks++;
            if(delay_Timer) timer.stopTimer(delay_Timer);
            delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
      
              }


        function click_bot_circle_Switcher() {

          let bot_circle_state_total = 3;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
                  normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
                  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                  normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                  bot_circle_state_txt = 'Батарея';
                  break;

              case 1:
                  normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
                  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                  normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
  
                  bot_circle_state_txt = 'Влажность';
                  break;

              case 2:
                  normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
                  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                  normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

                  bot_circle_state_txt = 'Погода';
                  break;

              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }

      function click_bot_hsmoth_Switcher() {

        let bot_hands_state_total = 2;

        hands_smoth_state = (hands_smoth_state + 1) % bot_hands_state_total;

        switch (hands_smoth_state) {

            case 0:
             // if (screenType == hmSetting.screen_type.WATCHFACE) {
             //   if (!normal_timerUpdateSecSmooth) {
             //     let animDelay = 0;
              //    let animRepeat = 1000/6;
              //    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
              //      time_update(false, false);
              //    }));  // end timer 
              //  };  // end timer check
              //};  // end screenType

              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

              hands_smoth_state_txt = 'Плавная стрелка';
                break;

            case 1:
              //if (normal_timerUpdateSecSmooth) {
             //   timer.stopTimer(normal_timerUpdateSecSmooth);
             //   normal_timerUpdateSecSmooth = undefined;
             // }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);

              hands_smoth_state_txt = 'Нормальная стрелка';
                break;

            default:
                break;
        }

        hmUI.showToast({ text: hands_smoth_state_txt });
      }

      function click_hands_Switcher() {
        let hands_toggle_total = 2;

        hands_toggle_state = (hands_toggle_state + 1) % hands_toggle_total;

        switch (hands_toggle_state) {
            case 0:

              normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                hour_path: '0002.png',
                hour_centerX: 240,
                hour_centerY: 240,
                hour_posX: 19,
                hour_posY: 170,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
  
              normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                minute_path: '0003.png',
                minute_centerX: 240,
                minute_centerY: 240,
                minute_posX: 27,
                minute_posY: 211,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
             break;

            case 1:
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: '0085.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 37,
              hour_posY: 154,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: '0086.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 29,
              minute_posY: 210,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;

            default:
                break;
        }
    }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 294,
              src: '0083.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 383,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 293,
              src: '0071.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 201,
              src: 'bat_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 352,
              // center_y: 188,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 79,
              // line_width: 5,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 136,
              font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0035.png',
              unit_tc: '0035.png',
              unit_en: '0035.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 352,
              center_y: 188,
              x: 26,
              y: 65,
              start_angle: -180,
              end_angle: 180,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 204,
              src: 'vlz_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 138,
              font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0035.png',
              unit_tc: '0035.png',
              unit_en: '0035.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 352,
              center_y: 188,
              x: 26,
              y: 65,
              start_angle: -180,
              end_angle: 180,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 206,
              font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0024.png',
              unit_tc: '0024.png',
              unit_en: '0024.png',
              negative_image: '0036.png',
              invalid_image: '0036.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 322,
              y: 139,
              image_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 239,
              src: '0068.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 209,
              font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 126,
              center_y: 190,
              x: 26,
              y: 64,
              start_angle: -62,
              end_angle: 119,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 407,
              src: '0069.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 314,
              font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 238,
              center_y: 360,
              x: 25,
              y: 65,
              start_angle: -150,
              end_angle: 150,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0005.png',
              center_x: 239,
              center_y: 238,
              posX: 38,
              posY: 238,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 340,
              week_en: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_tc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_sc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -86,
              day_startY: 352,
              day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_zero: 1,
              day_space: -16,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 342,
              hour_startY: 298,
              hour_array: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '0066.png',
              hour_unit_tc: '0066.png',
              hour_unit_en: '0066.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0002.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 19,
              hour_posY: 170,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 211,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 20,
              second_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0004.png',
              // center_x: 240,
              // center_y: 240,
              // x: 20,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 20,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: '0004.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 44,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  click_bot_circle_Switcher();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);
  
              normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
              normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            // START Calendar Shortcut
		        	normal_img_click_2 = hmUI.createWidget(hmUI.widget.IMG, {
               x: 68,
               y: 326,
               w: 100,
               h: 100,
               src: 'null.png',
               show_level: hmUI.show_level.ONLY_NORMAL,
               });
		          	normal_img_click_2.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
		          	hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
              });
            // END Calendar Shortcut					

            hands_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 195,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  getClick();
                  //click_hands_Switcher();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
          });
          hands_toggle_btn.setProperty(hmUI.prop.VISIBLE, true);

          //hands_smoth_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          //  x: 195,
          //  y: 0,
          //  text: '',
          //  w: 100,
          //  h: 45,
          //  normal_src: 'null.png',
          //  press_src: 'null.png',
          //  click_func: () => {
          //    click_bot_hsmoth_Switcher();
          //      vibro(9);
          //  },
          //  show_level: hmUI.show_level.ONLY_NORMAL,
        //});
        //hands_smoth_btn.setProperty(hmUI.prop.VISIBLE, true);

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0084.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 343,
              week_en: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_tc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_sc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -86,
              day_startY: 352,
              day_sc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_tc_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_en_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              day_zero: 1,
              day_space: -16,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 197,
              hour_startY: 361,
              hour_array: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '0066.png',
              hour_unit_tc: '0066.png',
              hour_unit_en: '0066.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0085.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 37,
              hour_posY: 154,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0086.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 29,
              minute_posY: 210,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 6,
              y: 6,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Нет связи,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Подключено,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Нет связи"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Подключено"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 334,
              y: 272,
              w: 100,
              h: 71,
              src: 'null.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 138,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 138,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
             normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 133,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 307,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -270;
                  let end_angle_normal_battery = 90;
                  let center_x_normal_battery = 352;
                  let center_y_normal_battery = 188;
                  let radius_normal_battery = 79;
                  let line_width_cs_normal_battery = 5;
                  let color_cs_normal_battery = 0xFFFF0000;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}