﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_distance_text_text_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 146,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 236,
              y: 197,
              src: '0046.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 287,
              src: '0045.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 266,
              y: 194,
              src: '0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 199,
              y: 197,
              src: '0044.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 8,
              y: 204,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: -1,
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 33,
              y: 164,
              src: 'SUN_0090.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 369,
              y: 204,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'sun_0068.png',
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 415,
              y: 164,
              src: 'SUN_0091.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 258,
              year_startY: 405,
              year_sc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              year_tc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              year_en_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 211,
              month_startY: 405,
              month_sc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              month_tc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              month_en_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0112.png',
              month_unit_tc: '0112.png',
              month_unit_en: '0112.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 166,
              day_startY: 405,
              day_sc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              day_tc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              day_en_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0112.png',
              day_unit_tc: '0112.png',
              day_unit_en: '0112.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 42,
              y: 224,
              week_en: ["day_0100.png","day_0101.png","day_0102.png","day_0103.png","day_0104.png","day_0105.png","day_0106.png"],
              week_tc: ["day_0100.png","day_0101.png","day_0102.png","day_0103.png","day_0104.png","day_0105.png","day_0106.png"],
              week_sc: ["day_0100.png","day_0101.png","day_0102.png","day_0103.png","day_0104.png","day_0105.png","day_0106.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 166,
              font_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              padding: false,
              h_space: -1,
              dot_image: '0112.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 55,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sun_0079.png',
              unit_tc: 'sun_0079.png',
              unit_en: 'sun_0079.png',
              negative_image: 'sun_0068.png',
              invalid_image: 'sun_0068.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 55,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sun_0079.png',
              unit_tc: 'sun_0079.png',
              unit_en: 'sun_0079.png',
              negative_image: 'sun_0068.png',
              invalid_image: 'sun_0068.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 114,
              font_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0033.png',
              unit_tc: '0033.png',
              unit_en: '0033.png',
              negative_image: '0032.png',
              invalid_image: '0032.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 47,
              image_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 319,
              y: 106,
              src: '0081.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 136,
              font_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 161,
              src: '0021.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 273,
              y: 84,
              image_array: ["kro_0.png","kro_1.png","kro_2.png","kro_3.png","kro_4.png","kro_5.png","kro_6.png","kro_7.png","kro_8.png","kro_9.png","kro_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 126,
              y: 93,
              src: '0019.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 130,
              font_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 84,
              image_array: ["kru_0.png","kru_1.png","kru_2.png","kru_3.png","kru_4.png","kru_5.png","kru_6.png","kru_7.png","kru_8.png","kru_9.png","kru_10.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 282,
              hour_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 282,
              minute_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              minute_zero: 1,
              minute_space: -9,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 298,
              second_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 302,
              src: '0111.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'TEX_0023.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 24,
              second_posY: 242,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 146,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 236,
              y: 197,
              src: '0046.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 287,
              src: '0045.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 266,
              y: 194,
              src: '0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 199,
              y: 197,
              src: '0044.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 8,
              y: 204,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: -1,
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 33,
              y: 164,
              src: 'SUN_0090.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 369,
              y: 204,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'sun_0068.png',
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 415,
              y: 164,
              src: 'SUN_0091.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 258,
              year_startY: 405,
              year_sc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              year_tc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              year_en_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 211,
              month_startY: 405,
              month_sc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              month_tc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              month_en_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0112.png',
              month_unit_tc: '0112.png',
              month_unit_en: '0112.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 166,
              day_startY: 405,
              day_sc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              day_tc_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              day_en_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0112.png',
              day_unit_tc: '0112.png',
              day_unit_en: '0112.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 42,
              y: 224,
              week_en: ["day_0100.png","day_0101.png","day_0102.png","day_0103.png","day_0104.png","day_0105.png","day_0106.png"],
              week_tc: ["day_0100.png","day_0101.png","day_0102.png","day_0103.png","day_0104.png","day_0105.png","day_0106.png"],
              week_sc: ["day_0100.png","day_0101.png","day_0102.png","day_0103.png","day_0104.png","day_0105.png","day_0106.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 166,
              font_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              padding: false,
              h_space: -1,
              dot_image: '0112.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 55,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sun_0079.png',
              unit_tc: 'sun_0079.png',
              unit_en: 'sun_0079.png',
              negative_image: 'sun_0068.png',
              invalid_image: 'sun_0068.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 55,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sun_0079.png',
              unit_tc: 'sun_0079.png',
              unit_en: 'sun_0079.png',
              negative_image: 'sun_0068.png',
              invalid_image: 'sun_0068.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 114,
              font_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0033.png',
              unit_tc: '0033.png',
              unit_en: '0033.png',
              negative_image: '0032.png',
              invalid_image: '0032.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 47,
              image_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 319,
              y: 106,
              src: '0081.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 136,
              font_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 161,
              src: '0021.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 273,
              y: 84,
              image_array: ["kro_0.png","kro_1.png","kro_2.png","kro_3.png","kro_4.png","kro_5.png","kro_6.png","kro_7.png","kro_8.png","kro_9.png","kro_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 126,
              y: 93,
              src: '0019.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 130,
              font_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 84,
              image_array: ["kru_0.png","kru_1.png","kru_2.png","kru_3.png","kru_4.png","kru_5.png","kru_6.png","kru_7.png","kru_8.png","kru_9.png","kru_10.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 282,
              hour_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 282,
              minute_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              minute_zero: 1,
              minute_space: -9,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 298,
              second_array: ["kro_Red_.0001.png","kro_Red_.0002.png","kro_Red_.0003.png","kro_Red_.0004.png","kro_Red_.0005.png","kro_Red_.0006.png","kro_Red_.0007.png","kro_Red_.0008.png","kro_Red_.0009.png","kro_Red_.0010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 302,
              src: '0111.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'TEX_0023.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 24,
              second_posY: 242,
              second_cover_path: 'tex_15.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  