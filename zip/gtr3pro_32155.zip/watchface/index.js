﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_pai_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_pai_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let timeSensor = ''

        let steps_mask_shadow_img = ''
        let pulse_mask_shadow_img = ''
        let bot_circle_btn = ''
        let circle_info_btn = ''
        let weather_btn = ''
        let weather_act_btn = ''
        let bg_toggle_btn = ''
        let hands_toggle_btn = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''


        let mask_pulse_txt_img = ''
        let mask_calendar_txt_img = ''
        let mask_digit_time_txt_img = ''

        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_calendar_jumpable_img_click = ''

        let bot_circle_state = 0 // 0 - calendar, 1 - pulse
        let bot_circle_state_txt = ''

        let weather_state = 0
        let weather_state_txt = ''

        let bg_toggle_state = 0 // 0 - white, 1 - black
        let bg_state_txt = ''

        let hands_toggle_state = 0 // 0 - yellow, 1 - gray
        let hands_state_txt = ''

        let normal_hand_second = 'hands_seconds_red.png';
        let normal_circle_second = 'circle_second_black_red.png';

        let step_goal = ''
        let step_goal_full_TXT = ''
        let step_goal_half_TXT = ''

        let test_btn = ''

        function click_hands_Switcher() {
          let hands_toggle_total = 3;

          hands_toggle_state = (hands_toggle_state + 1) % hands_toggle_total;

          switch (hands_toggle_state) {
              case 0:
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hands_hour_W.png',
                      hour_centerX: 240,
                      hour_centerY: 240,
                      hour_posX: 36,
                      hour_posY: 136,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'hands_minute_W.png',
                      minute_centerX: 240,
                      minute_centerY: 240,
                      minute_posX: 36,
                      minute_posY: 220,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  break;

              case 1:
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hands_hour_G.png',
                      hour_centerX: 240,
                      hour_centerY: 240,
                      hour_posX: 36,
                      hour_posY: 136,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'hands_minute_G.png',
                      minute_centerX: 240,
                      minute_centerY: 240,
                      minute_posX: 36,
                      minute_posY: 220,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  break;

              case 2:
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hands_hour.png',
                      hour_centerX: 240,
                      hour_centerY: 240,
                      hour_posX: 36,
                      hour_posY: 136,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'hands_minute.png',
                      minute_centerX: 240,
                      minute_centerY: 240,
                      minute_posX: 36,
                      minute_posY: 220,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  break;

              default:
                  break;
          }
      }

      function click_bot_circle_Switcher() {

          let bot_circle_state_total = 3;

          bot_circle_state = (bot_circle_state + 1) % bot_circle_state_total;

          switch (bot_circle_state) {

              case 0:
                  normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
                  mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

                  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
                  mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);

                  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                  mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, false);

                  bot_circle_state_txt = 'Режим календаря';
                  break;

              case 1:
                  normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
                  mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

                  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
                  mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

                  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                  mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, false);

                  bot_circle_state_txt = 'Режим пульса';
                  break;

              case 2:
                  normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
                  mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

                  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
                  mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

                  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                  mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_analog_clock_time_pointer_second_mini.setProperty(hmUI.prop.VISIBLE, true);

                  bot_circle_state_txt = 'Режим цифр. времени';
                  break;

              default:
                  break;
          }

          hmUI.showToast({ text: bot_circle_state_txt });
      }

      function click_weather_Switcher() {
        let weather_state_total = 3 // 0 - digit, 1 - ico, 2- luna

        weather_state = (weather_state + 1) % weather_state_total;

          switch (weather_state) {

        case 0:
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
              normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              weather_state_txt = 'Graphic weather';
          break;

        case 1:
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
              normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              weather_state_txt = 'Digit weather';
          break;

        case 2:
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            weather_state_txt = 'Luna';
          break;

      default:
          break;

    }

    hmUI.showToast({ text: weather_state_txt });
}
          

      function click_circle_appStart() {

          if (bot_circle_state == 0) {
              hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
          }
          if (bot_circle_state == 1) {
              hmApp.startApp({ appid: 1, url: 'heart_app_Screen', native: true });
          }
          if (bot_circle_state == 2) {
              hmApp.startApp({ appid: 1, url: 'AlarmInfoScreen', native: true });
          }
      }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'circle_second_black_red.png',
              // center_x: 240,
              // center_y: 240,
              // x: 154,
              // y: 154,
              // start_angle: 0,
              // end_angle: -360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 154,
              pos_y: 240 - 154,
              center_x: 240,
              center_y: 240,
              src: 'circle_second_black_red.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (-360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_black_red.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hands_small_black.png',
              center_x: 118,
              center_y: 246,
              x: 12,
              y: 58,
              start_angle: -128,
              end_angle: 126,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 278,
              font_array: ["diigits_red_medium_0.png","diigits_red_medium_1.png","diigits_red_medium_2.png","diigits_red_medium_3.png","diigits_red_medium_4.png","diigits_red_medium_5.png","diigits_red_medium_6.png","diigits_red_medium_7.png","diigits_red_medium_8.png","diigits_red_medium_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 346,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'dig_small_deg.png',
              unit_tc: 'dig_small_deg.png',
              unit_en: 'dig_small_deg.png',
              negative_image: 'dig_small_minus.png',
              invalid_image: 'dig_small_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 336,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 325,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 226,
              y: 324,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "pulse_red",
              anim_fps: 15,
              anim_size: 25,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            mask_pulse_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 245,
              src: 'mask_pulse_W.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);

            mask_calendar_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 245,
              src: 'mask_calendar_W.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            mask_calendar_txt_img.setProperty(hmUI.prop.VISIBLE, true);


            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 356,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 280,
              src: 'pulse_mask_shadow_red.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 90,
              // end_angle: -30,
              // radius: 110,
              // line_width: 8,
              // color: 0xFFE1451E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps_point_red.png',
              center_x: 240,
              center_y: 240,
              x: 0,
              y: 118,
              start_angle: 90,
              end_angle: -35,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 118,
              image_array: ["steps_mask_shadow.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 198,
              month_startY: 358,
              month_sc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_tc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_en_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 326,
              day_sc_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_tc_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_en_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
            //  x: 256,
            //  y: 245,
            //  src: 'mask_calendar_W.png',
            //  show_level: hmUI.show_level.ONLY_NORMAL,
            //});

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 282,
              week_en: ["weeks_red_1.png","weeks_red_2.png","weeks_red_3.png","weeks_red_4.png","weeks_red_5.png","weeks_red_6.png","weeks_red_7.png"],
              week_tc: ["weeks_red_1.png","weeks_red_2.png","weeks_red_3.png","weeks_red_4.png","weeks_red_5.png","weeks_red_6.png","weeks_red_7.png"],
              week_sc: ["weeks_red_1.png","weeks_red_2.png","weeks_red_3.png","weeks_red_4.png","weeks_red_5.png","weeks_red_6.png","weeks_red_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 214,
              hour_startY: 328,
              hour_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 214,
              minute_startY: 364,
              minute_array: ["dig_red_0.png", "dig_red_1.png", "dig_red_2.png", "dig_red_3.png", "dig_red_4.png", "dig_red_5.png", "dig_red_6.png", "dig_red_7.png", "dig_red_8.png", "dig_red_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 168,
              y: 282,
              src: 'clocks_mini_red.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              //x: 255,
              //y: 244,
              //src: 'mask_digit_time_W.png',
              //show_level: hmUI.show_level.ONLY_NORMAL,
            //});
            mask_digit_time_txt_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 245,
              src: 'mask_digit_time_W.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hands_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 36,
              hour_posY: 136,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hands_minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 36,
              minute_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hands_seconds_red.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 141,
              y: 238,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 79,
              y: 238,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hands_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 195,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'pst.png',
              press_src: 'pst.png',
              click_func: () => {
                  click_hands_Switcher();
                  vibro();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
          });
          hands_toggle_btn.setProperty(hmUI.prop.VISIBLE, true);

          weather_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 334,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'pst.png',
              press_src: 'pst.png',
              click_func: () => {
                  click_weather_Switcher();
                  vibro();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
          });
          weather_btn.setProperty(hmUI.prop.VISIBLE, true);

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

          weather_act_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 62,
            y: 311,
            text: '',
            w: 40,
            h: 40,
            normal_src: 'pst.png',
            press_src: 'pst.png',
            click_func: () => {
              hmApp.startApp({ url: "WeatherScreen", native: true });    
                vibro();
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        weather_act_btn.setProperty(hmUI.prop.VISIBLE, true);          

          bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 204,
            y: 390,
            text: '',
            w: 75,
            h: 75,
            normal_src: 'pst.png',
            press_src: 'pst.png',
            click_func: () => {
                click_bot_circle_Switcher();
                vibro();
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
            bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);

            normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
            mask_pulse_txt_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            mask_digit_time_txt_img.setProperty(hmUI.prop.VISIBLE, false);
           

            circle_info_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 320,
              text: '',
              w: 75,
              h: 75,
              normal_src: 'pst.png',
              press_src: 'pst.png',
              click_func: () => {
                 click_circle_appStart();

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
          });
          circle_info_btn.setProperty(hmUI.prop.VISIBLE, true);



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg_F.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hands_hour_G.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 36,
              hour_posY: 136,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hands_minute_G.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 36,
              minute_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hands_seconds_s.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 228,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = 0;
                  let end_angle_normal_step = -120;
                  let center_x_normal_step = 240;
                  let center_y_normal_step = 240;
                  let radius_normal_step = 114;
                  let line_width_cs_normal_step = 8;
                  let color_cs_normal_step = 0xFF0DCAF2;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                let secAngle = 0 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
