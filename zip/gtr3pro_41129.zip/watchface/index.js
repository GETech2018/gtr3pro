﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'skull-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 200,
              hour_array: ["uuu0.png","uuu1.png","uuu2.png","uuu3.png","uuu4.png","uuu5.png","uuu6.png","uuu7.png","uuu8.png","uuu9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 294,
              minute_startY: 200,
              minute_array: ["mmm0.png","mmm1.png","mmm2.png","mmm3.png","mmm4.png","mmm5.png","mmm6.png","mmm7.png","mmm8.png","mmm9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 314,
              second_startY: 252,
              second_array: ["sss0.png","sss1.png","sss2.png","sss3.png","sss4.png","sss5.png","sss6.png","sss7.png","sss8.png","sss9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'skull-back-night.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 200,
              hour_array: ["uuu0.png","uuu1.png","uuu2.png","uuu3.png","uuu4.png","uuu5.png","uuu6.png","uuu7.png","uuu8.png","uuu9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 294,
              minute_startY: 200,
              minute_array: ["mmm0.png","mmm1.png","mmm2.png","mmm3.png","mmm4.png","mmm5.png","mmm6.png","mmm7.png","mmm8.png","mmm9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 314,
              second_startY: 252,
              second_array: ["sss0.png","sss1.png","sss2.png","sss3.png","sss4.png","sss5.png","sss6.png","sss7.png","sss8.png","sss9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'skull-front.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 111,
              y: 343,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button.png',
              normal_src: 'button.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 343,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button.png',
              normal_src: 'button.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 425,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button.png',
              normal_src: 'button.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}