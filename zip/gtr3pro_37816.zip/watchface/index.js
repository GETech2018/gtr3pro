﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_pai_day_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let idle_background_bg_img = ''
        let editableTimePointers = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'B_01.png', path: 'B_01.png' },
                { id: 2, preview: 'B_02.png', path: 'B_02.png' },
                { id: 3, preview: 'B_03.png', path: 'B_03.png' },
                { id: 4, preview: 'B_04.png', path: 'B_04.png' },
                { id: 5, preview: 'B_05.png', path: 'B_05.png' },
                { id: 6, preview: 'B_06.png', path: 'B_06.png' },
                { id: 7, preview: 'B_07.png', path: 'B_07.png' },
              ],
              count: 7,
              default_id: 1,
              fg: 'Mask.png',
              tips_bg: 'Mask.png',
              tips_x: -103,
              tips_y: -103,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 127,
              font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 319,
              month_startY: 238,
              month_sc_array: ["m_01.png","m_02.png","m_03.png","m_04.png","m_05.png","m_06.png","m_07.png","m_08.png","m_09.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_01.png","m_02.png","m_03.png","m_04.png","m_05.png","m_06.png","m_07.png","m_08.png","m_09.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_01.png","m_02.png","m_03.png","m_04.png","m_05.png","m_06.png","m_07.png","m_08.png","m_09.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 252,
              y: 212,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 334,
              day_startY: 292,
              day_sc_array: ["d_01.png","d_02.png","d_03.png","d_04.png","d_05.png","d_06.png","d_07.png","d_08.png","d_09.png","d_10.png"],
              day_tc_array: ["d_01.png","d_02.png","d_03.png","d_04.png","d_05.png","d_06.png","d_07.png","d_08.png","d_09.png","d_10.png"],
              day_en_array: ["d_01.png","d_02.png","d_03.png","d_04.png","d_05.png","d_06.png","d_07.png","d_08.png","d_09.png","d_10.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 344,
              font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              padding: false,
              h_space: -2,
              negative_image: '0018.png',
              invalid_image: '0019.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 307,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 251,
              font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 134,
              center_y: 240,
              x: 10,
              y: 37,
              start_angle: 300,
              end_angle: 60,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_01.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_01.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_02.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_02.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_03.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_03.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_04.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_04.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_05.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_05.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_06.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_06.png',
                },
                {
                  id: 7,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 50,
                    posY: 235,
                    path: 'S_07.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 184,
                    path: '0003.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 44,
                    posY: 235,
                    path: '0004.png',
                  },
                  preview: 'Pr_07.png',
                },
              ],
              count: 7,
              default_id: 1,
              fg: 'frame.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: 'Mask.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}