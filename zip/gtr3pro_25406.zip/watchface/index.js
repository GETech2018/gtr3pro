﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_pai_day_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 45,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 117,
              src: 'pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 123,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 132,
              font_array: ["digital12_00.png","digital12_01.png","digital12_02.png","digital12_03.png","digital12_04.png","digital12_05.png","digital12_06.png","digital12_07.png","digital12_08.png","digital12_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'digital12_11.png',
              unit_tc: 'digital12_11.png',
              unit_en: 'digital12_11.png',
              negative_image: 'digital12_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 330,
              y: 45,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 338,
              src: 'bt01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 85,
              y: 338,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 59,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 16,
              image_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 362,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 252,
              y: 344,
              image_array: ["digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 362,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 345,
              image_array: ["digital2_00.png","digital2_01.png","digital2_02.png","digital2_03.png","digital2_04.png","digital2_05.png","digital2_06.png","digital2_07.png","digital2_08.png","digital2_09.png","digital2_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 291,
              font_array: ["digital12_00.png","digital12_01.png","digital12_02.png","digital12_03.png","digital12_04.png","digital12_05.png","digital12_06.png","digital12_07.png","digital12_08.png","digital12_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital12_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 291,
              month_sc_array: ["digital15_00.png","digital15_01.png","digital15_02.png","digital15_03.png","digital15_04.png","digital15_05.png","digital15_06.png","digital15_07.png","digital15_08.png","digital15_09.png","digital15_10.png","digital15_11.png"],
              month_tc_array: ["digital15_00.png","digital15_01.png","digital15_02.png","digital15_03.png","digital15_04.png","digital15_05.png","digital15_06.png","digital15_07.png","digital15_08.png","digital15_09.png","digital15_10.png","digital15_11.png"],
              month_en_array: ["digital15_00.png","digital15_01.png","digital15_02.png","digital15_03.png","digital15_04.png","digital15_05.png","digital15_06.png","digital15_07.png","digital15_08.png","digital15_09.png","digital15_10.png","digital15_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 138,
              day_startY: 291,
              day_sc_array: ["digital12_00.png","digital12_01.png","digital12_02.png","digital12_03.png","digital12_04.png","digital12_05.png","digital12_06.png","digital12_07.png","digital12_08.png","digital12_09.png"],
              day_tc_array: ["digital12_00.png","digital12_01.png","digital12_02.png","digital12_03.png","digital12_04.png","digital12_05.png","digital12_06.png","digital12_07.png","digital12_08.png","digital12_09.png"],
              day_en_array: ["digital12_00.png","digital12_01.png","digital12_02.png","digital12_03.png","digital12_04.png","digital12_05.png","digital12_06.png","digital12_07.png","digital12_08.png","digital12_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital12_10.png',
              day_unit_tc: 'digital12_10.png',
              day_unit_en: 'digital12_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 291,
              week_en: ["digital11_1.png","digital11_2.png","digital11_3.png","digital11_4.png","digital11_5.png","digital11_6.png","digital11_7.png"],
              week_tc: ["digital11_1.png","digital11_2.png","digital11_3.png","digital11_4.png","digital11_5.png","digital11_6.png","digital11_7.png"],
              week_sc: ["digital11_1.png","digital11_2.png","digital11_3.png","digital11_4.png","digital11_5.png","digital11_6.png","digital11_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 400,
              am_y: 244,
              am_sc_path: 'cam.png',
              am_en_path: 'cam.png',
              pm_x: 400,
              pm_y: 244,
              pm_sc_path: 'cpm.png',
              pm_en_path: 'cpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 189,
              hour_array: ["digital8_00.png","digital8_01.png","digital8_02.png","digital8_03.png","digital8_04.png","digital8_05.png","digital8_06.png","digital8_07.png","digital8_08.png","digital8_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'digital8_10.png',
              hour_unit_tc: 'digital8_10.png',
              hour_unit_en: 'digital8_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digital8_00.png","digital8_01.png","digital8_02.png","digital8_03.png","digital8_04.png","digital8_05.png","digital8_06.png","digital8_07.png","digital8_08.png","digital8_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 296,
              second_startY: 199,
              second_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  