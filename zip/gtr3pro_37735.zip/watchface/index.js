﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_circle_scale_mirror = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_battery_circle_scale = ''
        let normal_battery_circle_scale_mirror = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 349,
              // center_y: 248,
              // start_angle: -95,
              // end_angle: -265,
              // radius: 65,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFFBF80,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 248,
              start_angle: -95,
              end_angle: -265,
              radius: 59,
              line_width: 12,
              corner_flag: 1,
              color: 0xFFFFBF80,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 248,
              start_angle: -95,
              end_angle: 75,
              radius: 59,
              line_width: 12,
              corner_flag: 2,
              color: 0xFFFFBF80,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 250,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 286,
              y: 182,
              src: 'dial_100top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_thinarrow.png',
              center_x: 347,
              center_y: 239,
              x: 11,
              y: 51,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 132,
              // center_y: 248,
              // start_angle: -95,
              // end_angle: -265,
              // radius: 65,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFFC280,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 248,
              start_angle: -95,
              end_angle: -265,
              radius: 59,
              line_width: 12,
              corner_flag: 1,
              color: 0xFFFFC280,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 248,
              start_angle: -95,
              end_angle: 75,
              radius: 59,
              line_width: 12,
              corner_flag: 2,
              color: 0xFFFFC280,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 250,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 179,
              src: 'dial_100EF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_thinarrow.png',
              center_x: 133,
              center_y: 239,
              x: 11,
              y: 51,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_circlepin.png',
              center_x: 240,
              center_y: 127,
              posX: 16,
              posY: 70,
              start_angle: 0,
              end_angle: 360,
              scale_sc: 'dial_12.png',
              scale_tc: 'dial_12.png',
              scale_en: 'dial_12.png',
              scale_x: 166,
              scale_y: 53,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_smallpin.png',
              center_x: 240,
              center_y: 350,
              posX: 11,
              posY: 45,
              start_angle: 0,
              end_angle: 360,
              scale_sc: 'dial_31.png',
              scale_tc: 'dial_31.png',
              scale_en: 'dial_31.png',
              scale_x: 182,
              scale_y: 292,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointer_hours.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 17,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointer_minutes.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 206,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointer_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 18,
              second_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_dnd.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointer_hours_dnd.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 17,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointer_minutes_dnd.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 206,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 349,
                      center_y: 248,
                      start_angle: -95,
                      end_angle: -265,
                      radius: 59,
                      line_width: 12,
                      corner_flag: 1,
                      color: 0xFFFFBF80,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_heart_rate_circle_scale_mirror) {
                    normal_heart_rate_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 349,
                      center_y: 248,
                      start_angle: -95,
                      end_angle: 75,
                      radius: 59,
                      line_width: 12,
                      corner_flag: 2,
                      color: 0xFFFFBF80,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 248,
                      start_angle: -95,
                      end_angle: -265,
                      radius: 59,
                      line_width: 12,
                      corner_flag: 1,
                      color: 0xFFFFC280,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  if (normal_battery_circle_scale_mirror) {
                    normal_battery_circle_scale_mirror.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 248,
                      start_angle: -95,
                      end_angle: 75,
                      radius: 59,
                      line_width: 12,
                      corner_flag: 2,
                      color: 0xFFFFC280,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}