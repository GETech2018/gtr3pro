﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_system_disconnect_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stress_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_g_heart = ''
        let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/////////////////////  Show graph heart rate  /////////////////////

             normal_g_heart=hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{

                              x: 83,
                              y: 357,
                              w: 117,
                              h: 37,
                              line_color:0x1794B1,
                              line_width:1,
            type:hmUI.data_type.HEART,
            show_level:hmUI.show_level.ONLY_NORMAL
          })
 
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 155,
              font_array: ["digital11_0.png","digital11_1.png","digital11_2.png","digital11_3.png","digital11_4.png","digital11_5.png","digital11_6.png","digital11_7.png","digital11_8.png","digital11_9.png"], 
              padding: true,
              h_space: 0,
              dot_image: 'digital11_10.png',
			  invalid_image: 'off.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "A",
              anim_fps: 1,
              anim_size: 60,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 163,
              y: 411,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "A1",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 414,
              y: 298,
              src: '49.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 72,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 408,
              y: 251,
              font_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital5_11.png',
              unit_tc: 'digital5_11.png',
              unit_en: 'digital5_11.png',
              negative_image: 'digital5_10.png',
              invalid_image: 'digital5_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 415,
              y: 204,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 91,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital3_11.png',
              unit_tc: 'digital3_11.png',
              unit_en: 'digital3_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 295,
              image_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 317,
              image_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              image_length: 10,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 398,
              font_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 227,
              font_array: ["digital4_0.png","digital4_1.png","digital4_2.png","digital4_3.png","digital4_4.png","digital4_5.png","digital4_6.png","digital4_7.png","digital4_8.png","digital4_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital7_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 171,
              font_array: ["digital4_0.png","digital4_1.png","digital4_2.png","digital4_3.png","digital4_4.png","digital4_5.png","digital4_6.png","digital4_7.png","digital4_8.png","digital4_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 116,
              font_array: ["digital4_0.png","digital4_1.png","digital4_2.png","digital4_3.png","digital4_4.png","digital4_5.png","digital4_6.png","digital4_7.png","digital4_8.png","digital4_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 19,
              month_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 153,
              day_startY: 19,
              day_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 65,
              src: 'image3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 326,
              y: 50,
              week_en: ["digital12_0.png","digital12_1.png","digital12_2.png","digital12_3.png","digital12_4.png","digital12_5.png","digital12_6.png"],
              week_tc: ["digital12_0.png","digital12_1.png","digital12_2.png","digital12_3.png","digital12_4.png","digital12_5.png","digital12_6.png"],
              week_sc: ["digital12_0.png","digital12_1.png","digital12_2.png","digital12_3.png","digital12_4.png","digital12_5.png","digital12_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 146,
              hour_startY: 89,
              hour_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 282,
              minute_startY: 175,
              minute_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 378,
              y: 188,
              w: 100,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}