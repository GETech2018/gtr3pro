﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_altimeter_icon_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_temperature_icon_img = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 361,
              y: 58,
              src: '033.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 95,
              y: 60,
              src: '032.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 239,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 1,
              dot_image: '095.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 228,
              src: '100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 239,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 1,
              dot_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 228,
              src: '101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 294,
              y: 410,
              image_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 241,
              y: 374,
              week_en: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              week_tc: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              week_sc: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 366,
              month_startY: 377,
              month_sc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              month_tc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              month_en_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 373,
              src: '006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 309,
              day_startY: 377,
              day_sc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              day_tc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              day_en_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 337,
              src: '029.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 327,
              font_array: ["M_(0).png","M__(1).png","M__(2).png","M__(3).png","M__(4).png","M__(5).png","M__(6).png","M__(7).png","M__(8).png","M__(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 371,
              src: '006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 157,
              y: 419,
              w: 155,
              h: 31,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFF787878,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 377,
              font_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 377,
              font_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 281,
              font_array: ["M_(0).png","M__(1).png","M__(2).png","M__(3).png","M__(4).png","M__(5).png","M__(6).png","M__(7).png","M__(8).png","M__(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 284,
              image_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 327,
              font_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              padding: false,
              h_space: 0,
              dot_image: '005.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 328,
              src: '031.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 281,
              font_array: ["M_(0).png","M__(1).png","M__(2).png","M__(3).png","M__(4).png","M__(5).png","M__(6).png","M__(7).png","M__(8).png","M__(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 230,
              y: 290,
              image_array: ["065.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '018.png',
              center_x: 78,
              center_y: 126,
              x: 6,
              y: 28,
              start_angle: -121,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 201,
              font_array: ["W__(1).png","W__(2).png","W__(3).png","W__(4).png","W__(5).png","W__(6).png","W__(7).png","W__(8).png","W__(9).png","W__(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 232,
              src: '053.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '018.png',
              center_x: 401,
              center_y: 126,
              x: 6,
              y: 28,
              start_angle: -121,
              end_angle: 120,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 398,
              y: 201,
              font_array: ["W__(1).png","W__(2).png","W__(3).png","W__(4).png","W__(5).png","W__(6).png","W__(7).png","W__(8).png","W__(9).png","W__(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 404,
              y: 233,
              src: '054.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 237,
              hour_centerY: 129,
              hour_posX: 11,
              hour_posY: 101,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 238,
              minute_centerY: 129,
              minute_posX: 10,
              minute_posY: 118,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 238,
              second_centerY: 129,
              second_posX: 18,
              second_posY: 118,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 18,
              w: 201,
              h: 103,
              src: '133.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 128,
              w: 201,
              h: 89,
              src: '133.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 26,
              y: 0,
              w: 103,
              h: 103,
              src: '133.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 220,
              w: 256,
              h: 41,
              src: '133.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 323,
              w: 182,
              h: 45,
              src: '133.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 266,
              w: 124,
              h: 103,
              src: '133.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 91,
              w: 103,
              h: 175,
              src: '133.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 269,
              w: 181,
              h: 52,
              src: '133.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 361,
              y: 58,
              src: '033.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 95,
              y: 60,
              src: '032.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 239,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 1,
              dot_image: '095.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 228,
              src: '100.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 239,
              font_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png"],
              padding: false,
              h_space: 1,
              dot_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 228,
              src: '101.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 294,
              y: 410,
              image_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 241,
              y: 374,
              week_en: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              week_tc: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              week_sc: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 366,
              month_startY: 377,
              month_sc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              month_tc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              month_en_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 373,
              src: '006.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 309,
              day_startY: 377,
              day_sc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              day_tc_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              day_en_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 337,
              src: '029.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 327,
              font_array: ["M_(0).png","M__(1).png","M__(2).png","M__(3).png","M__(4).png","M__(5).png","M__(6).png","M__(7).png","M__(8).png","M__(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 371,
              src: '006.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 157,
              y: 419,
              w: 155,
              h: 31,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFF787878,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 377,
              font_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 377,
              font_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 281,
              font_array: ["M_(0).png","M__(1).png","M__(2).png","M__(3).png","M__(4).png","M__(5).png","M__(6).png","M__(7).png","M__(8).png","M__(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 284,
              image_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 327,
              font_array: ["S0_(0).png","S0_(2).png","S0_(3).png","S0_(4).png","S0_(5).png","S0_(6).png","S0_(7).png","S0_(8).png","S0_(9).png","S0_(91).png"],
              padding: false,
              h_space: 0,
              dot_image: '005.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 328,
              src: '031.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 281,
              font_array: ["M_(0).png","M__(1).png","M__(2).png","M__(3).png","M__(4).png","M__(5).png","M__(6).png","M__(7).png","M__(8).png","M__(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 230,
              y: 290,
              image_array: ["065.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '018.png',
              center_x: 78,
              center_y: 126,
              x: 6,
              y: 28,
              start_angle: -121,
              end_angle: 120,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 201,
              font_array: ["W__(1).png","W__(2).png","W__(3).png","W__(4).png","W__(5).png","W__(6).png","W__(7).png","W__(8).png","W__(9).png","W__(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 232,
              src: '053.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '018.png',
              center_x: 401,
              center_y: 126,
              x: 6,
              y: 28,
              start_angle: -121,
              end_angle: 120,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 398,
              y: 201,
              font_array: ["W__(1).png","W__(2).png","W__(3).png","W__(4).png","W__(5).png","W__(6).png","W__(7).png","W__(8).png","W__(9).png","W__(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 404,
              y: 233,
              src: '054.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 237,
              hour_centerY: 129,
              hour_posX: 11,
              hour_posY: 101,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 238,
              minute_centerY: 129,
              minute_posX: 10,
              minute_posY: 118,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 238,
              second_centerY: 129,
              second_posX: 18,
              second_posY: 118,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  