/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_digital_clock_img_hour = '';
		let normal_digital_clock_img_minute = '';
		let normal_digital_clock_img_second = '';
		let normal_date_img_date_week_img = '';
		let normal_date_current_date_monthday = '';
		let normal_date_img_date_month = '';
		let normal_battery_current_circle = '';
		let normal_battery_current_text_img = '';
		let normal_analog_clock_time_pointer_second = '';
		let normal_weather_image_progress_img_level = '';
		let normal_temperature_current_text_img = '';
		let normal_background_bg_img3 = '';
		let normal_background_bg_img4 = '';
		let normal_background_bg_img5 = '';
		let normal_background_bg_img6 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -16,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 61,
					hour_startY: 155,
					hour_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 192,
					minute_startY: 155,
					minute_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 326,
					second_startY: 155,
					second_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 246,
					y: 265,
					week_en: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					week_tc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					week_sc: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 117,
					day_startY: 257,
					day_sc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_tc_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_en_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 256,
					month_startY: 317,
					month_sc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png"],
					month_tc_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png"],
					month_en_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png"],
					month_is_character: true,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_current_circle = hmUI.createWidget(hmUI.widget.ARC);
				}

				const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
				battery.addEventListener(hmSensor.event.CHANGE, function() {
					updateScales('battery');
				});

				normal_battery_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 77,
					y: 373,
					font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0074.png',
					unit_tc: '0074.png',
					unit_en: '0074.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0075.png',
					second_centerX: 240,
					second_centerY: 240,
					second_posX: 7,
					second_posY: 242,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 204,
					y: 27,
					image_array: ["0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 265,
					y: 73,
					font_array: ["0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0116.png"],
					unit_tc: ["0116.png"],
					unit_en: ["0116.png"],
					negative_image: ["0115.png"],
					invalid_image: ["0117.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 258,
					y: 421,
					w: 20,
					h: 20,
					src: '0118.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 298,
					y: 412,
					w: 17,
					h: 17,
					src: '0119.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 333,
					y: 398,
					w: 13,
					h: 13,
					src: '0120.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 359,
					y: 385,
					w: 8,
					h: 8,
					src: '0121.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateScales() {
					let valueBattery = battery.current;
					let targetBattery = 100;
					let progressBattery = valueBattery / targetBattery;

					if (progressBattery > 1) {
						progressBattery = 1;
					}

					let progress_cs_normal_battery = progressBattery;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						let start_angle_normal_battery = 149;
						let end_angle_normal_battery = 212;
						let center_x_normal_battery = 250;
						let center_y_normal_battery = 243;
						let radius_normal_battery = 225;
						let line_width_cs_normal_battery = 10;
						let color_cs_normal_battery = 0x36FFFFFF;

						// calculated parameters
						let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
						let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
						let CircleWidth_normal_battery = 2 * radius_normal_battery;
						let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
						angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
						let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;

						normal_battery_current_circle.setProperty(hmUI.prop.MORE, {
							x: arcX_normal_battery,
							y: arcY_normal_battery,
							w: CircleWidth_normal_battery,
							h: CircleWidth_normal_battery,
							start_angle: start_angle_normal_battery,
							end_angle: end_angle_normal_battery_draw,
							color: color_cs_normal_battery,
							line_width: line_width_cs_normal_battery,
						});
					};

				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateScales();

					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}