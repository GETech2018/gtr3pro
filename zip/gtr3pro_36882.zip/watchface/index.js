﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
      (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;

        function getApp() {
          return __$$app$$__.app;
        }

        function getCurrentPage() {
          return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {
          px
        } = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start


        let normal_background_bg_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let timer_anim_rotate_2_mirror = false;
        let normal_rotate_animation_param_2_mirror = null;
        let normal_rotate_animation_count_2 = 0;
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let timer_anim_motion_1_mirror = false;
        let normal_motion_animation_paramX_1_mirror = null;
        let normal_motion_animation_paramY_1_mirror = null;
        let normal_motion_animation_count_1 = 0;
        let normal_motion_animation_img_2 = '';
        let normal_motion_animation_paramX_2 = null;
        let normal_motion_animation_paramY_2 = null;
        let normal_motion_animation_lastTime_2 = 0;
        let timer_anim_motion_2;
        let timer_anim_motion_2_mirror = false;
        let normal_motion_animation_paramX_2_mirror = null;
        let normal_motion_animation_paramY_2_mirror = null;
        let normal_motion_animation_count_2 = 0;
        let normal_motion_animation_img_3 = '';
        let normal_motion_animation_paramX_3 = null;
        let normal_motion_animation_paramY_3 = null;
        let normal_motion_animation_lastTime_3 = 0;
        let timer_anim_motion_3;
        let timer_anim_motion_3_mirror = false;
        let normal_motion_animation_paramX_3_mirror = null;
        let normal_motion_animation_paramY_3_mirror = null;
        let normal_motion_animation_count_3 = 0;
        let normal_motion_animation_img_4 = '';
        let normal_motion_animation_paramX_4 = null;
        let normal_motion_animation_paramY_4 = null;
        let normal_motion_animation_lastTime_4 = 0;
        let timer_anim_motion_4;
        let normal_motion_animation_count_4 = 0;
        let normal_motion_animation_img_5 = '';
        let normal_motion_animation_paramX_5 = null;
        let normal_motion_animation_paramY_5 = null;
        let normal_motion_animation_lastTime_5 = 0;
        let timer_anim_motion_5;
        let normal_motion_animation_count_5 = 0;
        let normal_image_img = ''
        let normal_digital_clock_img_time_hour = ''
        let image_top_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
          init_view() {
            //dynamic modify start


            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'dial.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            let screenType = hmSetting.getScreenType();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
            // src: 'min.png',
            // center_x: 145,
            // center_y: 387,
            // x: 110,
            // y: 56,
            // start_angle: 5,
            // end_angle: 72,
            // cover_path: 'overlay_min.png',
            // cover_x: 113,
            // cover_y: 350,
            // type: hmUI.data_type.minute,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 145 - 110,
              pos_y: 387 - 56,
              center_x: 145,
              center_y: 387,
              src: 'min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: 350,
              src: 'overlay_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
            // type: 1,
            // fps: 15,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 319,
              pos_y: 173,
              center_x: 350,
              center_y: 204,
              angle: 0,
              src: 'animation/anim_sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if (normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = -1;
              if (normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function

            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
            // start_angle: 0,
            // end_angle: 360,
            // pos_x: 31,
            // pos_y: 31,
            // center_x: 350,
            // center_y: 204,
            // src: 'anim_sec.png',
            // anim_fps: 15,
            // anim_duration: 5000,
            // repeat_count: 0,
            // anim_two_sides: False,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
            // start_angle: 0,
            // end_angle: -20,
            // pos_x: 40,
            // pos_y: 17,
            // center_x: 277,
            // center_y: 39,
            // src: 'anim_snake.png',
            // anim_fps: 15,
            // anim_duration: 5000,
            // repeat_count: 0,
            // anim_two_sides: True,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 203,
              pos_y: 227,
              src: 'animation/anim_kaak.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 203,
              anim_to: 203,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_1 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 227,
              anim_to: 253,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_1_mirror = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 203,
              anim_to: 203,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_1_mirror = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 253,
              anim_to: 227,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_1_mirror() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1_mirror);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1_mirror);
              normal_motion_animation_lastTime_1 = now.utc;
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if (normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = -1;
              if (normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation_mirror callback function

            function anim_motion_1_complete_call() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
              normal_motion_animation_lastTime_1 = now.utc;
            }; // end animation callback function

            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
            // x_start: 203,
            // y_start: 227,
            // x_end: 203,
            // y_end: 253,
            // src: 'anim_kaak.png',
            // anim_fps: 15,
            // anim_duration: 3000,
            // repeat_count: 0,
            // anim_two_sides: True,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 362,
              pos_y: 215,
              src: 'animation/anim_oog-knip2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_2 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 362,
              anim_to: 352,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_2 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 215,
              anim_to: 205,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 352,
              anim_to: 362,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 205,
              anim_to: 215,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_2_mirror() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2_mirror);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2_mirror);
              normal_motion_animation_lastTime_2 = now.utc;
              normal_motion_animation_count_2 = normal_motion_animation_count_2 - 1;
              if (normal_motion_animation_count_2 < -1) normal_motion_animation_count_2 = -1;
              if (normal_motion_animation_count_2 == 0) stop_anim_motion_2();
            }; // end animation_mirror callback function

            function anim_motion_2_complete_call() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2);
              normal_motion_animation_lastTime_2 = now.utc;
            }; // end animation callback function

            function stop_anim_motion_2() {
              if (timer_anim_motion_2) {
                timer.stopTimer(timer_anim_motion_2);
                timer_anim_motion_2 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_2 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
            // x_start: 362,
            // y_start: 215,
            // x_end: 352,
            // y_end: 205,
            // src: 'anim_oog-knip2.png',
            // anim_fps: 15,
            // anim_duration: 1000,
            // repeat_count: 0,
            // anim_two_sides: True,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 309,
              pos_y: 162,
              src: 'animation/anim_oog-knip2-lb.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_3 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 309,
              anim_to: 319,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_3 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 162,
              anim_to: 172,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 319,
              anim_to: 309,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 172,
              anim_to: 162,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_3_mirror() {
              normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_3_mirror);
              normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_3_mirror);
              normal_motion_animation_lastTime_3 = now.utc;
              normal_motion_animation_count_3 = normal_motion_animation_count_3 - 1;
              if (normal_motion_animation_count_3 < -1) normal_motion_animation_count_3 = -1;
              if (normal_motion_animation_count_3 == 0) stop_anim_motion_3();
            }; // end animation_mirror callback function

            function anim_motion_3_complete_call() {
              normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_3);
              normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_3);
              normal_motion_animation_lastTime_3 = now.utc;
            }; // end animation callback function

            function stop_anim_motion_3() {
              if (timer_anim_motion_3) {
                timer.stopTimer(timer_anim_motion_3);
                timer_anim_motion_3 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_3 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
            // x_start: 309,
            // y_start: 162,
            // x_end: 319,
            // y_end: 172,
            // src: 'anim_oog-knip2-lb.png',
            // anim_fps: 15,
            // anim_duration: 1000,
            // repeat_count: 0,
            // anim_two_sides: True,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 63,
              pos_y: 126,
              src: 'animation/zand_boven.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_4 = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: 63,
              anim_to: 63,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_4 = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: 126,
              anim_to: 162,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_4_complete_call() {
              normal_motion_animation_img_4.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_4);
              normal_motion_animation_img_4.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_4);
              normal_motion_animation_lastTime_4 = now.utc;
              normal_motion_animation_count_4 = normal_motion_animation_count_4 - 1;
              if (normal_motion_animation_count_4 < -1) normal_motion_animation_count_4 = -1;
              if (normal_motion_animation_count_4 == 0) stop_anim_motion_4();
            }; // end animation callback function

            function stop_anim_motion_4() {
              if (timer_anim_motion_4) {
                timer.stopTimer(timer_anim_motion_4);
                timer_anim_motion_4 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_4 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
            // x_start: 63,
            // y_start: 126,
            // x_end: 63,
            // y_end: 162,
            // src: 'zand_boven.png',
            // anim_fps: 15,
            // anim_duration: 5000,
            // repeat_count: 0,
            // anim_two_sides: False,
            // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 63,
              pos_y: 240,
              src: 'animation/zand_onder.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_5 = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: 63,
              anim_to: 63,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_5 = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: 240,
              anim_to: 205,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_5_complete_call() {
              normal_motion_animation_img_5.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_5);
              normal_motion_animation_img_5.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_5);
              normal_motion_animation_lastTime_5 = now.utc;
              normal_motion_animation_count_5 = normal_motion_animation_count_5 - 1;
              if (normal_motion_animation_count_5 < -1) normal_motion_animation_count_5 = -1;
              if (normal_motion_animation_count_5 == 0) stop_anim_motion_5();
            }; // end animation callback function

            function stop_anim_motion_5() {
              if (timer_anim_motion_5) {
                timer.stopTimer(timer_anim_motion_5);
                timer_anim_motion_5 = undefined;
              };
            }; // end stop_anim_motion function

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 281,
              hour_startY: 132,
              hour_array: ["0.png", "1.png", "2.png", "3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png"],
              hour_zero: 0,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 158,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 237,
              pos_y: 22,
              center_x: 277,
              center_y: 39,
              angle: 0,
              src: 'animation/anim_snake.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: 0,
              anim_to: -20,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 5000,
              anim_from: -20,
              anim_to: 0,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_2_mirror() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2_mirror);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if (normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = -1;
              if (normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();

            }; // end animation_mirror callback function

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
            }; // end animation callback function

            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 124,
              src: 'mask-totaal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 196,
              src: 'center-sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateMinute) {
                let normal_fullAngle_minute = 67;
                let normal_angle_minute = 5 + normal_fullAngle_minute * (minute + second / 60) / 60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    })); // end timer 
                  }; // end timer check
                }; // end screenType


                let nawAnimationTime = now.utc;;

                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 5000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if (delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0;
                if ((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };

                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 5000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if (delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0;
                if ((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2 * 2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    if (timer_anim_rotate_2_mirror) {
                      anim_rotate_2_mirror()
                    } else {
                      anim_rotate_2_complete_call()
                    };
                    timer_anim_rotate_2_mirror = !timer_anim_rotate_2_mirror;
                  })); // end timer create
                };

                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 3000;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if (delay_anim_motion_1 < 0) delay_anim_motion_1 = 0;
                if ((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1 * 2) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    if (timer_anim_motion_1_mirror) {
                      anim_motion_1_mirror()
                    } else {
                      anim_motion_1_complete_call()
                    };
                    timer_anim_motion_1_mirror = !timer_anim_motion_1_mirror;
                  })); // end timer create
                };

                let delay_anim_motion_2 = 0;
                let repeat_anim_motion_2 = 1000;
                delay_anim_motion_2 = repeat_anim_motion_2 - (nawAnimationTime - normal_motion_animation_lastTime_2);
                if (delay_anim_motion_2 < 0) delay_anim_motion_2 = 0;
                if ((nawAnimationTime - normal_motion_animation_lastTime_2) > repeat_anim_motion_2 * 2) {
                  normal_motion_animation_count_2 = 0;
                  timer_anim_motion_2_mirror = false;
                };

                if (!timer_anim_motion_2) {
                  timer_anim_motion_2 = timer.createTimer(delay_anim_motion_2, repeat_anim_motion_2, (function (option) {
                    if (timer_anim_motion_2_mirror) {
                      anim_motion_2_mirror()
                    } else {
                      anim_motion_2_complete_call()
                    };
                    timer_anim_motion_2_mirror = !timer_anim_motion_2_mirror;
                  })); // end timer create
                };

                let delay_anim_motion_3 = 0;
                let repeat_anim_motion_3 = 1000;
                delay_anim_motion_3 = repeat_anim_motion_3 - (nawAnimationTime - normal_motion_animation_lastTime_3);
                if (delay_anim_motion_3 < 0) delay_anim_motion_3 = 0;
                if ((nawAnimationTime - normal_motion_animation_lastTime_3) > repeat_anim_motion_3 * 2) {
                  normal_motion_animation_count_3 = 0;
                  timer_anim_motion_3_mirror = false;
                };

                if (!timer_anim_motion_3) {
                  timer_anim_motion_3 = timer.createTimer(delay_anim_motion_3, repeat_anim_motion_3, (function (option) {
                    if (timer_anim_motion_3_mirror) {
                      anim_motion_3_mirror()
                    } else {
                      anim_motion_3_complete_call()
                    };
                    timer_anim_motion_3_mirror = !timer_anim_motion_3_mirror;
                  })); // end timer create
                };

                let delay_anim_motion_4 = 0;
                let repeat_anim_motion_4 = 5000;
                delay_anim_motion_4 = repeat_anim_motion_4 - (nawAnimationTime - normal_motion_animation_lastTime_4);
                if (delay_anim_motion_4 < 0) delay_anim_motion_4 = 0;
                if ((nawAnimationTime - normal_motion_animation_lastTime_4) > repeat_anim_motion_4) {
                  normal_motion_animation_count_4 = 0;
                  timer_anim_motion_4_mirror = false;
                };

                if (!timer_anim_motion_4) {
                  timer_anim_motion_4 = timer.createTimer(delay_anim_motion_4, repeat_anim_motion_4, (function (option) {
                    anim_motion_4_complete_call()
                  })); // end timer create
                };

                let delay_anim_motion_5 = 0;
                let repeat_anim_motion_5 = 5000;
                delay_anim_motion_5 = repeat_anim_motion_5 - (nawAnimationTime - normal_motion_animation_lastTime_5);
                if (delay_anim_motion_5 < 0) delay_anim_motion_5 = 0;
                if ((nawAnimationTime - normal_motion_animation_lastTime_5) > repeat_anim_motion_5) {
                  normal_motion_animation_count_5 = 0;
                  timer_anim_motion_5_mirror = false;
                };

                if (!timer_anim_motion_5) {
                  timer_anim_motion_5 = timer.createTimer(delay_anim_motion_5, repeat_anim_motion_5, (function (option) {
                    anim_motion_5_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_motion_1();
                stop_anim_motion_2();
                stop_anim_motion_3();
                stop_anim_motion_4();
                stop_anim_motion_5();

              }),
            });

            //dynamic modify end
          },
          onInit() {
            logger.log('index page.js on init invoke');
          },
          build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
          },
          onDestroy() {
            logger.log('index page.js on destroy invoke');
          }
        });;
      })();
    } catch (e) {
      console.log('Mini Program Error', e);
      e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
