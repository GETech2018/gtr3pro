﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        // start user_functions.js
		let element_index = 1;
        let element_count = 4;
		
		function click_Content() {
              element_index++;
              if(element_index > element_count) element_index = 1;
			  
			  normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 4);

              if (element_index == 1) {
                 hmUI.showToast({text: 'CALENDAR'});
               };
              if (element_index == 2) {
                 hmUI.showToast({text: 'BATTERY'});
               };
			  if (element_index == 3) {
                 hmUI.showToast({text: 'WEATHER'});
               };
              if (element_index == 4) {
                 hmUI.showToast({text: 'ACTIVITY'});
               };
        };
		
		let noanimnumber = 1
        let totalnoanim = 2

        function click_NoAnim() {
            if(noanimnumber>=totalnoanim) {
            noanimnumber=1;
                UpdateNoanimOne();
                }
            else {
                noanimnumber=noanimnumber+1;
                if(noanimnumber==2) {
                  UpdateNoanimTwo();
                }
            }
        }
		
		function UpdateNoanimOne(){
			
		normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		Button_2.setProperty(hmUI.prop.VISIBLE, true);
		Button_4.setProperty(hmUI.prop.VISIBLE, true);			
		hmUI.showToast({text: 'Animation SHOW'});
		}
		
		function UpdateNoanimTwo(){
			
		normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		Button_2.setProperty(hmUI.prop.VISIBLE, false);
		Button_4.setProperty(hmUI.prop.VISIBLE, false);
		hmUI.showToast({text: 'Animation HIDE'});
		}
		
		let nocontnumber = 1
        let totalnocont = 2

        function click_NoCont() {
            if(nocontnumber>=totalnocont) {
            nocontnumber=1;
                UpdateNocontOne();
                }
            else {
                nocontnumber=nocontnumber+1;
                if(nocontnumber==2) {
                  UpdateNocontTwo();
                }
            }
        }
		
		function UpdateNocontOne(){
			
		normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
		hmUI.showToast({text: 'Content SHOW'});
		}
		
		function UpdateNocontTwo(){
			
		normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);  
		hmUI.showToast({text: 'Content HIDE'});
		}
		
		let animhnumber = 0
		let normal_background_bg_img = ''
		
		normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, false);
		
		function click_Hideanimation() {
              animhnumber=animhnumber+1;
              switch (animhnumber) {
              case 1:
              Hideanimation(1); break;
              default:
              Hideanimation(0); animhnumber=0;
              }
              if(animhnumber==1) hmUI.showToast({text: 'Animation STOP'});
		      if(animhnumber==0) hmUI.showToast({text: 'Animation START'});
        }
		
		function Hideanimation(number) {
           if(number==1) {
                  Hideanim();
			        } else {
                  Showanim();
              }
        }
		
        function Hideanim(){
				  normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, false);
				  normal_rotate_animation_img_2.setProperty(hmUI.prop.VISIBLE, false);
				  normal_rotate_animation_img_3.setProperty(hmUI.prop.VISIBLE, false);
				  normal_rotate_animation_img_4.setProperty(hmUI.prop.VISIBLE, false);
				  normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, true);
				  normal_background_bg.setProperty(hmUI.prop.VISIBLE, false);
        }

		function Showanim(){
				  normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
				  normal_rotate_animation_img_2.setProperty(hmUI.prop.VISIBLE, true);
				  normal_rotate_animation_img_3.setProperty(hmUI.prop.VISIBLE, true);
				  normal_rotate_animation_img_4.setProperty(hmUI.prop.VISIBLE, true);
				  normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, false);
				  normal_background_bg.setProperty(hmUI.prop.VISIBLE, true);
        }	
		
		let circlenumber = 0
		
		function click_HideSmooth() {
              circlenumber=circlenumber+1;
              switch (circlenumber) {
              case 1:
              HideCircle(1); break;
              default:
              HideCircle(0); circlenumber=0;
              }
              if(circlenumber==1) hmUI.showToast({text: 'Second Circle STOP'});
		      if(circlenumber==0) hmUI.showToast({text: 'Second Circle START'});
        }
		
		function HideCircle(number) {
           if(number==1) {
                  Hidecircle();
			        } else {
                  Showcircle();
              }
        }
		
        function Hidecircle(){
				  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				  normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        }

		function Showcircle(){
				  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				  normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }	




		let timer_anim_rotate_1_mirror =''
		let timer_anim_rotate_2_mirror =''
		let timer_anim_rotate_3_mirror =''
		let timer_anim_rotate_4_mirror =''
		let normal_time_circle_scale = ''
        let normal_image_img_TT = ''
        let intervalId;
		let callnumber = 0
		
		function click_CallHide() {
              callnumber=callnumber+1;
              switch (callnumber) {
              case 1:
              HideCall(1); break;
              default:
              HideCall(0); callnumber=0;
              }
              if(callnumber==1) hmUI.showToast({text: 'Color Seconds HIDE'});
		      if(callnumber==0) hmUI.showToast({text: 'Color Seconds SHOW'});
        }
		
		function HideCall(number) {
           if(number==1) {
                  Hidecall();
			        } else {
                  Showcall();
              }
        }
		
        function Hidecall(){
				  normal_time_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
				  normal_image_img_TT.setProperty(hmUI.prop.VISIBLE, false);
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
				  normal_analog_clock_time_pointer_second_1.setProperty(hmUI.prop.VISIBLE, true);
        }

		function Showcall(){
				  normal_time_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
				  normal_image_img_TT.setProperty(hmUI.prop.VISIBLE, true);
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
				  normal_analog_clock_time_pointer_second_1.setProperty(hmUI.prop.VISIBLE, false);
        }	
        // end user_functions.js

        let normal_background_bg = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let normal_rotate_animation_count_4 = 0;
        let normal_pai_icon_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 13;
        let normal_step_TextCircle_img_height = 26;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 13;
        let normal_calorie_TextCircle_img_height = 26;
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_spo2_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_stand_icon_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stress_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		let normal_analog_clock_time_pointer_second_1 = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_stress_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
		let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 189,
              pos_y: 295,
              center_x: 264,
              center_y: 370,
              angle: 0,
              src: 'animation/red.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 75,
              // pos_y: 75,
              // center_x: 264,
              // center_y: 370,
              // src: 'red.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 110,
              pos_y: 354,
              center_x: 159,
              center_y: 403,
              angle: 0,
              src: 'animation/grey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: -360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: -360,
              // pos_x: 49,
              // pos_y: 49,
              // center_x: 159,
              // center_y: 403,
              // src: 'grey.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 256,
              pos_y: 317,
              center_x: 292,
              center_y: 353,
              angle: 0,
              src: 'animation/small.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: -360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
              normal_rotate_animation_lastTime_3 = now.utc;
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: -360,
              // pos_x: 36,
              // pos_y: 36,
              // center_x: 292,
              // center_y: 353,
              // src: 'small.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 59,
              pos_y: 280,
              center_x: 125,
              center_y: 346,
              angle: 0,
              src: 'animation/white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: -360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
              normal_rotate_animation_lastTime_4 = now.utc;
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: -360,
              // pos_x: 66,
              // pos_y: 66,
              // center_x: 125,
              // center_y: 346,
              // src: 'white.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'no_circle.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_circle.png',
              // center_x: 240,
              // center_y: 240,
              // x: 239,
              // y: 239,
              // start_angle: -105,
              // end_angle: 255,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'sec_circle.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bck_stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 240,
              center_y: 240,
              x: 211,
              y: 211,
              start_angle: 0,
              end_angle: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 190,
              // angle: 19,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 - 203,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 162,
              // angle: 19,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 - 175,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bck_wea.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 118,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_wea.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bck_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 240,
              center_y: 240,
              x: 211,
              y: 211,
              start_angle: 0,
              end_angle: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bck_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_tc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_sc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -30,
              day_startY: 59,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'under2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'under1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 381,
              am_y: 198,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 381,
              pm_y: 197,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 310,
              hour_startY: 177,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 310,
              minute_startY: 254,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 383,
              second_startY: 254,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 244,
              hour_cover_path: 'top_red.png',
              hour_cover_x: 0,
              hour_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 244,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 18,
              second_posY: 244,
              second_cover_path: 'top_black.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second_1 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_cover_path: 'top_black.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_analog_clock_time_pointer_second_1.setProperty(hmUI.prop.VISIBLE, false);

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF0D0D0D',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_bck_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 240,
              center_y: 240,
              x: 211,
              y: 211,
              start_angle: 0,
              end_angle: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 381,
              am_y: 224,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 381,
              pm_y: 224,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 310,
              hour_startY: 177,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 310,
              minute_startY: 254,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 244,
              hour_cover_path: 'top_red.png',
              hour_cover_x: 0,
              hour_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 244,
              minute_cover_path: 'top_black.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
			
			// start user_script_end.js







////////////////  Time_Circle_sale ///////////////////////////////////

           normal_time_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 360,
              radius: 90,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            

            normal_image_img_TT = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'topsec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        const time = hmSensor.createSensor(hmSensor.id.TIME);

          function second_circle_call() {
                
                let valueTime = time.second;
                let targetTime = 60;
                let progressTime = valueTime/targetTime;
                if (progressTime > 1) progressTime = 1;
                let progress_cs_normal_time = progressTime;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_time_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_time * 100);
                  if (level==0) { level = 360 }; 

                    if (normal_time_circle_scale) {
                    normal_time_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 0,
                       end_angle: 360,
                      radius: 230,
                      line_width: 22,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                     level: level,  // ค่าเปลี่ยนแปลงตาม level
                

                    });
                  };
                };

            };



		function startInterval() {
			intervalId = setInterval(second_circle_call, 200); //  1 Second = (1000 millisecond)
		}
			startInterval();

////////////////  Time_Circle_sale  END  ///////////////////////////////////////////////






let cc = 0
if (cc ==0 ){
	normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
	normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	
	normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);  
	normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);  
	normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);  
	normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);  
	
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
	
	normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
	normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
	
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
	
	cc = 1;
}
            // end user_script_end.js

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 428,
              y: 211,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Content();
                			   vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 310,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Hideanimation();
                			   vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 391,
              y: 317,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_NoAnim();
                			   vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 250,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_HideSmooth();
                			   vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 391,
              y: 111,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_NoCont();
                			   vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 222,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CallHide();
                			   vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 19;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 190));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 19;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 162));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 10000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 10000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    anim_rotate_3_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 10000;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    anim_rotate_4_complete_call()
                  })); // end timer create
                };
                let secAngle = -105 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = -105 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}