﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;


        let normal_image_img = ''

        let normal_battery_image_progress_img_level = ''
        let normal_battery2_image_progress_img_level = ''
        let normal_battery3_image_progress_img_level = ''
        let normal_battery4_image_progress_img_level = ''
        let normal_battery5_image_progress_img_level = ''

        let normal_battery_icon_img = ''
        let normal_battery_TextRotate = new Array(5);

        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery2_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery3_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery4_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery5_TextRotate_ASCIIARRAY = new Array(10);

        let normal_battery_TextRotate_img_width = 17;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 17;
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''

        let normal_analog_clock_pro_second_pointer_img = ''

        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextRotate = new Array(5);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 17;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 17;
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        let timeSensor = ''



//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 4
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'HeartRate'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Temp.'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Seconds'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){

        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);

     normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //heart
        function UpdateBackgroundTwo(){

        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
      normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //temp
        function UpdateBackgroundThree(){

        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
 
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);

   normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //second
        function UpdateBackgroundFour(){

        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////

        // color change
        let btncolorfont = ''
        let colornumber = 1
        let totalcolorpictures = 5

        function click_color() {
            if(colornumber>=totalcolorpictures) {
            colornumber=1;
                UpdatecolorOne();
                }
            else {
                colornumber=colornumber+1;
                if(colornumber==2) {
                  UpdatecolorTwo();
                }
                if(colornumber==3) {
                  UpdatecolorThree();
                }
                if(colornumber==4) {
                  UpdatecolorFour();
                }
                if(colornumber==5) {
                  UpdatecolorFive();
                }
 
            }
          if(colornumber==1) hmUI.showToast({text: 'Blue'});
          if(colornumber==2) hmUI.showToast({text: 'Orange'});
          if(colornumber==3) hmUI.showToast({text: 'Red'});
          if(colornumber==4) hmUI.showToast({text: 'Green'});
          if(colornumber==5) hmUI.showToast({text: 'White'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color1
        function UpdatecolorOne(){

        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery2_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery5_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "SH" + parseInt(colornumber) + ".png");
        normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "Font_Batt_S.png");
        const result = hmSetting.setScreenOff()


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color2
        function UpdatecolorTwo(){
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery3_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery5_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "SH" + parseInt(colornumber) + ".png");
        normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "Font2_batt_S.png");
        const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color3
        function UpdatecolorThree(){
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery4_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery5_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "SH" + parseInt(colornumber) + ".png");
        normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "Font3_batt_S.png");
        const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color4
        function UpdatecolorFour(){
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery5_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "SH" + parseInt(colornumber) + ".png");
        normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "Font4_batt_S.png");
        const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color5
        function UpdatecolorFive(){
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery2_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery5_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "top" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "SH" + parseInt(colornumber) + ".png");
        normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "Font5_batt_S.png");
        const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF212121',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 25000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };
//////////////////////////animation ////////
           let now = hmSensor.createSensor(hmSensor.id.TIME);

           function anim_rotate_1_complete_call() {
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
                normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
                normal_rotate_animation_lastTime_1 = now.utc;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

/////////*****
            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'anim_0.png',
              // anim_fps: 15,
              // anim_duration: 25000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

//////////////// end animation //////////////////



            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 31,
              y: 132,
              src: 'img_mid.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//////////////

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 143,
              image_array: ["batt01.png","batt02.png","batt03.png","batt04.png","batt05.png","batt06.png","batt07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery2_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 143,
              image_array: ["batt_2_01.png","batt_2_02.png","batt_2_03.png","batt_2_04.png","batt_2_05.png","batt_2_06.png","batt_2_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery3_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 143,
              image_array: ["batt_3_01.png","batt_3_02.png","batt_3_03.png","batt_3_04.png","batt_3_05.png","batt_3_06.png","batt_3_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery4_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 143,
              image_array: ["batt_4_01.png","batt_4_02.png","batt_4_03.png","batt_4_04.png","batt_4_05.png","batt_4_06.png","batt_4_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery5_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 143,
              image_array: ["batt_5_01.png","batt_5_02.png","batt_5_03.png","batt_5_04.png","batt_5_05.png","batt_5_06.png","batt_5_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/////////////////

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 96,
              // y: 231,
              // font_array: ["Font_batt_0.png","Font_batt_1.png","Font_batt_2.png","Font_batt_3.png","Font_batt_4.png","Font_batt_5.png","Font_batt_6.png","Font_batt_7.png","Font_batt_8.png","Font_batt_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 90,
              // unit_en: 'Font_Batt_S.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Font_batt_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Font_batt_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Font_batt_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Font_batt_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Font_batt_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Font_batt_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Font_batt_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Font_batt_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Font_batt_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Font_batt_9.png';  // set of images with numbers


            normal_battery2_TextRotate_ASCIIARRAY[0] = 'Font2_batt_0.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[1] = 'Font2_batt_1.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[2] = 'Font2_batt_2.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[3] = 'Font2_batt_3.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[4] = 'Font2_batt_4.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[5] = 'Font2_batt_5.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[6] = 'Font2_batt_6.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[7] = 'Font2_batt_7.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[8] = 'Font2_batt_8.png';  // set of images with numbers
            normal_battery2_TextRotate_ASCIIARRAY[9] = 'Font2_batt_9.png';  // set of images with numbers

            normal_battery3_TextRotate_ASCIIARRAY[0] = 'Font3_batt_0.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[1] = 'Font3_batt_1.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[2] = 'Font3_batt_2.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[3] = 'Font3_batt_3.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[4] = 'Font3_batt_4.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[5] = 'Font3_batt_5.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[6] = 'Font3_batt_6.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[7] = 'Font3_batt_7.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[8] = 'Font3_batt_8.png';  // set of images with numbers
            normal_battery3_TextRotate_ASCIIARRAY[9] = 'Font3_batt_9.png';  // set of images with numbers

            normal_battery4_TextRotate_ASCIIARRAY[0] = 'Font4_batt_0.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[1] = 'Font4_batt_1.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[2] = 'Font4_batt_2.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[3] = 'Font4_batt_3.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[4] = 'Font4_batt_4.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[5] = 'Font4_batt_5.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[6] = 'Font4_batt_6.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[7] = 'Font4_batt_7.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[8] = 'Font4_batt_8.png';  // set of images with numbers
            normal_battery4_TextRotate_ASCIIARRAY[9] = 'Font4_batt_9.png';  // set of images with numbers

            normal_battery5_TextRotate_ASCIIARRAY[0] = 'Font5_batt_0.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[1] = 'Font5_batt_1.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[2] = 'Font5_batt_2.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[3] = 'Font5_batt_3.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[4] = 'Font5_batt_4.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[5] = 'Font5_batt_5.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[6] = 'Font5_batt_6.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[7] = 'Font5_batt_7.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[8] = 'Font5_batt_8.png';  // set of images with numbers
            normal_battery5_TextRotate_ASCIIARRAY[9] = 'Font5_batt_9.png';  // set of images with numbers


            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 85,
                center_y: 254,
                pos_x: 85,
                pos_y: 254,
                angle: -90,
                src: 'Font_batt_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 85,
              center_y: 254,
              pos_x: 85,
              pos_y: 254,
              angle: -90,
              src: 'Font_Batt_S.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 375,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Act_symbo1.png',
              unit_tc: 'Act_symbo1.png',
              unit_en: 'Act_symbo1.png',
              negative_image: 'Act_symbo2.png',
              invalid_image: 'Act_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 411,
              src: 'icon_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 375,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 418,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 147,
              y: 375,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 418,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 194,
              day_startY: 73,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 39,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 204,
              second_startY: 375,
              second_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 407,
              src: 'icon_second.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 129,
              am_y: 85,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 129,
              pm_y: 85,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 147,
              minute_startY: 244,
              minute_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 147,
              hour_startY: 161,
              hour_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'SH1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 18,
              // y: 249,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 18,
              pos_y: 240 - 248,
              center_x: 240,
              center_y: 240,
              src: 'SH1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF212121',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 31,
              y: 132,
              src: 'img_mid.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 143,
              image_array: ["batt_5_01.png","batt_5_02.png","batt_5_03.png","batt_5_04.png","batt_5_05.png","batt_5_06.png","batt_5_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 96,
              // y: 231,
              // font_array: ["Font5_batt_0.png","Font5_batt_1.png","Font5_batt_2.png","Font5_batt_3.png","Font5_batt_4.png","Font5_batt_5.png","Font5_batt_6.png","Font5_batt_7.png","Font5_batt_8.png","Font5_batt_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 90,
              // unit_en: 'Font5_batt_S.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'Font5_batt_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'Font5_batt_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'Font5_batt_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'Font5_batt_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'Font5_batt_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'Font5_batt_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'Font5_batt_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'Font5_batt_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'Font5_batt_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'Font5_batt_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 85,
                center_y: 254,
                pos_x: 85,
                pos_y: 254,
                angle: -90,
                src: 'Font5_batt_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 85,
              center_y: 254,
              pos_x: 85,
              pos_y: 254,
              angle: -90,
              src: 'Font5_batt_S.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 375,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 418,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 194,
              day_startY: 73,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 39,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 129,
              am_y: 85,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 129,
              pm_y: 85,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 147,
              minute_startY: 244,
              minute_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 147,
              hour_startY: 161,
              hour_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'SH5.png',
              // center_x: 240,
              // center_y: 240,
              // x: 18,
              // y: 249,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 18,
              pos_y: 240 - 248,
              center_x: 240,
              center_y: 240,
              src: 'SH5.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });
          normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 245,
              w: 51,
              h: 51,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 165,
              w: 52,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 198,
              y: 3,
              w: 59,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 370,
              w: 103,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 370,
              w: 106,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 54,
              w: 100,
              h: 72,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});


            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 370,
              w: 106,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {

              console.log('update text rotate BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 2 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
/////
   if ( colornumber==1){
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
}

   if ( colornumber==2){
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery2_TextRotate_ASCIIARRAY[charCode]);
}

   if ( colornumber==3){
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery3_TextRotate_ASCIIARRAY[charCode]);
}

   if ( colornumber==4){
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery4_TextRotate_ASCIIARRAY[charCode]);
}

   if ( colornumber==5){
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery5_TextRotate_ASCIIARRAY[charCode]);
}
/////

                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 85 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + 2 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 85 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                text_update();

//////////////////// animation function ///////////////
             
               let timer_anim_rotate_1_mirror = ''
               let nawAnimationTime = now.utc;;
              
               let delay_anim_rotate_1 = 0;
               let repeat_anim_rotate_1 = 25000;
               delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
             if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                 normal_rotate_animation_count_1 = 0;
                 timer_anim_rotate_1_mirror = false;
             };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                   anim_rotate_1_complete_call()
                 })); // end timer create
               };

///////////////////end animation function /////////////////


                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
              }),



              pause_call: (function () {

/////// call  animation //////
            stop_anim_rotate_1();
/////////end call animation ///////

                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery2_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery3_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery4_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery5_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

     normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

 
  }
//////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 427,
              text: '',
              w: 106,
              h: 53,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

          // color change
            btncolorfont = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 382,
              y: 172,
              text: '',
              w: 53,
              h: 148,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolorfont.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}