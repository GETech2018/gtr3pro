﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_stress_icon_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_hour_cover_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_minute_cover_pointer_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_hour_cover_pointer_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_icon_img = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
		let calendar_btn = ''
		let battery_btn = ''
		let next_panel_btn = ''
        let prev_panel_btn = ''
		let panel_state = ''
		let next_over_btn = ''
        let prev_over_btn = ''
		let over_toggle_state = ''
		let animhnumber = 0
		let btnanimstop = ''
 		let btnanimhide = ''
		let bg_toggle_state = ''
		let btn_bg = ''
		let color_toggle_state = ''
		let btn_color = ''

		function loadSettings() {

      if (hmFS.SysProGetInt('goliath_panel') === undefined) {
        panel_state = 0;
        hmFS.SysProSetInt('goliath_panel', panel_state);
      }
      else {
        panel_state = hmFS.SysProGetInt('goliath_panel');
      }

      if (hmFS.SysProGetInt('goliath_color') === undefined) {
        color_toggle_state = 0;
        hmFS.SysProSetInt('goliath_color', color_toggle_state);
      }
      else {
        color_toggle_state = hmFS.SysProGetInt('goliath_color');
      }
	  
	    if (hmFS.SysProGetInt('goliath_over') === undefined) {
        over_toggle_state = 0;
        hmFS.SysProSetInt('goliath_over', over_toggle_state);
      }
      else {
        over_toggle_state = hmFS.SysProGetInt('goliath_over');
      }

      if (hmFS.SysProGetInt('goliath_bg') === undefined) {
        bg_toggle_state = 0;
        hmFS.SysProSetInt('goliath_bg', bg_toggle_state);
      }
      else {
        bg_toggle_state = hmFS.SysProGetInt('goliath_bg');
      }
	  
	  
	    if (hmFS.SysProGetInt('goliath_animh') === undefined) {
		animhnumber = 0;
		hmFS.SysProSetInt('goliath_animh', animhnumber);
			}
	  else {
		 animhnumber = hmFS.SysProGetInt('goliath_animh');
	  }
    }
	
	function click_panel_Switcher() {
		
	  let panel_state_total = 5;

      panel_state = (panel_state + 1) % panel_state_total;

      hmFS.SysProSetInt('goliath_panel', panel_state);

      apply_panel_switch();
    }

    function click_panel_Switcher_reverse() {
		
	  let panel_state_total = 5;

      if (panel_state == 0) {
        panel_state = panel_state_total - 1;
      } else {
        panel_state = (panel_state - 1) % panel_state_total;
      }

      hmFS.SysProSetInt('goliath_panel', panel_state);

      apply_panel_switch();
    }

    function apply_panel_switch() {
      switch (panel_state) {

        case 0:
          //panel 1
          normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

          //panel 2
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);

          //panel 3
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 4
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 5
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          break;

        case 1:
          //panel 1
          normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          //panel 2
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, true);

          //panel 3
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 4
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 5
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          break;

        case 2:
          //panel 1
          normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          //panel 2
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);

          //panel 3
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  
		  
		  //panel 4
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 5
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
          break;
		  
		  case 3:
          //panel 1
          normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          //panel 2
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);

          //panel 3
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 4
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  
		  //panel 5
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          break;
		  
		  case 4:
          //panel 1
          normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          //panel 2
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);

          //panel 3
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 4
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  //panel 5
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

          break;

        default:
          break;
      }
    }
	
	function click_over_Switcher() {
		
	  let over_toggle_total = 3;

      over_toggle_state = (over_toggle_state + 1) % over_toggle_total;
	  
      hmFS.SysProSetInt('goliath_over', over_toggle_state);
	  
      apply_over_Switcher();
    }
	
	function click_over_Switcher_reverse() {
		
	  let over_toggle_total = 3;

	  if (over_toggle_state == 0) {
        over_toggle_state = over_toggle_total - 1;
      } else {
		over_toggle_state = (over_toggle_state - 1) % over_toggle_total;
	  }
	  
      hmFS.SysProSetInt('goliath_over', over_toggle_state);
	  
      apply_over_Switcher();
    }

    function apply_over_Switcher() {
      switch (over_toggle_state) {

        case 0:
          normal_battery_icon_img.setProperty(hmUI.prop.SRC, 'over1.png');
          break;

        case 1:
          normal_battery_icon_img.setProperty(hmUI.prop.SRC, 'over2.png');
          break;

        case 2:
          normal_battery_icon_img.setProperty(hmUI.prop.SRC, 'over3.png');
          break;

        default:
          break;
      }
    }
		
		function click_Hideanimation() {
              animhnumber=animhnumber+1;
			  hmFS.SysProSetInt('goliath_animh', animhnumber);
              switch (animhnumber) {
              case 1:
              Hideanimation(1); break;
              default:
              Hideanimation(0); animhnumber=0;
              }
              if(animhnumber==1) hmUI.showToast({text: 'Animation HIDE'});
		      if(animhnumber==0) hmUI.showToast({text: 'Animation SHOW'});
        }
		
		function Hideanimation(number) {
           if(number==1) {
                  Hideanim();
			        } else {
                  Showanim();
              }
        }
		
        function Hideanim(){
				  normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, false);
        }

		function Showanim(){
				  normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
        }	
		
		function click_bg_Switcher() {
			
		  let bg_toggle_total = 9;
		  
		  bg_toggle_state = (bg_toggle_state + 1) % bg_toggle_total;
		  
          hmFS.SysProSetInt('goliath_bg', bg_toggle_state);
		  
          apply_bg_Switcher();
        }

    function apply_bg_Switcher() {
      switch (bg_toggle_state) {

        case 0:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg1.png');
          break;

        case 1:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg2.png');
          break;

        case 2:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg3.png');
          break;

        case 3:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg4.png');
          break;
		  
		case 4:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg5.png');
          break;

        case 5:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg6.png');
          break;

        case 6:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg7.png');
          break;

        case 7:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg8.png');
          break;
		  
		case 8:
          normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'bg9.png');
          break;

        default:
          break;
      }
    }
	
	function click_color_Switcher() {
		
		let color_toggle_total = 9;
		
        color_toggle_state = (color_toggle_state + 1) % color_toggle_total;
		
        hmFS.SysProSetInt('goliath_color', color_toggle_state);
		
        apply_color_Switcher();
    }

    function apply_color_Switcher() {
      switch (color_toggle_state) {

        case 0:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main1.png');
          break;

        case 1:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main2.png');
          break;

        case 2:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main3.png');
          break;

        case 3:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main4.png');
          break;
		  
		case 4:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main5.png');
          break;

        case 5:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main6.png');
          break;

        case 6:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main7.png');
          break;

        case 7:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main8.png');
          break;
		  
		case 8:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main9.png');
          break;

        default:
          break;
      }
    }
		
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 20,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
                normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
                normal_rotate_animation_lastTime_1 = now.utc;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'anim_0.png',
              // anim_fps: 20,
              // anim_duration: 3000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 350,
              y: 206,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 170,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              dot_image: 'num_16.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 140,
              src: 'icon_ss.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 277,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              dot_image: 'num_16.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 305,
              src: 'icon_sr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 284,
              src: 'icon_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 284,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -4,
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 162,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'num_15.png',
              unit_tc: 'num_15.png',
              unit_en: 'num_15.png',
              negative_image: 'num_14.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 195,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_act.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 165,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 284,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              imperial_unit_sc: 'num_12.png',
              imperial_unit_tc: 'num_12.png',
              imperial_unit_en: 'num_12.png',
              dot_image: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 237,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 332,
              month_startY: 278,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			 normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 337,
              day_startY: 213,
              day_sc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_tc_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_en_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 321,
              y: 142,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			 normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 318,
              second_startY: 299,
              second_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 148,
              src: 'icon_24h.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 318,
              am_y: 148,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 318,
              pm_y: 148,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 336,
              minute_startY: 242,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 336,
              hour_startY: 181,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_hour.png',
              // center_x: 160,
              // center_y: 240,
              // x: 90,
              // y: 90,
              // start_angle: 180,
              // end_angle: 393,
              // cover_path: 't_hour_top.png',
              // cover_x: 70,
              // cover_y: 150,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 160 - 90,
              pos_y: 240 - 90,
              center_x: 160,
              center_y: 240,
              src: 't_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 150,
              src: 't_hour_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_min.png',
              // center_x: 160,
              // center_y: 240,
              // x: 110,
              // y: 110,
              // start_angle: 180,
              // end_angle: 393,
              // cover_path: 't_min_top.png',
              // cover_x: 50,
              // cover_y: 130,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 160 - 110,
              pos_y: 240 - 110,
              center_x: 160,
              center_y: 240,
              src: 't_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 130,
              src: 't_min_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_sec.png',
              // center_x: 160,
              // center_y: 240,
              // x: 85,
              // y: 145,
              // start_angle: 160,
              // end_angle: 89,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 160 - 85,
              pos_y: 240 - 145,
              center_x: 160,
              center_y: 240,
              src: 't_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_batt.png',
              center_x: 160,
              center_y: 240,
              x: 28,
              y: 105,
              start_angle: 125,
              end_angle: 53,
              cover_path: 'ov_batt.png',
              cover_x: 189,
              cover_y: 150,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'over1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 371,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'batt_unit.png',
              unit_tc: 'batt_unit.png',
              unit_en: 'batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 369,
              src: 'batt_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 79,
              src: 'hr_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 72,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_hour.png',
              // center_x: 160,
              // center_y: 240,
              // x: 90,
              // y: 90,
              // start_angle: 180,
              // end_angle: 393,
              // cover_path: 't_hour_top.png',
              // cover_x: 70,
              // cover_y: 150,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 160 - 90,
              pos_y: 240 - 90,
              center_x: 160,
              center_y: 240,
              src: 't_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 150,
              src: 't_hour_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_min.png',
              // center_x: 160,
              // center_y: 240,
              // x: 110,
              // y: 110,
              // start_angle: 180,
              // end_angle: 393,
              // cover_path: 't_min_top.png',
              // cover_x: 50,
              // cover_y: 130,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 160 - 110,
              pos_y: 240 - 110,
              center_x: 160,
              center_y: 240,
              src: 't_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 130,
              src: 't_min_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 336,
              minute_startY: 242,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 336,
              hour_startY: 181,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_batt.png',
              center_x: 160,
              center_y: 240,
              x: 28,
              y: 105,
              start_angle: 125,
              end_angle: 53,
              cover_path: 'ov_batt.png',
              cover_x: 189,
              cover_y: 150,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'over_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 240,
              w: 100,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 180,
              w: 100,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 240,
              w: 100,
              h: 70,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 170,
              w: 100,
              h: 70,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 270,
              w: 100,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 160,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 190,
              w: 50,
              h: 100,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 145,
              w: 100,
              h: 60,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 280,
              w: 100,
              h: 60,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 70,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 210,
              w: 100,
              h: 65,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			
			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 333,
              y: 180,
			  text: '',
              w: 100,
              h: 120,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 360,
			  text: '',
              w: 100,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			next_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 50,
          y: 345,
          text: '',
          w: 50,
          h: 50,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_panel_Switcher();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        prev_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 50,
          y: 85,
          text: '',
          w: 50,
          h: 50,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_panel_Switcher_reverse();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
		
		next_over_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 230,
          y: 110,
          text: '',
          w: 50,
          h: 50,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_over_Switcher();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
		
		prev_over_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 230,
          y: 320,
          text: '',
          w: 50,
          h: 50,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_over_Switcher_reverse();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
		
		    btnanimstop = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 10,
              text: '',
              w: 100,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_Hideanimation();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			btnanimhide = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 420,
              text: '',
              w: 100,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_Hideanimation();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			btn_bg = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 360,
              text: '',
              w: 70,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_bg_Switcher();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			btn_color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 70,
              text: '',
              w: 70,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_color_Switcher();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
			});

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateMinute) {
                let normal_fullAngle_minute = 213;
                let normal_angle_minute = 180 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 213;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 180 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              let normal_fullAngle_second = -71;
              let normal_angle_second = 160 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateMinute) {
                let idle_fullAngle_minute = 213;
                let idle_angle_minute = 180 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 213;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 180 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

            };
			
			loadSettings();

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 3000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                stop_anim_rotate_1();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}