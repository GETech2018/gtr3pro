﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 320,
              src: '0508.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 320,
              src: '0509.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 36,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 94,
              week_en: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_tc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_sc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 330,
              month_startY: 228,
              month_sc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_tc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_en_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 274,
              day_startY: 226,
              day_sc_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              day_tc_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              day_en_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["pulse_0.png","pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png","pulse_6.png","pulse_7.png","pulse_8.png","pulse_9.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 334,
              font_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 326,
              src: '0440.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 44,
              font_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: '0118.png',
              unit_tc: '0118.png',
              unit_en: '0118.png',
              negative_image: '0096.png',
              invalid_image: '0095.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 34,
              image_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 282,
              font_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '0660.png',
              unit_tc: '0660.png',
              unit_en: '0660.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 281,
              y: 262,
              image_array: ["pwr_0.png","pwr_1.png","pwr_2.png","pwr_3.png","pwr_4.png","pwr_5.png","pwr_6.png","pwr_7.png","pwr_8.png","pwr_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 422,
              font_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 378,
              font_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["step_0.png","step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 138,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 274,
              minute_startY: 140,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 372,
              second_startY: 140,
              second_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 320,
              src: '0508.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 320,
              src: '0509.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 94,
              week_en: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_tc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_sc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 330,
              month_startY: 228,
              month_sc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_tc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_en_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 274,
              day_startY: 226,
              day_sc_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              day_tc_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              day_en_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 282,
              font_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '0660.png',
              unit_tc: '0660.png',
              unit_en: '0660.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 281,
              y: 262,
              image_array: ["pwr_0.png","pwr_1.png","pwr_2.png","pwr_3.png","pwr_4.png","pwr_5.png","pwr_6.png","pwr_7.png","pwr_8.png","pwr_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 138,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 274,
              minute_startY: 140,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 372,
              second_startY: 140,
              second_array: ["mdig_0.png","mdig_1.png","mdig_2.png","mdig_3.png","mdig_4.png","mdig_5.png","mdig_6.png","mdig_7.png","mdig_8.png","mdig_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: НЕТ СВЯЗИ!,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: СВЯЗЬ ЕСТЬ!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "НЕТ СВЯЗИ!"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "СВЯЗЬ ЕСТЬ!"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'blend.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 135,
              w: 80,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 135,
              w: 85,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 175,
              w: 100,
              h: 100,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 315,
              w: 110,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 75,
              w: 100,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 75,
              w: 100,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 20,
              w: 110,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 210,
              w: 100,
              h: 100,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 310,
              w: 90,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 310,
              w: 100,
              h: 100,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 420,
              w: 120,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 367,
              w: 150,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}