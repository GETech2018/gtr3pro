    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_sun_current_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 318,
              y: 37,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 13,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 72,
              font_array: ["A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_126.png',
              unit_tc: 'A100_126.png',
              unit_en: 'A100_126.png',
              negative_image: 'A100_124.png',
              invalid_image: 'A100_125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 229,
              day_startY: 11,
              day_sc_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              day_tc_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              day_en_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 62,
              week_en: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png"],
              week_tc: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png"],
              week_sc: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 278,
              font_array: ["A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              padding: false,
              h_space: -2,
              dot_image: 'dig_6_w_min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 97,
              // center_y: 318,
              // start_angle: 76,
              // end_angle: 283,
              // radius: 60,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 97,
              center_y: 318,
              start_angle: 76,
              end_angle: 283,
              radius: 55,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 269,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 241,
              // center_y: 399,
              // start_angle: 76,
              // end_angle: 286,
              // radius: 66,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 241,
              center_y: 399,
              start_angle: 76,
              end_angle: 286,
              radius: 61,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 344,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 383,
              // center_y: 318,
              // start_angle: 76,
              // end_angle: 283,
              // radius: 60,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 383,
              center_y: 318,
              start_angle: 76,
              end_angle: 283,
              radius: 55,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 269,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 34,
              am_y: 141,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 34,
              pm_y: 141,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 101,
              hour_array: ["H-1.png","H-2.png","H-3.png","H-4.png","H-5.png","H-6.png","H-7.png","H-8.png","H-9.png","H-10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 259,
              minute_startY: 101,
              minute_array: ["H-1.png","H-2.png","H-3.png","H-4.png","H-5.png","H-6.png","H-7.png","H-8.png","H-9.png","H-10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 391,
              second_startY: 181,
              second_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 318,
              y: 37,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
              autoToggleWeatherIcons();
            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 13,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 72,
              font_array: ["A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_126.png',
              unit_tc: 'A100_126.png',
              unit_en: 'A100_126.png',
              negative_image: 'A100_124.png',
              invalid_image: 'A100_125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 229,
              day_startY: 11,
              day_sc_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              day_tc_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              day_en_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 62,
              week_en: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png"],
              week_tc: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png"],
              week_sc: ["D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 278,
              font_array: ["A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              padding: false,
              h_space: -2,
              dot_image: 'dig_6_w_min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 97,
              // center_y: 318,
              // start_angle: 76,
              // end_angle: 283,
              // radius: 60,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 97,
              center_y: 318,
              start_angle: 76,
              end_angle: 283,
              radius: 55,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 269,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 241,
              // center_y: 399,
              // start_angle: 76,
              // end_angle: 286,
              // radius: 66,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 241,
              center_y: 399,
              start_angle: 76,
              end_angle: 286,
              radius: 61,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 344,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 383,
              // center_y: 318,
              // start_angle: 76,
              // end_angle: 283,
              // radius: 60,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF595959,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 383,
              center_y: 318,
              start_angle: 76,
              end_angle: 283,
              radius: 55,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF595959,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 269,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 34,
              am_y: 141,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 34,
              pm_y: 141,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 101,
              hour_array: ["H-1.png","H-2.png","H-3.png","H-4.png","H-5.png","H-6.png","H-7.png","H-8.png","H-9.png","H-10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 259,
              minute_startY: 101,
              minute_array: ["H-1.png","H-2.png","H-3.png","H-4.png","H-5.png","H-6.png","H-7.png","H-8.png","H-9.png","H-10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 391,
              second_startY: 181,
              second_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 95,
              src: '0050.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 97,
              y: 16,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 63,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 230,
              y: 33,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 307,
              y: 33,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 430,
              y: 208,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 342,
              y: 270,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 342,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 261,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 261,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 388,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 48,
              y: 400,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -2,
              y: 203,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 97,
                      center_y: 318,
                      start_angle: 76,
                      end_angle: 283,
                      radius: 55,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 241,
                      center_y: 399,
                      start_angle: 76,
                      end_angle: 286,
                      radius: 61,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 383,
                      center_y: 318,
                      start_angle: 76,
                      end_angle: 283,
                      radius: 55,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 97,
                      center_y: 318,
                      start_angle: 76,
                      end_angle: 283,
                      radius: 55,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 241,
                      center_y: 399,
                      start_angle: 76,
                      end_angle: 286,
                      radius: 61,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 383,
                      center_y: 318,
                      start_angle: 76,
                      end_angle: 283,
                      radius: 55,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF595959,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				autoToggleWeatherIcons();
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}