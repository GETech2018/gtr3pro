﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
 width: D_W,
 height: D_H
} = hmSetting.getDeviceInfo();


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//#endregion

let text_pressere; // отображаем давление
let text_pressere_changes; // отображаем изменение давления 


let theme_up = 0

function click_theme_up() {
 theme_up = (theme_up + 1) % 2
 normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, theme_up == 0);
 normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, theme_up == 0);
 normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, theme_up == 1);
 normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, theme_up == 1);
 normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, theme_up == 1);
}

let theme_left = 0

function click_theme_left() {
 theme_left = (theme_left + 1) % 2
 normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, theme_left == 0);
 normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, theme_left == 0);
 normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, theme_left == 1);
 normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, theme_left == 1);
}

let theme_right = 0

function click_theme_right() {
 theme_right = (theme_right + 1) % 2

 normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, theme_right == 0);
 normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, theme_right == 0);
 normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, theme_right == 1);
 normal_press_text_text_img.setProperty(hmUI.prop.VISIBLE, theme_right == 1);
}

        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF000000, 0xFF00265A, 0xFF5A0004, 0xFF005A0F, 0xFF5A5500, 0xFFFF0000, 0xFF008040, 0xFF0080FF, 0xFFFBC807];
        let bgColorToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 102,
              src: 'ic_zak.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 67,
              // start_y: 292,
              // color: 0xFFFFFFFF,
              // lenght: 22,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 126,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 102,
              src: 'ic_vos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 126,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'dig_v.png',
              dot_image: 'dig_dot2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 126,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 4,
              dot_image: 'dig_dot2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 102,
              src: 'ic_mm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 102,
              src: 'ic_vl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 126,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'dig_pr.png',
              unit_tc: 'dig_pr.png',
              unit_en: 'dig_pr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 50,
              src: 'ic_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 73,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'dig_km.png',
              unit_tc: 'dig_km.png',
              unit_en: 'dig_km.png',
              dot_image: 'dig_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 400,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 50,
              src: 'ic_now.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 192,
              y: 69,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 73,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'dig_g.png',
              unit_tc: 'dig_g.png',
              unit_en: 'dig_g.png',
              negative_image: 'dig_m.png',
              invalid_image: 'dig_v.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 349,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 272,
              image_array: ["step_pr_0.png","step_pr_1.png","step_pr_2.png","step_pr_3.png","step_pr_4.png","step_pr_5.png","step_pr_6.png","step_pr_7.png","step_pr_8.png","step_pr_9.png","step_pr_10.png","step_pr_11.png","step_pr_12.png","step_pr_13.png","step_pr_14.png","step_pr_15.png","step_pr_16.png","step_pr_17.png","step_pr_18.png","step_pr_19.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 349,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 229,
              month_startY: 158,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 300,
              year_startY: 164,
              year_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              year_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              year_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 184,
              day_startY: 164,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 108,
              y: 164,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 194,
              hour_array: ["H0.png","H1.png","H2.png","H3.png","H4.png","H5.png","H6.png","H7.png","H8.png","H9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 265,
              minute_startY: 194,
              minute_array: ["H0.png","H1.png","H2.png","H3.png","H4.png","H5.png","H6.png","H7.png","H8.png","H9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 53,
              y: 203,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 301,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 207,
              src: 'a_dot2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 161,
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'dig_pr.png',
              unit_tc: 'dig_pr.png',
              unit_en: 'dig_pr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 273,
              month_startY: 265,
              month_sc_array: ["A_month_0.png","A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png"],
              month_tc_array: ["A_month_0.png","A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png"],
              month_en_array: ["A_month_0.png","A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 221,
              day_startY: 271,
              day_sc_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              day_tc_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              day_en_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 271,
              week_en: ["A_week_0.png","A_week_1.png","A_week_2.png","A_week_3.png","A_week_4.png","A_week_5.png","A_week_6.png"],
              week_tc: ["A_week_0.png","A_week_1.png","A_week_2.png","A_week_3.png","A_week_4.png","A_week_5.png","A_week_6.png"],
              week_sc: ["A_week_0.png","A_week_1.png","A_week_2.png","A_week_3.png","A_week_4.png","A_week_5.png","A_week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 194,
              hour_array: ["H0.png","H1.png","H2.png","H3.png","H4.png","H5.png","H6.png","H7.png","H8.png","H9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 265,
              minute_startY: 194,
              minute_array: ["H0.png","H1.png","H2.png","H3.png","H4.png","H5.png","H6.png","H7.png","H8.png","H9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

           const step = hmSensor.createSensor(hmSensor.id.STEP);

           normal_step_progress_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 316*(D_W /466),
            y: 263*(D_H /466),
            text: 23,
            font_array: ["dig_0.png", "dig_1.png", "dig_2.png", "dig_3.png", "dig_4.png", "dig_5.png", "dig_6.png", "dig_7.png", "dig_8.png", "dig_9.png"],
            padding: true,
            h_space: 4,
            align_h: hmUI.align.LEFT,
            //type: hmUI.data_type.FAT_BURNING,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

            normal_alarm_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293*(D_W /466),
              y: 291*(D_H /466),
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: true,
              h_space: 4,
              invalid_image: 'dig_vAL.png',
              dot_image: 'dig_dot2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_press_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273*(D_W /466),
              y: 122*(D_H /466),
              text: "760",
              font_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
             // type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, theme_up == 0);	
normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, theme_up == 0);
normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, theme_up == 1);
normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, theme_up == 1);
normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, theme_up == 1);	

normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, theme_left == 0);
normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, theme_left == 0);
normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, theme_left == 1);
normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, theme_left == 1);	

 normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, theme_right == 0);
 normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, theme_right == 0);
 normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, theme_right == 1);
 normal_press_text_text_img.setProperty(hmUI.prop.VISIBLE, theme_right == 1);


            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 188,
              w: 103,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'press.png',
              normal_src: 'press.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 0,
              w: 103,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'press.png',
              normal_src: 'press.png',
              click_func: (button_widget) => {
                click_theme_up();
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 93,
              y: 104,
              w: 103,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'press.png',
              normal_src: 'press.png',
              click_func: (button_widget) => {
                click_theme_left();
vibro();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 104,
              w: 103,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'press.png',
              normal_src: 'press.png',
              click_func: (button_widget) => {
                click_theme_right();
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 207,
              // y: 183,
              // w: 50,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'press.png',
              // normal_src: 'press.png',
              // color_list: 0xFF000000|0xFF00265A|0xFF5A0004|0xFF005A0F|0xFF5A5500|0xFFFF0000|0xFF008040|0xFF0080FF|0xFFFBC807,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 183,
              w: 50,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'press.png',
              normal_src: 'press.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 67;
                  let start_y_normal_battery = 292;
                  let lenght_ls_normal_battery = 22;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                console.log('resume_call.js');
                // start resume_call.js

let valueStep = step.current;
let targetStep = step.target;
let distStr = parseInt(step.current * 100 / step.target)
normal_step_progress_current_text_img.setProperty(hmUI.prop.TEXT, String(distStr));

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
                  
let pressere_changes_str = "=";
//let color_pressere = 0x00ff00;
// let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;
				  
let pressere_changes = changesPressure(pressure_array);
if(pressere_changes < 0) {pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/}
if(pressere_changes > 0) {pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/}
//text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);
                  
//let value_str = value == 0 ? "--" : value + pressere_changes_str;
//text_pressere.setProperty(hmUI.prop.TEXT, value_str);
//text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);

normal_press_text_text_img.setProperty(hmUI.prop.TEXT, String(value));


                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}