﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_system_disconnect_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day1.png',
              center_x: 238,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: -50,
              end_angle: 40,
              scale_sc: 'wd1.png',
              scale_tc: 'wd1.png',
              scale_en: 'wd1.png',
              scale_x: 0,
              scale_y: 0,
              cover_path: 'overlay_on.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'overlay_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png","batt_11.png","batt_12.png","batt_13.png","batt_14.png","batt_15.png","batt_16.png","batt_17.png","batt_18.png","batt_19.png","batt_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 156,
              hour_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              hour_zero: 1,
              hour_space: -25,
              hour_unit_sc: 'big_11.png',
              hour_unit_tc: 'big_11.png',
              hour_unit_en: 'big_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              minute_zero: 1,
              minute_space: -25,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 314,
              second_startY: 184,
              second_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              second_zero: 1,
              second_space: -15,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 69,
              src: 'time_overlay.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'overlay_on1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 156,
              hour_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              hour_zero: 1,
              hour_space: -25,
              hour_unit_sc: 'big_11.png',
              hour_unit_tc: 'big_11.png',
              hour_unit_en: 'big_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              minute_zero: 1,
              minute_space: -25,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 314,
              second_startY: 184,
              second_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              second_zero: 1,
              second_space: -15,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  