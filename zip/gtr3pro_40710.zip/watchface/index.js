﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0;
		
		let COVERstyle = 0;
        function click_COVER() {
			COVERstyle=COVERstyle+1;
            if(COVERstyle>5)  {COVERstyle=0;}
			hmUI.showToast({text: "COVER "+ COVERstyle }); normal_image_img.setProperty(hmUI.prop.SRC, "cov" + COVERstyle + ".png");
        }

		let BACKstyle = 0;
        function click_BACKGROUND() {
			BACKstyle=BACKstyle+1;
            if(BACKstyle>3)  {BACKstyle=0;}
			hmUI.showToast({text: "BACKGROUND "+ BACKstyle }); normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + BACKstyle + ".png");
        }
		
		let MODEnumber = 1;
        function click_MODE() {
			MODEnumber=MODEnumber+1;
            if(MODEnumber>3)  {MODEnumber=0;}
			
			hmUI.showToast({text: "MODE " + MODEnumber });
			
			normal_hour_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_hour_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_minute_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_minute_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_second_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_second_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
			
			normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[3].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[4].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            
			normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[3].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[4].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            
            normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_heart_rate_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_heart_rate_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[3].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
			
        }
/*        
            normal_year_text_font.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_month_name_font.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);

			normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_analog_clock_pro_minute_cover_pointer_img.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            
*/		

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 25;
        let normal_heart_rate_TextCircle_img_height = 28;
        let normal_heart_rate_TextCircle_unit = null;
        let normal_heart_rate_TextCircle_unit_width = 53;
        let normal_spo2_TextCircle = new Array(3);
        let normal_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let normal_spo2_TextCircle_img_width = 25;
        let normal_spo2_TextCircle_img_height = 28;
        let normal_spo2_TextCircle_unit = null;
        let normal_spo2_TextCircle_unit_width = 29;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 25;
        let normal_calorie_TextCircle_img_height = 28;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 25;
        let normal_distance_TextCircle_img_height = 28;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 36;
        let normal_distance_TextCircle_dot_width = 11;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 25;
        let normal_step_TextCircle_img_height = 28;
        let normal_step_TextCircle_unit = null;
        let normal_step_TextCircle_unit_width = 66;
        let normal_year_text_font = ''
        let normal_date_img_date_day = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WEN', 'THR', 'FRI', 'SAT', 'SUN'];
        let normal_month_name_font = ''
        let normal_Month_Array = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', ];
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 25;
        let normal_hour_TextCircle_img_height = 28;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 11;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 25;
        let normal_minute_TextCircle_img_height = 28;
        let normal_minute_TextCircle_unit = null;
        let normal_minute_TextCircle_unit_width = 11;
        let normal_second_TextCircle = new Array(2);
        let normal_second_TextCircle_ASCIIARRAY = new Array(10);
        let normal_second_TextCircle_img_width = 25;
        let normal_second_TextCircle_img_height = 28;
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_minute_cover_pointer_img = ''
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 25;
        let idle_hour_TextCircle_img_height = 28;
        let idle_hour_TextCircle_unit = null;
        let idle_hour_TextCircle_unit_width = 11;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextCircle = new Array(2);
        let idle_minute_TextCircle_ASCIIARRAY = new Array(10);
        let idle_minute_TextCircle_img_width = 25;
        let idle_minute_TextCircle_img_height = 28;
        let idle_minute_TextCircle_unit = null;
        let idle_minute_TextCircle_unit_width = 11;
        let idle_second_TextCircle = new Array(2);
        let idle_second_TextCircle_ASCIIARRAY = new Array(10);
        let idle_second_TextCircle_img_width = 25;
        let idle_second_TextCircle_img_height = 28;
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 169,
              // char_space_angle: 1,
              // unit: 'txt_bpm.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'txt_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 210,
              // char_space_angle: 1,
              // unit: 'txt_percent.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_spo2_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_spo2_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_spo2_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_spo2_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'txt_percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
            spo2.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 150,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 173,
              // char_space_angle: 1,
              // unit: 'txt_km.png',
              // imperial_unit: 'txt_ml.png',
              // dot_image: 'num1d.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'txt_km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'txt_ml.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 195,
              // char_space_angle: 1,
              // unit: 'txt_steps.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_step_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'txt_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 115,
              y: 240,
              w: 70,
              h: 40,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 314,
              day_startY: 247,
              day_sc_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              day_tc_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              day_en_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 300,
              y: 215,
              w: 70,
              h: 40,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON, TUE, WEN, THR, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 115,
              y: 215,
              w: 70,
              h: 40,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'phourx.png',
              hour_centerX: 245,
              hour_centerY: 245,
              hour_posX: 12,
              hour_posY: 128,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pminx.png',
              minute_centerX: 245,
              minute_centerY: 245,
              minute_posX: 12,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'psecx.png',
              second_centerX: 245,
              second_centerY: 245,
              second_posX: 10,
              second_posY: 173,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'phour1.png',
              // center_x: 240,
              // center_y: 241,
              // x: 13,
              // y: 128,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 13,
              pos_y: 241 - 128,
              center_x: 240,
              center_y: 241,
              src: 'phour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pmin1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 12,
              // y: 180,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'pdot.png',
              // cover_x: 221,
              // cover_y: 222,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 12,
              pos_y: 240 - 180,
              center_x: 240,
              center_y: 240,
              src: 'pmin1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 222,
              src: 'pdot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'psec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 10,
              // y: 173,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 10,
              pos_y: 240 - 173,
              center_x: 240,
              center_y: 240,
              src: 'psec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 203,
              // char_space_angle: 1,
              // unit: 'num1c.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_hour_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'num1c.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 184,
              // char_space_angle: 1,
              // unit: 'num1c.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_minute_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_minute_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_minute_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'num1c.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 165,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_second_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'phourn.png',
              // center_x: 240,
              // center_y: 241,
              // x: 13,
              // y: 128,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 13,
              pos_y: 241 - 128,
              center_x: 240,
              center_y: 241,
              src: 'phourn.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pminn.png',
              // center_x: 240,
              // center_y: 240,
              // x: 12,
              // y: 180,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'pdotn.png',
              // cover_x: 221,
              // cover_y: 222,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 12,
              pos_y: 240 - 180,
              center_x: 240,
              center_y: 240,
              src: 'pminn.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 222,
              src: 'pdotn.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 205,
              // char_space_angle: 1,
              // unit: 'num1c.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_hour_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_hour_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'num1c.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 186,
              // char_space_angle: 1,
              // unit: 'num1c.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_minute_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_minute_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_minute_TextCircle_unit_width / 2,
              pos_y: 240 + 198,
              src: 'num1c.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num10.png","num11.png","num12.png","num13.png","num14.png","num15.png","num16.png","num17.png","num18.png","num19.png"],
              // radius: 226,
              // angle: 167,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextCircle_ASCIIARRAY[0] = 'num10.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[1] = 'num11.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[2] = 'num12.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[3] = 'num13.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[4] = 'num14.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[5] = 'num15.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[6] = 'num16.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[7] = 'num17.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[8] = 'num18.png';  // set of images with numbers
            idle_second_TextCircle_ASCIIARRAY[9] = 'num19.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_second_TextCircle_img_width / 2,
                pos_y: 240 + 198,
                src: 'num10.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 389,
              w: 250,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_on.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_MODE();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: -13,
              w: 205,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_top.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_BACKGROUND();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc ==0 ){
	click_MODE();
	cc = 1;
}
/*
  if (screenType != hmSetting.screen_type.AOD && TIMERstyle==2) {

  if (screenType != hmSetting.screen_type.AOD && TIMERstyle==2) {
*/
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_circle_string = normal_heart_rate_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==3) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 349;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  let normal_heart_rate_TextCircle_unit_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 226));
                  normal_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_unit_width/2, 226));
                  // alignment = RIGHT
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + (normal_heart_rate_TextCircle_img_angle + normal_heart_rate_TextCircle_unit_angle + 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_heart_rate_TextCircle_unit_angle;
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle spo2_SPO2');
              let valueSpO2 = spo2.current;
              let normal_spo2_circle_string = parseInt(valueSpO2).toString();
              normal_spo2_circle_string = normal_spo2_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==3) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 390;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && normal_spo2_circle_string.length > 0 && normal_spo2_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_spo2_TextCircle_img_angle = 0;
                  let normal_spo2_TextCircle_dot_img_angle = 0;
                  let normal_spo2_TextCircle_unit_angle = 0;
                  normal_spo2_TextCircle_img_angle = toDegree(Math.atan2(normal_spo2_TextCircle_img_width/2, 226));
                  normal_spo2_TextCircle_unit_angle = toDegree(Math.atan2(normal_spo2_TextCircle_unit_width/2, 226));
                  // alignment = RIGHT
                  let normal_spo2_TextCircle_angleOffset = normal_spo2_TextCircle_img_angle * (normal_spo2_circle_string.length - 1);
                  normal_spo2_TextCircle_angleOffset = normal_spo2_TextCircle_angleOffset + 1 * (normal_spo2_circle_string.length - 1) / 2;
                  normal_spo2_TextCircle_angleOffset = normal_spo2_TextCircle_angleOffset + (normal_spo2_TextCircle_img_angle + normal_spo2_TextCircle_unit_angle + 1) / 2;
                  normal_spo2_TextCircle_angleOffset = -normal_spo2_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_spo2_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_spo2_TextCircle_img_width / 2);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, normal_spo2_TextCircle_ASCIIARRAY[charCode]);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_spo2_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_spo2_TextCircle_unit_angle;
                  normal_spo2_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();
              normal_calorie_circle_string = normal_calorie_circle_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==3) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 330;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);
              normal_distance_circle_string = normal_distance_circle_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==2) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 353;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 226));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 226));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'num1d.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();
              normal_step_circle_string = normal_step_circle_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==2) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 375;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  let normal_step_TextCircle_unit_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 226));
                  normal_step_TextCircle_unit_angle = toDegree(Math.atan2(normal_step_TextCircle_unit_width/2, 226));
                  // alignment = RIGHT
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + (normal_step_TextCircle_img_angle + normal_step_TextCircle_unit_angle + 1) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_step_TextCircle_unit_angle;
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==1) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 383;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 226));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_hour_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==1) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 364;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  let normal_minute_TextCircle_unit_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 226));
                  normal_minute_TextCircle_unit_angle = toDegree(Math.atan2(normal_minute_TextCircle_unit_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_minute_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_minute_TextCircle_unit_angle;
                  normal_minute_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_circle_string = parseInt(valueSecond).toString();
              normal_second_circle_string = normal_second_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD && MODEnumber==1) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 345;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_circle_string.length > 0 && normal_second_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_second_TextCircle_img_angle = 0;
                  let normal_second_TextCircle_dot_img_angle = 0;
                  normal_second_TextCircle_img_angle = toDegree(Math.atan2(normal_second_TextCircle_img_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_second_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_second_TextCircle_img_width / 2);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.SRC, normal_second_TextCircle_ASCIIARRAY[charCode]);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_second_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 385;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  let idle_hour_TextCircle_unit_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, 226));
                  idle_hour_TextCircle_unit_angle = toDegree(Math.atan2(idle_hour_TextCircle_unit_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_hour_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_hour_TextCircle_unit_angle;
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let idle_minute_circle_string = parseInt(valueMinute).toString();
              idle_minute_circle_string = idle_minute_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 366;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_circle_string.length > 0 && idle_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_minute_TextCircle_img_angle = 0;
                  let idle_minute_TextCircle_dot_img_angle = 0;
                  let idle_minute_TextCircle_unit_angle = 0;
                  idle_minute_TextCircle_img_angle = toDegree(Math.atan2(idle_minute_TextCircle_img_width/2, 226));
                  idle_minute_TextCircle_unit_angle = toDegree(Math.atan2(idle_minute_TextCircle_unit_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_minute_TextCircle_img_width / 2);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.SRC, idle_minute_TextCircle_ASCIIARRAY[charCode]);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_minute_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_minute_TextCircle_unit_angle;
                  idle_minute_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let idle_second_circle_string = parseInt(valueSecond).toString();
              idle_second_circle_string = idle_second_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 347;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_circle_string.length > 0 && idle_second_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_second_TextCircle_img_angle = 0;
                  let idle_second_TextCircle_dot_img_angle = 0;
                  idle_second_TextCircle_img_angle = toDegree(Math.atan2(idle_second_TextCircle_img_width/2, 226));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_second_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_second_TextCircle_img_width / 2);
                      idle_second_TextCircle[index].setProperty(hmUI.prop.SRC, idle_second_TextCircle_ASCIIARRAY[charCode]);
                      idle_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_second_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}