﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'marine-bck2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 115,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'nn-percentuale.png',
              unit_tc: 'nn-percentuale.png',
              unit_en: 'nn-percentuale.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 85,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'nn-percentuale.png',
              unit_tc: 'nn-percentuale.png',
              unit_en: 'nn-percentuale.png',
              invalid_image: 'nn-0010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 260,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 180,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'nn-0011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 165,
              src: 'nn-alba.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 285,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'nn-0011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 268,
              src: 'nn-tramonto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 243,
              // center_y: 350,
              // start_angle: 153,
              // end_angle: 25,
              // radius: 56,
              // line_width: 5,
              // color: 0xFFE31C21,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 321,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 342,
              src: 'nn-HR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 359,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'nn-km.png',
              unit_tc: 'nn-km.png',
              unit_en: 'nn-km.png',
              dot_image: 'nn-0010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 234,
              font_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'num-meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 117,
              y: 195,
              image_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 306,
              font_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 326,
              src: 'passi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 350,
              // start_angle: 210,
              // end_angle: 331,
              // radius: 57,
              // line_width: 5,
              // color: 0xFF00FF40,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 321,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 342,
              src: 'nn-percentuale.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 272,
              y: 169,
              week_en: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              week_tc: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              week_sc: ["day-0001.png","day-0002.png","day-0003.png","day-0004.png","day-0005.png","day-0006.png","day-0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 313,
              month_startY: 243,
              month_sc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_tc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_en_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 211,
              day_sc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_tc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_en_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ahod.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 19,
              hour_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'amin.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 19,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec-an.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 8,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 234,
              font_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'num-meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 117,
              y: 195,
              image_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 321,
              font_array: ["nn-0000.png","nn-0001.png","nn-0002.png","nn-0003.png","nn-0004.png","nn-0005.png","nn-0006.png","nn-0007.png","nn-0008.png","nn-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 342,
              src: 'nn-percentuale.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 313,
              month_startY: 243,
              month_sc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_tc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_en_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 211,
              day_sc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_tc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_en_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 88,
              hour_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 88,
              minute_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 227,
              second_startY: 88,
              second_array: ["se-0000.png","se-0001.png","se-0002.png","se-0003.png","se-0004.png","se-0005.png","se-0006.png","se-0007.png","se-0008.png","se-0009.png"],
              second_zero: 0,
              second_space: -19,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 88,
              src: 'nu-0010.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_normal_heart_rate = 63;
                  let end_angle_normal_heart_rate = -65;
                  let center_x_normal_heart_rate = 243;
                  let center_y_normal_heart_rate = 350;
                  let radius_normal_heart_rate = 56;
                  let line_width_cs_normal_heart_rate = 5;
                  let color_cs_normal_heart_rate = 0xFFE31C21;
                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 120;
                  let end_angle_normal_battery = 241;
                  let center_x_normal_battery = 239;
                  let center_y_normal_battery = 350;
                  let radius_normal_battery = 57;
                  let line_width_cs_normal_battery = 5;
                  let color_cs_normal_battery = 0xFF00FF40;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  