﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

function endDemo (options) {
    hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'bg_demo.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
  }

const demoPeriod = 10 * 1000;
timer.createTimer(
    demoPeriod,
    demoPeriod,
    endDemo,
    {}
)

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 257,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 114,
              center_y: 240,
              x: 10,
              y: 56,
              start_angle: 211,
              end_angle: 330,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 133,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_0.png',
              center_x: 240,
              center_y: 111,
              x: 10,
              y: 60,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 15,
              month_startY: 16,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 375,
              day_startY: 229,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 221,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 115,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 170,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              imperial_unit_sc: 'pointer_3.png',
              imperial_unit_tc: 'pointer_3.png',
              imperial_unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 328,
                y: 170,
                font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'pointer_3.png',
                unit_tc: 'pointer_3.png',
                unit_en: 'pointer_3.png',
                imperial_unit_sc: 'pointer_3.png',
                imperial_unit_tc: 'pointer_3.png',
                imperial_unit_en: 'pointer_3.png',
                negative_image: 'pointer_2.png',
                invalid_image: 'dot.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 341,
              y: 295,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 388,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_0.png',
              center_x: 240,
              center_y: 363,
              x: 10,
              y: 60,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 156,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 257,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 114,
              center_y: 240,
              x: 10,
              y: 56,
              start_angle: 211,
              end_angle: 330,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 133,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_0.png',
              center_x: 240,
              center_y: 111,
              x: 10,
              y: 60,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 15,
              month_startY: 16,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 375,
              day_startY: 229,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 221,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 115,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 170,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              imperial_unit_sc: 'pointer_3.png',
              imperial_unit_tc: 'pointer_3.png',
              imperial_unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 328,
                y: 170,
                font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'pointer_3.png',
                unit_tc: 'pointer_3.png',
                unit_en: 'pointer_3.png',
                imperial_unit_sc: 'pointer_3.png',
                imperial_unit_tc: 'pointer_3.png',
                imperial_unit_en: 'pointer_3.png',
                negative_image: 'pointer_2.png',
                invalid_image: 'dot.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 341,
              y: 295,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 388,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_0.png',
              center_x: 240,
              center_y: 363,
              x: 10,
              y: 60,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 156,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 42,
              w: 140,
              h: 140,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 296,
              w: 140,
              h: 140,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 176,
              w: 130,
              h: 130,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 218,
              w: 130,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 115,
              w: 50,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}