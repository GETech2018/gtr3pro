﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_low_TextRotate = new Array(4);
        let normal_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_low_TextRotate_img_width = 21;
        let normal_low_TextRotate_unit = null;
        let normal_low_TextRotate_unit_width = 35;
        let normal_low_TextRotate_dot_width = 21;
        let normal_low_TextRotate_error_img_width = 21;
        let normal_weather_image_progress_img_level = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 21;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 27;
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 21;
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 56;
        let normal_timerTextUpdate = undefined;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 31;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 56;
        let normal_alarm_jumpable_img_click = ''

        let normal_g_heart = ''
        let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
        let min_heart = Math.min(...heartArr)
        let max_heart = Math.max(...heartArr)

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

   /////////////////////  Show graph heart rate  /////////////////////

             normal_g_heart=hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{

                              x: 49,
                              y: 265,
                              w: 232,
                              h: 60,
                              line_color:0xFF6600,
                              line_width:2,
            type:hmUI.data_type.HEART,
            show_level:hmUI.show_level.ONLY_NORMAL
          });


  ////////////////////////////////////////////////////////////////////

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 81,
              y: 362,
              src: '109.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 20,
              y: 21,
              src: '111.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 442,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFC57D,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 169,
              // y: 104,
              // font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 90,
              // unit_en: '110.png',
              // invalid_image: '59.png',
              // dot_image: '59.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextRotate_ASCIIARRAY[0] = '38.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[1] = '39.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[2] = '40.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[3] = '41.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[4] = '42.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[5] = '43.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[6] = '44.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[7] = '45.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[8] = '46.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[9] = '47.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 169,
                center_y: 104,
                pos_x: 169,
                pos_y: 104,
                angle: 90,
                src: '38.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 169,
              center_y: 104,
              pos_x: 169,
              pos_y: 104,
              angle: 90,
              src: '110.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 71,
              y: 88,
              image_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 166,
              // y: 416,
              // font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 91,
              // unit_en: '112.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '38.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '39.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '40.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '41.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '42.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '43.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '44.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '45.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '46.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '47.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 166,
                center_y: 416,
                pos_x: 166,
                pos_y: 416,
                angle: 91,
                src: '38.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 166,
              center_y: 416,
              pos_x: 166,
              pos_y: 416,
              angle: 91,
              src: '112.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -88,
              y: -24,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 139,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              padding: false,
              h_space: -1,
              dot_image: '58.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 351,
              // y: 437,
              // font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 90,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = '38.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '39.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '40.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '41.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '42.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '43.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '44.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '45.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '46.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '47.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 351,
                center_y: 437,
                pos_x: 351,
                pos_y: 437,
                angle: 90,
                src: '38.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 295,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 337,
              y: 254,
              image_array: ["146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png"],
              image_length: 25,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 392,
              month_sc_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_tc_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_en_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -3,
              y: 97,
              week_en: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              week_tc: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              week_sc: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 309,
              day_sc_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              day_tc_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              day_en_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 276,
              // y: 2,
              // font_array: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '18.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '19.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '20.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '21.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '22.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '23.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '24.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '25.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '26.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '27.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 276,
                center_y: 2,
                pos_x: 276,
                pos_y: 2,
                angle: 0,
                src: '18.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 332,
              // y: 111,
              // font_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 8,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = '28.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = '29.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = '30.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = '31.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = '32.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = '33.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = '34.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = '35.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = '36.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = '37.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 332,
                center_y: 111,
                pos_x: 332,
                pos_y: 111,
                angle: 90,
                src: '28.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 276,
              // y: 77,
              // font_array: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '18.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '19.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '20.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '21.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '22.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '23.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '24.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '25.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '26.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '27.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 276,
                center_y: 77,
                pos_x: 276,
                pos_y: 77,
                angle: 0,
                src: '18.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block



            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 378,
              y: 194,
              w: 100,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    ///////////////////////  show value  main , max , min /////////////////////////

              let heart_num = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 322,
                                y: 79,
                                type: hmUI.data_type.HEART,
                                font_array:["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                                h_space: 0,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                                invalid_image: "38.png",
                                isCharacter: true,

                              });

               let maxText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 322,
                                y: 139,
                                text: max_heart,
                                type: hmUI.data_type.HEART,
                                font_array:["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                                h_space: 0,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                             });


                 let minText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 322,
                                y: 109,
                                text: min_heart,
                                type: hmUI.data_type.HEART,
                                font_array:["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                                h_space: 2,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                             });

     ////////////////// End /////////////////////////

            function text_update() {
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate low_forecastData');
              let temperatureLow = undefined;
              let normal_low_rotate_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_rotate_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_rotate_string.length > 0 && normal_low_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_low_TextRotate_posOffset = normal_low_TextRotate_img_width * normal_low_rotate_string.length;
                  img_offset -= normal_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 169 + img_offset);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_low_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 169 + img_offset);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.SRC, '59.png');
                      normal_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_low_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 169 + img_offset);
                  normal_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 169 - normal_low_TextRotate_error_img_width / 2);
                  normal_low_TextRotate[0].setProperty(hmUI.prop.SRC, '59.png');
                  normal_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();
              normal_battery_rotate_string = normal_battery_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 166 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 166 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();
              normal_calorie_rotate_string = normal_calorie_rotate_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 351 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  img_offset -= normal_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 276 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeNaw.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_second_TextRotate_posOffset = normal_second_TextRotate_img_width * normal_second_rotate_string.length;
                  normal_second_TextRotate_posOffset = normal_second_TextRotate_posOffset + 8 * (normal_second_rotate_string.length - 1);
                  img_offset -= normal_second_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 332 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  img_offset -= normal_minute_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 276 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

                                    let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
                                    let min_heart = Math.min(...heartArr)
                                    let max_heart = Math.max(...heartArr)
                                  
                                      heart_num.setProperty(hmUI.prop.MORE, {
                                        x: 322,
                                        y: 79,
                                        type: hmUI.data_type.HEART,
                             font_array:["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                                        h_space: 2,
                                        align_h: hmUI.align.CENTER_H,
                                        padding: false,
                                        isCharacter: true,
                                        invalid_image: "39.png",

                                    });


                                    maxText.setProperty(hmUI.prop.MORE, {
                                        x: 322,
                                        y: 139,
                                        text: max_heart,
                                        type: hmUI.data_type.HEART,
                              font_array:["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                                        h_space: 0,
                                        align_h: hmUI.align.CENTER_H,
                                        padding: false,
                                        isCharacter: true,
                                    });

                                    minText.setProperty(hmUI.prop.MORE, {
                                        x: 322,
                                        y: 109,
                                        text: min_heart,
                                        type: hmUI.data_type.HEART,
                               font_array:["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
                                        h_space: 0,
                                        align_h: hmUI.align.CENTER_H,
                                        padding: false,
                                        isCharacter: true,
                                    });

                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}