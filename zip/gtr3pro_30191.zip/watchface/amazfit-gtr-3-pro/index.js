try {
	(() => {
		const g = __$$hmAppManager$$__.currentApp;
		
		//-----01此处添加下列代码 代码块 开始位置 ------

let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 5000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
    function easeInAnim(){
            secondPic.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": "easein",
                    "anim_duration": 100,
      "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 30,
                    "anim_key": "alpha",
                });
    }
    /**
     * 在合适的层级调用此方法即可
     */
    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
    }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
			
	  /*更该02记录的数值*/
			
          w: 480,/*屏幕宽度  3p 480*/
          h: 480,/*屏幕宽度  3p 480*/
          pos_x: 480 / 2 - 20,/*旋转中心   替换-后面数值 02记录的数值*/
          pos_y: 480 / 2 - 240,/*旋转中心  替换-后面数值 02记录的数值*/
          center_x: 240, /*表盘旋转中心 3p 240*/
          center_y: 240,/*表盘旋转中心 3p 240*/
          src: '297.png',/*秒针图片 .png*/
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
    }
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘
          easeInAnim();
          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
      } else {
            duration = 0;
    }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
        stopSecAnim();
        }),
                });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

//-----01此处添加下列代码结束 代码块 结束位置------
		
		const n = g.current,
			{
				px: e
			} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(g, n)), g.__globals__);
		let p = "",
			a = "",
			_ = "",
			t = "",
			h = "";
		const i = Logger.getLogger("watchface6");
		n.module = DeviceRuntimeCore.WatchFace({
			init_view() {
				function g(g) {
					return "INVALID" === g
				}
				hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: "2.png",
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 114,
					y: 90,
					type: hmUI.data_type.SUN_RISE,
					font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
					align_h: hmUI.align.RIGHT,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					dot_image: "14.png",
					invalid_image: "13.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 279,
					y: 90,
					type: hmUI.data_type.SUN_SET,
					font_array: ["15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png"],
					align_h: hmUI.align.LEFT,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					dot_image: "26.png",
					invalid_image: "25.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 238,
					y: 90,
					type: hmUI.data_type.UVI,
					font_array: ["27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "37.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 67,
					y: 153,
					type: hmUI.data_type.WEATHER_CURRENT,
					font_array: ["38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					negative_image: "49.png",
					invalid_image: "48.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 142,
					y: 128,
					type: hmUI.data_type.WEATHER_HIGH,
					font_array: ["50.png", "51.png", "52.png", "53.png", "54.png", "55.png", "56.png", "57.png", "58.png", "59.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					negative_image: "61.png",
					invalid_image: "60.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 78,
					y: 128,
					type: hmUI.data_type.WEATHER_LOW,
					font_array: ["50.png", "51.png", "52.png", "53.png", "54.png", "55.png", "56.png", "57.png", "58.png", "59.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					negative_image: "63.png",
					invalid_image: "62.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 142,
					y: 154,
					type: hmUI.data_type.AQI,
					font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "64.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 117,
					y: 179,
					type: hmUI.data_type.HUMIDITY,
					font_array: ["65.png", "66.png", "67.png", "68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png"],
					align_h: hmUI.align.RIGHT,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "75.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 220,
					y: 127,
					image_array: ["76.png", "77.png", "78.png", "79.png", "80.png", "81.png", "82.png", "83.png", "84.png", "85.png", "86.png", "87.png", "88.png", "89.png", "90.png", "91.png", "92.png", "93.png", "94.png", "95.png", "96.png", "97.png", "98.png", "99.png", "100.png", "101.png", "102.png", "103.png", "104.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), p = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 284,
					y: 120,
					w: 70,
					h: 22,
					text: "",
					color: "0xFFFFFFFF",
					text_size: 16,
					align_h: hmUI.align.LEFT,
					align_v: hmUI.align.TOP,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), a = hmSensor.createSensor(hmSensor.id.TIME), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 308,
					y: 153,
					type: hmUI.data_type.WIND,
					font_array: ["105.png", "106.png", "107.png", "108.png", "109.png", "110.png", "111.png", "112.png", "113.png", "114.png"],
					align_h: hmUI.align.LEFT,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "115.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 307,
					y: 180,
					type: hmUI.data_type.ALTIMETER,
					font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
					align_h: hmUI.align.LEFT,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "116.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 361,
					y: 123,
					image_array: ["117.png", "118.png", "119.png", "120.png", "121.png", "122.png", "123.png", "124.png", "125.png", "126.png", "127.png", "128.png", "129.png", "130.png", "131.png", "132.png", "133.png", "134.png", "135.png", "136.png", "137.png", "138.png", "139.png", "140.png", "141.png", "142.png", "143.png", "144.png", "145.png", "146.png"],
					image_length: 30,
					type: hmUI.data_type.MOON,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 53,
					y: 262,
					type: hmUI.data_type.STEP,
					font_array: ["147.png", "148.png", "149.png", "150.png", "151.png", "152.png", "153.png", "154.png", "155.png", "156.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 2,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "157.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 83,
					y: 325,
					type: hmUI.data_type.CAL,
					font_array: ["158.png", "159.png", "160.png", "161.png", "162.png", "163.png", "164.png", "165.png", "166.png", "167.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "168.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: "169.png",
					center_x: 107,
					center_y: 333,
					x: 10,
					y: 38,
					type: hmUI.data_type.CAL,
					start_angle: -130,
					end_angle: 132,
					cover_x: 0,
					cover_y: 0,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 153,
					y: 295,
					image_array: ["170.png", "171.png", "172.png", "173.png", "174.png", "175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png"],
					image_length: 12,
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_zero: 1,
					hour_startX: 248,
					hour_startY: 267,
					hour_array: ["182.png", "183.png", "184.png", "185.png", "186.png", "187.png", "188.png", "189.png", "190.png", "191.png"],
					hour_space: 2,
					hour_align: hmUI.align.CENTER_H,
					minute_zero: 1,
					minute_startX: 327,
					minute_startY: 267,
					minute_array: ["182.png", "183.png", "184.png", "185.png", "186.png", "187.png", "188.png", "189.png", "190.png", "191.png"],
					minute_space: 2,
					minute_align: hmUI.align.CENTER_H,
					minute_follow: 0,
					second_zero: 1,
					second_startX: 393,
					second_startY: 284,
					second_array: ["192.png", "193.png", "194.png", "195.png", "196.png", "197.png", "198.png", "199.png", "200.png", "201.png"],
					second_space: 2,
					second_align: hmUI.align.CENTER_H,
					second_follow: 0,
					enable: !1,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 36,
					y: 215,
					image_array: ["202.png", "203.png", "204.png", "205.png", "206.png", "207.png", "208.png", "209.png", "210.png", "211.png"],
					image_length: 10,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 268,
					src: "212.png",
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 253,
					y: 350,
					week_sc: ["213.png", "214.png", "215.png", "216.png", "217.png", "218.png", "219.png"],
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 255,
					year_startY: 318,
					year_sc_array: ["220.png", "221.png", "222.png", "223.png", "224.png", "225.png", "226.png", "227.png", "228.png", "229.png"],
					year_tc_array: ["220.png", "221.png", "222.png", "223.png", "224.png", "225.png", "226.png", "227.png", "228.png", "229.png"],
					year_en_array: ["220.png", "221.png", "222.png", "223.png", "224.png", "225.png", "226.png", "227.png", "228.png", "229.png"],
					year_align: hmUI.align.CENTER_H,
					year_zero: 1,
					year_space: 2,
					year_is_character: !1,
					month_startX: 332,
					month_startY: 318,
					month_sc_array: ["230.png", "231.png", "232.png", "233.png", "234.png", "235.png", "236.png", "237.png", "238.png", "239.png"],
					month_tc_array: ["230.png", "231.png", "232.png", "233.png", "234.png", "235.png", "236.png", "237.png", "238.png", "239.png"],
					month_en_array: ["230.png", "231.png", "232.png", "233.png", "234.png", "235.png", "236.png", "237.png", "238.png", "239.png"],
					month_align: hmUI.align.CENTER_H,
					month_zero: 1,
					month_follow: 0,
					month_space: 2,
					month_is_character: !1,
					day_startX: 380,
					day_startY: 318,
					day_sc_array: ["240.png", "241.png", "242.png", "243.png", "244.png", "245.png", "246.png", "247.png", "248.png", "249.png"],
					day_tc_array: ["240.png", "241.png", "242.png", "243.png", "244.png", "245.png", "246.png", "247.png", "248.png", "249.png"],
					day_en_array: ["240.png", "241.png", "242.png", "243.png", "244.png", "245.png", "246.png", "247.png", "248.png", "249.png"],
					day_align: hmUI.align.CENTER_H,
					day_zero: 1,
					day_follow: 0,
					day_space: 2,
					day_is_character: !1,
					enable: !1,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 131,
					y: 388,
					type: hmUI.data_type.HEART,
					font_array: ["250.png", "251.png", "252.png", "253.png", "254.png", "255.png", "256.png", "257.png", "258.png", "259.png"],
					align_h: hmUI.align.RIGHT,
					h_space: 2,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "260.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 203,
					y: 388,
					type: hmUI.data_type.PAI_WEEKLY,
					font_array: ["261.png", "262.png", "263.png", "264.png", "265.png", "266.png", "267.png", "268.png", "269.png", "270.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "271.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 210,
					y: 411,
					type: hmUI.data_type.DISTANCE,
					font_array: ["272.png", "273.png", "274.png", "275.png", "276.png", "277.png", "278.png", "279.png", "280.png", "281.png"],
					align_h: hmUI.align.CENTER_H,
					h_space: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
					dot_image: "283.png",
					invalid_image: "282.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 296,
					y: 388,
					type: hmUI.data_type.SPO2,
					font_array: ["284.png", "285.png", "286.png", "287.png", "288.png", "289.png", "290.png", "291.png", "292.png", "293.png"],
					align_h: hmUI.align.LEFT,
					h_space: 2,
					show_level: hmUI.show_level.ONLY_NORMAL,
					invalid_image: "294.png",
					padding: !1,
					isCharacter: !1
				}), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 121,
					y: 36,
					src: "295.png",
					type: hmUI.system_status.DISCONNECT,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_centerX: 240,
					hour_centerY: 240,
					hour_posX: 20,
					hour_posY: 240,
					hour_path: "296.png",
					hour_cover_x: 0,
					hour_cover_y: 0,
					second_centerX: 240,
					second_centerY: 240,
					second_posX: 1001,
					second_posY: 1001,
					second_path: "297.png",
					second_cover_x: 0,
					second_cover_y: 0,
					enable: !1,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), 
					/*03此处添加  setSec()*/
					setSec()
					
					
					hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: "298.png",
					show_level: hmUI.show_level.ONLY_AOD
				}), hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_zero: 1,
					hour_startX: 84,
					hour_startY: 128,
					hour_array: ["299.png", "300.png", "301.png", "302.png", "303.png", "304.png", "305.png", "306.png", "307.png", "308.png"],
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					minute_zero: 1,
					minute_startX: 264,
					minute_startY: 128,
					minute_array: ["299.png", "300.png", "301.png", "302.png", "303.png", "304.png", "305.png", "306.png", "307.png", "308.png"],
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					minute_follow: 0,
					enable: !1,
					show_level: hmUI.show_level.ONLY_AOD
				}), hmUI.createWidget(hmUI.widget.IMG, {
					x: 48,
					y: 77,
					src: "309.png",
					show_level: hmUI.show_level.ONLY_AOD
				}), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 38,
					y: 282,
					image_array: ["310.png", "311.png", "312.png", "313.png", "314.png", "315.png", "316.png", "317.png", "318.png", "319.png"],
					image_length: 10,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_AOD
				}), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 70,
					y: 52,
					w: 320,
					h: 60,
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 50,
					y: 116,
					w: 390,
					h: 90,
					type: hmUI.data_type.HUMIDITY,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 34,
					y: 254,
					w: 200,
					h: 120,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 80,
					y: 380,
					w: 100,
					h: 60,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 185,
					y: 380,
					w: 100,
					h: 75,
					type: hmUI.data_type.PAI_WEEKLY,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 290,
					y: 380,
					w: 100,
					h: 70,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL
				}), hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: function() {
						t = a.lunar_month, h = a.lunar_day, a.getShowFestival(), g(t) || (t.indexOf("闰") > -1 ? _ = t : g(h) || (_ = t + h)), p.setProperty(hmUI.prop.MORE, {
							text: _
						})
					}
				})
			},
			onInit() {
				i.log("index page.js on init invoke")
			},
			build() {
				this.init_view(), i.log("index page.js on ready invoke")
			},
			onDestroy() {
				i.log("index page.js on destroy invoke")
				
				/*04此处添加 stopSecAnim() */
				stopSecAnim()
				
			}
		})
	})()
} catch (g) {
	console.log("Mini Program Error", g), g && g.stack && g.stack.split(/\n/)
		.forEach((g => console.log("error stack", g)))
}