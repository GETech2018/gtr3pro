﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 200,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 200,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 363,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Oth012.png',
              unit_tc: 'Oth012.png',
              unit_en: 'Oth012.png',
              negative_image: 'Oth011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 363,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Oth012.png',
              unit_tc: 'Oth012.png',
              unit_en: 'Oth012.png',
              negative_image: 'Oth011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 436,
              font_array: ["Sec01.png","Sec02.png","Sec03.png","Sec04.png","Sec05.png","Sec06.png","Sec07.png","Sec08.png","Sec09.png","Sec10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Sec12.png',
              unit_tc: 'Sec12.png',
              unit_en: 'Sec12.png',
              negative_image: 'Sec11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 171,
              y: 320,
              image_array: ["w001.png","w002.png","w003.png","w004.png","w005.png","w006.png","w007.png","w008.png","w009.png","w010.png","w011.png","w012.png","w013.png","w014.png","w015.png","w016.png","w017.png","w018.png","w019.png","w020.png","w021.png","w022.png","w023.png","w024.png","w025.png","w026.png","w027.png","w028.png","w029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 121,
              week_en: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_tc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_sc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 126,
              hour_startY: 209,
              hour_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 251,
              minute_startY: 209,
              minute_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 215,
              second_startY: 283,
              second_array: ["Sec01.png","Sec02.png","Sec03.png","Sec04.png","Sec05.png","Sec06.png","Sec07.png","Sec08.png","Sec09.png","Sec10.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 111,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Oth014.png',
              unit_tc: 'Oth014.png',
              unit_en: 'Oth014.png',
              dot_image: 'Oth013.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 111,
              font_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 294,
              font_array: ["time001.png","time002.png","time003.png","time004.png","time005.png","time006.png","time007.png","time008.png","time009.png","time010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'time011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 294,
              font_array: ["time001.png","time002.png","time003.png","time004.png","time005.png","time006.png","time007.png","time008.png","time009.png","time010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'time011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 34,
              day_sc_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              day_tc_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              day_en_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 158,
              month_startY: 61,
              month_sc_array: ["Mon001.png","Mon002.png","Mon003.png","Mon004.png","Mon005.png","Mon006.png","Mon007.png","Mon008.png","Mon009.png","Mon010.png","Mon011.png","Mon012.png"],
              month_tc_array: ["Mon001.png","Mon002.png","Mon003.png","Mon004.png","Mon005.png","Mon006.png","Mon007.png","Mon008.png","Mon009.png","Mon010.png","Mon011.png","Mon012.png"],
              month_en_array: ["Mon001.png","Mon002.png","Mon003.png","Mon004.png","Mon005.png","Mon006.png","Mon007.png","Mon008.png","Mon009.png","Mon010.png","Mon011.png","Mon012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 150,
              src: 'BLK.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 293,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 407,
              y: 150,
              src: 'BDNK.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 197,
              w: 214,
              h: 115,
              src: 'Ya.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 197,
              w: 115,
              h: 125,
              src: 'Ya.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 325,
              w: 160,
              h: 160,
              src: 'Ya.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 398,
              y: 193,
              w: 82,
              h: 75,
              src: 'Ya.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 294,
              y: 75,
              w: 103,
              h: 99,
              src: 'Ya.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 124,
              week_en: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_tc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              week_sc: ["week001.png","week002.png","week003.png","week004.png","week005.png","week006.png","week007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 211,
              am_y: 176,
              am_sc_path: 'am01.png',
              am_en_path: 'am01.png',
              pm_x: 211,
              pm_y: 176,
              pm_sc_path: 'am02.png',
              pm_en_path: 'am02.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 127,
              hour_startY: 209,
              hour_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 248,
              minute_startY: 209,
              minute_array: ["hrs01.png","hrs02.png","hrs03.png","hrs04.png","hrs05.png","hrs06.png","hrs07.png","hrs08.png","hrs09.png","hrs10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 215,
              second_startY: 283,
              second_array: ["Sec01.png","Sec02.png","Sec03.png","Sec04.png","Sec05.png","Sec06.png","Sec07.png","Sec08.png","Sec09.png","Sec10.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 93,
              day_sc_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              day_tc_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              day_en_array: ["Oth001.png","Oth002.png","Oth003.png","Oth004.png","Oth005.png","Oth006.png","Oth007.png","Oth008.png","Oth009.png","Oth010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  