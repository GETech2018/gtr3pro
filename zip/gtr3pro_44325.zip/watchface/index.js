﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg127.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 120,
              src: 'btoff3.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 402,
              y: 120,
              src: 'alarmon4.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 231,
              font_array: ["chars_A9338F91_000.png","chars_A9338F91_001.png","chars_A9338F91_002.png","chars_A9338F91_003.png","chars_A9338F91_004.png","chars_A9338F91_005.png","chars_A9338F91_006.png","chars_A9338F91_007.png","chars_A9338F91_008.png","chars_A9338F91_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gpa.png',
              unit_tc: 'gpa.png',
              unit_en: 'gpa.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 227,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 253,
              y: 313,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 314,
              font_array: ["chars_A9338F91_000.png","chars_A9338F91_001.png","chars_A9338F91_002.png","chars_A9338F91_003.png","chars_A9338F91_004.png","chars_A9338F91_005.png","chars_A9338F91_006.png","chars_A9338F91_007.png","chars_A9338F91_008.png","chars_A9338F91_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ms.png',
              unit_tc: 'ms.png',
              unit_en: 'ms.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 273,
              font_array: ["chars_A9338F91_000.png","chars_A9338F91_001.png","chars_A9338F91_002.png","chars_A9338F91_003.png","chars_A9338F91_004.png","chars_A9338F91_005.png","chars_A9338F91_006.png","chars_A9338F91_007.png","chars_A9338F91_008.png","chars_A9338F91_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'proce.png',
              unit_tc: 'proce.png',
              unit_en: 'proce.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 271,
              src: 'vlaz1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 352,
              font_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 352,
              src: 'step_11_31x31.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 358,
              image_array: ["set_19_73x20_h153s100b100_img_level_1.png","set_19_73x20_h153s100b100_img_level_2.png","set_19_73x20_h153s100b100_img_level_3.png","set_19_73x20_h153s100b100_img_level_4.png","set_19_73x20_h153s100b100_img_level_5.png","set_19_73x20_h153s100b100_img_level_6.png","set_19_73x20_h153s100b100_img_level_7.png","set_19_73x20_h153s100b100_img_level_8.png","set_19_73x20_h153s100b100_img_level_9.png","set_19_73x20_h153s100b100_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 400,
              font_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 400,
              src: 'custom_icon_1759858195347_1759944860298_28x28_h0s0b0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 223,
              y: 398,
              image_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 352,
              font_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km1.png',
              unit_tc: 'km1.png',
              unit_en: 'km1.png',
              dot_image: 'chars_4ADD1DFC_010.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 353,
              src: 'custom_icon_1759578027333_1759657717258_29x29_h0s100b0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 44,
              week_en: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 20,
              day_sc_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              day_tc_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              day_en_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'chars_A9881C97_010.png',
              day_unit_tc: 'chars_A9881C97_010.png',
              day_unit_en: 'chars_A9881C97_010.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 212,
              month_startY: 20,
              month_sc_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              month_tc_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              month_en_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'chars_A9881C97_010.png',
              month_unit_tc: 'chars_A9881C97_010.png',
              month_unit_en: 'chars_A9881C97_010.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 254,
              year_startY: 20,
              year_sc_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              year_tc_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              year_en_array: ["chars_5224D3FE_000.png","chars_5224D3FE_001.png","chars_5224D3FE_002.png","chars_5224D3FE_003.png","chars_5224D3FE_004.png","chars_5224D3FE_005.png","chars_5224D3FE_006.png","chars_5224D3FE_007.png","chars_5224D3FE_008.png","chars_5224D3FE_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 390,
              y: 235,
              image_array: ["set_37_76x76_img_level_1.png","set_37_76x76_img_level_2.png","set_37_76x76_img_level_3.png","set_37_76x76_img_level_4.png","set_37_76x76_img_level_5.png","set_37_76x76_img_level_6.png","set_37_76x76_img_level_7.png","set_37_76x76_img_level_8.png","set_37_76x76_img_level_9.png","set_37_76x76_img_level_10.png","set_37_76x76_img_level_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 407,
              y: 260,
              font_array: ["chars_4CC3B615_000.png","chars_4CC3B615_001.png","chars_4CC3B615_002.png","chars_4CC3B615_003.png","chars_4CC3B615_004.png","chars_4CC3B615_005.png","chars_4CC3B615_006.png","chars_4CC3B615_007.png","chars_4CC3B615_008.png","chars_4CC3B615_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 410,
              y: 300,
              src: 'zar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 235,
              font_array: ["chars_A9338F91_000.png","chars_A9338F91_001.png","chars_A9338F91_002.png","chars_A9338F91_003.png","chars_A9338F91_004.png","chars_A9338F91_005.png","chars_A9338F91_006.png","chars_A9338F91_007.png","chars_A9338F91_008.png","chars_A9338F91_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_A9338F91_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 228,
              src: 'sunset_1_b_40x40.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 310,
              font_array: ["chars_A9338F91_000.png","chars_A9338F91_001.png","chars_A9338F91_002.png","chars_A9338F91_003.png","chars_A9338F91_004.png","chars_A9338F91_005.png","chars_A9338F91_006.png","chars_A9338F91_007.png","chars_A9338F91_008.png","chars_A9338F91_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_A9338F91_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 300,
              src: 'sunrise_1_b_40x40.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 400,
              font_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 400,
              src: 'heart-rate_29x29_h0s0b0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 176,
              image_array: ["moon_1_38x38_moon_1.png","moon_1_38x38_moon_2.png","moon_1_38x38_moon_3.png","moon_1_38x38_moon_4.png","moon_1_38x38_moon_5.png","moon_1_38x38_moon_6.png","moon_1_38x38_moon_7.png","moon_1_38x38_moon_8.png","moon_1_38x38_moon_9.png","moon_1_38x38_moon_10.png","moon_1_38x38_moon_11.png","moon_1_38x38_moon_12.png","moon_1_38x38_moon_13.png","moon_1_38x38_moon_14.png","moon_1_38x38_moon_15.png","moon_1_38x38_moon_16.png","moon_1_38x38_moon_17.png","moon_1_38x38_moon_18.png","moon_1_38x38_moon_19.png","moon_1_38x38_moon_20.png","moon_1_38x38_moon_21.png","moon_1_38x38_moon_22.png","moon_1_38x38_moon_23.png","moon_1_38x38_moon_24.png","moon_1_38x38_moon_25.png","moon_1_38x38_moon_26.png","moon_1_38x38_moon_27.png","moon_1_38x38_moon_28.png","moon_1_38x38_moon_29.png","moon_1_38x38_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 296,
              font_array: ["chars_A9881C97_000.png","chars_A9881C97_001.png","chars_A9881C97_002.png","chars_A9881C97_003.png","chars_A9881C97_004.png","chars_A9881C97_005.png","chars_A9881C97_006.png","chars_A9881C97_007.png","chars_A9881C97_008.png","chars_A9881C97_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A9881C97_011.png',
              unit_tc: 'chars_A9881C97_011.png',
              unit_en: 'chars_A9881C97_011.png',
              negative_image: 'chars_A9881C97_010.png',
              invalid_image: 'chars_A9881C97_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 238,
              font_array: ["chars_A8D0EB0A_000.png","chars_A8D0EB0A_001.png","chars_A8D0EB0A_002.png","chars_A8D0EB0A_003.png","chars_A8D0EB0A_004.png","chars_A8D0EB0A_005.png","chars_A8D0EB0A_006.png","chars_A8D0EB0A_007.png","chars_A8D0EB0A_008.png","chars_A8D0EB0A_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A8D0EB0A_011.png',
              unit_tc: 'chars_A8D0EB0A_011.png',
              unit_en: 'chars_A8D0EB0A_011.png',
              negative_image: 'chars_A8D0EB0A_010.png',
              invalid_image: 'chars_A8D0EB0A_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 261,
              src: 'custom_icon_1762642810304_16x16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 310,
              font_array: ["chars_A8D0EB0A_000.png","chars_A8D0EB0A_001.png","chars_A8D0EB0A_002.png","chars_A8D0EB0A_003.png","chars_A8D0EB0A_004.png","chars_A8D0EB0A_005.png","chars_A8D0EB0A_006.png","chars_A8D0EB0A_007.png","chars_A8D0EB0A_008.png","chars_A8D0EB0A_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_A8D0EB0A_011.png',
              unit_tc: 'chars_A8D0EB0A_011.png',
              unit_en: 'chars_A8D0EB0A_011.png',
              negative_image: 'chars_A8D0EB0A_010.png',
              invalid_image: 'chars_A8D0EB0A_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 288,
              src: 'custom_icon_1762642942385_16x16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 136,
              y: 237,
              image_array: ["set_6_56x56_meteo_1.png","set_6_56x56_meteo_2.png","set_6_56x56_meteo_3.png","set_6_56x56_meteo_4.png","set_6_56x56_meteo_5.png","set_6_56x56_meteo_6.png","set_6_56x56_meteo_7.png","set_6_56x56_meteo_8.png","set_6_56x56_meteo_9.png","set_6_56x56_meteo_10.png","set_6_56x56_meteo_11.png","set_6_56x56_meteo_12.png","set_6_56x56_meteo_13.png","set_6_56x56_meteo_14.png","set_6_56x56_meteo_15.png","set_6_56x56_meteo_16.png","set_6_56x56_meteo_17.png","set_6_56x56_meteo_18.png","set_6_56x56_meteo_19.png","set_6_56x56_meteo_20.png","set_6_56x56_meteo_21.png","set_6_56x56_meteo_22.png","set_6_56x56_meteo_23.png","set_6_56x56_meteo_24.png","set_6_56x56_meteo_25.png","set_6_56x56_meteo_26.png","set_6_56x56_meteo_27.png","set_6_56x56_meteo_28.png","set_6_56x56_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 18,
              y: 264,
              w: 105,
              h: 36,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 102,
              hour_array: ["chars_58B1C0F5_000.png","chars_58B1C0F5_001.png","chars_58B1C0F5_002.png","chars_58B1C0F5_003.png","chars_58B1C0F5_004.png","chars_58B1C0F5_005.png","chars_58B1C0F5_006.png","chars_58B1C0F5_007.png","chars_58B1C0F5_008.png","chars_58B1C0F5_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 264,
              minute_startY: 102,
              minute_array: ["chars_5A3CFE78_000.png","chars_5A3CFE78_001.png","chars_5A3CFE78_002.png","chars_5A3CFE78_003.png","chars_5A3CFE78_004.png","chars_5A3CFE78_005.png","chars_5A3CFE78_006.png","chars_5A3CFE78_007.png","chars_5A3CFE78_008.png","chars_5A3CFE78_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 400,
              second_startY: 172,
              second_array: ["chars_53309291_000.png","chars_53309291_001.png","chars_53309291_002.png","chars_53309291_003.png","chars_53309291_004.png","chars_53309291_005.png","chars_53309291_006.png","chars_53309291_007.png","chars_53309291_008.png","chars_53309291_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 62,
              src: 'chars_5F61F4B0_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg128.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 360,
              font_array: ["chars_A9338F91_000.png","chars_A9338F91_001.png","chars_A9338F91_002.png","chars_A9338F91_003.png","chars_A9338F91_004.png","chars_A9338F91_005.png","chars_A9338F91_006.png","chars_A9338F91_007.png","chars_A9338F91_008.png","chars_A9338F91_009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'proce.png',
              unit_tc: 'proce.png',
              unit_en: 'proce.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 358,
              src: 'custom_icon_1762600438495_25x25.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 162,
              week_en: ["daw1.png","daw2.png","daw3.png","daw4.png","daw5.png","daw6.png","daw7.png"],
              week_tc: ["daw1.png","daw2.png","daw3.png","daw4.png","daw5.png","daw6.png","daw7.png"],
              week_sc: ["daw1.png","daw2.png","daw3.png","daw4.png","daw5.png","daw6.png","daw7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 400,
              day_startY: 225,
              day_sc_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              day_tc_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              day_en_array: ["chars_4ADD1DFC_000.png","chars_4ADD1DFC_001.png","chars_4ADD1DFC_002.png","chars_4ADD1DFC_003.png","chars_4ADD1DFC_004.png","chars_4ADD1DFC_005.png","chars_4ADD1DFC_006.png","chars_4ADD1DFC_007.png","chars_4ADD1DFC_008.png","chars_4ADD1DFC_009.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0213.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 26,
              hour_posY: 138,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0214.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 206,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0215.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 201,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 165,
              w: 90,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 109,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 110,
              w: 100,
              h: 100,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 355,
              y: 110,
              w: 90,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 225,
              w: 100,
              h: 110,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 225,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 225,
              w: 100,
              h: 110,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 395,
              w: 110,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 395,
              w: 110,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 340,
              w: 350,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 373,
              y: 240,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 5,
              w: 100,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}