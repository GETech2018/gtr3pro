﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'clock_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 406,
              month_startY: 229,
              month_sc_array: ["month-01.png","month-02.png","month-03.png","month-04.png","month-05.png","month-06.png","month-07.png","month-08.png","month-09.png","month-10.png","month-11.png","month-12.png"],
              month_tc_array: ["month-01.png","month-02.png","month-03.png","month-04.png","month-05.png","month-06.png","month-07.png","month-08.png","month-09.png","month-10.png","month-11.png","month-12.png"],
              month_en_array: ["month-01.png","month-02.png","month-03.png","month-04.png","month-05.png","month-06.png","month-07.png","month-08.png","month-09.png","month-10.png","month-11.png","month-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 369,
              day_startY: 229,
              day_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 311,
              y: 229,
              week_en: ["weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png","weekday-7.png"],
              week_tc: ["weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png","weekday-7.png"],
              week_sc: ["weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png","weekday-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'clock_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'clock_minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'clock_second.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  