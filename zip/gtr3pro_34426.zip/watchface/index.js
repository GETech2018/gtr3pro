﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bck-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 250,
              y: 159,
              w: 157,
              h: 29,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 121,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'num-gradi.png',
              unit_tc: 'num-gradi.png',
              unit_en: 'num-gradi.png',
              negative_image: 'num-meno.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 113,
              image_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 316,
              year_startY: 329,
              year_sc_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              year_tc_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              year_en_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              year_zero: 1,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 254,
              month_startY: 335,
              month_sc_array: ["mese-01.png","mese-02.png","mese-03.png","mese-04.png","mese-05.png","mese-06.png","mese-07.png","mese-08.png","mese-09.png","mese-10.png","mese-11.png","mese-12.png"],
              month_tc_array: ["mese-01.png","mese-02.png","mese-03.png","mese-04.png","mese-05.png","mese-06.png","mese-07.png","mese-08.png","mese-09.png","mese-10.png","mese-11.png","mese-12.png"],
              month_en_array: ["mese-01.png","mese-02.png","mese-03.png","mese-04.png","mese-05.png","mese-06.png","mese-07.png","mese-08.png","mese-09.png","mese-10.png","mese-11.png","mese-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 304,
              y: 300,
              week_en: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              week_tc: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              week_sc: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 260,
              day_startY: 294,
              day_sc_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              day_tc_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              day_en_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 399,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 241,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'num-km.png',
              unit_tc: 'num-km.png',
              unit_en: 'num-km.png',
              dot_image: 'num-punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 206,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 52,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 125,
              hour_array: ["n-00.png","n-01.png","n-02.png","n-03.png","n-04.png","n-05.png","n-06.png","n-07.png","n-08.png","n-09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 57,
              minute_startY: 252,
              minute_array: ["n-00.png","n-01.png","n-02.png","n-03.png","n-04.png","n-05.png","n-06.png","n-07.png","n-08.png","n-09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 239,
              src: 'ico-ore.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 86,
              am_y: 392,
              am_sc_path: '0141.png',
              am_en_path: '0141.png',
              pm_x: 86,
              pm_y: 392,
              pm_sc_path: '0142.png',
              pm_en_path: '0142.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 67,
              y: 239,
              src: 'ico-bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 91,
              y: 57,
              src: 'alaron.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aode.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 305,
              month_startY: 133,
              month_sc_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              month_tc_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              month_en_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 131,
              y: 142,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 133,
              day_sc_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              day_tc_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              day_en_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 128,
              src: '0102.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 240,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'num-km.png',
              unit_tc: 'num-km.png',
              unit_en: 'num-km.png',
              dot_image: 'num-punto.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 320,
              font_array: ["dig_10_w_0.png","dig_10_w_1.png","dig_10_w_2.png","dig_10_w_3.png","dig_10_w_4.png","dig_10_w_5.png","dig_10_w_6.png","dig_10_w_7.png","dig_10_w_8.png","dig_10_w_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0114.png',
              unit_tc: '0114.png',
              unit_en: '0114.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 321,
              src: '0140.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 193,
              hour_array: ["aod-ore-00.png","aod-ore-01.png","aod-ore-02.png","aod-ore-03.png","aod-ore-04.png","aod-ore-05.png","aod-ore-06.png","aod-ore-07.png","aod-ore-08.png","aod-ore-09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 193,
              minute_array: ["aod-ore-00.png","aod-ore-01.png","aod-ore-02.png","aod-ore-03.png","aod-ore-04.png","aod-ore-05.png","aod-ore-06.png","aod-ore-07.png","aod-ore-08.png","aod-ore-09.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 194,
              src: 'aod-ore-duepunti.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 41,
              am_y: 230,
              am_sc_path: '0141.png',
              am_en_path: '0141.png',
              pm_x: 392,
              pm_y: 230,
              pm_sc_path: '0142.png',
              pm_en_path: '0142.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Disconnected,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Disconnected"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connected"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 65,
              w: 103,
              h: 103,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 118,
              w: 132,
              h: 68,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 379,
              w: 72,
              h: 68,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 410,
              y: 206,
              w: 72,
              h: 68,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}