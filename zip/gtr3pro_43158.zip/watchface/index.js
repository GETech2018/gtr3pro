﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 13;
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 13;
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 13;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 23;
        let normal_distance_TextRotate_dot_width = 9;
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 13;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 13;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 20;
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_stress_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let Button_1 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['fundo_1.png', 'fundo_2.png', 'fundo_3.png', 'fundo_4.png', 'fundo_5.png', 'fundo_6.png', 'fundo_7.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fundo_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 248,
              y: 44,
              src: '0107.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 80,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0763.png',
              unit_tc: '0763.png',
              unit_en: '0763.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 395,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 211,
              end_angle: 180,
              radius: 214,
              line_width: 8,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFC0C0C0,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 173,
              // y: 388,
              // font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 78,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = '0024.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = '0025.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = '0026.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = '0027.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = '0028.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = '0029.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = '0030.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = '0031.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = '0032.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = '0033.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 173,
                center_y: 388,
                pos_x: 173,
                pos_y: 388,
                angle: 78,
                src: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 400,
              src: '0499.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 182,
              // end_angle: 150,
              // radius: 218,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 182,
              end_angle: 150,
              radius: 214,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 261,
              // y: 395,
              // font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 54,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = '0024.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '0025.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '0026.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '0027.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '0028.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '0029.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '0030.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '0031.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '0032.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '0033.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 261,
                center_y: 395,
                pos_x: 261,
                pos_y: 395,
                angle: 54,
                src: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 128,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 92,
              image_array: ["w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png","w30.png","w31.png","w32.png","w33.png","w34.png","w35.png","w36.png","w37.png","w38.png","w39.png","w40.png","w41.png","w42.png","w43.png","w44.png","w45.png","w46.png","w47.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 314,
              // y: 363,
              // font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 41,
              // unit_en: '0400.png',
              // dot_image: 'dot.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = '0024.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = '0025.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = '0026.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = '0027.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = '0028.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = '0029.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = '0030.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = '0031.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = '0032.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = '0033.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 314,
                center_y: 363,
                pos_x: 314,
                pos_y: 363,
                angle: 41,
                src: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 314,
              center_y: 363,
              pos_x: 314,
              pos_y: 363,
              angle: 41,
              src: '0400.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 364,
              src: '0498.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 151,
              // end_angle: 120,
              // radius: 218,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 151,
              end_angle: 120,
              radius: 214,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 356,
              // y: 345,
              // font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 30,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '0024.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '0025.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '0026.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '0027.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '0028.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '0029.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '0030.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '0031.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '0032.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '0033.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 356,
                center_y: 345,
                pos_x: 356,
                pos_y: 345,
                angle: 30,
                src: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 394,
              y: 156,
              src: '133.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 394,
              y: 298,
              src: '134.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 52,
              src: '0260.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 155,
              // y: 100,
              // font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -76,
              // unit_en: '0763.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '0024.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '0025.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '0026.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '0027.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '0028.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '0029.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '0030.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '0031.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '0032.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '0033.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 155,
                center_y: 100,
                pos_x: 155,
                pos_y: 100,
                angle: -76,
                src: '0024.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 155,
              center_y: 100,
              pos_x: 155,
              pos_y: 100,
              angle: -76,
              src: '0763.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'blend01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 112,
              y: 179,
              week_en: ["0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              week_tc: ["0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              week_sc: ["0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 330,
              day_startY: 187,
              day_sc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              day_tc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              day_en_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 276,
              month_startY: 226,
              month_sc_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
              month_tc_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
              month_en_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr+1.png',
              hour_centerX: 171,
              hour_centerY: 239,
              hour_posX: 89,
              hour_posY: 89,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 171,
              minute_centerY: 239,
              minute_posX: 89,
              minute_posY: 89,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg_1.png',
              second_centerX: 171,
              second_centerY: 239,
              second_posX: 8,
              second_posY: 82,
              second_cover_path: 'CENTRO.png',
              second_cover_x: 167,
              second_cover_y: 234,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 297,
              hour_startY: 259,
              hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'PONTS.png',
              hour_unit_tc: 'PONTS.png',
              hour_unit_en: 'PONTS.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 361,
              minute_startY: 259,
              minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fundo_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 330,
              day_startY: 187,
              day_sc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              day_tc_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              day_en_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 276,
              month_startY: 226,
              month_sc_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
              month_tc_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
              month_en_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 297,
              hour_startY: 259,
              hour_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'PONTS.png',
              hour_unit_tc: 'PONTS.png',
              hour_unit_en: 'PONTS.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 361,
              minute_startY: 259,
              minute_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 112,
              y: 179,
              week_en: ["0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              week_tc: ["0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              week_sc: ["0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'blend01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr.png',
              hour_centerX: 171,
              hour_centerY: 239,
              hour_posX: 89,
              hour_posY: 89,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 171,
              minute_centerY: 239,
              minute_posX: 89,
              minute_posY: 89,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg.png',
              second_centerX: 171,
              second_centerY: 239,
              second_posX: 8,
              second_posY: 82,
              second_cover_path: 'CENTRO.png',
              second_cover_x: 167,
              second_cover_y: 234,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 123,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0177.png',
              normal_src: '0177.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 0,
              // y: 0,
              // w: 100,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0177.png',
              // normal_src: '0177.png',
              // bg_list: fundo_1|fundo_2|fundo_3|fundo_4|fundo_5|fundo_6|fundo_7,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0177.png',
              normal_src: '0177.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 2 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 173 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_posOffset + 2 * (normal_calorie_rotate_string.length - 1);
                  img_offset -= normal_calorie_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 261 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset + 2 * (normal_distance_rotate_string.length - 1);
                  img_offset -= normal_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 314 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width + 2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 314 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'dot.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width + 2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 314 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 2 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 356 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 2 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 155 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 155 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 182,
                      end_angle: 150,
                      radius: 214,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 151,
                      end_angle: 120,
                      radius: 214,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}