﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_pai_pointer_progress_img_pointer = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 345,
              src: 'System_BT_disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 245,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 379,
              month_startY: 303,
              month_sc_array: ["MONTH_ICONS_01.png","MONTH_ICONS_02.png","MONTH_ICONS_03.png","MONTH_ICONS_04.png","MONTH_ICONS_05.png","MONTH_ICONS_06.png","MONTH_ICONS_07.png","MONTH_ICONS_08.png","MONTH_ICONS_09.png","MONTH_ICONS_10.png","MONTH_ICONS_11.png","MONTH_ICONS_12.png"],
              month_tc_array: ["MONTH_ICONS_01.png","MONTH_ICONS_02.png","MONTH_ICONS_03.png","MONTH_ICONS_04.png","MONTH_ICONS_05.png","MONTH_ICONS_06.png","MONTH_ICONS_07.png","MONTH_ICONS_08.png","MONTH_ICONS_09.png","MONTH_ICONS_10.png","MONTH_ICONS_11.png","MONTH_ICONS_12.png"],
              month_en_array: ["MONTH_ICONS_01.png","MONTH_ICONS_02.png","MONTH_ICONS_03.png","MONTH_ICONS_04.png","MONTH_ICONS_05.png","MONTH_ICONS_06.png","MONTH_ICONS_07.png","MONTH_ICONS_08.png","MONTH_ICONS_09.png","MONTH_ICONS_10.png","MONTH_ICONS_11.png","MONTH_ICONS_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 289,
              week_en: ["DAYWEEK_ICONS_01.png","DAYWEEK_ICONS_02.png","DAYWEEK_ICONS_03.png","DAYWEEK_ICONS_04.png","DAYWEEK_ICONS_05.png","DAYWEEK_ICONS_06.png","DAYWEEK_ICONS_07.png"],
              week_tc: ["DAYWEEK_ICONS_01.png","DAYWEEK_ICONS_02.png","DAYWEEK_ICONS_03.png","DAYWEEK_ICONS_04.png","DAYWEEK_ICONS_05.png","DAYWEEK_ICONS_06.png","DAYWEEK_ICONS_07.png"],
              week_sc: ["DAYWEEK_ICONS_01.png","DAYWEEK_ICONS_02.png","DAYWEEK_ICONS_03.png","DAYWEEK_ICONS_04.png","DAYWEEK_ICONS_05.png","DAYWEEK_ICONS_06.png","DAYWEEK_ICONS_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -180,
              day_startY: 193,
              day_sc_array: ["Day_fonts_01.png","Day_fonts_02.png","Day_fonts_03.png","Day_fonts_04.png","Day_fonts_05.png","Day_fonts_06.png","Day_fonts_07.png","Day_fonts_08.png","Day_fonts_09.png","Day_fonts_10.png"],
              day_tc_array: ["Day_fonts_01.png","Day_fonts_02.png","Day_fonts_03.png","Day_fonts_04.png","Day_fonts_05.png","Day_fonts_06.png","Day_fonts_07.png","Day_fonts_08.png","Day_fonts_09.png","Day_fonts_10.png"],
              day_en_array: ["Day_fonts_01.png","Day_fonts_02.png","Day_fonts_03.png","Day_fonts_04.png","Day_fonts_05.png","Day_fonts_06.png","Day_fonts_07.png","Day_fonts_08.png","Day_fonts_09.png","Day_fonts_10.png"],
              day_zero: 1,
              day_space: -178,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 48,
              font_array: ["sunrise_set_01.png","sunrise_set_02.png","sunrise_set_03.png","sunrise_set_04.png","sunrise_set_05.png","sunrise_set_06.png","sunrise_set_07.png","sunrise_set_08.png","sunrise_set_09.png","sunrise_set_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'ACT_11.png',
              dot_image: 'sunrise_set_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 48,
              font_array: ["sunrise_set_01.png","sunrise_set_02.png","sunrise_set_03.png","sunrise_set_04.png","sunrise_set_05.png","sunrise_set_06.png","sunrise_set_07.png","sunrise_set_08.png","sunrise_set_09.png","sunrise_set_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sunrise_set_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 192,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_14.png',
              unit_tc: 'ACT_14.png',
              unit_en: 'ACT_14.png',
              dot_image: 'ACT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 100,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_13.png',
              unit_tc: 'ACT_13.png',
              unit_en: 'ACT_13.png',
              negative_image: 'ACT_11.png',
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 67,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 151,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 227,
              y: 41,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 198,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_15.png',
              unit_tc: 'ACT_15.png',
              unit_en: 'ACT_15.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 74,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png","Battery_icons_11.png","Battery_icons_12.png","Battery_icons_13.png","Battery_icons_14.png","Battery_icons_15.png","Battery_icons_16.png","Battery_icons_17.png","Battery_icons_18.png","Battery_icons_19.png","Battery_icons_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_Pai.png',
              center_x: 116,
              center_y: 311,
              x: 18,
              y: 60,
              start_angle: -28,
              end_angle: 149,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_steps.png',
              center_x: 116,
              center_y: 311,
              x: 22,
              y: 89,
              start_angle: -28,
              end_angle: 149,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 151,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 270,
              am_sc_path: 'Time_AM.png',
              am_en_path: 'Time_AM.png',
              pm_x: 412,
              pm_y: 270,
              pm_sc_path: 'Time_PM.png',
              pm_en_path: 'Time_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 344,
              hour_startY: 244,
              hour_array: ["Digital_time_01.png","Digital_time_02.png","Digital_time_03.png","Digital_time_04.png","Digital_time_05.png","Digital_time_06.png","Digital_time_07.png","Digital_time_08.png","Digital_time_09.png","Digital_time_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 400,
              minute_startY: 244,
              minute_array: ["Digital_time_01.png","Digital_time_02.png","Digital_time_03.png","Digital_time_04.png","Digital_time_05.png","Digital_time_06.png","Digital_time_07.png","Digital_time_08.png","Digital_time_09.png","Digital_time_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 388,
              y: 244,
              src: 'Digital_time_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 22,
              hour_posY: 243,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 243,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 243,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 218,
              w: 48,
              h: 48,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 398,
              y: 237,
              w: 48,
              h: 37,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 236,
              w: 42,
              h: 36,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 21,
              w: 159,
              h: 45,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 352,
              y: 67,
              w: 63,
              h: 60,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 327,
              y: 148,
              w: 34,
              h: 31,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 257,
              y: 149,
              w: 60,
              h: 32,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 148,
              w: 103,
              h: 32,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 345,
              src: 'System_BT_disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 245,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 379,
              month_startY: 303,
              month_sc_array: ["MONTH_ICONS_01.png","MONTH_ICONS_02.png","MONTH_ICONS_03.png","MONTH_ICONS_04.png","MONTH_ICONS_05.png","MONTH_ICONS_06.png","MONTH_ICONS_07.png","MONTH_ICONS_08.png","MONTH_ICONS_09.png","MONTH_ICONS_10.png","MONTH_ICONS_11.png","MONTH_ICONS_12.png"],
              month_tc_array: ["MONTH_ICONS_01.png","MONTH_ICONS_02.png","MONTH_ICONS_03.png","MONTH_ICONS_04.png","MONTH_ICONS_05.png","MONTH_ICONS_06.png","MONTH_ICONS_07.png","MONTH_ICONS_08.png","MONTH_ICONS_09.png","MONTH_ICONS_10.png","MONTH_ICONS_11.png","MONTH_ICONS_12.png"],
              month_en_array: ["MONTH_ICONS_01.png","MONTH_ICONS_02.png","MONTH_ICONS_03.png","MONTH_ICONS_04.png","MONTH_ICONS_05.png","MONTH_ICONS_06.png","MONTH_ICONS_07.png","MONTH_ICONS_08.png","MONTH_ICONS_09.png","MONTH_ICONS_10.png","MONTH_ICONS_11.png","MONTH_ICONS_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 289,
              week_en: ["DAYWEEK_ICONS_01.png","DAYWEEK_ICONS_02.png","DAYWEEK_ICONS_03.png","DAYWEEK_ICONS_04.png","DAYWEEK_ICONS_05.png","DAYWEEK_ICONS_06.png","DAYWEEK_ICONS_07.png"],
              week_tc: ["DAYWEEK_ICONS_01.png","DAYWEEK_ICONS_02.png","DAYWEEK_ICONS_03.png","DAYWEEK_ICONS_04.png","DAYWEEK_ICONS_05.png","DAYWEEK_ICONS_06.png","DAYWEEK_ICONS_07.png"],
              week_sc: ["DAYWEEK_ICONS_01.png","DAYWEEK_ICONS_02.png","DAYWEEK_ICONS_03.png","DAYWEEK_ICONS_04.png","DAYWEEK_ICONS_05.png","DAYWEEK_ICONS_06.png","DAYWEEK_ICONS_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -180,
              day_startY: 193,
              day_sc_array: ["Day_fonts_01.png","Day_fonts_02.png","Day_fonts_03.png","Day_fonts_04.png","Day_fonts_05.png","Day_fonts_06.png","Day_fonts_07.png","Day_fonts_08.png","Day_fonts_09.png","Day_fonts_10.png"],
              day_tc_array: ["Day_fonts_01.png","Day_fonts_02.png","Day_fonts_03.png","Day_fonts_04.png","Day_fonts_05.png","Day_fonts_06.png","Day_fonts_07.png","Day_fonts_08.png","Day_fonts_09.png","Day_fonts_10.png"],
              day_en_array: ["Day_fonts_01.png","Day_fonts_02.png","Day_fonts_03.png","Day_fonts_04.png","Day_fonts_05.png","Day_fonts_06.png","Day_fonts_07.png","Day_fonts_08.png","Day_fonts_09.png","Day_fonts_10.png"],
              day_zero: 1,
              day_space: -178,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 48,
              font_array: ["sunrise_set_01.png","sunrise_set_02.png","sunrise_set_03.png","sunrise_set_04.png","sunrise_set_05.png","sunrise_set_06.png","sunrise_set_07.png","sunrise_set_08.png","sunrise_set_09.png","sunrise_set_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'ACT_11.png',
              dot_image: 'sunrise_set_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 48,
              font_array: ["sunrise_set_01.png","sunrise_set_02.png","sunrise_set_03.png","sunrise_set_04.png","sunrise_set_05.png","sunrise_set_06.png","sunrise_set_07.png","sunrise_set_08.png","sunrise_set_09.png","sunrise_set_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sunrise_set_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 192,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_14.png',
              unit_tc: 'ACT_14.png',
              unit_en: 'ACT_14.png',
              dot_image: 'ACT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 100,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_13.png',
              unit_tc: 'ACT_13.png',
              unit_en: 'ACT_13.png',
              negative_image: 'ACT_11.png',
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 67,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 151,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 227,
              y: 41,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 198,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_15.png',
              unit_tc: 'ACT_15.png',
              unit_en: 'ACT_15.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 74,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png","Battery_icons_11.png","Battery_icons_12.png","Battery_icons_13.png","Battery_icons_14.png","Battery_icons_15.png","Battery_icons_16.png","Battery_icons_17.png","Battery_icons_18.png","Battery_icons_19.png","Battery_icons_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_Pai.png',
              center_x: 116,
              center_y: 311,
              x: 18,
              y: 60,
              start_angle: -28,
              end_angle: 149,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_steps.png',
              center_x: 116,
              center_y: 311,
              x: 22,
              y: 89,
              start_angle: -28,
              end_angle: 149,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 151,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 270,
              am_sc_path: 'Time_AM.png',
              am_en_path: 'Time_AM.png',
              pm_x: 412,
              pm_y: 270,
              pm_sc_path: 'Time_PM.png',
              pm_en_path: 'Time_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 344,
              hour_startY: 244,
              hour_array: ["Digital_time_01.png","Digital_time_02.png","Digital_time_03.png","Digital_time_04.png","Digital_time_05.png","Digital_time_06.png","Digital_time_07.png","Digital_time_08.png","Digital_time_09.png","Digital_time_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 400,
              minute_startY: 244,
              minute_array: ["Digital_time_01.png","Digital_time_02.png","Digital_time_03.png","Digital_time_04.png","Digital_time_05.png","Digital_time_06.png","Digital_time_07.png","Digital_time_08.png","Digital_time_09.png","Digital_time_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 388,
              y: 244,
              src: 'Digital_time_11.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 22,
              hour_posY: 243,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 243,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 243,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  