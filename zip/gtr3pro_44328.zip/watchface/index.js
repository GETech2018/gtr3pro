﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_year_TextCircle = new Array(4);
        let normal_year_TextCircle_ASCIIARRAY = new Array(10);
        let normal_year_TextCircle_img_width = 20;
        let normal_year_TextCircle_img_height = 30;
        let normal_timerTextUpdate = undefined;
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 20;
        let normal_heart_rate_TextCircle_img_height = 30;
        let normal_heart_rate_circle_scale = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 20;
        let normal_step_TextCircle_img_height = 30;
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 20;
        let normal_battery_TextCircle_img_height = 30;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 27;
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_calorie_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0020.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // radius: 192,
              // angle: 65,
              // char_space_angle: -1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextCircle_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_year_TextCircle_img_width / 2,
                pos_y: 240 - 222,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 426,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 16,
              y: 223,
              src: '0246.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 430,
              y: 223,
              src: '0247.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 45,
              month_sc_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              month_tc_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              month_en_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 330,
              src: '0910.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // radius: 233,
              // angle: 195,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 203,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 192,
              // end_angle: 236,
              // radius: 196,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 192,
              end_angle: 236,
              radius: 190,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 8,
              day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 301,
              y: 27,
              week_en: ["000019.png","000020.png","000021.png","000022.png","000023.png","000024.png","000025.png"],
              week_tc: ["000019.png","000020.png","000021.png","000022.png","000023.png","000024.png","000025.png"],
              week_sc: ["000019.png","000020.png","000021.png","000022.png","000023.png","000024.png","000025.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 410,
              y: 320,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 168,
              // end_angle: 124,
              // radius: 196,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 168,
              end_angle: 124,
              radius: 190,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // radius: 233,
              // angle: 164,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 203,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 43,
              y: 31,
              src: '45.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // radius: 203,
              // angle: -22,
              // char_space_angle: -1,
              // unit: '0069.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 - 233,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 - 233,
              src: '0069.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 31,
              image_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 190,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              negative_image: '0022.png',
              invalid_image: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 258,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              negative_image: '0022.png',
              invalid_image: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 274,
              y: 292,
              src: 'max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 258,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              negative_image: '0022.png',
              invalid_image: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 293,
              src: 'min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 149,
              image_array: ["w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png","w30.png","w31.png","w32.png","w33.png","w34.png","w35.png","w36.png","w37.png","w38.png","w39.png","w40.png","w41.png","w42.png","w43.png","w44.png","w45.png","w46.png","w47.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2022_07_24_12_46_IMG_0261.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 13,
              hour_posY: 103,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2022_07_24_12_46_IMG_0262.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 14,
              minute_posY: 179,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '000.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 12,
              second_posY: 177,
              second_cover_path: '2022_07_24_12_46_IMG_0263.png',
              second_cover_x: 233,
              second_cover_y: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'blend2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0022.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'blend2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 218,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF80FF80,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 360,
              radius: 217,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF80FF80,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 9,
              src: '0245.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2022_07_24_12_46_IMG_0261.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 13,
              hour_posY: 103,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2022_07_24_12_46_IMG_0262.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 14,
              minute_posY: 179,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec2.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 10,
              second_posY: 193,
              second_cover_path: '2022_07_24_12_46_IMG_0263.png',
              second_cover_x: 233,
              second_cover_y: 233,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'blend2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_circle_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 65;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_circle_string.length > 0 && normal_year_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_year_TextCircle_img_angle = 0;
                  let normal_year_TextCircle_dot_img_angle = 0;
                  normal_year_TextCircle_img_angle = toDegree(Math.atan2(normal_year_TextCircle_img_width/2, 192));
                  // alignment = CENTER_H
                  let normal_year_TextCircle_angleOffset = normal_year_TextCircle_img_angle * (normal_year_circle_string.length - 1);
                  normal_year_TextCircle_angleOffset = normal_year_TextCircle_angleOffset + -1 * (normal_year_circle_string.length - 1) / 2;
                  char_Angle -= normal_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_year_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_year_TextCircle_img_width / 2);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.SRC, normal_year_TextCircle_ASCIIARRAY[charCode]);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_year_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 375;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 233));
                  // alignment = RIGHT
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 344;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 233));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -22;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 203));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 203));
                  // alignment = RIGHT
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + -1 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + -1) / 2;
                  char_Angle -= 2 * normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 192,
                      end_angle: 236,
                      radius: 190,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 168,
                      end_angle: 124,
                      radius: 190,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 217,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF80FF80,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}