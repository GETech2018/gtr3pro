﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_pai_icon_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_stand_icon_img = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_pai_icon_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_stand_current_text_img = ''
        let idle_stand_current_separator_img = ''
        let idle_stand_icon_img = ''
        let idle_calorie_icon_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -79,
              y: -3,
              src: 'backgrou55.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 202,
              src: 'icon-batt-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 188,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 3,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 250,
              src: 'icon-batt-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 70,
              month_startY: 85,
              month_sc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_tc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_en_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 372,
              font_array: ["wtiny_Slender_32_grey_0001.png","wtiny_Slender_32_grey_0002.png","wtiny_Slender_32_grey_0003.png","wtiny_Slender_32_grey_0004.png","wtiny_Slender_32_grey_0005.png","wtiny_Slender_32_grey_0006.png","wtiny_Slender_32_grey_0007.png","wtiny_Slender_32_grey_0008.png","wtiny_Slender_32_grey_0009.png","wtiny_Slender_32_grey_0010.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              dot_image: 'dot_Picture_167.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 393,
              src: 'icon-steps-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 15,
              src: 'icon_logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 202,
              src: 'icon-heart-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 398,
              y: 190,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 242,
              src: 'icon-heart-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 316,
              src: 'icon-acti-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 323,
              font_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 362,
              src: 'steppsr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 137,
              week_en: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_tc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_sc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 407,
              src: 'distr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 72,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              negative_image: 'icon_weather_4.png',
              invalid_image: 'icon_weather_4.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 229,
              y: 114,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 126,
              hour_array: ["Kazmann_32_green_0001.png","Kazmann_32_green_0002.png","Kazmann_32_green_0003.png","Kazmann_32_green_0004.png","Kazmann_32_green_0005.png","Kazmann_32_green_0006.png","Kazmann_32_green_0007.png","Kazmann_32_green_0008.png","Kazmann_32_green_0009.png","Kazmann_32_green_0010.png"],
              hour_zero: 1,
              hour_space: -188,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 22,
              minute_startY: 242,
              minute_array: ["Kazmann_32_grey_0001.png","Kazmann_32_grey_0002.png","Kazmann_32_grey_0003.png","Kazmann_32_grey_0004.png","Kazmann_32_grey_0005.png","Kazmann_32_grey_0006.png","Kazmann_32_grey_0007.png","Kazmann_32_grey_0008.png","Kazmann_32_grey_0009.png","Kazmann_32_grey_0010.png"],
              minute_zero: 1,
              minute_space: -188,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 55,
              second_startY: 192,
              second_array: ["wtiny_Slender_32_grey_0001.png","wtiny_Slender_32_grey_0002.png","wtiny_Slender_32_grey_0003.png","wtiny_Slender_32_grey_0004.png","wtiny_Slender_32_grey_0005.png","wtiny_Slender_32_grey_0006.png","wtiny_Slender_32_grey_0007.png","wtiny_Slender_32_grey_0008.png","wtiny_Slender_32_grey_0009.png","wtiny_Slender_32_grey_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 40,
              am_y: 248,
              am_sc_path: 'slender_zam.png',
              am_en_path: 'slender_zam.png',
              pm_x: 40,
              pm_y: 248,
              pm_sc_path: 'slender_zpm.png',
              pm_en_path: 'slender_zpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 165,
              day_startY: 85,
              day_sc_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              day_tc_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              day_en_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 399,
              y: 304,
              font_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 344,
              src: 'icon_stand_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 367,
              y: 295,
              src: 'icon_stand_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -50,
              y: -49,
              src: 'Picture2-Ring2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -79,
              y: -3,
              src: 'backgrou55.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 202,
              src: 'icon-batt-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 188,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 3,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 250,
              src: 'icon-batt-1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 70,
              month_startY: 85,
              month_sc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_tc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_en_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 372,
              font_array: ["wtiny_Slender_32_grey_0001.png","wtiny_Slender_32_grey_0002.png","wtiny_Slender_32_grey_0003.png","wtiny_Slender_32_grey_0004.png","wtiny_Slender_32_grey_0005.png","wtiny_Slender_32_grey_0006.png","wtiny_Slender_32_grey_0007.png","wtiny_Slender_32_grey_0008.png","wtiny_Slender_32_grey_0009.png","wtiny_Slender_32_grey_0010.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              dot_image: 'dot_Picture_167.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 393,
              src: 'icon-steps-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 15,
              src: 'icon_logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 202,
              src: 'icon-heart-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 398,
              y: 190,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 242,
              src: 'icon-heart-1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 316,
              src: 'icon-acti-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 323,
              font_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 362,
              src: 'steppsr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 137,
              week_en: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_tc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_sc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 407,
              src: 'distr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 72,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              negative_image: 'icon_weather_4.png',
              invalid_image: 'icon_weather_4.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 229,
              y: 114,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 165,
              day_startY: 85,
              day_sc_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              day_tc_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              day_en_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 399,
              y: 304,
              font_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 344,
              src: 'icon_stand_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 367,
              y: 295,
              src: 'icon_stand_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -50,
              y: -49,
              src: 'Picture2-Ring2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -11,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 126,
              hour_array: ["Kazmann_32_green_0001.png","Kazmann_32_green_0002.png","Kazmann_32_green_0003.png","Kazmann_32_green_0004.png","Kazmann_32_green_0005.png","Kazmann_32_green_0006.png","Kazmann_32_green_0007.png","Kazmann_32_green_0008.png","Kazmann_32_green_0009.png","Kazmann_32_green_0010.png"],
              hour_zero: 1,
              hour_space: -188,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 22,
              minute_startY: 242,
              minute_array: ["Kazmann_32_grey_0001.png","Kazmann_32_grey_0002.png","Kazmann_32_grey_0003.png","Kazmann_32_grey_0004.png","Kazmann_32_grey_0005.png","Kazmann_32_grey_0006.png","Kazmann_32_grey_0007.png","Kazmann_32_grey_0008.png","Kazmann_32_grey_0009.png","Kazmann_32_grey_0010.png"],
              minute_zero: 1,
              minute_space: -188,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 55,
              second_startY: 192,
              second_array: ["wtiny_Slender_32_grey_0001.png","wtiny_Slender_32_grey_0002.png","wtiny_Slender_32_grey_0003.png","wtiny_Slender_32_grey_0004.png","wtiny_Slender_32_grey_0005.png","wtiny_Slender_32_grey_0006.png","wtiny_Slender_32_grey_0007.png","wtiny_Slender_32_grey_0008.png","wtiny_Slender_32_grey_0009.png","wtiny_Slender_32_grey_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 40,
              am_y: 248,
              am_sc_path: 'slender_zam.png',
              am_en_path: 'slender_zam.png',
              pm_x: 40,
              pm_y: 248,
              pm_sc_path: 'slender_zpm.png',
              pm_en_path: 'slender_zpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}