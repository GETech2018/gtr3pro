﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 400,
              font_array: ["tem_num_0.png","tem_num_1.png","tem_num_2.png","tem_num_3.png","tem_num_4.png","tem_num_5.png","tem_num_6.png","tem_num_7.png","tem_num_8.png","tem_num_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'batta_percent.png',
              unit_tc: 'batta_percent.png',
              unit_en: 'batta_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 401,
              y: 284,
              image_array: ["moon_00.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_07.png","moon_08.png","moon_09.png"],
              image_length: 9,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 285,
              font_array: ["tem_num_0.png","tem_num_1.png","tem_num_2.png","tem_num_3.png","tem_num_4.png","tem_num_5.png","tem_num_6.png","tem_num_7.png","tem_num_8.png","tem_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'tem_num_degree.png',
              unit_tc: 'tem_num_degree.png',
              unit_en: 'tem_num_degree.png',
              negative_image: 'tem_num_minus.png',
              invalid_image: 'tem_num_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 281,
              image_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 231,
              src: 'step_num_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 346,
              font_array: ["step_num_0.png","step_num_1.png","step_num_2.png","step_num_3.png","step_num_4.png","step_num_5.png","step_num_6.png","step_num_7.png","step_num_8.png","step_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 231,
              src: 'step_num_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 231,
              font_array: ["step_num_0.png","step_num_1.png","step_num_2.png","step_num_3.png","step_num_4.png","step_num_5.png","step_num_6.png","step_num_7.png","step_num_8.png","step_num_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 121,
              y: 214,
              src: 'stepshoe.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 290,
              year_startY: 56,
              year_sc_array: ["yar_num_0.png","yar_num_1.png","yar_num_2.png","yar_num_3.png","yar_num_4.png","yar_num_5.png","yar_num_6.png","yar_num_7.png","yar_num_8.png","yar_num_9.png"],
              year_tc_array: ["yar_num_0.png","yar_num_1.png","yar_num_2.png","yar_num_3.png","yar_num_4.png","yar_num_5.png","yar_num_6.png","yar_num_7.png","yar_num_8.png","yar_num_9.png"],
              year_en_array: ["yar_num_0.png","yar_num_1.png","yar_num_2.png","yar_num_3.png","yar_num_4.png","yar_num_5.png","yar_num_6.png","yar_num_7.png","yar_num_8.png","yar_num_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 201,
              month_startY: 41,
              month_sc_array: ["MONTH_0.png","MONTH_1.png","MONTH_2.png","MONTH_3.png","MONTH_4.png","MONTH_5.png","MONTH_6.png","MONTH_7.png","MONTH_8.png","MONTH_9.png","MONTH_10.png","MONTH_11.png"],
              month_tc_array: ["MONTH_0.png","MONTH_1.png","MONTH_2.png","MONTH_3.png","MONTH_4.png","MONTH_5.png","MONTH_6.png","MONTH_7.png","MONTH_8.png","MONTH_9.png","MONTH_10.png","MONTH_11.png"],
              month_en_array: ["MONTH_0.png","MONTH_1.png","MONTH_2.png","MONTH_3.png","MONTH_4.png","MONTH_5.png","MONTH_6.png","MONTH_7.png","MONTH_8.png","MONTH_9.png","MONTH_10.png","MONTH_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 118,
              day_startY: 47,
              day_sc_array: ["DAY1_num_0.png","DAY1_num_1.png","DAY1_num_2.png","DAY1_num_3.png","DAY1_num_4.png","DAY1_num_5.png","DAY1_num_6.png","DAY1_num_7.png","DAY1_num_8.png","DAY1_num_9.png"],
              day_tc_array: ["DAY1_num_0.png","DAY1_num_1.png","DAY1_num_2.png","DAY1_num_3.png","DAY1_num_4.png","DAY1_num_5.png","DAY1_num_6.png","DAY1_num_7.png","DAY1_num_8.png","DAY1_num_9.png"],
              day_en_array: ["DAY1_num_0.png","DAY1_num_1.png","DAY1_num_2.png","DAY1_num_3.png","DAY1_num_4.png","DAY1_num_5.png","DAY1_num_6.png","DAY1_num_7.png","DAY1_num_8.png","DAY1_num_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: -26,
              week_en: ["weekday_0.png","weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png"],
              week_tc: ["weekday_0.png","weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png"],
              week_sc: ["weekday_0.png","weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 22,
              am_y: 158,
              am_sc_path: 'timemode1_am.png',
              am_en_path: 'timemode1_am.png',
              pm_x: 22,
              pm_y: 158,
              pm_sc_path: 'timemode1_pm.png',
              pm_en_path: 'timemode1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 100,
              hour_array: ["hour111_num_0.png","hour111_num_1.png","hour111_num_2.png","hour111_num_3.png","hour111_num_4.png","hour111_num_5.png","hour111_num_6.png","hour111_num_7.png","hour111_num_8.png","hour111_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 204,
              minute_startY: 100,
              minute_array: ["min111_num_0.png","min111_num_1.png","min111_num_2.png","min111_num_3.png","min111_num_4.png","min111_num_5.png","min111_num_6.png","min111_num_7.png","min111_num_8.png","min111_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 348,
              second_startY: 115,
              second_array: ["SECD_num_0.png","SECD_num_1.png","SECD_num_2.png","SECD_num_3.png","SECD_num_4.png","SECD_num_5.png","SECD_num_6.png","SECD_num_7.png","SECD_num_8.png","SECD_num_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 106,
              src: 'SECD_num_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 106,
              src: 'SECD_num_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 355,
              y: 284,
              w: 100,
              h: 61,
              src: '0103.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 284,
              w: 160,
              h: 50,
              src: '0103.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 81,
              y: 349,
              w: 172,
              h: 59,
              src: '0103.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 203,
              w: 162,
              h: 57,
              src: '0103.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 68,
              am_y: 158,
              am_sc_path: 'aod_timemode1_am.png',
              am_en_path: 'aod_timemode1_am.png',
              pm_x: 68,
              pm_y: 158,
              pm_sc_path: 'aod_timemode1_pm.png',
              pm_en_path: 'aod_timemode1_pm.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 106,
              hour_startY: 100,
              hour_array: ["aod_num_0.png","aod_num_1.png","aod_num_2.png","aod_num_3.png","aod_num_4.png","aod_num_5.png","aod_num_6.png","aod_num_7.png","aod_num_8.png","aod_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 100,
              minute_array: ["aod_num_0.png","aod_num_1.png","aod_num_2.png","aod_num_3.png","aod_num_4.png","aod_num_5.png","aod_num_6.png","aod_num_7.png","aod_num_8.png","aod_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 106,
              src: 'aod_num_colon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  