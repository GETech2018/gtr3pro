﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_stress_icon_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -125,
              hour_startY: -98,
              hour_array: ["green_layer_Hr_0001.png","green_layer_Hr_0002.png","green_layer_Hr_0003.png","green_layer_Hr_0004.png","green_layer_Hr_0005.png","green_layer_Hr_0006.png","green_layer_Hr_0007.png","green_layer_Hr_0008.png","green_layer_Hr_0009.png","green_layer_Hr_0010.png"],
              hour_zero: 1,
              hour_space: -219,
              hour_align: hmUI.align.LEFT,

              minute_startX: 130,
              minute_startY: -98,
              minute_array: ["blue_layer_Min_0001.png","blue_layer_Min_0002.png","blue_layer_Min_0003.png","blue_layer_Min_0004.png","blue_layer_Min_0005.png","blue_layer_Min_0006.png","blue_layer_Min_0007.png","blue_layer_Min_0008.png","blue_layer_Min_0009.png","blue_layer_Min_0010.png"],
              minute_zero: 1,
              minute_space: -225,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 153,
              y: 139,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Picture",
              anim_fps: 2,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -122,
              hour_startY: -98,
              hour_array: ["green_layer_Hr_0001.png","green_layer_Hr_0002.png","green_layer_Hr_0003.png","green_layer_Hr_0004.png","green_layer_Hr_0005.png","green_layer_Hr_0006.png","green_layer_Hr_0007.png","green_layer_Hr_0008.png","green_layer_Hr_0009.png","green_layer_Hr_0010.png"],
              hour_zero: 1,
              hour_space: -211,
              hour_align: hmUI.align.LEFT,

              minute_startX: 124,
              minute_startY: -98,
              minute_array: ["blue_layer_Min_0001.png","blue_layer_Min_0002.png","blue_layer_Min_0003.png","blue_layer_Min_0004.png","blue_layer_Min_0005.png","blue_layer_Min_0006.png","blue_layer_Min_0007.png","blue_layer_Min_0008.png","blue_layer_Min_0009.png","blue_layer_Min_0010.png"],
              minute_zero: 1,
              minute_space: -209,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 459,
              src: 'Picturelogo237.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -34,
              y: -4,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}