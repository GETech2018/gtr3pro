﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
		let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
		let next_panel_btn = ''
		let prev_panel_btn = ''
		let panel_state = ''
		let panel_state_total = 9
		let bg_toggle_total = 9
		let bg_toggle_btn = ''
		let bg_toggle_state = ''
		let calendar_btn = ''
		let battery_btn = ''
		
		function loadSettings() {

      if (hmFS.SysProGetInt('shine_panel') === undefined) {
        panel_state = 0;
        hmFS.SysProSetInt('shine_panel', panel_state);
      }
      else {
        panel_state = hmFS.SysProGetInt('shine_panel');
      }

      if (hmFS.SysProGetInt('shine_bg') === undefined) {
        bg_toggle_state = 0;
        hmFS.SysProSetInt('shine_bg', bg_toggle_state);
      }
      else {
        bg_toggle_state = hmFS.SysProGetInt('shine_bg');
      }
    }
	
		function click_panel_Switcher() {

      panel_state = (panel_state + 1) % panel_state_total;

      hmFS.SysProSetInt('shine_panel', panel_state);

      apply_panel_switch();
    }

    function click_panel_Switcher_reverse() {

      if (panel_state == 0) {
        panel_state = panel_state_total - 1;
      } else {
        panel_state = (panel_state - 1) % panel_state_total;
      }

      hmFS.SysProSetInt('shine_panel', panel_state);

      apply_panel_switch();
    }

    function apply_panel_switch() {
      switch (panel_state) {

        case 0:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'T I M E'});

          break;

        case 1:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'B A T T E R Y'});

          break;

        case 2:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'S T E P S'});

          break;
		  
		case 3:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'P U L S E'});

          break;

        case 4:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'D I S T A N C E'});

          break;

        case 5:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'C A L O R I E S'});

          break;
		  
		case 6:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'P A I'});

          break;

        case 7:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'W E A T H E R'});

          break;

        case 8:
          //panel 1
          normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 2
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 3
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 4
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 5
          normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 6
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 7
          normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 8
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  //panel 9
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
		  normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
		  calendar_btn.setProperty(hmUI.prop.VISIBLE, true);
		  
		  hmUI.showToast({text: 'D A T E'});

          break;

        default:
          break;
      }
    }
	
	function click_bg_Switcher() {
      
      bg_toggle_state = (bg_toggle_state + 1) % bg_toggle_total;
	  
      hmFS.SysProSetInt('shine_bg', bg_toggle_state);
	  
      apply_bg_switch();
    }

    function apply_bg_switch() {
		
      switch (bg_toggle_state) {

        case 0:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main1.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour1.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min1.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top1.png');
		  hmUI.showToast({text: 'O R A N G E'});
          break;

        case 1:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main2.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour2.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min2.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top2.png');
		  hmUI.showToast({text: 'C Y A N'});
          break;

        case 2:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main3.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour3.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min3.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top3.png');
		  hmUI.showToast({text: 'R E D'});
          break;

        case 3:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main4.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour4.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min4.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top4.png');
		  hmUI.showToast({text: 'B L U E'});
          break;
		  
		case 4:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main5.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour5.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min5.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top5.png');
		  hmUI.showToast({text: 'Y E L L O W'});
          break;

        case 5:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main6.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour6.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min6.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top6.png');
		  hmUI.showToast({text: 'P U R P L E'});
          break;

        case 6:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main7.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour7.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min7.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top7.png');
		  hmUI.showToast({text: 'G R E E N'});
          break;

        case 7:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main8.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour8.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min8.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top8.png');
		  hmUI.showToast({text: 'F U C H S I A'});
          break;
		  
		case 8:
          normal_image_img.setProperty(hmUI.prop.SRC, 'main9.png');
		  normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 't_hour9.png');
		  normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 't_min9.png');
		  normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.SRC, 't_top9.png');
		  hmUI.showToast({text: 'C O L O R L E S S'});
          break;

        default:
          break;
      }
    }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["bg1.png","bg2.png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 328,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel9.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 237,
              month_startY: 329,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'num_13.png',
              unit_tc: 'num_13.png',
              unit_en: 'num_13.png',
              negative_image: 'num_14.png',
              invalid_image: 'num_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 325,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 329,
              src: 'sym_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 329,
              src: 'sym_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_km.png',
              unit_tc: 'unit_km.png',
              unit_en: 'unit_km.png',
              dot_image: 'num_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 329,
              src: 'sym_pul.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 330,
              src: 'sym_stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 't_batt.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -30,
              end_angle: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 328,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 330,
              src: 'sym_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 204,
              hour_startY: 328,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'num_11.png',
              hour_unit_tc: 'num_11.png',
              hour_unit_en: 'num_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'panel_am.png',
              am_en_path: 'panel_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'panel_pm.png',
              pm_en_path: 'panel_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_hour1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 't_hour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_min1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 't_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_sec.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 't_top1.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 't_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 't_top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'aod_t_batt.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -30,
              end_angle: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_t_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_t_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_path: 'aod_t_top.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 320,
              w: 65,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 320,
              w: 65,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 320,
              w: 175,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 320,
              w: 175,
              h: 50,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 320,
              w: 175,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 320,
              w: 175,
              h: 50,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 320,
              w: 175,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 320,
              w: 175,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			
			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 152,
              y: 320,
			  text: '',
              w: 175,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			calendar_btn.setProperty(hmUI.prop.VISIBLE, false);
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 110,
			  text: '',
              w: 170,
              h: 60,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			next_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 330,
                y: 320,
				text: '',
				w: 50,
				h: 50,
				normal_src: '0_Empty.png',
				press_src: '0_Empty.png',
				click_func: () => {
				click_panel_Switcher();
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			prev_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 100,
                y: 320,
				text: '',
				w: 50,
				h: 50,
				normal_src: '0_Empty.png',
				press_src: '0_Empty.png',
				click_func: () => {
				click_panel_Switcher_reverse();
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			bg_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 200,
				y: 200,
				text: '',
				w: 80,
				h: 80,
				normal_src: '0_Empty.png',
				press_src: '0_Empty.png',
				click_func: () => {
				click_bg_Switcher();
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };
			
			loadSettings();
			apply_panel_switch();
			apply_bg_switch();

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}