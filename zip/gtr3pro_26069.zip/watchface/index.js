
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright � CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF43E7E7',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


let screenType = hmSetting.getScreenType(); // Cuidado, debe hacerse el let solo una vez
            // animate
            if (screenType != hmSetting.screen_type.AOD) {

               let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "more",
                    anim_ext: "png",
                    anim_fps: 15,
                    anim_size: 10,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	           });
       	    }


            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 27,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0154.png',
              unit_tc: '0154.png',
              unit_en: '0154.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 147,
              y: 33,
              image_array: ["bat_001.png","bat_002.png","bat_003.png","bat_004.png","bat_005.png","bat_006.png","bat_007.png","bat_008.png","bat_009.png","bat_010.png","bat_011.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 409,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0038.png',
              unit_tc: '0038.png',
              unit_en: '0038.png',
              dot_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 393,
              src: 'text_0126.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 372,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 343,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0049.png',
              invalid_image: '0050.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 383,
              image_array: ["poc_0082.png","poc_0083.png","poc_0084.png","poc_0085.png","poc_0086.png","poc_0087.png","poc_0088.png","poc_0089.png","poc_0090.png","poc_0091.png","poc_0092.png","poc_0093.png","poc_0094.png","poc_0095.png","poc_0096.png","poc_0097.png","poc_0098.png","poc_0099.png","poc_0100.png","poc_0101.png","poc_0102.png","poc_0103.png","poc_0104.png","poc_0105.png","poc_0106.png","poc_0107.png","poc_0108.png","poc_0109.png","poc_0110.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 91,
              font_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 63,
              image_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 111,
              y: 73,
              week_en: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_tc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_sc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 188,
              year_startY: 113,
              year_sc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              year_tc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              year_en_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 128,
              month_startY: 113,
              month_sc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              month_tc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              month_en_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'txt_Red_.0011.png',
              month_unit_tc: 'txt_Red_.0011.png',
              month_unit_en: 'txt_Red_.0011.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 69,
              day_startY: 113,
              day_sc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              day_tc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              day_en_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'txt_Red_.0011.png',
              day_unit_tc: 'txt_Red_.0011.png',
              day_unit_en: 'txt_Red_.0011.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 158,
              hour_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 158,
              minute_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 213,
              second_startY: 320,
              second_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 211,
              src: 'Red_.0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 111,
              y: 73,
              week_en: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_tc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              week_sc: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 188,
              year_startY: 113,
              year_sc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              year_tc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              year_en_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 128,
              month_startY: 113,
              month_sc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              month_tc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              month_en_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'txt_Red_.0011.png',
              month_unit_tc: 'txt_Red_.0011.png',
              month_unit_en: 'txt_Red_.0011.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 69,
              day_startY: 113,
              day_sc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              day_tc_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              day_en_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'txt_Red_.0011.png',
              day_unit_tc: 'txt_Red_.0011.png',
              day_unit_en: 'txt_Red_.0011.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 158,
              hour_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 158,
              minute_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 213,
              second_startY: 320,
              second_array: ["txt_Red_.0001.png","txt_Red_.0002.png","txt_Red_.0003.png","txt_Red_.0004.png","txt_Red_.0005.png","txt_Red_.0006.png","txt_Red_.0007.png","txt_Red_.0008.png","txt_Red_.0009.png","txt_Red_.0010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 211,
              src: 'Red_.0011.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  