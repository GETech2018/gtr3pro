    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 183,
              src: '0267.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 264,
              src: 'H_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 414,
              font_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 32,
              month_startY: 243,
              month_sc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              month_tc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              month_en_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 32,
              day_startY: 190,
              day_sc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              day_tc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              day_en_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 120,
              week_en: ["d_0.png","d_1.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              week_tc: ["d_0.png","d_1.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              week_sc: ["d_0.png","d_1.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 93,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 303,
              font_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0047.png',
              unit_tc: '0047.png',
              unit_en: '0047.png',
              negative_image: '0073.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 38,
              font_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 386,
              am_y: 116,
              am_sc_path: '0264.png',
              am_en_path: '0264.png',
              pm_x: 386,
              pm_y: 116,
              pm_sc_path: '0265.png',
              pm_en_path: '0265.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 388,
              hour_startY: 190,
              hour_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 388,
              minute_startY: 243,
              minute_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 400,
              second_startY: 303,
              second_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 80,
              image_array: ["0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              image_length: 27,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 78,
              y: 274,
              src: '0267.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 213,
              day_sc_array: ["D5_Sec_0.png","D5_Sec_1.png","D5_Sec_2.png","D5_Sec_3.png","D5_Sec_4.png","D5_Sec_5.png","D5_Sec_6.png","D5_Sec_7.png","D5_Sec_8.png","D5_Sec_9.png"],
              day_tc_array: ["D5_Sec_0.png","D5_Sec_1.png","D5_Sec_2.png","D5_Sec_3.png","D5_Sec_4.png","D5_Sec_5.png","D5_Sec_6.png","D5_Sec_7.png","D5_Sec_8.png","D5_Sec_9.png"],
              day_en_array: ["D5_Sec_0.png","D5_Sec_1.png","D5_Sec_2.png","D5_Sec_3.png","D5_Sec_4.png","D5_Sec_5.png","D5_Sec_6.png","D5_Sec_7.png","D5_Sec_8.png","D5_Sec_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 161,
              y: 170,
              week_en: ["Y-1.png","Y-2.png","Y-3.png","Y-4.png","Y-5.png","Y-6.png","Y-7.png"],
              week_tc: ["Y-1.png","Y-2.png","Y-3.png","Y-4.png","Y-5.png","Y-6.png","Y-7.png"],
              week_sc: ["Y-1.png","Y-2.png","Y-3.png","Y-4.png","Y-5.png","Y-6.png","Y-7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 386,
              am_y: 152,
              am_sc_path: '0264.png',
              am_en_path: '0264.png',
              pm_x: 386,
              pm_y: 152,
              pm_sc_path: '0265.png',
              pm_en_path: '0265.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 68,
              hour_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 312,
              minute_startY: 68,
              minute_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 34,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 104,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 167,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 73,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 196,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 295,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 103,
              y: 356,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 245,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 326,
              y: 77,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 157,
              y: 410,
              w: 180,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'm_2.png',
              normal_src: 'm_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				autoToggleWeatherIcons();
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}