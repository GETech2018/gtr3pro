﻿    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
      (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;

        function getApp() {
          return __$$app$$__.app;
        }

        function getCurrentPage() {
          return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {
          px
        } = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start


        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_image2_img = ''
        let normal_image3_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_gmt_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_image2_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_gmt_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
          init_view() {
            //dynamic modify start
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date.png',
              center_x: 240,
              center_y: 240,
              posX: 167,
              posY: 167,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'dial.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              src: 'bezel.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            /*            normal_image3_img = hmUI.createWidget(hmUI.widget.IMG, {
                          x: 0,
                          y: 0,
                          w: 480,
                          h: 480,
                          pos_x: 0,
                          pos_y: 0,
                          center_x: 240,
                          center_y: 240,
                          src: 'pijlen.png',
                          angle: 0,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                        });*/

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
              time_update(true, true);
            });
            let screenType = hmSetting.getScreenType();

            /*          normal_analog_clock_pro_gmtS_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: deviceInfo.width,
                        h: deviceInfo.height,
                        pos_x: 240 - 29,
                        pos_y: 244 - 165,
                        center_x: 240,
                        center_y: 244,
                        src: 'gmt-s.png',
                        angle: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                      });*/

            normal_analog_clock_pro_gmt_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 27,
              pos_y: 240 - 201,
              center_x: 240,
              center_y: 240,
              src: 'gmt.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 16,
              pos_y: 240 - 121,
              center_x: 240,
              center_y: 240,
              src: 'uur.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 21,
              pos_y: 240 - 181,
              center_x: 240,
              center_y: 240,
              src: 'min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 15,
              pos_y: 240 - 190,
              center_x: 240,
              center_y: 240,
              src: 'sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360 * (animDuration * 6 / 1000)) / 360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);

            }


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'dial-n.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel-n.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 16,
              pos_y: 240 - 121,
              center_x: 240,
              center_y: 240,
              src: 'uur-n.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 21,
              pos_y: 240 - 181,
              center_x: 240,
              center_y: 240,
              src: 'min-n.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 15,
              pos_y: 240 - 190,
              center_x: 240,
              center_y: 240,
              src: 'sec-n.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            /*    image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 233,
                  y: 233,
                  src: 'top.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });*/

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                GMTmin();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 380,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                GMTplus();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            /*Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 380,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                bezelMin();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                bezelPlus();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button*/

            /////////////////////////// GMT 
            let GMTnumber = 0
            let GMTHours = 23
            let nameGMT = ''
            let nameBez = ''
            let GMTnumber_idle = 0
            let GMTindicator = ''
            let bezelRotate = 0
            const BezelIndicator = ''
            //let timeUTC = timeSensor.utc

            function GMTplus() {
              if (GMTnumber >= GMTHours) {
                GMTnumber = 0;
              } else {
                GMTnumber = GMTnumber + 1;
              }
              if (GMTnumber > 12) {
                GMTindicator = "-" + (24 - GMTnumber)
              } else {
                GMTindicator = "+" + GMTnumber
              }
              GMTnumber_idle = GMTnumber
              nameGMT = "Δ " + GMTindicator + " HOURS"
              time_update(true, true);
              vibro(25);
              hmUI.showToast({
                text: nameGMT
              });
            }

            function GMTmin() {
              if (GMTnumber <= 0) {
                GMTnumber = 23;
              } else {
                GMTnumber = GMTnumber - 1;
              }
              if (GMTnumber > 12) {
                GMTindicator = "-" + (24 - GMTnumber)
              } else {
                GMTindicator = "+" + GMTnumber
              }
              GMTnumber_idle = GMTnumber

              nameGMT = "Δ " + GMTindicator + " HOURS"
              time_update(true, true);
              vibro(25);
              hmUI.showToast({
                text: nameGMT
              });
            }
            // bezel delta -
            function bezelPlus() {
              bezelRotate = bezelRotate + 15;

              normal_image2_img.setProperty(hmUI.prop.ANGLE, bezelRotate);
              if (bezelRotate / 15 > 23) bezelRotate = 0;
              //time_update(true, true);
              //if (Math.abs(bezelRotate / 15) > 12) {
              //bezelIndicator = "+" + 24 - Math.abs(bezelRotate / 15)
              //} else {
              bezelIndicator = "min " + bezelRotate / 15
              //}

              nameBez = "Δ " + bezelIndicator + " HOURS"
              vibro(25);
              hmUI.showToast({
                text: nameBez

              });
            }
            //bezel delta +
            function bezelMin() {
              bezelRotate = bezelRotate - 15;

              normal_image2_img.setProperty(hmUI.prop.ANGLE, bezelRotate);
              if ((bezelRotate / 15) < -23) bezelRotate = 0;
              //time_update(true, true);
              // if (Math.abs(bezelRotate / 15) > 12) {
              //  bezelIndicator = "min " + 24 - Math.abs(bezelRotate / 15)
              //} else {
              bezelIndicator = "plus " + bezelRotate / 15
              //}

              nameBez = "Δ " + bezelIndicator + " HOURS"
              vibro(25);
              hmUI.showToast({
                text: nameBez
              });
            }
            /////////////////////// end GMT

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = 0 + normal_fullAngle_hour * normal_hour / 24 + (normal_fullAngle_hour / 24) * minute / 60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, 0 + 360 * (hour / 12) + (360 / 12) * minute / 60);
                //normal_analog_clock_pro_hourS_pointer_img.setProperty(hmUI.prop.ANGLE, 0 + 360 * (hour / 12) + (360 / 24) * minute / 60);
                normal_analog_clock_pro_gmt_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour + GMTnumber * 15);
                //normal_analog_clock_pro_gmtS_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour + GMTnumber * 15);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute * (minute + second / 60) / 60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
                //normal_analog_clock_pro_minuteS_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour * idle_hour / 24 + (idle_fullAngle_hour / 24) * minute / 60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, 0 + 360 * (hour / 12) + (360 / 12) * minute / 60);
                //normal_analog_clock_pro_gmt_pointer_img.setProperty(hmUI.prop.ANGLE, (0 + 360 * (hour / 12) + (360 / 24) * minute / 60) + GMTnumber * 15);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute * (minute + second / 60) / 60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second * (second + (timeSensor.utc % 1000) / 1000) / 60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    })); // end timer 
                  }; // end timer check
                }; // end screenType

                let secAngle = 0 + (360 * 6) * (timeSensor.second + ((timeSensor.utc % 1000) / 1000)) / 360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                //normal_analog_clock_pro_secondS_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000 * (60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360 * 6) * (timeSensor.second + ((timeSensor.utc % 1000) / 1000)) / 360;
                      startSecAnim(secAngle, animDuration);
                    })); // end timer 
                  }; // end timer check
                }; // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    })); // end timer 
                  }; // end timer check
                }; // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000 / 15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    })); // end timer 
                  }; // end timer check
                }; // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

            //dynamic modify end
          },
          onInit() {
            logger.log('index page.js on init invoke');
          },
          build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
          },
          onDestroy() {
            logger.log('index page.js on destroy invoke');
          }
        });;
      })();
    } catch (e) {
      console.log('Mini Program Error', e);
      e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
