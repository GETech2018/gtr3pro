﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 39;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 29;
        let normal_temperature_current_TextRotate_dot_width = 26;
        let normal_temperature_current_TextRotate_error_img_width = 26;
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 194,
              year_startY: 8,
              year_sc_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              year_tc_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              year_en_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              year_zero: 1,
              year_space: -2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 431,
              y: 170,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 386,
              y: 169,
              src: 'ALARME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 413,
              image_array: ["weather_0001.png","weather_0002.png","weather_0003.png","weather_0004.png","weather_0005.png","weather_0006.png","weather_0007.png","weather_0008.png","weather_0009.png","weather_0010.png","weather_0011.png","weather_0012.png","weather_0013.png","weather_0014.png","weather_0015.png","weather_0016.png","weather_0017.png","weather_0018.png","weather_0019.png","weather_0020.png","weather_0021.png","weather_0022.png","weather_0023.png","weather_0024.png","weather_0025.png","weather_0026.png","weather_0027.png","weather_0028.png","weather_0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 100,
              // y: 360,
              // font_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 45,
              // unit_en: 'TT_12.png',
              // negative_image: 'TT_10.png',
              // invalid_image: 'TT_10.png',
              // dot_image: 'TT_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'TT_00.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'TT_01.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'TT_02.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'TT_03.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'TT_04.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'TT_05.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'TT_06.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'TT_07.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'TT_08.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'TT_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 100,
                center_y: 360,
                pos_x: 100,
                pos_y: 360,
                angle: 45,
                src: 'TT_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 100,
              center_y: 360,
              pos_x: 100,
              pos_y: 360,
              angle: 45,
              src: 'TT_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 419,
              font_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 352,
              month_startY: 98,
              month_sc_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              month_tc_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              month_en_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              month_zero: 1,
              month_space: -4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 245,
              day_startY: 98,
              day_sc_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              day_tc_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              day_en_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              day_zero: 1,
              day_space: -4,
              day_unit_sc: 'TT_11.png',
              day_unit_tc: 'TT_11.png',
              day_unit_en: 'TT_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 110,
              y: 49,
              week_en: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              week_tc: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              week_sc: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 108,
              font_array: ["P_00.png","P_01.png","P_02.png","P_03.png","P_04.png","P_05.png","P_06.png","P_07.png","P_08.png","P_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 298,
              font_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 301,
              font_array: ["KM-01.png","KM-02.png","KM-03.png","KM-04.png","KM-05.png","KM-06.png","KM-07.png","KM-08.png","KM-09.png","KM-10.png"],
              padding: false,
              h_space: -2,
              dot_image: 'KM-11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 341,
              font_array: ["ST_00.png","ST_01.png","ST_02.png","ST_03.png","ST_04.png","ST_05.png","ST_06.png","ST_07.png","ST_08.png","ST_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 175,
              hour_array: ["min_0001.png","min_0002.png","min_0003.png","min_0004.png","min_0005.png","min_0006.png","min_0007.png","min_0008.png","min_0009.png","min_0010.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 236,
              minute_startY: 172,
              minute_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 388,
              second_startY: 218,
              second_array: ["TT_00.png","TT_01.png","TT_02.png","TT_03.png","TT_04.png","TT_05.png","TT_06.png","TT_07.png","TT_08.png","TT_09.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 190,
              hour_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'aod_0011.png',
              hour_unit_tc: 'aod_0011.png',
              hour_unit_en: 'aod_0011.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 254,
              minute_startY: 170,
              minute_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'aod_0011.png',
              minute_unit_tc: 'aod_0011.png',
              minute_unit_en: 'aod_0011.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 384,
              second_startY: 213,
              second_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aodblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 82,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 7,
              w: 100,
              h: 70,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 190,
              w: 100,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 380,
              y: 215,
              w: 85,
              h: 65,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 339,
              w: 222,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 340,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 404,
              w: 80,
              h: 70,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 380,
              y: 160,
              w: 85,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 290,
              w: 120,
              h: 45,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + -4 * (normal_temperature_current_rotate_string.length - 1);
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 100 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 100 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'TT_10.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 100 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 100 - normal_temperature_current_TextRotate_error_img_width / 2);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'TT_10.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}