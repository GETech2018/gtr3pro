﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'Preview1.png', path: 'Main.png' },
                { id: 2, preview: 'Preview2.png', path: 'Main_1.png' },
                { id: 3, preview: 'Preview3.png', path: 'Main_2.png' },
                { id: 4, preview: 'Preview4.png', path: 'Main_3.png' },
                { id: 5, preview: 'Preview5.png', path: 'Main_4.png' },
                { id: 6, preview: 'Preview6.png', path: 'Main_5.png' },
                { id: 7, preview: 'Preview7.png', path: 'Main_6.png' },
                { id: 8, preview: 'Preview8.png', path: 'Main_7.png' },
                { id: 9, preview: 'Preview9.png', path: 'Main_8.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 350,
              y: 102,
              image_array: ["Mond_00.png","Mond_01.png","Mond_02.png","Mond_03.png","Mond_04.png","Mond_05.png","Mond_06.png","Mond_07.png","Mond_08.png","Mond_09.png","Mond_10.png","Mond_11.png","Mond_12.png","Mond_13.png","Mond_14.png","Mond_15.png","Mond_16.png","Mond_17.png","Mond_18.png","Mond_19.png","Mond_20.png","Mond_21.png","Mond_22.png","Mond_23.png","Mond_24.png","Mond_25.png","Mond_26.png","Mond_27.png","Mond_28.png","Mond_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 243,
              font_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 159,
              image_array: ["hs2_0.png","hs2_1.png","hs2_2.png","hs2_3.png","hs2_4.png","hs2_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 341,
              font_array: ["e_0.png","e_1.png","e_2.png","e_3.png","e_4.png","e_5.png","e_6.png","e_7.png","e_8.png","e_9.png"],
              padding: false,
              h_space: -12,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 173,
              y: 41,
              w: 175,
              h: 78,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 96,
              font_array: ["e_0.png","e_1.png","e_2.png","e_3.png","e_4.png","e_5.png","e_6.png","e_7.png","e_8.png","e_9.png"],
              padding: false,
              h_space: -9,
              unit_sc: 'z_grd.png',
              unit_tc: 'z_grd.png',
              unit_en: 'z_grd.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 89,
              y: 68,
              image_array: ["wx_00.png","wx_01.png","wx_02.png","wx_03.png","wx_04.png","wx_05.png","wx_06.png","wx_07.png","wx_08.png","wx_09.png","wx_10.png","wx_11.png","wx_12.png","wx_13.png","wx_14.png","wx_15.png","wx_16.png","wx_17.png","wx_18.png","wx_19.png","wx_20.png","wx_21.png","wx_22.png","wx_23.png","wx_24.png","wx_25.png","wx_26.png","wx_27.png","wx_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 395,
              font_array: ["i_0.png","i_1.png","i_2.png","i_3.png","i_4.png","i_5.png","i_6.png","i_7.png","i_8.png","i_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'z_pkt.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 356,
              font_array: ["i_0.png","i_1.png","i_2.png","i_3.png","i_4.png","i_5.png","i_6.png","i_7.png","i_8.png","i_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 193,
              month_startY: 304,
              month_sc_array: ["M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png","M_12.png"],
              month_tc_array: ["M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png","M_12.png"],
              month_en_array: ["M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png","M_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 285,
              day_startY: 303,
              day_sc_array: ["Mz_0.png","Mz_1.png","Mz_2.png","Mz_3.png","Mz_4.png","Mz_5.png","Mz_6.png","Mz_7.png","Mz_8.png","Mz_9.png"],
              day_tc_array: ["Mz_0.png","Mz_1.png","Mz_2.png","Mz_3.png","Mz_4.png","Mz_5.png","Mz_6.png","Mz_7.png","Mz_8.png","Mz_9.png"],
              day_en_array: ["Mz_0.png","Mz_1.png","Mz_2.png","Mz_3.png","Mz_4.png","Mz_5.png","Mz_6.png","Mz_7.png","Mz_8.png","Mz_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 160,
              font_array: ["i_0.png","i_1.png","i_2.png","i_3.png","i_4.png","i_5.png","i_6.png","i_7.png","i_8.png","i_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 419,
              y: 159,
              src: 'i0_pzt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 160,
              image_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 185,
              hour_startY: 193,
              hour_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
              hour_zero: 1,
              hour_space: -34,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 340,
              minute_startY: 196,
              minute_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 346,
              second_startY: 244,
              second_array: ["e_0.png","e_1.png","e_2.png","e_3.png","e_4.png","e_5.png","e_6.png","e_7.png","e_8.png","e_9.png"],
              second_zero: 1,
              second_space: -13,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'MAIN_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 186,
              hour_array: ["e1_1.png","e1_2.png","e1_3.png","e1_4.png","e1_5.png","e1_6.png","e1_7.png","e1_8.png","e1_9.png","e1_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 187,
              minute_array: ["f1_1.png","f1_2.png","f1_3.png","f1_4.png","f1_5.png","f1_6.png","f1_7.png","f1_8.png","f1_9.png","f1_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}