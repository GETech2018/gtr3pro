﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_altitude_target_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_humidity_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_altitude_target_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_humidity_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_wind_direction_image_progress_img_level = ''
        let idle_wind_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 396,
              y: 191,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 364,
              month_startY: 124,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 388,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              negative_image: 'Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 388,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 395,
              day_startY: 157,
              day_sc_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              day_tc_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              day_en_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 84,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 326,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Att_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 12,
              // start_y: 257,
              // color: 0xFF00FFFF,
              // lenght: 285,
              // line_width: 4,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 257,
              src: 'IcoPassi_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 271,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 413,
              y: 230,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 331,
              y: 256,
              image_array: ["Batt_00.png","Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 196,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 196,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 48,
              image_array: ["Wheat_01.png","Wheat_02.png","Wheat_03.png","Wheat_04.png","Wheat_05.png","Wheat_06.png","Wheat_07.png","Wheat_08.png","Wheat_09.png","Wheat_10.png","Wheat_11.png","Wheat_12.png","Wheat_13.png","Wheat_14.png","Wheat_15.png","Wheat_16.png","Wheat_17.png","Wheat_18.png","Wheat_19.png","Wheat_20.png","Wheat_21.png","Wheat_22.png","Wheat_23.png","Wheat_24.png","Wheat_25.png","Wheat_26.png","Wheat_27.png","Wheat_28.png","Wheat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 60,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Att_12.png',
              unit_tc: 'Att_12.png',
              unit_en: 'Att_12.png',
              imperial_unit_sc: 'Att_12.png',
              imperial_unit_tc: 'Att_12.png',
              imperial_unit_en: 'Att_12.png',
              negative_image: 'Att_11.png',
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 283,
              y: 18,
              image_array: ["Cardinale_01.png","Cardinale_02.png","Cardinale_03.png","Cardinale_04.png","Cardinale_05.png","Cardinale_06.png","Cardinale_07.png","Cardinale_08.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 13,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 280,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 326,
              y: 277,
              image_array: ["BMP_00.png","BMP_01.png","BMP_02.png","BMP_03.png","BMP_04.png","BMP_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 123,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 192,
              minute_startY: 123,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 148,
              second_startY: 195,
              second_array: ["Secondi_00.png","Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 125,
              src: 'Ore_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 396,
              y: 191,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 364,
              month_startY: 124,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 388,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              negative_image: 'Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 388,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 395,
              day_startY: 157,
              day_sc_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              day_tc_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              day_en_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 84,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 326,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Att_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 12,
              // start_y: 257,
              // color: 0xFF00FFFF,
              // lenght: 285,
              // line_width: 4,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 257,
              src: 'IcoPassi_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 271,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 413,
              y: 230,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 331,
              y: 256,
              image_array: ["Batt_00.png","Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 196,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 196,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 48,
              image_array: ["Wheat_01.png","Wheat_02.png","Wheat_03.png","Wheat_04.png","Wheat_05.png","Wheat_06.png","Wheat_07.png","Wheat_08.png","Wheat_09.png","Wheat_10.png","Wheat_11.png","Wheat_12.png","Wheat_13.png","Wheat_14.png","Wheat_15.png","Wheat_16.png","Wheat_17.png","Wheat_18.png","Wheat_19.png","Wheat_20.png","Wheat_21.png","Wheat_22.png","Wheat_23.png","Wheat_24.png","Wheat_25.png","Wheat_26.png","Wheat_27.png","Wheat_28.png","Wheat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 60,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Att_12.png',
              unit_tc: 'Att_12.png',
              unit_en: 'Att_12.png',
              imperial_unit_sc: 'Att_12.png',
              imperial_unit_tc: 'Att_12.png',
              imperial_unit_en: 'Att_12.png',
              negative_image: 'Att_11.png',
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 283,
              y: 18,
              image_array: ["Cardinale_01.png","Cardinale_02.png","Cardinale_03.png","Cardinale_04.png","Cardinale_05.png","Cardinale_06.png","Cardinale_07.png","Cardinale_08.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 13,
              font_array: ["Sist_00.png","Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 280,
              font_array: ["Att_00.png","Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 326,
              y: 277,
              image_array: ["BMP_00.png","BMP_01.png","BMP_02.png","BMP_03.png","BMP_04.png","BMP_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 123,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 192,
              minute_startY: 123,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 125,
              src: 'Ore_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 31,
              y: 264,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 354,
              y: 301,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375,
              y: 192,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 20,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 129,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 142,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 375,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 12;
                  let start_y_normal_step = 257;
                  let lenght_ls_normal_step = 285;
                  let line_width_ls_normal_step = 4;
                  let color_ls_normal_step = 0xFF00FFFF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 12;
                  let start_y_idle_step = 257;
                  let lenght_ls_idle_step = 285;
                  let line_width_ls_idle_step = 4;
                  let color_ls_idle_step = 0xFF00FFFF;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}