﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let editableTimePointers = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'bg_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg_5.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'bg_6.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: '0143.png',
              tips_x: 190,
              tips_y: 190,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 105,
              y: 223,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 259,
              y: 367,
              src: '0076.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 192,
              y: 366,
              src: '0059.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 296,
              y: 223,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 377,
              day_startY: 226,
              day_sc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_tc_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_en_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 10,
                    posY: 202,
                    path: '17a.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 137,
                    path: '5a.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 180,
                    path: '6a.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 10,
                    posY: 202,
                    path: '17b.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 137,
                    path: '5b.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 180,
                    path: '6b.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 10,
                    posY: 202,
                    path: '17c.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 137,
                    path: '5c.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 180,
                    path: '6c.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 10,
                    posY: 202,
                    path: '17d.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 137,
                    path: '5d.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 180,
                    path: '6d.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_x: 190,
              tips_y: 16,
              tips_bg: '0143.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 348,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 35,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 367,
              y: 194,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 197,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}