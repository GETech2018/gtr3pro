﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_date_img_date_week_img = ''
        let editableTimePointers = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'preview_0.png', path: 'bg_0.png' },
                { id: 2, preview: 'preview_1.png', path: 'bg_1.png' },
                { id: 3, preview: 'preview_2.png', path: 'bg_2.png' },
                { id: 4, preview: 'preview_3.png', path: 'bg_3.png' },
                { id: 5, preview: 'preview_4.png', path: 'bg_4.png' },
              ],
              count: 5,
              default_id: 1,
              fg: 'mask_0.png',
              tips_bg: 'mask_2.png',
              tips_x: 105,
              tips_y: 216,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 398,
              year_startY: 253,
              year_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              year_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              year_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 370,
              month_startY: 253,
              month_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              month_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              month_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'pointer_0.png',
              month_unit_tc: 'pointer_0.png',
              month_unit_en: 'pointer_0.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 343,
              day_startY: 253,
              day_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'pointer_0.png',
              day_unit_tc: 'pointer_0.png',
              day_unit_en: 'pointer_0.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_4.png',
              center_x: 240,
              center_y: 276,
              posX: 11,
              posY: 140,
              start_angle: 115,
              end_angle: 243,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 402,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 398,
              year_startY: 253,
              year_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              year_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              year_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 370,
              month_startY: 253,
              month_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              month_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              month_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'pointer_0.png',
              month_unit_tc: 'pointer_0.png',
              month_unit_en: 'pointer_0.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 343,
              day_startY: 253,
              day_sc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_tc_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_en_array: ["font_date_0.png","font_date_1.png","font_date_2.png","font_date_3.png","font_date_4.png","font_date_5.png","font_date_6.png","font_date_7.png","font_date_8.png","font_date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'pointer_0.png',
              day_unit_tc: 'pointer_0.png',
              day_unit_en: 'pointer_0.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date_4.png',
              center_x: 240,
              center_y: 276,
              posX: 11,
              posY: 140,
              start_angle: 115,
              end_angle: 243,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 402,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 31,
                    posY: 241,
                    path: 'sec_0.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 149,
                    posX: 21,
                    posY: 83,
                    path: 'hour_0.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 234,
                    path: 'minute_0.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 31,
                    posY: 241,
                    path: 'sec_1.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 149,
                    posX: 21,
                    posY: 83,
                    path: 'hour_1.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 234,
                    path: 'minute_1.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 31,
                    posY: 241,
                    path: 'sec_1.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 149,
                    posX: 21,
                    posY: 83,
                    path: 'hour_2.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 234,
                    path: 'minute_2.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 31,
                    posY: 241,
                    path: 'sec_1.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 149,
                    posX: 21,
                    posY: 83,
                    path: 'hour_3.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 234,
                    path: 'minute_3.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 31,
                    posY: 241,
                    path: 'sec_0.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 149,
                    posX: 21,
                    posY: 83,
                    path: 'hour_4.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 234,
                    path: 'minute_4.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
              ],
              count: 5,
              default_id: 1,
              fg: 'mask_0.png',
              tips_x: 316,
              tips_y: 237,
              tips_bg: 'mask_1.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
