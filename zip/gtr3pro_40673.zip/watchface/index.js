﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 14;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 14;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 14;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 14;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 74;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 74;
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 14;
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 14;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 14;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 14;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 74;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 74;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 375,
              src: '24.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 252,
              y: 340,
              src: '26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 232,
              // y: 395,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -1,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 232,
                center_y: 395,
                pos_x: 232,
                pos_y: 395,
                angle: -1,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 332,
              // y: 74,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 13,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 332,
                center_y: 74,
                pos_x: 332,
                pos_y: 74,
                angle: 13,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 157,
              // y: 134,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 6,
              // angle: 2,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 157,
                center_y: 134,
                pos_x: 157,
                pos_y: 134,
                angle: 2,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 328,
              // y: 132,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -13,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 328,
                center_y: 132,
                pos_x: 328,
                pos_y: 132,
                angle: -13,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 135,
              week_en: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              week_tc: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              week_sc: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 86,
              am_y: 186,
              am_sc_path: '22.png',
              am_en_path: '22.png',
              pm_x: 86,
              pm_y: 186,
              pm_sc_path: '23.png',
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 153,
              // y: 226,
              // font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -13,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '9.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '10.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '11.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 153,
                center_y: 226,
                pos_x: 153,
                pos_y: 226,
                angle: -13,
                src: '2.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 319,
              // y: 176,
              // font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -15,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '9.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '10.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '11.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 319,
                center_y: 176,
                pos_x: 319,
                pos_y: 176,
                angle: -15,
                src: '2.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 375,
              src: '24.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 252,
              y: 340,
              src: '26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 232,
              // y: 395,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -1,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 232,
                center_y: 395,
                pos_x: 232,
                pos_y: 395,
                angle: -1,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 332,
              // y: 74,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 13,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 332,
                center_y: 74,
                pos_x: 332,
                pos_y: 74,
                angle: 13,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 157,
              // y: 134,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 6,
              // angle: 2,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 157,
                center_y: 134,
                pos_x: 157,
                pos_y: 134,
                angle: 2,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 328,
              // y: 132,
              // font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -13,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'num-00.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'num-01.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'num-02.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'num-03.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'num-04.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'num-05.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'num-06.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'num-07.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'num-08.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'num-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 328,
                center_y: 132,
                pos_x: 328,
                pos_y: 132,
                angle: -13,
                src: 'num-00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 135,
              week_en: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              week_tc: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              week_sc: ["day-01.png","day-02.png","day-03.png","day-04.png","day-05.png","day-06.png","day-07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 86,
              am_y: 186,
              am_sc_path: '22.png',
              am_en_path: '22.png',
              pm_x: 86,
              pm_y: 186,
              pm_sc_path: '23.png',
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 153,
              // y: 226,
              // font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -13,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = '2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = '3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = '4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = '5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = '6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = '7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = '8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = '9.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = '10.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = '11.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 153,
                center_y: 226,
                pos_x: 153,
                pos_y: 226,
                angle: -13,
                src: '2.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 319,
              // y: 176,
              // font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -15,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = '2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = '3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = '4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = '5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = '6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = '7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = '8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = '9.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = '10.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = '11.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 319,
                center_y: 176,
                pos_x: 319,
                pos_y: 176,
                angle: -15,
                src: '2.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 257,
              y: 60,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 257,
              y: 130,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 106,
              y: 130,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 329,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 390,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 257,
              y: 207,
              w: 100,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 207,
              w: 100,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'C_2.png',
              normal_src: 'C_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_rotate_string = normal_heart_rate_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 3 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 232 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();
              normal_battery_rotate_string = normal_battery_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 2 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 332 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();
              normal_step_rotate_string = normal_step_rotate_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 6 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 157 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 6;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + 2 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 328 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 153 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 319 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              idle_heart_rate_rotate_string = idle_heart_rate_rotate_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 3 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 232 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();
              idle_battery_rotate_string = idle_battery_rotate_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + 2 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 332 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();
              idle_step_rotate_string = idle_step_rotate_string.padStart(5, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + 6 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 157 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + 6;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  idle_day_TextRotate_posOffset = idle_day_TextRotate_posOffset + 2 * (idle_day_rotate_string.length - 1);
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 328 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  img_offset -= idle_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 153 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  img_offset -= idle_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 319 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}