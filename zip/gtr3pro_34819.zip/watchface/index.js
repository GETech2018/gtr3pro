﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 240,
              src: '0141.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 241,
              src: '0140.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 361,
              month_startY: 189,
              month_sc_array: ["m1.png","m10.png","m11.png","m12.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              month_tc_array: ["m1.png","m10.png","m11.png","m12.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              month_en_array: ["m1.png","m10.png","m11.png","m12.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 188,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 302,
              day_startY: 178,
              day_sc_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              day_tc_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              day_en_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 348,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 336,
              image_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 398,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 389,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 338,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 288,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 62,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'num-gradi.png',
              unit_tc: 'num-gradi.png',
              unit_en: 'num-gradi.png',
              negative_image: 'num-meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 46,
              src: 'term.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 33,
              image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 3,
              am_y: 226,
              am_sc_path: 'icon_AM.png',
              am_en_path: 'icon_AM.png',
              pm_x: 3,
              pm_y: 226,
              pm_sc_path: 'icon_PM.png',
              pm_en_path: 'icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 158,
              hour_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 45,
              minute_startY: 244,
              minute_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 91,
              second_startY: 134,
              second_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 240,
              src: '0141.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 241,
              src: '0140.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 361,
              month_startY: 189,
              month_sc_array: ["m1.png","m10.png","m11.png","m12.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              month_tc_array: ["m1.png","m10.png","m11.png","m12.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              month_en_array: ["m1.png","m10.png","m11.png","m12.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 188,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 302,
              day_startY: 178,
              day_sc_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              day_tc_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              day_en_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 348,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 336,
              image_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 398,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 389,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 338,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 288,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 62,
              font_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'num-gradi.png',
              unit_tc: 'num-gradi.png',
              unit_en: 'num-gradi.png',
              negative_image: 'num-meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 46,
              src: 'term.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 33,
              image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 3,
              am_y: 226,
              am_sc_path: 'icon_AM.png',
              am_en_path: 'icon_AM.png',
              pm_x: 3,
              pm_y: 226,
              pm_sc_path: 'icon_PM.png',
              pm_en_path: 'icon_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 158,
              hour_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 45,
              minute_startY: 244,
              minute_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 91,
              second_startY: 134,
              second_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 188,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 27,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 363,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 286,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}