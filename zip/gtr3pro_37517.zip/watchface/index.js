﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_pointer_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 21;
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_icon_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 21;
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 274,
              src: 'i_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 246,
              src: 'i_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 209,
              src: 'i_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 170,
              src: 'i_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 31,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 's_temp.png',
              unit_tc: 's_temp.png',
              unit_en: 's_temp.png',
              negative_image: 's_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_heart_rate_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 66,
              // start_y: 294,
              // color: 0xFF7F7F7F,
              // pointer: 'progress_ind.png',
              // lenght: -179,
              // line_width: 45,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 251,
              src: 'i_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 149,
              // y: 298,
              // font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 90,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 's_00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 's_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 's_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 's_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 's_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 's_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 's_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 's_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 's_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 's_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 149,
                center_y: 298,
                pos_x: 149,
                pos_y: 298,
                angle: 90,
                src: 's_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 64,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 2,
              dot_image: 's_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 443,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 's_batt.png',
              unit_tc: 's_batt.png',
              unit_en: 's_batt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 377,
              // start_y: 294,
              // color: 0xFF838383,
              // pointer: 'progress_ind.png',
              // lenght: -179,
              // line_width: 45,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 376,
              y: 250,
              src: 'i_stps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 338,
              // y: 106,
              // font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 's_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 's_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 's_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 's_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 's_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 's_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 's_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 's_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 's_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 's_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 338,
                center_y: 106,
                pos_x: 338,
                pos_y: 106,
                angle: -90,
                src: 's_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 400,
              week_en: ["wk_00.png","wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png"],
              week_tc: ["wk_00.png","wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png"],
              week_sc: ["wk_00.png","wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 326,
              day_sc_array: ["med_00.png","med_01.png","med_02.png","med_03.png","med_04.png","med_05.png","med_06.png","med_07.png","med_08.png","med_09.png"],
              day_tc_array: ["med_00.png","med_01.png","med_02.png","med_03.png","med_04.png","med_05.png","med_06.png","med_07.png","med_08.png","med_09.png"],
              day_en_array: ["med_00.png","med_01.png","med_02.png","med_03.png","med_04.png","med_05.png","med_06.png","med_07.png","med_08.png","med_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 78,
              month_startY: 315,
              month_sc_array: ["month_00.png","month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png"],
              month_tc_array: ["month_00.png","month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png"],
              month_en_array: ["month_00.png","month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 431,
              am_y: 188,
              am_sc_path: 'i_am.png',
              am_en_path: 'i_am.png',
              pm_x: 431,
              pm_y: 188,
              pm_sc_path: 'i_pm.png',
              pm_en_path: 'i_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 162,
              hour_startY: 102,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 162,
              minute_startY: 203,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_ind.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 443,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 's_batt.png',
              unit_tc: 's_batt.png',
              unit_en: 's_batt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 400,
              week_en: ["wk_00.png","wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png"],
              week_tc: ["wk_00.png","wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png"],
              week_sc: ["wk_00.png","wk_01.png","wk_02.png","wk_03.png","wk_04.png","wk_05.png","wk_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 162,
              hour_startY: 102,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 162,
              minute_startY: 203,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 321,
              w: 109,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 107,
              w: 85,
              h: 190,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 64,
              y: 107,
              w: 85,
              h: 190,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 19,
              y: 146,
              w: 38,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 148,
              y: 23,
              w: 180,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 149 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 338 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 66;
                  let start_y_normal_heart_rate = 294;
                  let lenght_ls_normal_heart_rate = -179;
                  let line_width_ls_normal_heart_rate = 45;
                  let color_ls_normal_heart_rate = 0xFF7F7F7F;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    line_width_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_y_normal_heart_rate_draw = start_y_normal_heart_rate_draw - line_width_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_heart_rate = 23;
                  let pointer_offset_y_ls_normal_heart_rate = 6;
                  normal_heart_rate_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw + line_width_ls_normal_heart_rate / 2 - pointer_offset_x_ls_normal_heart_rate,
                    y: start_y_normal_heart_rate + lenght_ls_normal_heart_rate - pointer_offset_y_ls_normal_heart_rate,
                    src: 'progress_ind.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 377;
                  let start_y_normal_step = 294;
                  let lenght_ls_normal_step = -179;
                  let line_width_ls_normal_step = 45;
                  let color_ls_normal_step = 0xFF838383;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 23;
                  let pointer_offset_y_ls_normal_step = 6;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step + lenght_ls_normal_step - pointer_offset_y_ls_normal_step,
                    src: 'progress_ind.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}