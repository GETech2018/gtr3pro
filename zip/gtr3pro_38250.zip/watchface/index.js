﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_calorie_icon_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aodbg001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 66,
              y: 83,
              src: '0502.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 83,
              src: '0503.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 166,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 34,
              w: 180,
              h: 34,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 120,
              font_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              unit_sc: '0136.png',
              unit_tc: '0136.png',
              unit_en: '0136.png',
              negative_image: '0421.png',
              invalid_image: '0421.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 86,
              y: 116,
              image_array: ["19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 326,
              font_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 284,
              src: '0284.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 364,
              font_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              unit_sc: '0422.png',
              unit_tc: '0422.png',
              unit_en: '0422.png',
              dot_image: '0423.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 320,
              src: '0121.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 364,
              font_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 324,
              src: '0498.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 406,
              font_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              unit_sc: '0420.png',
              unit_tc: '0420.png',
              unit_en: '0420.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 378,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 256,
              year_startY: 74,
              year_sc_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              year_tc_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              year_en_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 206,
              month_startY: 74,
              month_sc_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              month_tc_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              month_en_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: '0423.png',
              month_unit_tc: '0423.png',
              month_unit_en: '0423.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 156,
              day_startY: 74,
              day_sc_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              day_tc_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              day_en_array: ["0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: '0423.png',
              day_unit_tc: '0423.png',
              day_unit_en: '0423.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 158,
              y: 120,
              week_en: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              week_tc: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              week_sc: ["0610.png","0611.png","0612.png","0613.png","0614.png","0615.png","0616.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 177,
              hour_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 270,
              minute_startY: 177,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0282.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 26,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: -39,
              src: '0_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 177,
              hour_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 270,
              minute_startY: 177,
              minute_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}