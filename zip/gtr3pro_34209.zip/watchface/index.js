﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_year = ''
        let normal_spo2_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextRotate = new Array(5);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 18;
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let calendar_btn = ''
		let battery_btn = ''
		let activity_btn = ''
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 9
		let handsnumber = 1
        let totalhands = 9

        function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
                 if(colornumber==2) hmUI.showToast({text: 'A M B E R'});
				 if(colornumber==3) hmUI.showToast({text: 'G R E E N'});
                 if(colornumber==4) hmUI.showToast({text: 'O C E A N'});
				 if(colornumber==5) hmUI.showToast({text: 'R E D'});
                 if(colornumber==6) hmUI.showToast({text: 'C Y A N'});
				 if(colornumber==7) hmUI.showToast({text: 'P U R P L E'});
				 if(colornumber==8) hmUI.showToast({text: 'B L U E'});
                 if(colornumber==9) hmUI.showToast({text: 'C O L O R L E S S'});
            }
            if(colornumber==1) hmUI.showToast({text: 'O R A N G E'});
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
			call_change_Hands();
        }

        function call_change_Hands() {
              if(colornumber==2) {
                ChangeHands(2);
              } else if(colornumber==3) {
                ChangeHands(3);
              } else if(colornumber==4) {
                ChangeHands(4);
              } else if(colornumber==5) {
                ChangeHands(5);
			  } else if(colornumber==6) {
                ChangeHands(6);
			  } else if(colornumber==7) {
                ChangeHands(7);
              } else if(colornumber==8) {
                ChangeHands(8);
			  } else if(colornumber==9) {
                ChangeHands(9);
              } else if(colornumber==1) {
                ChangeHands(1);
              }
        }

		function ChangeHands(number) {
           if(number==2) {
				  secondstring='ana_sec2.png';
             } else if(number==3) {
				  secondstring='ana_sec3.png';
             } else if(number==4) {
				  secondstring='ana_sec4.png';
             } else if(number==5) {
				  secondstring='ana_sec5.png';
             } else if(number==6) {
				  secondstring='ana_sec6.png';
			 } else if(number==7) {
				  secondstring='ana_sec7.png';
			 } else if(number==8) {
				  secondstring='ana_sec8.png';
			 } else if(number==9) {
				  secondstring='ana_sec9.png';
             } else {
				  secondstring='ana_sec1.png';
             }
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
			  second_path: secondstring,
              second_centerX: 240,
              second_centerY: 239,
              second_posX: 139,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 134,
              y: 322,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 182,
              year_startY: 172,
              year_sc_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              year_tc_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              year_en_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 400,
              font_array: ["light_0.png","light_1.png","light_2.png","light_3.png","light_4.png","light_5.png","light_6.png","light_7.png","light_8.png","light_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 400,
              font_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 250,
              font_array: ["light_0.png","light_1.png","light_2.png","light_3.png","light_4.png","light_5.png","light_6.png","light_7.png","light_8.png","light_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 271,
              y: 172,
              image_array: ["steps_01.png","steps_02.png","steps_03.png","steps_04.png","steps_05.png","steps_06.png","steps_07.png","steps_08.png","steps_09.png","steps_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 339,
              font_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 22,
              y: 265,
              week_en: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_tc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_sc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 39,
              month_startY: 177,
              month_sc_array: ["mons_1.png","mons_2.png","mons_3.png","mons_4.png","mons_5.png","mons_6.png","mons_7.png","mons_8.png","mons_9.png","mons_10.png","mons_11.png","mons_12.png"],
              month_tc_array: ["mons_1.png","mons_2.png","mons_3.png","mons_4.png","mons_5.png","mons_6.png","mons_7.png","mons_8.png","mons_9.png","mons_10.png","mons_11.png","mons_12.png"],
              month_en_array: ["mons_1.png","mons_2.png","mons_3.png","mons_4.png","mons_5.png","mons_6.png","mons_7.png","mons_8.png","mons_9.png","mons_10.png","mons_11.png","mons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 57,
              day_startY: 133,
              day_sc_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              day_tc_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              day_en_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 116,
              font_array: ["dig_11_w_0.png","dig_11_w_1.png","dig_11_w_2.png","dig_11_w_3.png","dig_11_w_4.png","dig_11_w_5.png","dig_11_w_6.png","dig_11_w_7.png","dig_11_w_8.png","dig_11_w_9.png"],
              padding: true,
              h_space: 1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'mi.png',
              imperial_unit_tc: 'mi.png',
              imperial_unit_en: 'mi.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 342,
              src: 'Batt_symbol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 338,
              font_array: ["light_0.png","light_1.png","light_2.png","light_3.png","light_4.png","light_5.png","light_6.png","light_7.png","light_8.png","light_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 342,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 217,
              // start_y: 335,
              // color: 0xFFFF8C00,
              // pointer: 'Batt_arrow.png',
              // lenght: 60,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 116,
              font_array: ["dig_11_w_0.png","dig_11_w_1.png","dig_11_w_2.png","dig_11_w_3.png","dig_11_w_4.png","dig_11_w_5.png","dig_11_w_6.png","dig_11_w_7.png","dig_11_w_8.png","dig_11_w_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'degr.png',
              unit_tc: 'degr.png',
              unit_en: 'degr.png',
              negative_image: 'dig_11_w_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 304,
              y: 49,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 243,
              y: 53,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 63,
              src: 'srss.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 45,
              font_array: ["light_0.png","light_1.png","light_2.png","light_3.png","light_4.png","light_5.png","light_6.png","light_7.png","light_8.png","light_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'light_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 75,
              font_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dark_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 202,
              hour_array: ["dig_21_w_0.png","dig_21_w_1.png","dig_21_w_2.png","dig_21_w_3.png","dig_21_w_4.png","dig_21_w_5.png","dig_21_w_6.png","dig_21_w_7.png","dig_21_w_8.png","dig_21_w_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 157,
              minute_startY: 202,
              minute_array: ["dig_21_w_0.png","dig_21_w_1.png","dig_21_w_2.png","dig_21_w_3.png","dig_21_w_4.png","dig_21_w_5.png","dig_21_w_6.png","dig_21_w_7.png","dig_21_w_8.png","dig_21_w_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 56,
              second_startY: 319,
              second_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 202,
              src: 'dig_21_w_dots.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 258,
              am_y: 283,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 258,
              pm_y: 283,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'ana_sec1.png',
              second_centerX: 240,
              second_centerY: 239,
              second_posX: 139,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 91,
              y: 385,
              src: 'Zone_Icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 400,
              font_array: ["light_0.png","light_1.png","light_2.png","light_3.png","light_4.png","light_5.png","light_6.png","light_7.png","light_8.png","light_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 399,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 302,
              y: 204,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 108,
              month_startY: 177,
              month_sc_array: ["mons_1.png","mons_2.png","mons_3.png","mons_4.png","mons_5.png","mons_6.png","mons_7.png","mons_8.png","mons_9.png","mons_10.png","mons_11.png","mons_12.png"],
              month_tc_array: ["mons_1.png","mons_2.png","mons_3.png","mons_4.png","mons_5.png","mons_6.png","mons_7.png","mons_8.png","mons_9.png","mons_10.png","mons_11.png","mons_12.png"],
              month_en_array: ["mons_1.png","mons_2.png","mons_3.png","mons_4.png","mons_5.png","mons_6.png","mons_7.png","mons_8.png","mons_9.png","mons_10.png","mons_11.png","mons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 64,
              day_startY: 172,
              day_sc_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              day_tc_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              day_en_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 190,
              src: 'aod_Batt_symbol.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 300,
              // y: 271,
              // font_array: ["dark_0.png","dark_1.png","dark_2.png","dark_3.png","dark_4.png","dark_5.png","dark_6.png","dark_7.png","dark_8.png","dark_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'dark_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'dark_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'dark_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'dark_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'dark_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'dark_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'dark_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'dark_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'dark_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'dark_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 300,
                center_y: 271,
                pos_x: 300,
                pos_y: 271,
                angle: -90,
                src: 'dark_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 275,
              y: 190,
              image_array: ["aod_Batt_icon_01.png","aod_Batt_icon_02.png","aod_Batt_icon_03.png","aod_Batt_icon_04.png","aod_Batt_icon_05.png","aod_Batt_icon_06.png","aod_Batt_icon_07.png","aod_Batt_icon_08.png","aod_Batt_icon_09.png","aod_Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 202,
              hour_array: ["dig_21_w_0.png","dig_21_w_1.png","dig_21_w_2.png","dig_21_w_3.png","dig_21_w_4.png","dig_21_w_5.png","dig_21_w_6.png","dig_21_w_7.png","dig_21_w_8.png","dig_21_w_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 157,
              minute_startY: 202,
              minute_array: ["dig_21_w_0.png","dig_21_w_1.png","dig_21_w_2.png","dig_21_w_3.png","dig_21_w_4.png","dig_21_w_5.png","dig_21_w_6.png","dig_21_w_7.png","dig_21_w_8.png","dig_21_w_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 202,
              src: 'dig_21_w_dots.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 200,
              w: 100,
              h: 75,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 200,
              w: 100,
              h: 75,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 45,
              w: 60,
              h: 60,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 310,
              w: 70,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 45,
              w: 100,
              h: 60,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 45,
              w: 80,
              h: 60,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 112,
              w: 100,
              h: 45,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 320,
              w: 80,
              h: 50,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 370,
              w: 70,
              h: 70,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 370,
              w: 70,
              h: 70,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 370,
              w: 70,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 205,
              w: 85,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 110,
			  text: '',
              w: 70,
              h: 60,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 310,
			  text: '',
              w: 160,
              h: 60,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			activity_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 110,
			  text: '',
              w: 150,
              h: 60,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ url: 'SportListScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 383,
              text: '',
              w: 50,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);

            function text_update() {

              console.log('update text rotate BATTERY');
              let valueBattery = battery.current;
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 300 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 217;
                  let start_y_normal_battery = 335;
                  let lenght_ls_normal_battery = 60;
                  let line_width_ls_normal_battery = 0;
                  let color_ls_normal_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 13;
                  let pointer_offset_y_ls_normal_battery = 7;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'Batt_arrow.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}