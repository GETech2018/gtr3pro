﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            

  	    let screenType = hmSetting.getScreenType();
            // animate
            if (screenType != hmSetting.screen_type.AOD) {

               let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "Cosmos",
                    anim_ext: "png",
                    anim_fps: 40,
                    anim_size: 45,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	           });
       	    }
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'coronatrans.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 118,
              src: 'gauge.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'MiniNeedle.png',
              center_x: 242,
              center_y: 152,
              x: 7,
              y: 32,
              start_angle: -90,
              end_angle: 90,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 87,
              y: 58,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 405,
              font_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 408,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 362,
              font_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 362,
              font_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 316,
              month_sc_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              month_tc_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              month_en_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              month_zero: 1,
              month_space: -6,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 156,
              day_startY: 316,
              day_sc_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              day_tc_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              day_en_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              day_zero: 1,
              day_space: -6,
              day_unit_sc: 'guion.png',
              day_unit_tc: 'guion.png',
              day_unit_en: 'guion.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 323,
              week_en: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              week_tc: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              week_sc: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 192,
              y: 35,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 269,
              y: 36,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 113,
              font_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'degrees.png',
              unit_tc: 'degrees.png',
              unit_en: 'degrees.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 36,
              image_array: ["Weat_1.png","Weat_2.png","Weat_3.png","Weat_4.png","Weat_5.png","Weat_6.png","Weat_7.png","Weat_8.png","Weat_9.png","Weat_10.png","Weat_11.png","Weat_12.png","Weat_13.png","Weat_14.png","Weat_15.png","Weat_16.png","Weat_17.png","Weat_18.png","Weat_19.png","Weat_20.png","Weat_21.png","Weat_22.png","Weat_23.png","Weat_24.png","Weat_25.png","Weat_26.png","Weat_27.png","Weat_28.png","Weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 36,
              src: 'Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 226,
              // start_y: 38,
              // color: 0xFF0DF900,
              // lenght: 32,
              // line_width: 15,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 67,
              font_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 162,
              hour_array: ["NWTr_10.png","NWTr_11.png","NWTr_12.png","NWTr_13.png","NWTr_14.png","NWTr_15.png","NWTr_16.png","NWTr_17.png","NWTr_18.png","NWTr_19.png"],
              hour_zero: 1,
              hour_space: -25,
              hour_unit_sc: 'NWTrSep.png',
              hour_unit_tc: 'NWTrSep.png',
              hour_unit_en: 'NWTrSep.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 238,
              minute_startY: 162,
              minute_array: ["NWTr_10.png","NWTr_11.png","NWTr_12.png","NWTr_13.png","NWTr_14.png","NWTr_15.png","NWTr_16.png","NWTr_17.png","NWTr_18.png","NWTr_19.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 316,
              second_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 33,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Second.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 24,
              second_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 192,
              y: 35,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 269,
              y: 36,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 36,
              src: 'Batt.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 226,
              // start_y: 38,
              // color: 0xFF0DF900,
              // lenght: 32,
              // line_width: 15,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 162,
              hour_array: ["NWTr_10.png","NWTr_11.png","NWTr_12.png","NWTr_13.png","NWTr_14.png","NWTr_15.png","NWTr_16.png","NWTr_17.png","NWTr_18.png","NWTr_19.png"],
              hour_zero: 1,
              hour_space: -25,
              hour_unit_sc: 'NWTrSep.png',
              hour_unit_tc: 'NWTrSep.png',
              hour_unit_en: 'NWTrSep.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 238,
              minute_startY: 162,
              minute_array: ["NWTr_10.png","NWTr_11.png","NWTr_12.png","NWTr_13.png","NWTr_14.png","NWTr_15.png","NWTr_16.png","NWTr_17.png","NWTr_18.png","NWTr_19.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 316,
              second_array: ["NWSmallTr_10.png","NWSmallTr_11.png","NWSmallTr_12.png","NWSmallTr_13.png","NWSmallTr_14.png","NWSmallTr_15.png","NWSmallTr_16.png","NWSmallTr_17.png","NWSmallTr_18.png","NWSmallTr_19.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 226;
                  let start_y_normal_battery = 38;
                  let lenght_ls_normal_battery = 32;
                  let line_width_ls_normal_battery = 15;
                  let color_ls_normal_battery = 0xFF0DF900;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 226;
                  let start_y_idle_battery = 38;
                  let lenght_ls_idle_battery = 32;
                  let line_width_ls_idle_battery = 15;
                  let color_ls_idle_battery = 0xFF0DF900;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  