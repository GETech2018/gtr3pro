﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [39,39,39,39,39,39],
              y: [190,190,190,190,190,190],
              image_array: ["battery_00.png","battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 424,
              font_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0052.png',
              unit_tc: '0052.png',
              unit_en: '0052.png',
              dot_image: '0074.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 45,
              src: '0062.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 45,
              src: '0063.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 164,
              font_array: ["hum_00.png","hum_01.png","hum_02.png","hum_03.png","hum_04.png","hum_05.png","hum_06.png","hum_07.png","hum_08.png","hum_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0076.png',
              unit_tc: '0076.png',
              unit_en: '0076.png',
              negative_image: '0075.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 85,
              y: 139,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 354,
              font_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 395,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 354,
              font_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 354,
              font_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 396,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 336,
              month_startY: 159,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 58,
              y: 88,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 275,
              day_startY: 159,
              day_sc_array: ["month_day_00.png","month_day_01.png","month_day_02.png","month_day_03.png","month_day_04.png","month_day_05.png","month_day_06.png","month_day_07.png","month_day_08.png","month_day_09.png"],
              day_tc_array: ["month_day_00.png","month_day_01.png","month_day_02.png","month_day_03.png","month_day_04.png","month_day_05.png","month_day_06.png","month_day_07.png","month_day_08.png","month_day_09.png"],
              day_en_array: ["month_day_00.png","month_day_01.png","month_day_02.png","month_day_03.png","month_day_04.png","month_day_05.png","month_day_06.png","month_day_07.png","month_day_08.png","month_day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 392,
              am_y: 228,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 392,
              pm_y: 228,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 224,
              hour_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 249,
              minute_startY: 224,
              minute_array: ["Numbers_big_00.png","Numbers_big_01.png","Numbers_big_02.png","Numbers_big_03.png","Numbers_big_04.png","Numbers_big_05.png","Numbers_big_06.png","Numbers_big_07.png","Numbers_big_08.png","Numbers_big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 391,
              second_startY: 289,
              second_array: ["Numbers_small_00.png","Numbers_small_01.png","Numbers_small_02.png","Numbers_small_03.png","Numbers_small_04.png","Numbers_small_05.png","Numbers_small_06.png","Numbers_small_07.png","Numbers_small_08.png","Numbers_small_09.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 247,
              src: 'Untitled_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 419,
              font_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0050.png',
              unit_tc: '0050.png',
              unit_en: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 380,
              src: '0150.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 136,
              month_sc_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              month_tc_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              month_en_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 136,
              day_sc_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              day_tc_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              day_en_array: ["Numbers_little_00.png","Numbers_little_01.png","Numbers_little_02.png","Numbers_little_03.png","Numbers_little_04.png","Numbers_little_05.png","Numbers_little_06.png","Numbers_little_07.png","Numbers_little_08.png","Numbers_little_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 136,
              src: '0074.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 308,
              am_sc_path: 'sunset_AM.png',
              am_en_path: 'sunset_AM.png',
              pm_x: 221,
              pm_y: 308,
              pm_sc_path: 'sunset_PM.png',
              pm_en_path: 'sunset_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 189,
              hour_array: ["AODNumbers_big_00.png","AODNumbers_big_01.png","AODNumbers_big_02.png","AODNumbers_big_03.png","AODNumbers_big_04.png","AODNumbers_big_05.png","AODNumbers_big_06.png","AODNumbers_big_07.png","AODNumbers_big_08.png","AODNumbers_big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 190,
              minute_array: ["AODNumbers_big_00.png","AODNumbers_big_01.png","AODNumbers_big_02.png","AODNumbers_big_03.png","AODNumbers_big_04.png","AODNumbers_big_05.png","AODNumbers_big_06.png","AODNumbers_big_07.png","AODNumbers_big_08.png","AODNumbers_big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 208,
              src: '0012.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 22,
              w: 80,
              h: 80,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 18,
              w: 80,
              h: 80,
              src: '0175.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 107,
              y: 131,
              w: 120,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 339,
              w: 100,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 344,
              w: 100,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
