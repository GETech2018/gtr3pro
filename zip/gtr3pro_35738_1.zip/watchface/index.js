﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = ''

        let normal_g_heart = ''
        let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
        let min_heart = Math.min(...heartArr)
        

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

   /////////////////////  Show graph heart rate  /////////////////////

             normal_g_heart=hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{

                              x: 84,
                              y: 297,
                              w: 310,
                              h: 50,
                              line_color:0xFF6600,
                              line_width:2,
            type:hmUI.data_type.HEART,
            show_level:hmUI.show_level.ONLY_NORMAL
          });


  ////////////////////////////////////////////////////////////////////

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 351,
              y: 225,
              src: '39.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 1,
              y: 0,
              src: '40.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 262,
              font_array: ["digital11_0.png","digital11_1.png","digital11_2.png","digital11_3.png","digital11_4.png","digital11_5.png","digital11_6.png","digital11_7.png","digital11_8.png","digital11_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital11_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 262,
              font_array: ["digital11_0.png","digital11_1.png","digital11_2.png","digital11_3.png","digital11_4.png","digital11_5.png","digital11_6.png","digital11_7.png","digital11_8.png","digital11_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital11_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 377,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'digital9_11.png',
              unit_tc: 'digital9_11.png',
              unit_en: 'digital9_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 360,
              image_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 377,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 235,
              y: 360,
              image_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 34,
              w: 150,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 118,
              font_array: ["digital4_0.png","digital4_1.png","digital4_2.png","digital4_3.png","digital4_4.png","digital4_5.png","digital4_6.png","digital4_7.png","digital4_8.png","digital4_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital4_11.png',
              unit_tc: 'digital4_11.png',
              unit_en: 'digital4_11.png',
              negative_image: 'digital4_10.png',
              invalid_image: 'digital4_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 118,
              font_array: ["digital4_0.png","digital4_1.png","digital4_2.png","digital4_3.png","digital4_4.png","digital4_5.png","digital4_6.png","digital4_7.png","digital4_8.png","digital4_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital4_11.png',
              unit_tc: 'digital4_11.png',
              unit_en: 'digital4_11.png',
              negative_image: 'digital4_10.png',
              invalid_image: 'digital4_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 104,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 118,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'digital3_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 198,
              month_startY: 91,
              month_sc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_tc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_en_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 64,
              week_en: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              week_tc: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              week_sc: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 52,
              day_sc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              day_tc_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              day_en_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 143,
              hour_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 217,
              minute_startY: 143,
              minute_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 351,
              second_startY: 158,
              second_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 138,
              src: 'digital1_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'image3.png',
              // center_x: 240,
              // center_y: 240,
              // x: 24,
              // y: 221,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 24,
              pos_y: 240 - 221,
              center_x: 240,
              center_y: 240,
              src: 'image3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 137,
              month_sc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_tc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_en_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 251,
              y: 106,
              week_en: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              week_tc: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              week_sc: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 97,
              day_sc_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              day_tc_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              day_en_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 194,
              hour_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 228,
              minute_startY: 194,
              minute_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 376,
              second_startY: 195,
              second_array: ["71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 207,
              src: '70.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 192,
              w: 100,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    ///////////////////////  show value  main , max , min /////////////////////////

              let heart_num = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 77,
                                y: 255,
                                type: hmUI.data_type.HEART,
                                font_array:["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
                                h_space: 0,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                                invalid_image: "digital13_0.png",
                                isCharacter: true,
                                show_level:hmUI.show_level.ONLY_NORMAL

                              });

                 let minText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 154,
                                y: 255,
                                text: min_heart,
                                type: hmUI.data_type.HEART,
                                font_array:["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
                                h_space: 2,
                                align_h: hmUI.align.CENTER_H,
                                padding: false,
                                isCharacter: true,
                                show_level:hmUI.show_level.ONLY_NORMAL
                             });

     ////////////////// End /////////////////////////

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

            };

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

                                    let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
                                    let min_heart = Math.min(...heartArr)
                                    
                                  
                                      heart_num.setProperty(hmUI.prop.MORE, {
                                        x: 77,
                                        y: 255,
                                        type: hmUI.data_type.HEART,
                                        font_array:["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
                                        h_space: 2,
                                        align_h: hmUI.align.CENTER_H,
                                        padding: false,
                                        isCharacter: true,
                                        invalid_image: "digital13_0.png",
                                        show_level:hmUI.show_level.ONLY_NORMAL
                                    });

                                      minText.setProperty(hmUI.prop.MORE, {
                                        x: 154,
                                        y: 255,
                                        text: min_heart,
                                        type: hmUI.data_type.HEART,
                                        font_array:["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png"],
                                        h_space: 0,
                                        align_h: hmUI.align.CENTER_H,
                                        padding: false,
                                        isCharacter: true,
                                        show_level:hmUI.show_level.ONLY_NORMAL
                                    });

                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}