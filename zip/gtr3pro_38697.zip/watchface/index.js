﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colorNumber = 1
let totalColors = 5
let colorName = ''


function click_color() {

    if(colorNumber >= totalColors) {
        colorNumber = 1;
    }
    else {
        colorNumber = colorNumber + 1;
    }


    //*** Toast with text / Toast con texto ***
    if ( colorNumber == 1) { colorName = "Original"}
    if ( colorNumber > 1)  { colorName = "Variant " + parseInt(colorNumber - 1)}
    hmUI.showToast({text: colorName });


    //*** Toast with text and index / Toast con texto e indice ***
    //hmUI.showToast({text: "Color " + parseInt(colorNumber) });


    //*** Toast with index / Toast con indice ***
	//hmUI.showToast({text: "" + parseInt(colorNumber) });


    normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colorNumber) + ".png");
         
    }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_image_progress_img_progress = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let image_top_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 435,
              src: 'IconAlertStrip.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 274,
              y: 442,
              src: 'IconLock2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 442,
              src: 'IconAudio2.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 442,
              src: 'IconBT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 213,
              y: 442,
              src: 'IconBell2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 373,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 371,
              src: 'IconO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 299,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              dot_image: 'SymbolDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 411,
              y: 299,
              src: 'IconRoute.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 16,
              src: 'Trophy00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 230,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 429,
              y: 228,
              src: 'IconFeet.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [186,186,186,186,186,186,186,186,186,186],
              y: [16,16,16,16,16,16,16,16,16,16],
              image_array: ["Trophy01.png","Trophy02.png","Trophy03.png","Trophy04.png","Trophy05.png","Trophy06.png","Trophy07.png","Trophy08.png","Trophy09.png","Trophy10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 340,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 73,
              y: 341,
              src: 'IconHeart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 294,
              image_array: ["GaugeH01.png","GaugeH02.png","GaugeH03.png","GaugeH04.png","GaugeH05.png","GaugeH06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 112,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 115,
              src: 'IconBattery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 67,
              image_array: ["Gauge00.png","Gauge01.png","Gauge02.png","Gauge03.png","Gauge04.png","Gauge05.png","Gauge06.png","Gauge07.png","Gauge08.png","Gauge09.png","Gauge10.png","Gauge11.png","Gauge12.png","Gauge13.png","Gauge14.png","Gauge15.png","Gauge16.png","Gauge17.png","Gauge18.png","Gauge19.png","Gauge20.png","Gauge21.png","Gauge22.png","Gauge23.png","Gauge24.png","Gauge25.png"],
              image_length: 26,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 73,
              year_startY: 106,
              year_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_zero: 1,
              year_space: 5,
              year_unit_sc: 'SymbolDash.png',
              year_unit_tc: 'SymbolDash.png',
              year_unit_en: 'SymbolDash.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 106,
              month_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 68,
              day_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 68,
              week_en: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              week_tc: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              week_sc: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 150,
              hour_array: ["DigitL0.png","DigitL1.png","DigitL2.png","DigitL3.png","DigitL4.png","DigitL5.png","DigitL6.png","DigitL7.png","DigitL8.png","DigitL9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_unit_sc: 'SymbolColon.png',
              hour_unit_tc: 'SymbolColon.png',
              hour_unit_en: 'SymbolColon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 132,
              minute_startY: 150,
              minute_array: ["DigitL0.png","DigitL1.png","DigitL2.png","DigitL3.png","DigitL4.png","DigitL5.png","DigitL6.png","DigitL7.png","DigitL8.png","DigitL9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 170,
              second_startY: 230,
              second_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 230,
              src: 'Meridian24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 16,
              am_y: 230,
              am_sc_path: 'MeridianAM.png',
              am_en_path: 'MeridianAM.png',
              pm_x: 16,
              pm_y: 230,
              pm_sc_path: 'MeridianPM.png',
              pm_en_path: 'MeridianPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 435,
              src: 'IconAlertStrip.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 274,
              y: 442,
              src: 'IconLock2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 442,
              src: 'IconAudio2.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 442,
              src: 'IconBT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 213,
              y: 442,
              src: 'IconBell2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 373,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 371,
              src: 'IconO2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 299,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              dot_image: 'SymbolDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 411,
              y: 299,
              src: 'IconRoute.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 16,
              src: 'Trophy00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 230,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 429,
              y: 228,
              src: 'IconFeet.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [186,186,186,186,186,186,186,186,186,186],
              y: [16,16,16,16,16,16,16,16,16,16],
              image_array: ["Trophy01.png","Trophy02.png","Trophy03.png","Trophy04.png","Trophy05.png","Trophy06.png","Trophy07.png","Trophy08.png","Trophy09.png","Trophy10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 340,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 73,
              y: 341,
              src: 'IconHeart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 294,
              image_array: ["GaugeH01.png","GaugeH02.png","GaugeH03.png","GaugeH04.png","GaugeH05.png","GaugeH06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 112,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 115,
              src: 'IconBattery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 67,
              image_array: ["Gauge00.png","Gauge01.png","Gauge02.png","Gauge03.png","Gauge04.png","Gauge05.png","Gauge06.png","Gauge07.png","Gauge08.png","Gauge09.png","Gauge10.png","Gauge11.png","Gauge12.png","Gauge13.png","Gauge14.png","Gauge15.png","Gauge16.png","Gauge17.png","Gauge18.png","Gauge19.png","Gauge20.png","Gauge21.png","Gauge22.png","Gauge23.png","Gauge24.png","Gauge25.png"],
              image_length: 26,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 73,
              year_startY: 106,
              year_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_zero: 1,
              year_space: 5,
              year_unit_sc: 'SymbolDash.png',
              year_unit_tc: 'SymbolDash.png',
              year_unit_en: 'SymbolDash.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 106,
              month_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 172,
              day_startY: 68,
              day_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 68,
              week_en: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              week_tc: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              week_sc: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 150,
              hour_array: ["DigitL0.png","DigitL1.png","DigitL2.png","DigitL3.png","DigitL4.png","DigitL5.png","DigitL6.png","DigitL7.png","DigitL8.png","DigitL9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_unit_sc: 'SymbolColon.png',
              hour_unit_tc: 'SymbolColon.png',
              hour_unit_en: 'SymbolColon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 132,
              minute_startY: 150,
              minute_array: ["DigitL0.png","DigitL1.png","DigitL2.png","DigitL3.png","DigitL4.png","DigitL5.png","DigitL6.png","DigitL7.png","DigitL8.png","DigitL9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 170,
              second_startY: 230,
              second_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 230,
              src: 'Meridian24H.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 16,
              am_y: 230,
              am_sc_path: 'MeridianAM.png',
              am_en_path: 'MeridianAM.png',
              pm_x: 16,
              pm_y: 230,
              pm_sc_path: 'MeridianPM.png',
              pm_en_path: 'MeridianPM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: Disconnected,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Disconnected"});
                  vibro(25);
                }
                if(status) {
                  hmUI.showToast({text: "Connected"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ZFace.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 171,
              y: 429,
              w: 137,
              h: 37,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 89,
              y: 304,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 186,
              w: 120,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: -15,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}