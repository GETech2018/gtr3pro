﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'Previewa.png', path: 'bg_0.png' },
                { id: 2, preview: 'Previewb.png', path: 'bg_2.png' },
                { id: 3, preview: 'Previewc.png', path: 'bg_3.png' },
                { id: 4, preview: 'Previewd.png', path: 'bg_7.png' },
                { id: 5, preview: 'Previewe.png', path: 'bg_7.png' },
                { id: 6, preview: 'Previewf.png', path: 'bg_8.png' },
              ],
              count: 6,
              default_id: 1,
              fg: '.png',
              tips_bg: '0140.png',
              tips_x: 160,
              tips_y: 160,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 243,
              src: 'icon_bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 287,
              src: 'icon_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 163,
              font_array: ["battery_00.png","battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0108.png',
              unit_tc: '0108.png',
              unit_en: '0108.png',
              negative_image: '0107.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 174,
              image_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 131,
              y: 193,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 299,
              day_startY: 173,
              day_sc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              day_tc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              day_en_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 376,
              month_startY: 173,
              month_sc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              month_tc_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              month_en_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 193,
              font_array: ["battery_00.png","battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 166,
              image_array: ["0002.png","0003.png","0004.png","0005.png","0006.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 349,
              font_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_distance_KM.png',
              unit_tc: 'icon_distance_KM.png',
              unit_en: 'icon_distance_KM.png',
              dot_image: 'DOWN_W_DISTANCE_Numb_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 61,
              font_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 61,
              font_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 350,
              font_array: ["Date_Numb_00.png","Date_Numb_01.png","Date_Numb_02.png","Date_Numb_03.png","Date_Numb_04.png","Date_Numb_05.png","Date_Numb_06.png","Date_Numb_07.png","Date_Numb_08.png","Date_Numb_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 106,
              image_array: ["steps_progress_01.png","steps_progress_1.png","steps_progress_2.png","steps_progress_3.png","steps_progress_4.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 384,
              am_y: 236,
              am_sc_path: 'icon_AM.png',
              am_en_path: 'icon_AM.png',
              pm_x: 384,
              pm_y: 236,
              pm_sc_path: 'icon_PM.png',
              pm_en_path: 'icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 88,
              hour_startY: 238,
              hour_array: ["B_Numb_00.png","B_Numb_01.png","B_Numb_02.png","B_Numb_03.png","B_Numb_04.png","B_Numb_05.png","B_Numb_06.png","B_Numb_07.png","B_Numb_08.png","B_Numb_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 237,
              minute_array: ["B_Numb_00.png","B_Numb_01.png","B_Numb_02.png","B_Numb_03.png","B_Numb_04.png","B_Numb_05.png","B_Numb_06.png","B_Numb_07.png","B_Numb_08.png","B_Numb_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 371,
              second_startY: 280,
              second_array: ["S_Numb_00.png","S_Numb_01.png","S_Numb_02.png","S_Numb_03.png","S_Numb_04.png","S_Numb_05.png","S_Numb_06.png","S_Numb_07.png","S_Numb_08.png","S_Numb_09.png"],
              second_zero: 1,
              second_space: -8,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 402,
              font_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0154.png',
              unit_tc: '0154.png',
              unit_en: '0154.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 189,
              y: 383,
              src: '0155.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 255,
              month_startY: 143,
              month_sc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              month_tc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              month_en_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 143,
              day_sc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              day_tc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              day_en_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 148,
              src: '0153.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 212,
              am_y: 307,
              am_sc_path: '0141.png',
              am_en_path: '0141.png',
              pm_x: 212,
              pm_y: 307,
              pm_sc_path: '0142.png',
              pm_en_path: '0142.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 197,
              hour_array: ["AOD_B_Numb_00.png","AOD_B_Numb_01.png","AOD_B_Numb_02.png","AOD_B_Numb_03.png","AOD_B_Numb_04.png","AOD_B_Numb_05.png","AOD_B_Numb_06.png","AOD_B_Numb_07.png","AOD_B_Numb_08.png","AOD_B_Numb_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 197,
              minute_array: ["AOD_B_Numb_00.png","AOD_B_Numb_01.png","AOD_B_Numb_02.png","AOD_B_Numb_03.png","AOD_B_Numb_04.png","AOD_B_Numb_05.png","AOD_B_Numb_06.png","AOD_B_Numb_07.png","AOD_B_Numb_08.png","AOD_B_Numb_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 19,
              y: 253,
              w: 100,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 144,
              w: 100,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 39,
              w: 100,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 331,
              w: 130,
              h: 100,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
