﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'quadrante green day.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 202,
              y: 89,
              src: '0038.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 234,
              y: 81,
              image_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 98,
              y: 290,
              w: 182,
              h: 37,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 333,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'darknum_14.png',
              unit_tc: 'darknum_14.png',
              unit_en: 'darknum_14.png',
              negative_image: 'darknum_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 232,
              y: 324,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 366,
              year_startY: 278,
              year_sc_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              year_tc_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              year_en_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 328,
              month_startY: 278,
              month_sc_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              month_tc_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              month_en_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 296,
              day_startY: 278,
              day_sc_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              day_tc_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              day_en_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 316,
              // center_y: 184,
              // start_angle: 0,
              // end_angle: 353,
              // radius: 61,
              // line_width: 6,
              // color: 0xFF00FFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 165,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 144,
              src: 'passi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 158,
              // center_y: 184,
              // start_angle: 0,
              // end_angle: 354,
              // radius: 58,
              // line_width: 7,
              // color: 0xFFEDF20D,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 175,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 146,
              src: 'fuoco.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_hour.png',
              hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_min.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec0.png',
              second_centerX: 239,
              second_centerY: 240,
              second_posX: 239,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 263;
                  let center_x_normal_step = 316;
                  let center_y_normal_step = 184;
                  let radius_normal_step = 61;
                  let line_width_cs_normal_step = 6;
                  let color_cs_normal_step = 0xFF00FFFF;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale
                  // initial parameters
                  let start_angle_normal_fat_burning = -90;
                  let end_angle_normal_fat_burning = 264;
                  let center_x_normal_fat_burning = 158;
                  let center_y_normal_fat_burning = 184;
                  let radius_normal_fat_burning = 58;
                  let line_width_cs_normal_fat_burning = 7;
                  let color_cs_normal_fat_burning = 0xFFEDF20D;
                  
                  // calculated parameters
                  let arcX_normal_fat_burning = center_x_normal_fat_burning - radius_normal_fat_burning;
                  let arcY_normal_fat_burning = center_y_normal_fat_burning - radius_normal_fat_burning;
                  let CircleWidth_normal_fat_burning = 2 * radius_normal_fat_burning;
                  let angle_offset_normal_fat_burning = end_angle_normal_fat_burning - start_angle_normal_fat_burning;
                  angle_offset_normal_fat_burning = angle_offset_normal_fat_burning * progress_cs_normal_fat_burning;
                  let end_angle_normal_fat_burning_draw = start_angle_normal_fat_burning + angle_offset_normal_fat_burning;
                  
                  normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_fat_burning,
                    y: arcY_normal_fat_burning,
                    w: CircleWidth_normal_fat_burning,
                    h: CircleWidth_normal_fat_burning,
                    start_angle: start_angle_normal_fat_burning,
                    end_angle: end_angle_normal_fat_burning_draw,
                    color: color_cs_normal_fat_burning,
                    line_width: line_width_cs_normal_fat_burning,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
