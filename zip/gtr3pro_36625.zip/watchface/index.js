﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stand_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_stress_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_step_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_step_icon_img = ''
        let idle_battery_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 437,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 48,
              hour_array: ["leaf_aceh_54_0001.png","leaf_aceh_54_0002.png","leaf_aceh_54_0003.png","leaf_aceh_54_0004.png","leaf_aceh_54_0005.png","leaf_aceh_54_0006.png","leaf_aceh_54_0007.png","leaf_aceh_54_0008.png","leaf_aceh_54_0009.png","leaf_aceh_54_0010.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 307,
              minute_startY: 45,
              minute_array: ["m_leaf_aceh_54_0001.png","m_leaf_aceh_54_0002.png","m_leaf_aceh_54_0003.png","m_leaf_aceh_54_0004.png","m_leaf_aceh_54_0005.png","m_leaf_aceh_54_0006.png","m_leaf_aceh_54_0007.png","m_leaf_aceh_54_0008.png","m_leaf_aceh_54_0009.png","m_leaf_aceh_54_0010.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -20,
              am_y: 215,
              am_sc_path: 'amPicture67.png',
              am_en_path: 'amPicture67.png',
              pm_x: -20,
              pm_y: 215,
              pm_sc_path: 'amPicture68.png',
              pm_en_path: 'amPicture68.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -7,
              y: 5,
              src: 'Line_shadow _2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -11,
              y: 251,
              src: 'Line_shadow _2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 290,
              day_startY: -32,
              day_sc_array: ["s_leaf_aceh_54_0001.png","s_leaf_aceh_54_0002.png","s_leaf_aceh_54_0003.png","s_leaf_aceh_54_0004.png","s_leaf_aceh_54_0005.png","s_leaf_aceh_54_0006.png","s_leaf_aceh_54_0007.png","s_leaf_aceh_54_0008.png","s_leaf_aceh_54_0009.png","s_leaf_aceh_54_0010.png"],
              day_tc_array: ["s_leaf_aceh_54_0001.png","s_leaf_aceh_54_0002.png","s_leaf_aceh_54_0003.png","s_leaf_aceh_54_0004.png","s_leaf_aceh_54_0005.png","s_leaf_aceh_54_0006.png","s_leaf_aceh_54_0007.png","s_leaf_aceh_54_0008.png","s_leaf_aceh_54_0009.png","s_leaf_aceh_54_0010.png"],
              day_en_array: ["s_leaf_aceh_54_0001.png","s_leaf_aceh_54_0002.png","s_leaf_aceh_54_0003.png","s_leaf_aceh_54_0004.png","s_leaf_aceh_54_0005.png","s_leaf_aceh_54_0006.png","s_leaf_aceh_54_0007.png","s_leaf_aceh_54_0008.png","s_leaf_aceh_54_0009.png","s_leaf_aceh_54_0010.png"],
              day_zero: 0,
              day_space: -62,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 123,
              src: 'dash_leaf_aceh_54_0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -264,
              y: 109,
              src: 'Picture159.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 356,
              y: 126,
              week_en: ["day_leaf_aceh_54_0001.png","day_leaf_aceh_54_0002.png","day_leaf_aceh_54_0003.png","day_leaf_aceh_54_0004.png","day_leaf_aceh_54_0005.png","day_leaf_aceh_54_0006.png","day_leaf_aceh_54_0007.png"],
              week_tc: ["day_leaf_aceh_54_0001.png","day_leaf_aceh_54_0002.png","day_leaf_aceh_54_0003.png","day_leaf_aceh_54_0004.png","day_leaf_aceh_54_0005.png","day_leaf_aceh_54_0006.png","day_leaf_aceh_54_0007.png"],
              week_sc: ["day_leaf_aceh_54_0001.png","day_leaf_aceh_54_0002.png","day_leaf_aceh_54_0003.png","day_leaf_aceh_54_0004.png","day_leaf_aceh_54_0005.png","day_leaf_aceh_54_0006.png","day_leaf_aceh_54_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 305,
              y: 280,
              src: 'pwe_leaf_aceh_54_0009.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 372,
              y: 125,
              font_array: ["s_leaf_aceh_54_0001.png","s_leaf_aceh_54_0002.png","s_leaf_aceh_54_0003.png","s_leaf_aceh_54_0004.png","s_leaf_aceh_54_0005.png","s_leaf_aceh_54_0006.png","s_leaf_aceh_54_0007.png","s_leaf_aceh_54_0008.png","s_leaf_aceh_54_0009.png","s_leaf_aceh_54_0010.png"],
              padding: false,
              h_space: -65,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 280,
              src: 'dash_leaf_aceh_54_0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 48,
              hour_array: ["leaf_aceh_54_0001.png","leaf_aceh_54_0002.png","leaf_aceh_54_0003.png","leaf_aceh_54_0004.png","leaf_aceh_54_0005.png","leaf_aceh_54_0006.png","leaf_aceh_54_0007.png","leaf_aceh_54_0008.png","leaf_aceh_54_0009.png","leaf_aceh_54_0010.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 307,
              minute_startY: 45,
              minute_array: ["m_leaf_aceh_54_0001.png","m_leaf_aceh_54_0002.png","m_leaf_aceh_54_0003.png","m_leaf_aceh_54_0004.png","m_leaf_aceh_54_0005.png","m_leaf_aceh_54_0006.png","m_leaf_aceh_54_0007.png","m_leaf_aceh_54_0008.png","m_leaf_aceh_54_0009.png","m_leaf_aceh_54_0010.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -20,
              am_y: 215,
              am_sc_path: 'amPicture67.png',
              am_en_path: 'amPicture67.png',
              pm_x: -20,
              pm_y: 215,
              pm_sc_path: 'amPicture68.png',
              pm_en_path: 'amPicture68.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -264,
              y: 109,
              src: 'Picture159.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -11,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}