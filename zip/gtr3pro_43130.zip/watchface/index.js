    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_step_icon_img = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 26;
        let normal_step_TextCircle_img_height = 23;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['1.png', '2.png', '3.png', '4.png', '5.png'];
        let backgroundToastList = ['fondo1', 'fondo2', 'fondo3', 'fondo4', 'fondo5'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 51,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 68,
              font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              padding: false,
              h_space: 1,
              unit_sc: '56.png',
              unit_tc: '56.png',
              unit_en: '56.png',
              negative_image: '54.png',
              invalid_image: '55.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 197,
              end_angle: 410,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 442,
              font_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              padding: true,
              h_space: 2,
              unit_sc: '79.png',
              unit_tc: '79.png',
              unit_en: '79.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 381,
              week_en: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png"],
              week_tc: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png"],
              week_sc: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 378,
              day_sc_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_tc_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_en_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 125,
              hour_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 80,
              minute_startY: 247,
              minute_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 422,
              second_startY: 222,
              second_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 434,
              y: 290,
              src: '112.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              // radius: -218,
              // angle: -57,
              // char_space_angle: -1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '69.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '70.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '71.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '72.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '73.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '74.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '75.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '76.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '77.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '78.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 207,
                src: '69.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 426,
              y: 161,
              src: '110.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 222,
              src: '111.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 64,
              src: '111.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 439,
              font_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              padding: true,
              h_space: 2,
              unit_sc: '79.png',
              unit_tc: '79.png',
              unit_en: '79.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 381,
              week_en: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png"],
              week_tc: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png"],
              week_sc: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 378,
              day_sc_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_tc_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_en_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 125,
              hour_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 80,
              minute_startY: 247,
              minute_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 391,
              y: 288,
              w: 70,
              h: 125,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 55,
              w: 76,
              h: 61,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 62,
              w: 122,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 213,
              w: 52,
              h: 52,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 104,
              y: 354,
              w: 52,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'telef.png',
              normal_src: 'telef.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 354,
              w: 52,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'home.png',
              normal_src: 'home.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 374,
              w: 126,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 436,
              w: 126,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 93,
              // y: 126,
              // w: 289,
              // h: 233,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 26,
              // press_src: 'transparent.png',
              // normal_src: 'transparent.png',
              // bg_list: 1|2|3|4|5,
              // toast_list: fondo1|fondo2|fondo3|fondo4|fondo5,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 93,
              y: 126,
              w: 289,
              h: 233,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();
              normal_step_circle_string = normal_step_circle_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -57;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, -218));
                  // alignment = RIGHT
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + -1 * (normal_step_circle_string.length - 1) / 2;
                  char_Angle -= 2 * normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
				autoToggleWeatherIcons();
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}