﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 15;
        let normal_timerTextUpdate = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 15;
        let idle_timerTextUpdate = undefined;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 141,
              center_y: 240,
              x: 15,
              y: 62,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0016.png',
              center_x: 338,
              center_y: 240,
              posX: 15,
              posY: 62,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 393,
              // y: 328,
              // font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '0006.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '0007.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '0008.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '0009.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '0010.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '0011.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '0012.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '0013.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '0014.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '0015.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 393,
                center_y: 328,
                pos_x: 393,
                pos_y: 328,
                angle: 45,
                src: '0006.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 36,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0016.png',
              center_x: 141,
              center_y: 240,
              x: 15,
              y: 62,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0016.png',
              center_x: 338,
              center_y: 240,
              posX: 15,
              posY: 62,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 393,
              // y: 328,
              // font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = '0006.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = '0007.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = '0008.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = '0009.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = '0010.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = '0011.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = '0012.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = '0013.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = '0014.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = '0015.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 393,
                center_y: 328,
                pos_x: 393,
                pos_y: 328,
                angle: 45,
                src: '0006.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 36,
              minute_posY: 208,
              minute_cover_path: '0017.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + -2 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 393 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  idle_day_TextRotate_posOffset = idle_day_TextRotate_posOffset + -2 * (idle_day_rotate_string.length - 1);
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 393 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}