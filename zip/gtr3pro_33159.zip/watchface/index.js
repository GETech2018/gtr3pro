﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_stress_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_pai_icon_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let image_top_img = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''

        let normal_anim_h='';
        let normal_anim_h_group='';
        let anim_f=10;
        let fps_s=30;

        // смена маски
        let bot_circle_btn = ''
        //let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 2
     
        function click_mask() {
            if(mask_num>=mask_all) {mask_num=1;}
            else { mask_num=mask_num+1;}
            hmUI.showToast({text: "<Маска> " + parseInt(mask_num) });
            normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
        }

        // смена безеля
        //let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 12
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Фон> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }         


let hands_smoth_btn = ''
let hands_smoth_state = 0 // 0 - smoth, 1 - normal
let hands_smoth_state_txt = ''


function click_bot_hsmoth_Switcher() {

  let bot_hands_state_total = 2;

  hands_smoth_state = (hands_smoth_state + 1) % bot_hands_state_total;

  switch (hands_smoth_state) {

      case 0:

        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        hands_smoth_state_txt = 'Плавная стрелка';
          break;

      case 1:

        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);

        hands_smoth_state_txt = 'Нормальная стрелка';
          break;

      default:
          break;
  }

  hmUI.showToast({ text: hands_smoth_state_txt });
}

let moon_weath_btn = ''
let moon_weath_state = 0 // 0 - moon, 1 - weather
let moon_weath_state_txt = ''


function click_mw_Switcher() {

  let mw_state_total = 2;

  moon_weath_state = (moon_weath_state + 1) % mw_state_total;

  switch (moon_weath_state) {

      case 0:
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        moon_weath_state_txt = 'Луна';
          break;

      case 1:
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        moon_weath_state_txt = 'Погода';
          break;

      default:
          break;
  }

  hmUI.showToast({ text: moon_weath_state_txt });
}

let ac_switch_btn = ''
let ac_state = 0 // 0 - step, 1 - calories, 2- distance
let ac_state_txt = ''


function click_ac_Switcher() {

  let ac_state_total = 3;

  ac_state = (ac_state + 1) % ac_state_total;

  switch (ac_state) {

      case 0:
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        ac_state_txt = 'Шаги';
          break;

      case 1:
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        ac_state_txt = 'Калории';
      break;

      case 2:
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        ac_state_txt = 'Дистанция';
      break;
    
      default:
          break;
  }

  hmUI.showToast({ text: ac_state_txt });
}

const curTime = hmSensor.createSensor(hmSensor.id.TIME);

//------------------------ автозамена иконок погоды -----------------------------------

let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]

let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
let weatherData = weather.getForecastWeather();
let forecastData = weatherData.forecastData;
let sunData = weatherData.tideData;
let today = '';
let sunriseMins = '';
let sunsetMins = '';
let sunriseMins_def = 8 * 60;			// время восхода
let sunsetMins_def = 20 * 60;			// и заката по умолчанию

let curMins = '';

let isDayIcons = true;
let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь

function autoToggleWeatherIcons() {

weatherData = weather.getForecastWeather();
sunData = weatherData.tideData;
if (sunData.count > 0){
today = sunData.data[0];
sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
} else {
sunriseMins = sunriseMins_def;
sunsetMins = sunsetMins_def;
}

curMins = curTime.hour * 60 + curTime.minute;
let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

if(isDayNow){
if(!isDayIcons){
  for (let i = 0; i < wiReplacement.length; i++) {
    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
  }
  isDayIcons = true;
}
} else {
if(isDayIcons){
  for (let i = 0; i < wiReplacement.length; i++) {
    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
  }
  isDayIcons = false;
}
}
}

//------------------------ автозамена иконок погоды ----------------------------------- \\		


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 350,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 65,
              y: 347,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 137,
              center_y: 240,
              x: 89,
              y: 89,
              start_angle: -150,
              end_angle: -26,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 304,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 327,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);


            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 364,
              src: 'distance_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 374,
              src: 'cal_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
 
            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 317,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
 
            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 240,
              center_y: 354,
              x: 89,
              y: 89,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 366,
              src: 'step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 317,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 2,
              src: 'tenfont.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 240,
              center_y: 354,
              x: 89,
              y: 89,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fondate.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 359,
              day_startY: 227,
              day_sc_array: ["numd_1.png","numd_2.png","numd_3.png","numd_4.png","numd_5.png","numd_6.png","numd_7.png","numd_8.png","numd_9.png","numd_10.png"],
              day_tc_array: ["numd_1.png","numd_2.png","numd_3.png","numd_4.png","numd_5.png","numd_6.png","numd_7.png","numd_8.png","numd_9.png","numd_10.png"],
              day_en_array: ["numd_1.png","numd_2.png","numd_3.png","numd_4.png","numd_5.png","numd_6.png","numd_7.png","numd_8.png","numd_9.png","numd_10.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'date_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 166,
              src: 'weather_fm_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 367,
              y: 169,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'num_15.png',
              unit_tc: 'num_15.png',
              unit_en: 'num_15.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            autoToggleWeatherIcons();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 339,
              y: 151,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 145,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
		      	  animation_call()
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 38,
              // y: 161,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 38,
              pos_y: 240 - 161,
              center_x: 240,
              center_y: 240,
              src: 'hour_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'minute_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 29,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 29,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'minute_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 238,
              center_x: 240,
              center_y: 240,
              src: 'sec_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 26,
              second_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_aod_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 38,
              hour_posY: 161,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_aod_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 29,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            bot_circle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  click_bot_hsmoth_Switcher();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            bot_circle_btn.setProperty(hmUI.prop.VISIBLE, true);
            
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 0,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  click_Bezel();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 190,
              text: '',
              w: 70,
              h: 100,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                  click_mask();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_mask.setProperty(hmUI.prop.VISIBLE, true);

            moon_weath_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 128,
              text: '',
              w: 100,
              h: 76,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                click_mw_Switcher();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            moon_weath_btn.setProperty(hmUI.prop.VISIBLE, true); 

            normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            ac_switch_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 362,
              text: '',
              w: 100,
              h: 76,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
                click_ac_Switcher();
                  vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            ac_switch_btn.setProperty(hmUI.prop.VISIBLE, true); 


	     		// низкий заряд
			    hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 190,
              w: 70,
              h: 100,
			        text: '',
			        normal_src: 'null.png',
			        press_src: 'null.png',
			        click_func: () => {
				      hmApp.startApp({ url: 'LowBatteryScreen', native: true });
			        },
			        show_level: hmUI.show_level.ONLY_NORMAL,
			    });				
	      	// календарь
		    	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 206,
              w: 100,
              h: 82,
			        text: '',
			        normal_src: 'null.png',
			        press_src: 'null.png',
			        click_func: () => {
				      hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			    },
			    show_level: hmUI.show_level.ONLY_NORMAL,
			   });	

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 300,
              w: 100,
              h: 58,
              src: 'null.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 300,
              w: 100,
              h: 58,
              src: 'null.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 300,
              w: 100,
              h: 82,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 300,
              w: 100,
              h: 58,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function animation_call(){
              if(typeof normal_anim_h !== 'string'){
                hmUI.deleteWidget(normal_anim_h);
              }	
                    
              if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
      
                  normal_anim_h = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    anim_path: 'animation',
                    anim_prefix: 'heart',
                    anim_ext: 'png',
                    anim_fps: Math.ceil(heart_rate.last/10),//6,//30,
                    repeat_count: 0,
                    anim_size: 6,
                    anim_status: hmUI.anim_status.START,
                    anim_repeat: true,
                    x: 326,//0,
                    y: 336,//0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });	
			
              }
            }

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                autoToggleWeatherIcons();
                animation_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}