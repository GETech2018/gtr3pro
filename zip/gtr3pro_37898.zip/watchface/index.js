﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let bg_list = [
            '0001.png',
            '0002.png',
            '0003.png',
            '0004.png',
			'0005.png',
			'0006.png',
        ];
        let bg_index = 0;

        function bg_switching() {
            bg_index++;
            if (bg_index >= bg_list.length) bg_index = 0;
            normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let editableZone_1_step_circle_scale = null;
        let editableZone_1_calorie_circle_scale = null;
        let editableZone_1_heart_rate_circle_scale = null;
        let editableZone_1_pai_circle_scale = null;
        let editGroup_1  = ''
        let editableZone_2_step_circle_scale = null;
        let editableZone_2_calorie_circle_scale = null;
        let editableZone_2_heart_rate_circle_scale = null;
        let editableZone_2_pai_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_step_circle_scale = null;
        let editableZone_3_calorie_circle_scale = null;
        let editableZone_3_heart_rate_circle_scale = null;
        let editableZone_3_pai_circle_scale = null;
        let editGroup_3  = ''
        let editableZone_4_step_circle_scale = null;
        let editableZone_4_calorie_circle_scale = null;
        let editableZone_4_heart_rate_circle_scale = null;
        let editableZone_4_pai_circle_scale = null;
        let editGroup_4  = ''
        let mask = ''
        let fg_mask = ''
        let normal_battery_circle_scale = ''
        let normal_image_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_uvi_icon_img = ''
        let idle_sun_icon_img = ''
        let idle_wind_icon_img = ''
        let idle_image_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_month = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });
            console.log('Watch_Face.Editable_Elements before AOD');

            let screenType = hmSetting.getScreenType();            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 68,
              y: 172,
              w: 136,
              h: 136,
              select_image: '0021.png',
              un_select_image: '0016.png',
              default_type: hmUI.edit_type.UVI,
              optional_types: [
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.DATE, preview: 'ez(1)_DATE.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_STEP.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0022.png',
              tips_x: -5,
              tips_y: 144,
              tips_width: 98,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 88,
                  day_startY: 220,
                  day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_zero: 1,
                  day_space: 1,
                  day_unit_sc: '0023.png',
                  day_unit_tc: '0023.png',
                  day_unit_en: '0023.png',
                  day_align: hmUI.align.RIGHT,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 172,
                  src: 'cov_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  month_startX: 142,
                  month_startY: 220,
                  month_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_zero: 1,
                  month_space: 1,
                  month_align: hmUI.align.LEFT,
                  month_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 136,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 136,
                  center_y: 240,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 84,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 69,
                  y: 172,
                  src: 'ic_2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_1_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 136,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 136,
                  center_y: 240,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 94,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 69,
                  y: 172,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_1_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 136,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 136,
                  center_y: 240,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                heart_rate.addEventListener(hmSensor.event.LAST, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 105,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 69,
                  y: 172,
                  src: 'ic_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_1_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 136,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 136,
                    center_y: 240,
                    start_angle: 360,
                    end_angle: 0,
                    radius: 61,
                    line_width: 12,
                    corner_flag: 0,
                    color: 0xFF000000,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                pai.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 106,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 69,
                  y: 172,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 88,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  dot_image: '0023.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 172,
                  src: 'ic_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 170,
                  src: 'cov_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 172,
              y: 68,
              w: 136,
              h: 136,
              select_image: '0021.png',
              un_select_image: '0020.png',
              default_type: hmUI.edit_type.UVI,
              optional_types: [
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.DATE, preview: 'ez(1)_DATE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0022.png',
              tips_x: 18,
              tips_y: -41,
              tips_width: 98,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 192,
                  day_startY: 118,
                  day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_zero: 1,
                  day_space: 1,
                  day_unit_sc: '0023.png',
                  day_unit_tc: '0023.png',
                  day_unit_en: '0023.png',
                  day_align: hmUI.align.RIGHT,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 67,
                  src: 'cov_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  month_startX: 247,
                  month_startY: 116,
                  month_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_zero: 1,
                  month_space: 1,
                  month_align: hmUI.align.LEFT,
                  month_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                // editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 136,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 240,
                  center_y: 136,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 188,
                  y: 118,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 68,
                  src: 'ic_2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_2_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 136,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 240,
                  center_y: 136,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 199,
                  y: 118,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 68,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_2_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 136,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 240,
                  center_y: 136,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 209,
                  y: 118,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 68,
                  src: 'ic_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_2_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 136,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 136,
                    start_angle: 360,
                    end_angle: 0,
                    radius: 61,
                    line_width: 12,
                    corner_flag: 0,
                    color: 0xFF000000,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 211,
                  y: 118,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 68,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 193,
                  y: 118,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  dot_image: '0023.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 67,
                  src: 'ic_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 171,
                  y: 67,
                  src: 'cov_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 275,
              y: 172,
              w: 136,
              h: 136,
              select_image: '0021.png',
              un_select_image: '0020.png',
              default_type: hmUI.edit_type.UVI,
              optional_types: [
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.DATE, preview: 'ez(1)_DATE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0022.png',
              tips_x: 47,
              tips_y: 144,
              tips_width: 98,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 298,
                  day_startY: 220,
                  day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_zero: 1,
                  day_space: 1,
                  day_unit_sc: '0023.png',
                  day_unit_tc: '0023.png',
                  day_unit_en: '0023.png',
                  day_align: hmUI.align.RIGHT,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'cov_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  month_startX: 354,
                  month_startY: 220,
                  month_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_zero: 1,
                  month_space: 0,
                  month_align: hmUI.align.LEFT,
                  month_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'cov_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 342,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 342,
                  center_y: 240,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 291,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'ic_2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_3_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 342,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 342,
                  center_y: 240,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 300,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_3_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 342,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 342,
                  center_y: 240,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 314,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'ic_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_3_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 342,
                  // center_y: 240,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 342,
                    center_y: 240,
                    start_angle: 360,
                    end_angle: 0,
                    radius: 61,
                    line_width: 12,
                    corner_flag: 0,
                    color: 0xFF000000,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 313,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 296,
                  y: 220,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  dot_image: '0023.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'ic_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 275,
                  y: 171,
                  src: 'cov_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 172,
              y: 275,
              w: 136,
              h: 136,
              select_image: '0021.png',
              un_select_image: '0020.png',
              default_type: hmUI.edit_type.UVI,
              optional_types: [
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.DATE, preview: 'ez(1)_DATE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0022.png',
              tips_x: 18,
              tips_y: 137,
              tips_width: 98,
              tips_margin: 0,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 194,
                  day_startY: 324,
                  day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  day_zero: 0,
                  day_space: 0,
                  day_unit_sc: '0023.png',
                  day_unit_tc: '0023.png',
                  day_unit_en: '0023.png',
                  day_align: hmUI.align.RIGHT,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 171,
                  y: 275,
                  src: 'cov_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  month_startX: 248,
                  month_startY: 324,
                  month_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  month_zero: 1,
                  month_space: 0,
                  month_align: hmUI.align.LEFT,
                  month_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                // editableZone_4_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 342,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_4_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 240,
                  center_y: 342,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 188,
                  y: 324,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 274,
                  src: 'ic_2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_4_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 342,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_4_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 240,
                  center_y: 342,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 199,
                  y: 324,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 274,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_4_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 342,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_4_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 240,
                  center_y: 342,
                  start_angle: 360,
                  end_angle: 0,
                  radius: 61,
                  line_width: 12,
                  corner_flag: 0,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 324,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 274,
                  src: 'ic_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_4_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 240,
                  // center_y: 342,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 67,
                  // line_width: 12,
                  // line_cap: Rounded,
                  // color: 0xFF000000,
                  // mirror: False,
                  // inversion: True,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_4_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 240,
                    center_y: 342,
                    start_angle: 360,
                    end_angle: 0,
                    radius: 61,
                    line_width: 12,
                    corner_flag: 0,
                    color: 0xFF000000,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 324,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 274,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 195,
                  y: 324,
                  font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: '0023.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 172,
                  y: 274,
                  src: 'ic_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 171,
                  y: 274,
                  src: 'cov_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'cov_2.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'cov_2.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 240,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 0,
              radius: 236,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cov_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 273,
              src: '0026.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 223,
              src: '0025.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 176,
              src: '0027.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0017.png',
              // center_x: 240,
              // center_y: 240,
              // x: 22,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 22,
              pos_y: 240 - 172,
              center_x: 240,
              center_y: 240,
              src: '0017.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0018.png',
              // center_x: 240,
              // center_y: 240,
              // x: 22,
              // y: 218,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 22,
              pos_y: 240 - 218,
              center_x: 240,
              center_y: 240,
              src: '0018.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0019.png',
              // center_x: 240,
              // center_y: 240,
              // x: 2,
              // y: 229,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 2,
              pos_y: 240 - 229,
              center_x: 240,
              center_y: 240,
              src: '0019.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 240,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 0,
              radius: 236,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 171,
              src: 'cov_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 68,
              src: 'cov_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 275,
              src: 'cov_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cov_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 293,
              day_startY: 220,
              day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: '0023.png',
              day_unit_tc: '0023.png',
              day_unit_en: '0023.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 172,
              src: 'cov_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 348,
              month_startY: 220,
              month_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              month_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              month_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0017.png',
              // center_x: 240,
              // center_y: 240,
              // x: 22,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 22,
              pos_y: 240 - 172,
              center_x: 240,
              center_y: 240,
              src: '0017.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0018.png',
              // center_x: 240,
              // center_y: 240,
              // x: 22,
              // y: 218,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 22,
              pos_y: 240 - 218,
              center_x: 240,
              center_y: 240,
              src: '0018.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0019.png',
              // center_x: 240,
              // center_y: 240,
              // x: 2,
              // y: 229,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 2,
              pos_y: 240 - 229,
              center_x: 240,
              center_y: 240,
              src: '0019.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 0,
              press_src: '0024.png',
              normal_src: '0024.png',
              click_func: (button_widget) => {
                bg_switching();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = 1 - progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_step * 100);
                  if (editableZone_1_step_circle_scale) {
                    editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_1_calorie = 1 - progressCalories;

                if (editableZone_1_calorie_circle_scale) {

                  // editableZone_1_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_calorie * 100);
                  if (editableZone_1_calorie_circle_scale) {
                    editableZone_1_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_editableZone_1_heart_rate = 1 - progressHeartRate;

                if (editableZone_1_heart_rate_circle_scale) {

                  // editableZone_1_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_heart_rate * 100);
                  if (editableZone_1_heart_rate_circle_scale) {
                    editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_editableZone_1_pai = 1 - progressPAI;

                if (editableZone_1_pai_circle_scale) {

                  // editableZone_1_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_pai * 100);
                  if (editableZone_1_pai_circle_scale) {
                    editableZone_1_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 136,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_2_step = 1 - progressStep;

                if (editableZone_2_step_circle_scale) {

                  // editableZone_2_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_step * 100);
                  if (editableZone_2_step_circle_scale) {
                    editableZone_2_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 136,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_2_calorie = 1 - progressCalories;

                if (editableZone_2_calorie_circle_scale) {

                  // editableZone_2_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_calorie * 100);
                  if (editableZone_2_calorie_circle_scale) {
                    editableZone_2_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 136,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_2_heart_rate = 1 - progressHeartRate;

                if (editableZone_2_heart_rate_circle_scale) {

                  // editableZone_2_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_heart_rate * 100);
                  if (editableZone_2_heart_rate_circle_scale) {
                    editableZone_2_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 136,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_2_pai = 1 - progressPAI;

                if (editableZone_2_pai_circle_scale) {

                  // editableZone_2_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_pai * 100);
                  if (editableZone_2_pai_circle_scale) {
                    editableZone_2_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 136,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_3_step = 1 - progressStep;

                if (editableZone_3_step_circle_scale) {

                  // editableZone_3_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_step * 100);
                  if (editableZone_3_step_circle_scale) {
                    editableZone_3_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 342,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_3_calorie = 1 - progressCalories;

                if (editableZone_3_calorie_circle_scale) {

                  // editableZone_3_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_calorie * 100);
                  if (editableZone_3_calorie_circle_scale) {
                    editableZone_3_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 342,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_3_heart_rate = 1 - progressHeartRate;

                if (editableZone_3_heart_rate_circle_scale) {

                  // editableZone_3_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_heart_rate * 100);
                  if (editableZone_3_heart_rate_circle_scale) {
                    editableZone_3_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 342,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_3_pai = 1 - progressPAI;

                if (editableZone_3_pai_circle_scale) {

                  // editableZone_3_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_pai * 100);
                  if (editableZone_3_pai_circle_scale) {
                    editableZone_3_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 342,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_4_step = 1 - progressStep;

                if (editableZone_4_step_circle_scale) {

                  // editableZone_4_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_4_step * 100);
                  if (editableZone_4_step_circle_scale) {
                    editableZone_4_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 342,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_4_calorie = 1 - progressCalories;

                if (editableZone_4_calorie_circle_scale) {

                  // editableZone_4_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_4_calorie * 100);
                  if (editableZone_4_calorie_circle_scale) {
                    editableZone_4_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 342,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_4_heart_rate = 1 - progressHeartRate;

                if (editableZone_4_heart_rate_circle_scale) {

                  // editableZone_4_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_4_heart_rate * 100);
                  if (editableZone_4_heart_rate_circle_scale) {
                    editableZone_4_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 342,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_4_pai = 1 - progressPAI;

                if (editableZone_4_pai_circle_scale) {

                  // editableZone_4_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_4_pai * 100);
                  if (editableZone_4_pai_circle_scale) {
                    editableZone_4_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 342,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 61,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 236,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 236,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}