﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let calendar_btn = ''
		let battery_btn = ''
		let sports_btn = ''
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 9
		let handsnumber = 0
        let totalhands = 8
		
		function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
                 if(colornumber==2) hmUI.showToast({text: 'O R A N G E'});
				 if(colornumber==3) hmUI.showToast({text: 'G R E E N'});
                 if(colornumber==4) hmUI.showToast({text: 'R E D'});
				 if(colornumber==5) hmUI.showToast({text: 'Y E L L O W'});
                 if(colornumber==6) hmUI.showToast({text: 'B L U E'});
				 if(colornumber==7) hmUI.showToast({text: 'F U C H S I A'});
				 if(colornumber==8) hmUI.showToast({text: 'P U R P L E'});
				 if(colornumber==9) hmUI.showToast({text: 'C O L O R L E S S'});
            }
            if(colornumber==1) hmUI.showToast({text: 'C Y A N'});
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber) + ".png");
			call_change_Hands();
        }

        function call_change_Hands() {
              if(colornumber==1) {
                ChangeHands(0);
              } else if(colornumber==2) {
                ChangeHands(1);
              } else if(colornumber==3) {
                ChangeHands(2);
              } else if(colornumber==4) {
                ChangeHands(3);
			  } else if(colornumber==5) {
                ChangeHands(4);
			  } else if(colornumber==6) {
                ChangeHands(5);
              } else if(colornumber==7) {
                ChangeHands(6);
			  } else if(colornumber==8) {
                ChangeHands(7);
			  } else if(colornumber==9) {
                ChangeHands(8);
              }
        }
		
		function ChangeHands(number) {
           if(number==0) {
				  secondstring='time_sec1.png';
             } else if(number==1) {
				  secondstring='time_sec2.png';
             } else if(number==2) {
				  secondstring='time_sec3.png';
             } else if(number==3) {
				  secondstring='time_sec4.png';
             } else if(number==4) {
				  secondstring='time_sec5.png';
			 } else if(number==5) {
				  secondstring='time_sec6.png';
             } else if(number==6) {
				  secondstring='time_sec7.png';
			 } else if(number==7) {
				  secondstring='time_sec8.png';
             } else if(number==8) {
				  secondstring='time_sec9.png';
             }
				  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
				  second_path: secondstring,
				  second_centerX: 240,
                  second_centerY: 240,
                  second_posX: 240,
                  second_posY: 240,
				  second_cover_path: 'time_top.png',
                  second_cover_x: 0,
                  second_cover_y: 0,
				  show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 91,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 358,
              y: 374,
              src: 'status_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 290,
              y: 287,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 329,
              month_startY: 316,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 405,
              day_startY: 316,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 140,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 360,
              y: 144,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 373,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 298,
              image_array: ["pro_01.png","pro_02.png","pro_03.png","pro_04.png","pro_05.png","pro_06.png","pro_07.png","pro_08.png","pro_09.png","pro_10.png","pro_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 60,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 9,
              image_array: ["pro_01.png","pro_02.png","pro_03.png","pro_04.png","pro_05.png","pro_06.png","pro_07.png","pro_08.png","pro_09.png","pro_10.png","pro_11.png"],
              image_length: 11,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 115,
              // center_y: 240,
              // start_angle: -193,
              // end_angle: 113,
              // radius: 100,
              // line_width: 16,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 115,
              center_y: 240,
              start_angle: 113,
              end_angle: -193,
              radius: 92,
              line_width: 16,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'step_pointer.png',
              center_x: 115,
              center_y: 240,
              x: 16,
              y: 106,
              start_angle: -191,
              end_angle: 115,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 128,
              src: 'step_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 248,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 203,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'num_km.png',
              unit_tc: 'num_km.png',
              unit_en: 'num_km.png',
              imperial_unit_sc: 'num_mil.png',
              imperial_unit_tc: 'num_mil.png',
              imperial_unit_en: 'num_mil.png',
              dot_image: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 377,
              am_y: 222,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 377,
              pm_y: 222,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 262,
              hour_startY: 183,
              hour_array: ["hour_00.png","hour_01.png","hour_02.png","hour_03.png","hour_04.png","hour_05.png","hour_06.png","hour_07.png","hour_08.png","hour_09.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 390,
              minute_startY: 187,
              minute_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'time_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'time_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'time_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_cover_path: 'time_top.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 230,
              y: 418,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 373,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'time_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'time_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_path: 'time_top.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 390,
              y: 190,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 190,
              w: 100,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 360,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 169,
              w: 120,
              h: 70,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 60,
              w: 80,
              h: 80,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 125,
              w: 70,
              h: 55,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 125,
              w: 80,
              h: 55,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 245,
              w: 120,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 360,
              text: '',
              w: 70,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
            sports_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 80,
              text: '',
              w: 60,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'SportListScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 310,
			  text: '',
              w: 120,
              h: 45,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 345,
			  text: '',
              w: 80,
              h: 80,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 115,
                      center_y: 240,
                      start_angle: 113,
                      end_angle: -191,
                      radius: 92,
                      line_width: 16,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}