﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		let br_state = 2;
		let br_state_total = 5;
		
		function click_Contentr() {
              br_state = (br_state + 1) % br_state_total;
			apply_br_switch();
		}
		
		function click_Contentl() {
              if (br_state == 0) {
			br_state = br_state_total - 1;
				} else {
			br_state = (br_state - 1) % br_state_total;
				}	
			apply_br_switch();
		}

		function apply_br_switch() {
			switch (br_state) {

			case 0:
				normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
				Button_13.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
				Button_15.setProperty(hmUI.prop.VISIBLE, false);
				Button_16.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_17.setProperty(hmUI.prop.VISIBLE, true);
				Button_18.setProperty(hmUI.prop.VISIBLE, true);
				Button_19.setProperty(hmUI.prop.VISIBLE, true);
			break;

			case 1:
				normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
				Button_13.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_calorie_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_14.setProperty(hmUI.prop.VISIBLE, true);
				Button_15.setProperty(hmUI.prop.VISIBLE, true);
				Button_16.setProperty(hmUI.prop.VISIBLE, true);
				
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_17.setProperty(hmUI.prop.VISIBLE, false);
				Button_18.setProperty(hmUI.prop.VISIBLE, false);
				Button_19.setProperty(hmUI.prop.VISIBLE, false);
			break;

			case 2:
				normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_12.setProperty(hmUI.prop.VISIBLE, true);
				Button_13.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
				Button_15.setProperty(hmUI.prop.VISIBLE, false);
				Button_16.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_17.setProperty(hmUI.prop.VISIBLE, false);
				Button_18.setProperty(hmUI.prop.VISIBLE, false);
				Button_19.setProperty(hmUI.prop.VISIBLE, false);
			break;

			case 3:
				normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
				Button_10.setProperty(hmUI.prop.VISIBLE, true);
				Button_11.setProperty(hmUI.prop.VISIBLE, true);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				
				normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
				Button_13.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
				Button_15.setProperty(hmUI.prop.VISIBLE, false);
				Button_16.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_17.setProperty(hmUI.prop.VISIBLE, false);
				Button_18.setProperty(hmUI.prop.VISIBLE, false);
				Button_19.setProperty(hmUI.prop.VISIBLE, false);
			break;
			
			case 4:
				normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				
				normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
				Button_13.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
				Button_15.setProperty(hmUI.prop.VISIBLE, false);
				Button_16.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_17.setProperty(hmUI.prop.VISIBLE, false);
				Button_18.setProperty(hmUI.prop.VISIBLE, false);
				Button_19.setProperty(hmUI.prop.VISIBLE, false);
			break;

			default:
			break;
			}
		}
		
		let bc_state = 0;
		let bc_state_total = 2;
		
		function click_MainBC() {
              bc_state = (bc_state + 1) % bc_state_total;
			apply_bc_switch();
		}
		
		function apply_bc_switch() {
			switch (bc_state) {

			case 0:
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_1.setProperty(hmUI.prop.VISIBLE, false);
				Button_2.setProperty(hmUI.prop.VISIBLE, false);
				Button_3.setProperty(hmUI.prop.VISIBLE, false);
				Button_4.setProperty(hmUI.prop.VISIBLE, false);
				Button_5.setProperty(hmUI.prop.VISIBLE, false);
				Button_6.setProperty(hmUI.prop.VISIBLE, false);
				Button_7.setProperty(hmUI.prop.VISIBLE, false);
				
				Button_22.setProperty(hmUI.prop.VISIBLE, true);
				Button_23.setProperty(hmUI.prop.VISIBLE, true);
				
				Button_24.setProperty(hmUI.prop.VISIBLE, true);
				Button_25.setProperty(hmUI.prop.VISIBLE, true);
			break;

			case 1:
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_1.setProperty(hmUI.prop.VISIBLE, true);
				Button_2.setProperty(hmUI.prop.VISIBLE, true);
				Button_3.setProperty(hmUI.prop.VISIBLE, true);
				Button_4.setProperty(hmUI.prop.VISIBLE, true);
				Button_5.setProperty(hmUI.prop.VISIBLE, true);
				Button_6.setProperty(hmUI.prop.VISIBLE, true);
				Button_7.setProperty(hmUI.prop.VISIBLE, true);
				
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
				Button_13.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
				Button_15.setProperty(hmUI.prop.VISIBLE, false);
				Button_16.setProperty(hmUI.prop.VISIBLE, false);
				Button_17.setProperty(hmUI.prop.VISIBLE, false);
				Button_18.setProperty(hmUI.prop.VISIBLE, false);
				Button_19.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				Button_22.setProperty(hmUI.prop.VISIBLE, false);
				Button_23.setProperty(hmUI.prop.VISIBLE, false);
				
				Button_24.setProperty(hmUI.prop.VISIBLE, false);
				Button_25.setProperty(hmUI.prop.VISIBLE, false);
			break;

			default:
			break;
			}
		}
		
		let colornumber_01 = 1
        let totalcolors_01 = 1
		
		function click_Opt01() {
            
            normal_image_img.setProperty(hmUI.prop.SRC, "color1.png");
			normal_stress_icon_img.setProperty(hmUI.prop.SRC, "menu1.png");
			normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_moon_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_spo2_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_pai_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_distance_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt1.png");
        }
		
		let colornumber_02 = 1
        let totalcolors_02 = 1
		
		function click_Opt02() {
            if(colornumber_02>=totalcolors_02) {
            colornumber_02=1;
                }
            else {
                colornumber_02=colornumber_02+1;
            }
            normal_image_img.setProperty(hmUI.prop.SRC, "color3.png");
			normal_stress_icon_img.setProperty(hmUI.prop.SRC, "menu2.png");
			normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_moon_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_spo2_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_pai_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_distance_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt2.png");
        }
		
		let colornumber_03 = 1
        let totalcolors_03 = 1
		
		function click_Opt03() {
            if(colornumber_03>=totalcolors_03) {
            colornumber_03=1;
                }
            else {
                colornumber_03=colornumber_03+1;
            }
            normal_image_img.setProperty(hmUI.prop.SRC, "color2.png");
			normal_stress_icon_img.setProperty(hmUI.prop.SRC, "menu1.png");
			normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_moon_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_spo2_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_pai_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_distance_icon_img.setProperty(hmUI.prop.SRC, "fore1.png");
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt2.png");
        }
		
		let colornumber_04 = 1
        let totalcolors_04 = 1
		
		function click_Opt04() {
            if(colornumber_04>=totalcolors_04) {
            colornumber_04=1;
                }
            else {
                colornumber_04=colornumber_04+1;
            }
            normal_image_img.setProperty(hmUI.prop.SRC, "color1.png");
			normal_stress_icon_img.setProperty(hmUI.prop.SRC, "menu2.png");
			normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_moon_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_spo2_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_pai_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_distance_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt1.png");
        }
		
		let colornumber_05 = 1
        let totalcolors_05 = 1
		
		function click_Opt05() {
            if(colornumber_05>=totalcolors_05) {
            colornumber_05=1;
                }
            else {
                colornumber_05=colornumber_05+1;
            }
            normal_image_img.setProperty(hmUI.prop.SRC, "color3.png");
			normal_stress_icon_img.setProperty(hmUI.prop.SRC, "menu2.png");
			normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_moon_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_spo2_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_pai_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_distance_icon_img.setProperty(hmUI.prop.SRC, "fore2.png");
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt1.png");
        }
		
		let colornumber_06 = 1
        let totalcolors_06 = 1
		
		function click_Opt06() {
            if(colornumber_06>=totalcolors_06) {
            colornumber_06=1;
                }
            else {
                colornumber_06=colornumber_06+1;
            }
            normal_image_img.setProperty(hmUI.prop.SRC, "color2.png");
			normal_stress_icon_img.setProperty(hmUI.prop.SRC, "menu1.png");
			normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_moon_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_spo2_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_pai_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_distance_icon_img.setProperty(hmUI.prop.SRC, "fore3.png");
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt2.png");
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_stress_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_target_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_icon_img = ''
        let normal_step_target_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_stand_icon_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let Button_19 = ''
        let Button_20 = ''
        let Button_21 = ''
        let Button_22 = ''
        let Button_23 = ''
        let Button_24 = ''
        let Button_25 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 350,
              y: 352,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 356,
              src: 'st_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic5_weath.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 171,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_10.png',
              unit_tc: 'small_10.png',
              unit_en: 'small_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 137,
              image_array: ["hum_01.png","hum_02.png","hum_03.png","hum_04.png","hum_05.png","hum_06.png","hum_07.png","hum_08.png","hum_09.png","hum_10.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 193,
              src: 'fore1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 125,
              y: 289,
              w: 231,
              h: 25,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF6D0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 162,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 139,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 90,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'big_11.png',
              unit_tc: 'big_11.png',
              unit_en: 'big_11.png',
              negative_image: 'big_10.png',
              invalid_image: 'big_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 82,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun.png',
              center_x: 240,
              center_y: 240,
              x: 32,
              y: 180,
              start_angle: -50,
              end_angle: 50,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic4_sunm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 150,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'big_12.png',
              dot_image: 'big_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 150,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'big_12.png',
              dot_image: 'big_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic4_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 193,
              src: 'fore1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 60,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 114,
              // start_y: 140,
              // color: 0xFF3C3C3C,
              // lenght: 145,
              // line_width: 27,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic3_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 143,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 193,
              src: 'fore1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 90,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'big_14.png',
              unit_tc: 'big_14.png',
              unit_en: 'big_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 114,
              // start_y: 140,
              // color: 0xFF3C3C3C,
              // lenght: 145,
              // line_width: 27,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic2_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 171,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 143,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 193,
              src: 'fore1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 90,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 90,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 114,
              // start_y: 140,
              // color: 0xFF3C3C3C,
              // lenght: 145,
              // line_width: 27,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic1_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 171,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 143,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 106,
              y: 193,
              src: 'fore1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 90,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'big_km.png',
              unit_tc: 'big_km.png',
              unit_en: 'big_km.png',
              imperial_unit_sc: 'big_mil.png',
              imperial_unit_tc: 'big_mil.png',
              imperial_unit_en: 'big_mil.png',
              dot_image: 'big_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'batt1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -55,
              end_angle: 55,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 156,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 425,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 425,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 102,
              am_y: 321,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 102,
              pm_y: 321,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 149,
              hour_startY: 322,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 322,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 336,
              second_startY: 322,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 322,
              src: 'time_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'aod_st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_ic.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 143,
              font_array: ["aod_big_00.png","aod_big_01.png","aod_big_02.png","aod_big_03.png","aod_big_04.png","aod_big_05.png","aod_big_06.png","aod_big_07.png","aod_big_08.png","aod_big_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'aod_big_14.png',
              unit_tc: 'aod_big_14.png',
              unit_en: 'aod_big_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 137,
              image_array: ["aod_bat_01.png","aod_bat_02.png","aod_bat_03.png","aod_bat_04.png","aod_bat_05.png","aod_bat_06.png","aod_bat_07.png","aod_bat_08.png","aod_bat_09.png","aod_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 149,
              hour_startY: 322,
              hour_array: ["aod_time_00.png","aod_time_01.png","aod_time_02.png","aod_time_03.png","aod_time_04.png","aod_time_05.png","aod_time_06.png","aod_time_07.png","aod_time_08.png","aod_time_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 322,
              minute_array: ["aod_time_00.png","aod_time_01.png","aod_time_02.png","aod_time_03.png","aod_time_04.png","aod_time_05.png","aod_time_06.png","aod_time_07.png","aod_time_08.png","aod_time_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 322,
              src: 'aod_time_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 80,
              w: 120,
              h: 50,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 135,
              w: 120,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 80,
              w: 120,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 135,
              w: 120,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 144,
              y: 98,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bcp.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Opt06();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 83,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bcp.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Opt05();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 144,
              y: 311,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bcp.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Opt04();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 311,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bcp.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Opt03();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 326,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bcp.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Opt02();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 98,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bcp.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Opt01();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 205,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_MainBC();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 370,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_MainBC();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 370,
              y: 370,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 80,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'RespirationwidgetScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 80,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 80,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_19 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 135,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_20 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 110,
              w: 55,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_21 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 415,
              w: 170,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_22 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 320,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_23 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 320,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_24 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 431,
              y: 188,
              w: 40,
              h: 104,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'br2.png',
              normal_src: 'br1.png',
              click_func: (button_widget) => {
                click_Contentr();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_25 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 188,
              w: 40,
              h: 104,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'bl2.png',
              normal_src: 'bl1.png',
              click_func: (button_widget) => {
                click_Contentl();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
		let cc = 0
			if (cc ==0 ){
				normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
				Button_15.setProperty(hmUI.prop.VISIBLE, false);
				Button_16.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_17.setProperty(hmUI.prop.VISIBLE, false);
				Button_18.setProperty(hmUI.prop.VISIBLE, false);
				Button_19.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_1.setProperty(hmUI.prop.VISIBLE, false);
				Button_2.setProperty(hmUI.prop.VISIBLE, false);
				Button_3.setProperty(hmUI.prop.VISIBLE, false);
				Button_4.setProperty(hmUI.prop.VISIBLE, false);
				Button_5.setProperty(hmUI.prop.VISIBLE, false);
				Button_6.setProperty(hmUI.prop.VISIBLE, false);
				Button_7.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
		}
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 259;
                  let start_y_normal_heart_rate = 140;
                  let lenght_ls_normal_heart_rate = -145;
                  let line_width_ls_normal_heart_rate = 27;
                  let color_ls_normal_heart_rate = 0xFF3C3C3C;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 259;
                  let start_y_normal_calorie = 140;
                  let lenght_ls_normal_calorie = -145;
                  let line_width_ls_normal_calorie = 27;
                  let color_ls_normal_calorie = 0xFF3C3C3C;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 259;
                  let start_y_normal_step = 140;
                  let lenght_ls_normal_step = -145;
                  let line_width_ls_normal_step = 27;
                  let color_ls_normal_step = 0xFF3C3C3C;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}