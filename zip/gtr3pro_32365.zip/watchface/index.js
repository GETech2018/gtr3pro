﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -57,
              y: -55,
              src: 'rain_backg (3).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: -6,
              month_startY: 217,
              month_sc_array: ["Picture159.png","Picture160.png","Picture161.png","Picture162.png","Picture163.png","Picture164.png","Picture165.png","Picture166.png","Picture167.png","Picture168.png","Picture169.png","Picture170.png"],
              month_tc_array: ["Picture159.png","Picture160.png","Picture161.png","Picture162.png","Picture163.png","Picture164.png","Picture165.png","Picture166.png","Picture167.png","Picture168.png","Picture169.png","Picture170.png"],
              month_en_array: ["Picture159.png","Picture160.png","Picture161.png","Picture162.png","Picture163.png","Picture164.png","Picture165.png","Picture166.png","Picture167.png","Picture168.png","Picture169.png","Picture170.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 1,
              day_startY: 193,
              day_sc_array: ["pidigi_grey_sec0001.png","pidigi_grey_sec0002.png","pidigi_grey_sec0003.png","pidigi_grey_sec0004.png","pidigi_grey_sec0005.png","pidigi_grey_sec0006.png","pidigi_grey_sec0007.png","pidigi_grey_sec0008.png","pidigi_grey_sec0009.png","pidigi_grey_sec0010.png"],
              day_tc_array: ["pidigi_grey_sec0001.png","pidigi_grey_sec0002.png","pidigi_grey_sec0003.png","pidigi_grey_sec0004.png","pidigi_grey_sec0005.png","pidigi_grey_sec0006.png","pidigi_grey_sec0007.png","pidigi_grey_sec0008.png","pidigi_grey_sec0009.png","pidigi_grey_sec0010.png"],
              day_en_array: ["pidigi_grey_sec0001.png","pidigi_grey_sec0002.png","pidigi_grey_sec0003.png","pidigi_grey_sec0004.png","pidigi_grey_sec0005.png","pidigi_grey_sec0006.png","pidigi_grey_sec0007.png","pidigi_grey_sec0008.png","pidigi_grey_sec0009.png","pidigi_grey_sec0010.png"],
              day_zero: 1,
              day_space: -45,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 440,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 346,
              font_array: ["digi_smafruline_black_0001.png","digi_smafruline_black_0002.png","digi_smafruline_black_0003.png","digi_smafruline_black_0004.png","digi_smafruline_black_0005.png","digi_smafruline_black_0006.png","digi_smafruline_black_0007.png","digi_smafruline_black_0008.png","digi_smafruline_black_0009.png","digi_smafruline_black_0010.png"],
              padding: false,
              h_space: -61,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 37,
              font_array: ["digi_smafruline_white_0001.png","digi_smafruline_white_0002.png","digi_smafruline_white_0003.png","digi_smafruline_white_0004.png","digi_smafruline_white_0005.png","digi_smafruline_white_0006.png","digi_smafruline_white_0007.png","digi_smafruline_white_0008.png","digi_smafruline_white_0009.png","digi_smafruline_white_0010.png"],
              padding: false,
              h_space: -58,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 21,
              y: 46,
              font_array: ["digi_smafruline_white_0001.png","digi_smafruline_white_0002.png","digi_smafruline_white_0003.png","digi_smafruline_white_0004.png","digi_smafruline_white_0005.png","digi_smafruline_white_0006.png","digi_smafruline_white_0007.png","digi_smafruline_white_0008.png","digi_smafruline_white_0009.png","digi_smafruline_white_0010.png"],
              padding: false,
              h_space: -59,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 347,
              font_array: ["digi_smafruline_black_0001.png","digi_smafruline_black_0002.png","digi_smafruline_black_0003.png","digi_smafruline_black_0004.png","digi_smafruline_black_0005.png","digi_smafruline_black_0006.png","digi_smafruline_black_0007.png","digi_smafruline_black_0008.png","digi_smafruline_black_0009.png","digi_smafruline_black_0010.png"],
              padding: false,
              h_space: -59,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 132,
              hour_array: ["digi_fruline_black_0001.png","digi_fruline_black_0002.png","digi_fruline_black_0003.png","digi_fruline_black_0004.png","digi_fruline_black_0005.png","digi_fruline_black_0006.png","digi_fruline_black_0007.png","digi_fruline_black_0008.png","digi_fruline_black_0009.png","digi_fruline_black_0010.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 93,
              minute_startY: 248,
              minute_array: ["digi_fruline_white_0001.png","digi_fruline_white_0002.png","digi_fruline_white_0003.png","digi_fruline_white_0004.png","digi_fruline_white_0005.png","digi_fruline_white_0006.png","digi_fruline_white_0007.png","digi_fruline_white_0008.png","digi_fruline_white_0009.png","digi_fruline_white_0010.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 381,
              second_startY: 191,
              second_array: ["digi_grey_sec0001.png","digi_grey_sec0002.png","digi_grey_sec0003.png","digi_grey_sec0004.png","digi_grey_sec0005.png","digi_grey_sec0006.png","digi_grey_sec0007.png","digi_grey_sec0008.png","digi_grey_sec0009.png","digi_grey_sec0010.png"],
              second_zero: 1,
              second_space: -14,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 0,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 362,
              am_y: 195,
              am_sc_path: 'digi_grey_am0001.png',
              am_en_path: 'digi_grey_am0001.png',
              pm_x: 362,
              pm_y: 195,
              pm_sc_path: 'digi_grey_pm0001.png',
              pm_en_path: 'digi_grey_pm0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -47,
              y: -34,
              src: 'Shadow ring 239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF090400',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 438,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 318,
              font_array: ["small5_size_googlesan_grey_0001.png","small5_size_googlesan_grey_0002.png","small5_size_googlesan_grey_0003.png","small5_size_googlesan_grey_0004.png","small5_size_googlesan_grey_0005.png","small5_size_googlesan_grey_0006.png","small5_size_googlesan_grey_0007.png","small5_size_googlesan_grey_0008.png","small5_size_googlesan_grey_0009.png","small5_size_googlesan_grey_0010.png"],
              padding: false,
              h_space: -35,
              unit_sc: 'icon_pecnet_lightgrey.png',
              unit_tc: 'icon_pecnet_lightgrey.png',
              unit_en: 'icon_pecnet_lightgrey.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 328,
              src: 'icon_batt_grey.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -118,
              hour_startY: 57,
              hour_array: ["digi_grey_0001.png","digi_grey_0002.png","digi_grey_0003.png","digi_grey_0004.png","digi_grey_0005.png","digi_grey_0006.png","digi_grey_0007.png","digi_grey_0008.png","digi_grey_0009.png","digi_grey_0010.png"],
              hour_zero: 1,
              hour_space: -283,
              hour_align: hmUI.align.LEFT,

              minute_startX: 90,
              minute_startY: 58,
              minute_array: ["digi_grey_0001.png","digi_grey_0002.png","digi_grey_0003.png","digi_grey_0004.png","digi_grey_0005.png","digi_grey_0006.png","digi_grey_0007.png","digi_grey_0008.png","digi_grey_0009.png","digi_grey_0010.png"],
              minute_zero: 1,
              minute_space: -283,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 130,
              src: 'digi_column.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 365,
              am_y: 201,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 357,
              pm_y: 201,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
