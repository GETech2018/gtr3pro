﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 370,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 338,
              y: 369,
              image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 418,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 421,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 7,
              y: 253,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 1,
              y: 186,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 230,
              day_startY: 48,
              day_sc_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              day_tc_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              day_en_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 370,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Small_Km.png',
              unit_tc: 'Small_Km.png',
              unit_en: 'Small_Km.png',
              imperial_unit_sc: 'Small_Mi.png',
              imperial_unit_tc: 'Small_Mi.png',
              imperial_unit_en: 'Small_Mi.png',
              dot_image: 'SMALL_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 288,
              month_startY: 62,
              month_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              month_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              month_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 130,
              y: 62,
              week_en: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
              week_tc: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
              week_sc: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 119,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 119,
              minute_array: ["Time_Font_R_01.png","Time_Font_R_02.png","Time_Font_R_03.png","Time_Font_R_04.png","Time_Font_R_05.png","Time_Font_R_06.png","Time_Font_R_07.png","Time_Font_R_08.png","Time_Font_R_09.png","Time_Font_R_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 196,
              src: 'Top_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 415,
              y: 217,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'SecondHand.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 31,
              second_posY: 258,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 119,
              hour_array: ["Time_Font_R_01.png","Time_Font_R_02.png","Time_Font_R_03.png","Time_Font_R_04.png","Time_Font_R_05.png","Time_Font_R_06.png","Time_Font_R_07.png","Time_Font_R_08.png","Time_Font_R_09.png","Time_Font_R_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 119,
              minute_array: ["Time_Font_R_01.png","Time_Font_R_02.png","Time_Font_R_03.png","Time_Font_R_04.png","Time_Font_R_05.png","Time_Font_R_06.png","Time_Font_R_07.png","Time_Font_R_08.png","Time_Font_R_09.png","Time_Font_R_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 196,
              src: 'Top_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 415,
              y: 217,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 263,
              w: 60,
              h: 71,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 144,
              w: 60,
              h: 83,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 178,
              w: 50,
              h: 55,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 138,
              y: 66,
              w: 217,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 2,
              w: 72,
              h: 52,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 368,
              w: 104,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 213,
              w: 50,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 417,
              y: 215,
              w: 62,
              h: 49,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 425,
              w: 121,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
