﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_sun_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 222,
              src: '0109.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 432,
              y: 222,
              src: '0110.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 200,
              year_startY: 100,
              year_sc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              year_tc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              year_en_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              year_zero: 0,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 186,
              week_en: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              week_tc: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              week_sc: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 242,
              y: 311,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Black_TDots",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 242,
              y: 311,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Black_TDots",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 99,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 7,
              invalid_image: 'Small_Black_Minus.png',
              dot_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 225,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 226,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 4,
              negative_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 226,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 4,
              negative_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 226,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 4,
              negative_image: 'Small_Black_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 142,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 152,
              month_startY: 100,
              month_sc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              month_tc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              month_en_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 100,
              src: 'Small_Black_Minus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 100,
              day_sc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              day_tc_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              day_en_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 100,
              src: 'Small_Black_Minus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 228,
              image_array: ["GTR4_Casio_Batt__1.png","GTR4_Casio_Batt__2.png","GTR4_Casio_Batt__3.png","GTR4_Casio_Batt__4.png","GTR4_Casio_Batt__5.png","GTR4_Casio_Batt__6.png","GTR4_Casio_Batt__7.png","GTR4_Casio_Batt__8.png","GTR4_Casio_Batt__9.png","GTR4_Casio_Batt__10.png","GTR4_Casio_Batt__11.png","GTR4_Casio_Batt__12.png","GTR4_Casio_Batt__13.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 147,
              font_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              padding: false,
              h_space: 5,
              unit_sc: '0045.png',
              unit_tc: '0045.png',
              unit_en: '0045.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 264,
              hour_array: ["Cas_Big_Bold_Black_0.png","Cas_Big_Bold_Black_1.png","Cas_Big_Bold_Black_2.png","Cas_Big_Bold_Black_3.png","Cas_Big_Bold_Black_4.png","Cas_Big_Bold_Black_5.png","Cas_Big_Bold_Black_6.png","Cas_Big_Bold_Black_7.png","Cas_Big_Bold_Black_8.png","Cas_Big_Bold_Black_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 264,
              minute_array: ["Cas_Big_Bold_Black_0.png","Cas_Big_Bold_Black_1.png","Cas_Big_Bold_Black_2.png","Cas_Big_Bold_Black_3.png","Cas_Big_Bold_Black_4.png","Cas_Big_Bold_Black_5.png","Cas_Big_Bold_Black_6.png","Cas_Big_Bold_Black_7.png","Cas_Big_Bold_Black_8.png","Cas_Big_Bold_Black_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 388,
              second_startY: 300,
              second_array: ["Cas_Tiny_Black__0.png","Cas_Tiny_Black__1.png","Cas_Tiny_Black__2.png","Cas_Tiny_Black__3.png","Cas_Tiny_Black__4.png","Cas_Tiny_Black__5.png","Cas_Tiny_Black__6.png","Cas_Tiny_Black__7.png","Cas_Tiny_Black__8.png","Cas_Tiny_Black__9.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0101.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 200,
              year_startY: 100,
              year_sc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              year_tc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              year_en_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              year_zero: 0,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 186,
              week_en: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              week_tc: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              week_sc: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 152,
              month_startY: 100,
              month_sc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              month_tc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              month_en_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 100,
              src: 'Cas_Tiny_White__-.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 100,
              day_sc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              day_tc_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              day_en_array: ["Cas_Tiny_White__0.png","Cas_Tiny_White__1.png","Cas_Tiny_White__2.png","Cas_Tiny_White__3.png","Cas_Tiny_White__4.png","Cas_Tiny_White__5.png","Cas_Tiny_White__6.png","Cas_Tiny_White__7.png","Cas_Tiny_White__8.png","Cas_Tiny_White__9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 100,
              src: 'Cas_Tiny_White__-.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 264,
              hour_array: ["Cas_Big_Bold_White_0.png","Cas_Big_Bold_White_1.png","Cas_Big_Bold_White_2.png","Cas_Big_Bold_White_3.png","Cas_Big_Bold_White_4.png","Cas_Big_Bold_White_5.png","Cas_Big_Bold_White_6.png","Cas_Big_Bold_White_7.png","Cas_Big_Bold_White_8.png","Cas_Big_Bold_White_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 264,
              minute_array: ["Cas_Big_Bold_White_0.png","Cas_Big_Bold_White_1.png","Cas_Big_Bold_White_2.png","Cas_Big_Bold_White_3.png","Cas_Big_Bold_White_4.png","Cas_Big_Bold_White_5.png","Cas_Big_Bold_White_6.png","Cas_Big_Bold_White_7.png","Cas_Big_Bold_White_8.png","Cas_Big_Bold_White_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  