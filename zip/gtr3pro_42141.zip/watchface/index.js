    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
         let colornumber = 1
        let totalcolors = 6
        let namecolor = ''

        function click_Analog() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Style 1"}
if ( colornumber == 2) { namecolor = "Style 2"}
if ( colornumber == 3) { namecolor = "Style 3"}
if ( colornumber == 4) { namecolor = "Style 4"}
if ( colornumber == 5) { namecolor = "Style 5"}
if ( colornumber == 6) { namecolor = "Hidden"}
hmUI.showToast({text: namecolor });

        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 72;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['main01.png', 'main02.png', 'main03.png', 'main04.png', 'main05.png', 'main06.png', 'main07.png', 'main08.png', 'main09.png', 'main10.png', 'main11.png', 'main12.png', 'main13.png', 'main14.png', 'main15.png', 'main16.png', 'main17.png', 'main18.png', 'main19.png', 'main20.png', 'main21.png', 'main22.png', 'main23.png', 'main24.png', 'main25.png'];
        let backgroundToastList = ['Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        
        let degreeSum = 0;
        let crownSensitivity = 70;  // crown sensitivity level
        let timeSensor = '';
         const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('onDigitalCrown()');
            function onDigitalCrown() {
              setTimeout(() => {
                hmApp.registerSpinEvent(function (key, degree) {
                  if (key === hmApp.key.HOME) {
                    degreeSum += degree;
                    if (Math.abs(degreeSum) > crownSensitivity){
                      let step = degreeSum < 0 ? -1 : 1;
                      degreeSum = 0;
                      
                      console.log('SwitchBackground use crown');
                      backgroundIndex += step;
                      backgroundIndex = backgroundIndex < 0 ? backgroundList.length + backgroundIndex : backgroundIndex % backgroundList.length;
                      hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                      let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
                      if (toastText.length > 0) hmUI.showToast({text: toastText});
                      normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                      vibro(28);
                    }
                  } // key
                }) // crown
              }, 250);
            }
            //end of ignored block

            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 130,
              src: 'topampm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 464,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 21,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 59,
              // y: 342,
              // font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'DisMI.png',
              // invalid_image: '0_Empty.png',
              // dot_image: '0_Empty.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'E0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'E1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'E2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'E3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'E4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'E5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'E6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'E7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'E8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'E9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 59,
                center_y: 342,
                pos_x: 59,
                pos_y: 342,
                angle: 0,
                src: 'E0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 59,
              center_y: 342,
              pos_x: 59,
              pos_y: 342,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'DisMI.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 307,
              font_array: ["Dis_0.png","Dis_1.png","Dis_2.png","Dis_3.png","Dis_4.png","Dis_5.png","Dis_6.png","Dis_7.png","Dis_8.png","Dis_9.png"],
              padding: true,
              h_space: -1,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 370,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 94,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'O2_unit.png',
              unit_tc: 'O2_unit.png',
              unit_en: 'O2_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 126,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 82,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 154,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'Temp-.png',
              invalid_image: 'Temp-.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 360,
              month_startY: 163,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 325,
              day_startY: 163,
              day_sc_array: ["Batt_F_0.png","Batt_F_1.png","Batt_F_2.png","Batt_F_3.png","Batt_F_4.png","Batt_F_5.png","Batt_F_6.png","Batt_F_7.png","Batt_F_8.png","Batt_F_9.png"],
              day_tc_array: ["Batt_F_0.png","Batt_F_1.png","Batt_F_2.png","Batt_F_3.png","Batt_F_4.png","Batt_F_5.png","Batt_F_6.png","Batt_F_7.png","Batt_F_8.png","Batt_F_9.png"],
              day_en_array: ["Batt_F_0.png","Batt_F_1.png","Batt_F_2.png","Batt_F_3.png","Batt_F_4.png","Batt_F_5.png","Batt_F_6.png","Batt_F_7.png","Batt_F_8.png","Batt_F_9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 278,
              y: 163,
              week_en: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_tc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_sc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 300,
              font_array: ["Batt_F_0.png","Batt_F_1.png","Batt_F_2.png","Batt_F_3.png","Batt_F_4.png","Batt_F_5.png","Batt_F_6.png","Batt_F_7.png","Batt_F_8.png","Batt_F_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '0_Empty.png',
              dot_image: 'ss_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 332,
              font_array: ["Batt_F_0.png","Batt_F_1.png","Batt_F_2.png","Batt_F_3.png","Batt_F_4.png","Batt_F_5.png","Batt_F_6.png","Batt_F_7.png","Batt_F_8.png","Batt_F_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '0_Empty.png',
              dot_image: 'ss_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 385,
              font_array: ["Batt_F_0.png","Batt_F_1.png","Batt_F_2.png","Batt_F_3.png","Batt_F_4.png","Batt_F_5.png","Batt_F_6.png","Batt_F_7.png","Batt_F_8.png","Batt_F_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 345,
              image_array: ["Batt_P_01.png","Batt_P_02.png","Batt_P_03.png","Batt_P_04.png","Batt_P_05.png","Batt_P_06.png","Batt_P_07.png","Batt_P_08.png","Batt_P_09.png","Batt_P_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 75,
              font_array: ["Steps0.png","Steps1.png","Steps2.png","Steps3.png","Steps4.png","Steps5.png","Steps6.png","Steps7.png","Steps8.png","Steps9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 36,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Step_Pointer.png',
              center_x: 240,
              center_y: 240,
              x: 14,
              y: 241,
              start_angle: 212,
              end_angle: 328,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 216,
              font_array: ["Steps0.png","Steps1.png","Steps2.png","Steps3.png","Steps4.png","Steps5.png","Steps6.png","Steps7.png","Steps8.png","Steps9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 305,
              am_y: 130,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 306,
              pm_y: 130,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 275,
              hour_startY: 195,
              hour_array: ["Time0.png","Time1.png","Time2.png","Time3.png","Time4.png","Time5.png","Time6.png","Time7.png","Time8.png","Time9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 356,
              minute_startY: 195,
              minute_array: ["Time0.png","Time1.png","Time2.png","Time3.png","Time4.png","Time5.png","Time6.png","Time7.png","Time8.png","Time9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 318,
              second_startY: 134,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 191,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 37,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 37,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 37,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 37,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 37,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 37,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 99,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 99,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 97,
              y: 67,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 350,
              y: 67,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 228,
              day_startY: 94,
              day_sc_array: ["Dis_0.png","Dis_1.png","Dis_2.png","Dis_3.png","Dis_4.png","Dis_5.png","Dis_6.png","Dis_7.png","Dis_8.png","Dis_9.png"],
              day_tc_array: ["Dis_0.png","Dis_1.png","Dis_2.png","Dis_3.png","Dis_4.png","Dis_5.png","Dis_6.png","Dis_7.png","Dis_8.png","Dis_9.png"],
              day_en_array: ["Dis_0.png","Dis_1.png","Dis_2.png","Dis_3.png","Dis_4.png","Dis_5.png","Dis_6.png","Dis_7.png","Dis_8.png","Dis_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 133,
              week_en: ["103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              week_tc: ["103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              week_sc: ["103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -20,
              am_y: 236,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: -20,
              pm_y: 236,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 117,
              hour_startY: 173,
              hour_array: ["123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 261,
              minute_startY: 173,
              minute_array: ["123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 191,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 214,
              w: 138,
              h: 30,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 50,
              w: 68,
              h: 83,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 365,
              w: 61,
              h: 43,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 138,
              y: 124,
              w: 46,
              h: 46,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 140,
              w: 81,
              h: 39,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 329,
              y: 72,
              w: 73,
              h: 44,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 129,
              w: 61,
              h: 30,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 344,
              y: 198,
              w: 31,
              h: 87,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 15,
              w: 47,
              h: 49,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 301,
              y: 414,
              w: 50,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 213,
              y: 345,
              w: 59,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 367,
              y: 159,
              w: 84,
              h: 27,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 136,
              y: 20,
              w: 45,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 413,
              w: 45,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 315,
              w: 90,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 218,
              y: 217,
              w: 52,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //change analog style
                click_Analog()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 449,
              // y: 198,
              // w: 27,
              // h: 92,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // bg_list: main01|main02|main03|main04|main05|main06|main07|main08|main09|main10|main11|main12|main13|main14|main15|main16|main17|main18|main19|main20|main21|main22|main23|main24|main25,
              // toast_list: Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s,
              // use_crown: True,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 449,
              y: 198,
              w: 27,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 59 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 59 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, '0_Empty.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 59 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 59 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, '0_Empty.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				autoToggleWeatherIcons();
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                onDigitalCrown();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

                hmApp.unregisterSpinEvent();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}