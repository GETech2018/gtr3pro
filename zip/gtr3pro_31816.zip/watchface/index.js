﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_progress = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------

        let weather_icons = ["wz_0.png","wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png"]
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию

        let curMins = '';
 
        let isDayIcons = true;
        let wiReplacement = [0,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28];		// индексы иконок для замены день-ночь
 
        function autoToggleWeatherIcons() {

          weatherData = weather.getForecastWeather();
          sunData = weatherData.tideData;
          if (sunData.count > 0){
            today = sunData.data[0];
            sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
            sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          } else {
            sunriseMins = sunriseMins_def;
            sunsetMins = sunsetMins_def;
          }

        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
   
         if(isDayNow){
         if(!isDayIcons){
           for (let i = 0; i < wiReplacement.length; i++) {
             weather_icons[wiReplacement[i]] = "wz_" + wiReplacement[i].toString() + ".png";
           }
            isDayIcons = true;
          }
         } else {
           if(isDayIcons){
             for (let i = 0; i < wiReplacement.length; i++) {
             weather_icons[wiReplacement[i]] = "wz_" + wiReplacement[i].toString() + "n.png";
          }
            isDayIcons = false;
          }
         }
       }

      //------------------------ автозамена иконок погоды ----------------------------------- \\	

        // aod changer start

        let btn_aod = ''

        let curAODmode = 0;			// 0 - пусто
                                // 1 - минимальный
								// 2 - информативный

        let AODmodes = ["пустой", "минимальный", "средний"];
        let AODmodeCaption;

        function toggleAODmode() {
            curAODmode = (curAODmode + 1) % AODmodes.length;
            hmFS.SysProSetInt('parkur_aod', curAODmode);

            switch (curAODmode) {
                case 0:
                    AODmodeCaption = "пустой";
                    break;
                case 1:
                    AODmodeCaption = "минимальный";
                    break;
                case 2:
                    AODmodeCaption = "средний";
                    break;
                default:
                    AODmodeCaption = "";
                    break;
            }

            hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
        }

        function makeAOD() {

            let mode = hmFS.SysProGetInt('parkur_aod');

            if (mode == 1) {    // минимальный

              idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src: 'aod_1.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                hour_path: 'cl_1.png',
                hour_centerX: 239,
                hour_centerY: 240,
                hour_posX: 27,
                hour_posY: 224,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                minute_path: 'cl_2.png',
                minute_centerX: 240,
                minute_centerY: 240,
                minute_posX: 27,
                minute_posY: 226,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                second_path: 'cl_3.png',
                second_centerX: 240,
                second_centerY: 240,
                second_posX: 28,
                second_posY: 227,
                show_level: hmUI.show_level.ONLY_AOD,
              });

            }

            if (mode == 2) {			// средний

              idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src: 'aod_1.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 375,
                y: 180,
                font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 432,
                y: 184,
                image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
                image_length: 8,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 281,
                month_startY: 92,
                month_sc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
                month_tc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
                month_en_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
                month_zero: 1,
                month_space: 0,
                month_align: hmUI.align.CENTER_H,
                month_is_character: false,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                day_startX: 209,
                day_startY: 92,
                day_sc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
                day_tc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
                day_en_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
                day_zero: 1,
                day_space: 0,
                day_unit_sc: '104.png',
                day_unit_tc: '104.png',
                day_unit_en: '104.png',
                day_align: hmUI.align.LEFT,
                day_is_character: false,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 142,
                y: 92,
                week_en: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
                week_tc: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
                week_sc: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 346,
                y: 274,
                font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
                x: [112,112,112,112,112,112,112,112,112,112],
                y: [224,224,224,224,224,224,224,224,224,224],
                image_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
                image_length: 10,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 432,
                y: 280,
                image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
                image_length: 8,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 50,
                y: 274,
                font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
                padding: false,
                h_space: 0,
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.CAL,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 30,
                y: 280,
                image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
                image_length: 8,
                type: hmUI.data_type.CAL,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 50,
                y: 180,
                font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
                padding: false,
                h_space: 0,
                invalid_image: '93.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.HEART,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 30,
                y: 184,
                image_array: ["pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png","pu_6.png"],
                image_length: 6,
                type: hmUI.data_type.HEART,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                hour_path: 'cl_1.png',
                hour_centerX: 239,
                hour_centerY: 240,
                hour_posX: 27,
                hour_posY: 224,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                minute_path: 'cl_2.png',
                minute_centerX: 240,
                minute_centerY: 240,
                minute_posX: 27,
                minute_posY: 226,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                second_path: 'cl_3.png',
                second_centerX: 240,
                second_centerY: 240,
                second_posX: 28,
                second_posY: 227,
                show_level: hmUI.show_level.ONLY_AOD,
              });
  
              idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 182,
                hour_startY: 348,
                hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
                hour_zero: 1,
                hour_space: 0,
                hour_unit_sc: '0015.png',
                hour_unit_tc: '0015.png',
                hour_unit_en: '0015.png',
                hour_align: hmUI.align.CENTER_H,
  
                minute_startX: 0,
                minute_startY: 0,
                minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
                minute_zero: 1,
                minute_space: 0,
                minute_follow: 1,
                minute_align: hmUI.align.CENTER_H,
  
                show_level: hmUI.show_level.ONLY_AOD,
              });
            }
        }

        // aod changer end \\

        function loadSettings() {
            if (hmFS.SysProGetInt('parkur_aod') === undefined) {
                curAODmode = 1;
                hmFS.SysProSetInt('parkur_aod', curAODmode);
            } else {
                curAODmode = hmFS.SysProGetInt('parkur_aod');
            }
        }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'Bezel_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'Bezel_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'Bezel_3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'Bezel_4.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tap_1.png',
              tips_x: 132,
              tips_y: 316,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 420,
              src: '0040.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 168,
              y: 420,
              src: '0039.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 180,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 432,
              y: 184,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 281,
              month_startY: 342,
              month_sc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              month_tc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              month_en_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 342,
              day_sc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              day_tc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              day_en_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '104.png',
              day_unit_tc: '104.png',
              day_unit_en: '104.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 342,
              week_en: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              week_tc: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              week_sc: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 306,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 274,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [112,112,112,112,112,112,112,112,112,112],
              y: [224,224,224,224,224,224,224,224,224,224],
              image_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 432,
              y: 280,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 274,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 280,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 180,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              invalid_image: '93.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 184,
              image_array: ["pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png","pu_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 154,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 110,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              negative_image: '93.png',
              invalid_image: '93.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 110,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: 0,
              negative_image: '93.png',
              invalid_image: '93.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 75,
              font_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              padding: false,
              h_space: 0,
              negative_image: '82.png',
              invalid_image: '82.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            //  x: 210,
            //  y: 107,
            //  image_array: ["wz_0.png","wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png"],
            //  image_length: 29,
            //  type: hmUI.data_type.WEATHER_CURRENT,
            //  show_level: hmUI.show_level.ONLY_NORMAL,
            //});
            autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 107,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'cl_1.png',
              hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 27,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'cl_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'cl_3.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 380,
              hour_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '11.png',
              hour_unit_tc: '11.png',
              hour_unit_en: '11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

   
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Отключено !,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Подключено !,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Отключено !"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Подключено !"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 141,
              y: 310,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 310,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 80,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 344,
              y: 118,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 266,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 120,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 342,
              y: 270,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };
          //buttons start
          btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 195,
            y: 2,
            text: '',
            w: 100,
            h: 70,
            normal_src: 'null.png',
            press_src: 'null.png',
            click_func: () => {
                toggleAODmode();
                vibro(25);
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_aod.setProperty(hmUI.prop.VISIBLE, true);
        //buttons end

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();
                autoToggleWeatherIcons();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
              const currentScreenType = hmSetting.getScreenType();
              switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;

                  default:
                      break;
              }

                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
