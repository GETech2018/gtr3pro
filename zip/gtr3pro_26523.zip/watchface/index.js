﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let timer_anim_motion_1_mirror = false;
        let normal_motion_animation_paramX_1_mirror = null;
        let normal_motion_animation_paramY_1_mirror = null;
        let normal_motion_animation_count_1 = 0;
        let normal_motion_animation_img_2 = '';
        let normal_motion_animation_paramX_2 = null;
        let normal_motion_animation_paramY_2 = null;
        let normal_motion_animation_lastTime_2 = 0;
        let timer_anim_motion_2;
        let timer_anim_motion_2_mirror = false;
        let normal_motion_animation_paramX_2_mirror = null;
        let normal_motion_animation_paramY_2_mirror = null;
        let normal_motion_animation_count_2 = 0;
        let normal_motion_animation_img_3 = '';
        let normal_motion_animation_paramX_3 = null;
        let normal_motion_animation_paramY_3 = null;
        let normal_motion_animation_lastTime_3 = 0;
        let timer_anim_motion_3;
        let timer_anim_motion_3_mirror = false;
        let normal_motion_animation_paramX_3_mirror = null;
        let normal_motion_animation_paramY_3_mirror = null;
        let normal_motion_animation_count_3 = 0;
        let normal_motion_animation_img_4 = '';
        let normal_motion_animation_paramX_4 = null;
        let normal_motion_animation_paramY_4 = null;
        let normal_motion_animation_lastTime_4 = 0;
        let timer_anim_motion_4;
        let timer_anim_motion_4_mirror = false;
        let normal_motion_animation_paramX_4_mirror = null;
        let normal_motion_animation_paramY_4_mirror = null;
        let normal_motion_animation_count_4 = 0;
        let normal_motion_animation_img_5 = '';
        let normal_motion_animation_paramX_5 = null;
        let normal_motion_animation_paramY_5 = null;
        let normal_motion_animation_lastTime_5 = 0;
        let timer_anim_motion_5;
        let timer_anim_motion_5_mirror = false;
        let normal_motion_animation_paramX_5_mirror = null;
        let normal_motion_animation_paramY_5_mirror = null;
        let normal_motion_animation_count_5 = 0;
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 164,
              pos_y: 270,
              src: 'animation/bubble_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 164,
              anim_to: 193,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_1 = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 270,
              anim_to: 333,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_motion_animation_paramX_1_mirror = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 193,
              anim_to: 164,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_1_mirror = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 333,
              anim_to: 270,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_1_mirror() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1_mirror);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1_mirror);
              normal_motion_animation_lastTime_1 = now.utc;
            };

            function anim_motion_1_complete_call() {
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
                normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
                normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 164,
              // y_start: 270,
              // x_end: 193,
              // y_end: 333,
              // src: 'bubble_2.png',
              // anim_fps: 15,
              // anim_duration: 2500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 200,
              pos_y: 275,
              src: 'animation/bubble_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_2 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 200,
              anim_to: 228,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_2 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 275,
              anim_to: 333,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 228,
              anim_to: 200,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 333,
              anim_to: 275,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_2_mirror() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2_mirror);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2_mirror);
              normal_motion_animation_lastTime_2 = now.utc;
            };

            function anim_motion_2_complete_call() {
              normal_motion_animation_count_2 = normal_motion_animation_count_2 - 1;
              if(normal_motion_animation_count_2 < -1) normal_motion_animation_count_2 = - 1;
                normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2);
                normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2);
                normal_motion_animation_lastTime_2 = now.utc;
              if(normal_motion_animation_count_2 == 0) stop_anim_motion_2();
            }; // end animation callback function
            
            function stop_anim_motion_2() {
              if (timer_anim_motion_2) {
                timer.stopTimer(timer_anim_motion_2);
                timer_anim_motion_2 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_2 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 200,
              // y_start: 275,
              // x_end: 228,
              // y_end: 333,
              // src: 'bubble_1.png',
              // anim_fps: 15,
              // anim_duration: 3000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 237,
              pos_y: 423,
              src: 'animation/bubble_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_3 = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 237,
              anim_to: 304,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_3 = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 423,
              anim_to: 369,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 304,
              anim_to: 237,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 2500,
              anim_from: 369,
              anim_to: 423,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_3_mirror() {
              normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_3_mirror);
              normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_3_mirror);
              normal_motion_animation_lastTime_3 = now.utc;
            };

            function anim_motion_3_complete_call() {
              normal_motion_animation_count_3 = normal_motion_animation_count_3 - 1;
              if(normal_motion_animation_count_3 < -1) normal_motion_animation_count_3 = - 1;
                normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_3);
                normal_motion_animation_img_3.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_3);
                normal_motion_animation_lastTime_3 = now.utc;
              if(normal_motion_animation_count_3 == 0) stop_anim_motion_3();
            }; // end animation callback function
            
            function stop_anim_motion_3() {
              if (timer_anim_motion_3) {
                timer.stopTimer(timer_anim_motion_3);
                timer_anim_motion_3 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_3 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 237,
              // y_start: 423,
              // x_end: 304,
              // y_end: 369,
              // src: 'bubble_2.png',
              // anim_fps: 15,
              // anim_duration: 2500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 251,
              pos_y: 362,
              src: 'animation/bubble_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_4 = {
              anim_rate: 'linear',
              anim_duration: 3500,
              anim_from: 251,
              anim_to: 173,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_4 = {
              anim_rate: 'linear',
              anim_duration: 3500,
              anim_from: 362,
              anim_to: 389,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_4_mirror = {
              anim_rate: 'linear',
              anim_duration: 3500,
              anim_from: 173,
              anim_to: 251,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_4_mirror = {
              anim_rate: 'linear',
              anim_duration: 3500,
              anim_from: 389,
              anim_to: 362,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_4_mirror() {
              normal_motion_animation_img_4.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_4_mirror);
              normal_motion_animation_img_4.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_4_mirror);
              normal_motion_animation_lastTime_4 = now.utc;
            };

            function anim_motion_4_complete_call() {
              normal_motion_animation_count_4 = normal_motion_animation_count_4 - 1;
              if(normal_motion_animation_count_4 < -1) normal_motion_animation_count_4 = - 1;
                normal_motion_animation_img_4.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_4);
                normal_motion_animation_img_4.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_4);
                normal_motion_animation_lastTime_4 = now.utc;
              if(normal_motion_animation_count_4 == 0) stop_anim_motion_4();
            }; // end animation callback function
            
            function stop_anim_motion_4() {
              if (timer_anim_motion_4) {
                timer.stopTimer(timer_anim_motion_4);
                timer_anim_motion_4 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_4 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 251,
              // y_start: 362,
              // x_end: 173,
              // y_end: 389,
              // src: 'bubble_1.png',
              // anim_fps: 15,
              // anim_duration: 3500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 275,
              pos_y: 279,
              src: 'animation/bubble_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_5 = {
              anim_rate: 'linear',
              anim_duration: 2000,
              anim_from: 275,
              anim_to: 307,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_5 = {
              anim_rate: 'linear',
              anim_duration: 2000,
              anim_from: 279,
              anim_to: 326,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            normal_motion_animation_paramX_5_mirror = {
              anim_rate: 'linear',
              anim_duration: 2000,
              anim_from: 307,
              anim_to: 275,
              anim_fps: 15,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_5_mirror = {
              anim_rate: 'linear',
              anim_duration: 2000,
              anim_from: 326,
              anim_to: 279,
              anim_fps: 15,
              anim_key: "pos_y",
            };

            function anim_motion_5_mirror() {
              normal_motion_animation_img_5.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_5_mirror);
              normal_motion_animation_img_5.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_5_mirror);
              normal_motion_animation_lastTime_5 = now.utc;
            };

            function anim_motion_5_complete_call() {
              normal_motion_animation_count_5 = normal_motion_animation_count_5 - 1;
              if(normal_motion_animation_count_5 < -1) normal_motion_animation_count_5 = - 1;
                normal_motion_animation_img_5.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_5);
                normal_motion_animation_img_5.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_5);
                normal_motion_animation_lastTime_5 = now.utc;
              if(normal_motion_animation_count_5 == 0) stop_anim_motion_5();
            }; // end animation callback function
            
            function stop_anim_motion_5() {
              if (timer_anim_motion_5) {
                timer.stopTimer(timer_anim_motion_5);
                timer_anim_motion_5 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_5 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 275,
              // y_start: 279,
              // x_end: 307,
              // y_end: 326,
              // src: 'bubble_2.png',
              // anim_fps: 15,
              // anim_duration: 2000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 335,
              y: 310,
              w: 106,
              h: 30,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 278,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'deg.png',
              unit_tc: 'deg.png',
              unit_en: 'deg.png',
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 345,
              y: 332,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 335,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 276,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 344,
              y: 188,
              week_en: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              week_tc: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              week_sc: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 402,
              day_startY: 153,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 341,
              month_startY: 153,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 158,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 224,
              am_y: 400,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 224,
              pm_y: 400,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 183,
              hour_startY: 112,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 183,
              minute_startY: 293,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour hand.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 27,
              hour_posY: 145,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute hand.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second hand.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 20,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 106,
              w: 148,
              h: 111,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 264,
              w: 148,
              h: 111,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 106,
              w: 148,
              h: 111,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 264,
              w: 148,
              h: 111,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 2500;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1*2) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    if(timer_anim_motion_1_mirror) {
                      anim_motion_1_mirror()
                    } else {
                      anim_motion_1_complete_call()
                    };
                    timer_anim_motion_1_mirror = !timer_anim_motion_1_mirror;
                  })); // end timer create
                };
                
                let delay_anim_motion_2 = 0;
                let repeat_anim_motion_2 = 3000;
                delay_anim_motion_2 = repeat_anim_motion_2 - (nawAnimationTime - normal_motion_animation_lastTime_2);
                if(delay_anim_motion_2 < 0) delay_anim_motion_2 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_2) > repeat_anim_motion_2*2) {
                  normal_motion_animation_count_2 = 0;
                  timer_anim_motion_2_mirror = false;
                };

                if (!timer_anim_motion_2) {
                  timer_anim_motion_2 = timer.createTimer(delay_anim_motion_2, repeat_anim_motion_2, (function (option) {
                    if(timer_anim_motion_2_mirror) {
                      anim_motion_2_mirror()
                    } else {
                      anim_motion_2_complete_call()
                    };
                    timer_anim_motion_2_mirror = !timer_anim_motion_2_mirror;
                  })); // end timer create
                };
                
                let delay_anim_motion_3 = 0;
                let repeat_anim_motion_3 = 2500;
                delay_anim_motion_3 = repeat_anim_motion_3 - (nawAnimationTime - normal_motion_animation_lastTime_3);
                if(delay_anim_motion_3 < 0) delay_anim_motion_3 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_3) > repeat_anim_motion_3*2) {
                  normal_motion_animation_count_3 = 0;
                  timer_anim_motion_3_mirror = false;
                };

                if (!timer_anim_motion_3) {
                  timer_anim_motion_3 = timer.createTimer(delay_anim_motion_3, repeat_anim_motion_3, (function (option) {
                    if(timer_anim_motion_3_mirror) {
                      anim_motion_3_mirror()
                    } else {
                      anim_motion_3_complete_call()
                    };
                    timer_anim_motion_3_mirror = !timer_anim_motion_3_mirror;
                  })); // end timer create
                };
                
                let delay_anim_motion_4 = 0;
                let repeat_anim_motion_4 = 3500;
                delay_anim_motion_4 = repeat_anim_motion_4 - (nawAnimationTime - normal_motion_animation_lastTime_4);
                if(delay_anim_motion_4 < 0) delay_anim_motion_4 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_4) > repeat_anim_motion_4*2) {
                  normal_motion_animation_count_4 = 0;
                  timer_anim_motion_4_mirror = false;
                };

                if (!timer_anim_motion_4) {
                  timer_anim_motion_4 = timer.createTimer(delay_anim_motion_4, repeat_anim_motion_4, (function (option) {
                    if(timer_anim_motion_4_mirror) {
                      anim_motion_4_mirror()
                    } else {
                      anim_motion_4_complete_call()
                    };
                    timer_anim_motion_4_mirror = !timer_anim_motion_4_mirror;
                  })); // end timer create
                };
                
                let delay_anim_motion_5 = 0;
                let repeat_anim_motion_5 = 2000;
                delay_anim_motion_5 = repeat_anim_motion_5 - (nawAnimationTime - normal_motion_animation_lastTime_5);
                if(delay_anim_motion_5 < 0) delay_anim_motion_5 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_5) > repeat_anim_motion_5*2) {
                  normal_motion_animation_count_5 = 0;
                  timer_anim_motion_5_mirror = false;
                };

                if (!timer_anim_motion_5) {
                  timer_anim_motion_5 = timer.createTimer(delay_anim_motion_5, repeat_anim_motion_5, (function (option) {
                    if(timer_anim_motion_5_mirror) {
                      anim_motion_5_mirror()
                    } else {
                      anim_motion_5_complete_call()
                    };
                    timer_anim_motion_5_mirror = !timer_anim_motion_5_mirror;
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                stop_anim_motion_1();
                stop_anim_motion_2();
                stop_anim_motion_3();
                stop_anim_motion_4();
                stop_anim_motion_5();

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  