﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let editGroup_4  = ''
        let editableZone_5_calorie_circle_scale = null;
        let editableZone_5_step_circle_scale = null;
        let editableZone_5_pai_circle_scale = null;
        let editableZone_5_stand_circle_scale = null;
        let editableZone_5_battery_circle_scale = null;
        let editGroup_5  = ''
        let editableZone_6_battery_circle_scale = null;
        let editableZone_6_step_circle_scale = null;
        let editableZone_6_calorie_circle_scale = null;
        let editableZone_6_stand_circle_scale = null;
        let editableZone_6_pai_circle_scale = null;
        let editGroup_6  = ''
        let mask = ''
        let fg_mask = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0004.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 293,
              image_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 355,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0041.png',
              unit_tc: '0041.png',
              unit_en: '0041.png',
              imperial_unit_sc: '0041.png',
              imperial_unit_tc: '0041.png',
              imperial_unit_en: '0041.png',
              negative_image: '0040.png',
              invalid_image: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 188,
              y: 66,
              week_en: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
              week_tc: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
              week_sc: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 248,
              month_startY: 116,
              month_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              month_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              month_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 116,
              day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0035.png',
              day_unit_tc: '0035.png',
              day_unit_en: '0035.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 184,
              hour_startY: 408,
              hour_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0076.png',
              hour_unit_tc: '0076.png',
              hour_unit_en: '0076.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 408,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: '0076.png',
              minute_unit_tc: '0076.png',
              minute_unit_en: '0076.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 270,
              second_startY: 408,
              second_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0005.png',
              // center_x: 240,
              // center_y: 240,
              // x: 18,
              // y: 144,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 18,
              pos_y: 240 - 144,
              center_x: 240,
              center_y: 240,
              src: '0005.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0006.png',
              // center_x: 240,
              // center_y: 240,
              // x: 18,
              // y: 221,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 18,
              pos_y: 240 - 221,
              center_x: 240,
              center_y: 240,
              src: '0006.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0007.png',
              // center_x: 240,
              // center_y: 240,
              // x: 10,
              // y: 230,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 10,
              pos_y: 240 - 230,
              center_x: 240,
              center_y: 240,
              src: '0007.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 25,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0004.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0005.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 144,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0006.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 80,
              y: 70,
              w: 117,
              h: 111,
              select_image: '0081.png',
              un_select_image: '0001.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: '0028.png' },
                { type: hmUI.edit_type.HEART, preview: '0023.png' },
                { type: hmUI.edit_type.CAL, preview: '0030.png' },
                { type: hmUI.edit_type.PAI, preview: '0034.png' },
                { type: hmUI.edit_type.STEP, preview: '0039.png' },
                { type: hmUI.edit_type.STAND, preview: '0037.png' },
                { type: hmUI.edit_type.WEATHER, preview: '0111.png' },
                { type: hmUI.edit_type.MOON, preview: 'moon_select.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: '0032.png' },
                { type: hmUI.edit_type.SUN, preview: '0079.png' },
                { type: hmUI.edit_type.WIND, preview: '0075.png' },
                { type: hmUI.edit_type.UVI, preview: '0073.png' },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0080.png',
              tips_x: 8,
              tips_y: 94,
              tips_width: 103,
              tips_margin: 19,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 105,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0027.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 84,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0038.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 93,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0029.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 100,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 99,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0033.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 93,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0036.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 111,
                  y: 80,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0041.png',
                  unit_tc: '0041.png',
                  unit_en: '0041.png',
                  imperial_unit_sc: '0040.png',
                  imperial_unit_tc: '0040.png',
                  imperial_unit_en: '0040.png',
                  negative_image: '0040.png',
                  invalid_image: '0040.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 109,
                  y: 106,
                  image_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 108,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0072.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 96,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0031.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 89,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: '0011.png',
                  dot_image: '0076.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0077.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 108,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 99,
                  y: 108,
                  src: '0074.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 91,
                  y: 70,
                  image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 80,
              y: 296,
              w: 109,
              h: 105,
              select_image: '0081.png',
              un_select_image: '0001.png',
              default_type: hmUI.edit_type.PAI,
              optional_types: [
                { type: hmUI.edit_type.PAI, preview: '0034.png' },
                { type: hmUI.edit_type.HEART, preview: '0023.png' },
                { type: hmUI.edit_type.CAL, preview: '0030.png' },
                { type: hmUI.edit_type.STEP, preview: '0039.png' },
                { type: hmUI.edit_type.STAND, preview: '0037.png' },
                { type: hmUI.edit_type.WEATHER, preview: '0111.png' },
                { type: hmUI.edit_type.MOON, preview: 'moon_select.png' },
                { type: hmUI.edit_type.UVI, preview: '0073.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: '0032.png' },
                { type: hmUI.edit_type.SUN, preview: '0079.png' },
                { type: hmUI.edit_type.WIND, preview: '0075.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0028.png' },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0080.png',
              tips_x: 8,
              tips_y: 92,
              tips_width: 103,
              tips_margin: 19,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 100,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 103,
                  y: 350,
                  src: '0027.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 104,
                  y: 350,
                  src: '0038.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 97,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 103,
                  y: 350,
                  src: '0029.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 106,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 105,
                  y: 350,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 106,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 105,
                  y: 350,
                  src: '0033.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 97,
                  y: 326,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_2_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 104,
                  y: 350,
                  src: '0036.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 97,
                  y: 374,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0041.png',
                  unit_tc: '0041.png',
                  unit_en: '0041.png',
                  imperial_unit_sc: '0041.png',
                  imperial_unit_tc: '0041.png',
                  imperial_unit_en: '0041.png',
                  negative_image: '0040.png',
                  invalid_image: '0021.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 97,
                  y: 313,
                  image_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 106,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 94,
                  y: 350,
                  src: '0072.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 98,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 105,
                  y: 350,
                  src: '0031.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 92,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: '0076.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 103,
                  y: 350,
                  src: '0077.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 106,
                  y: 328,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 96,
                  y: 350,
                  src: '0115.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 94,
                  y: 320,
                  image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 290,
              y: 71,
              w: 119,
              h: 101,
              select_image: '0081.png',
              un_select_image: '0001.png',
              default_type: hmUI.edit_type.SUN,
              optional_types: [
                { type: hmUI.edit_type.SUN, preview: '0079.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0028.png' },
                { type: hmUI.edit_type.CAL, preview: '0030.png' },
                { type: hmUI.edit_type.HEART, preview: '0023.png' },
                { type: hmUI.edit_type.PAI, preview: '0034.png' },
                { type: hmUI.edit_type.STEP, preview: '0039.png' },
                { type: hmUI.edit_type.STAND, preview: '0037.png' },
                { type: hmUI.edit_type.WEATHER, preview: '0111.png' },
                { type: hmUI.edit_type.MOON, preview: 'moon_select.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: '0032.png' },
                { type: hmUI.edit_type.UVI, preview: '0073.png' },
                { type: hmUI.edit_type.WIND, preview: '0075.png' },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0080.png',
              tips_x: 9,
              tips_y: 93,
              tips_width: 101,
              tips_margin: 19,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 329,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 108,
                  src: '0027.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 316,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 108,
                  src: '0038.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 319,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 108,
                  src: '0029.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 329,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 330,
                  y: 108,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 329,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 108,
                  src: '0033.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_3_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 108,
                  src: '0036.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 124,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0041.png',
                  unit_tc: '0041.png',
                  unit_en: '0041.png',
                  imperial_unit_sc: '0041.png',
                  imperial_unit_tc: '0041.png',
                  imperial_unit_en: '0041.png',
                  negative_image: '0040.png',
                  invalid_image: '0021.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 328,
                  y: 63,
                  image_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 324,
                  y: 106,
                  src: '0072.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 327,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 108,
                  src: '0031.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 324,
                  y: 86,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: '0011.png',
                  dot_image: '0076.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 334,
                  y: 108,
                  src: '0077.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 332,
                  y: 84,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 328,
                  y: 103,
                  src: '0074.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 320,
                  y: 69,
                  image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 290,
              y: 297,
              w: 119,
              h: 101,
              select_image: '0081.png',
              un_select_image: '0001.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: '0039.png' },
                { type: hmUI.edit_type.PAI, preview: '0034.png' },
                { type: hmUI.edit_type.STAND, preview: '0037.png' },
                { type: hmUI.edit_type.WEATHER, preview: '0111.png' },
                { type: hmUI.edit_type.UVI, preview: '0073.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: '0032.png' },
                { type: hmUI.edit_type.SUN, preview: '0079.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0028.png' },
              ],
              count: 8,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0080.png',
              tips_x: 8,
              tips_y: 91,
              tips_width: 101,
              tips_margin: 19,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 327,
                  y: 327,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 348,
                  src: '0027.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321,
                  y: 321,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 336,
                  y: 345,
                  src: '0038.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 331,
                  y: 321,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: true,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 336,
                  y: 345,
                  src: '0029.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 331,
                  y: 321,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 333,
                  y: 345,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 330,
                  y: 326,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 330,
                  y: 347,
                  src: '0033.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321,
                  y: 321,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_4_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 329,
                  y: 345,
                  src: '0036.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 332,
                  y: 368,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '0041.png',
                  unit_tc: '0041.png',
                  unit_en: '0041.png',
                  imperial_unit_sc: '0041.png',
                  imperial_unit_tc: '0041.png',
                  imperial_unit_en: '0041.png',
                  negative_image: '0040.png',
                  invalid_image: '0021.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 330,
                  y: 302,
                  image_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 333,
                  y: 326,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 329,
                  y: 349,
                  src: '0112.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 327,
                  y: 321,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 345,
                  src: '0031.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 318,
                  y: 325,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: '0076.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 325,
                  y: 347,
                  src: '0077.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 331,
                  y: 321,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 345,
                  src: '0074.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

            editGroup_5 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10025,
              x: 35,
              y: 184,
              w: 117,
              h: 114,
              select_image: '0081.png',
              un_select_image: '0001.png',
              default_type: hmUI.edit_type.CAL,
              optional_types: [
                { type: hmUI.edit_type.CAL, preview: '0126.png' },
                { type: hmUI.edit_type.HEART, preview: '0113_H.png' },
                { type: hmUI.edit_type.STEP, preview: '0136.png' },
                { type: hmUI.edit_type.PAI, preview: '0130.png' },
                { type: hmUI.edit_type.STAND, preview: '0132.png' },
                { type: hmUI.edit_type.BATTERY, preview: '0122.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: '0118.png' },
                { type: hmUI.edit_type.WIND, preview: '0116.png' },
                { type: hmUI.edit_type.UVI, preview: '0113.png' },
              ],
              count: 9,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0080.png',
              tips_x: 6,
              tips_y: 95,
              tips_width: 101,
              tips_margin: 19,
            });

            const editType_5 = editGroup_5.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_5) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 81,
                  y: 243,
                  src: '0027.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 75,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0119.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_5_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 108,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 108,
                  center_y: 232,
                  start_angle: 502,
                  end_angle: 217,
                  radius: 48,
                  line_width: 13,
                  corner_flag: 0,
                  color: 0xFF464646,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                battery.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 89,
                  y: 247,
                  src: '0135.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 67,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0133.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_5_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 108,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 108,
                  center_y: 232,
                  start_angle: 502,
                  end_angle: 217,
                  radius: 48,
                  line_width: 13,
                  corner_flag: 0,
                  color: 0xFF464646,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 75,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0123_C.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_5_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 108,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 108,
                  center_y: 232,
                  start_angle: 502,
                  end_angle: 217,
                  radius: 48,
                  line_width: 13,
                  corner_flag: 0,
                  color: 0xFF464646,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 82,
                  y: 242,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 82,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0083.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 89,
                  y: 247,
                  src: '0129.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 84,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0127.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_5_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 108,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 108,
                    center_y: 232,
                    start_angle: 502,
                    end_angle: 217,
                    radius: 48,
                    line_width: 13,
                    corner_flag: 0,
                    color: 0xFF464646,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                pai.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 87,
                  y: 245,
                  src: '0131.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 75,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_5_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0123.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_5_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 108,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 501,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.STAND,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 108,
                    center_y: 232,
                    start_angle: 501,
                    end_angle: 217,
                    radius: 48,
                    line_width: 13,
                    corner_flag: 0,
                    color: 0xFF464646,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                stand.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0008.png',
              center_x: 109,
              center_y: 232,
              x: 7,
              y: 55,
              start_angle: 227,
              end_angle: 495,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 88,
                  y: 248,
                  src: '0112.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 92,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0083.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 87,
                  y: 240,
                  src: '0117.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 79,
                  y: 221,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 56,
                  y: 180,
                  src: '0114.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 82,
                  y: 238,
                  src: '0074.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 92,
                  y: 215,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 57,
                  y: 180,
                  src: '0114.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 109,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_6 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10026,
              x: 319,
              y: 184,
              w: 117,
              h: 114,
              select_image: '0081.png',
              un_select_image: '0001.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: '0136.png' },
                { type: hmUI.edit_type.WIND, preview: '0116.png' },
                { type: hmUI.edit_type.UVI, preview: '0113.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: '0118.png' },
                { type: hmUI.edit_type.STEP, preview: '0136.png' },
                { type: hmUI.edit_type.CAL, preview: '0126.png' },
                { type: hmUI.edit_type.STAND, preview: '0132.png' },
                { type: hmUI.edit_type.HEART, preview: '0113_H.png' },
                { type: hmUI.edit_type.PAI, preview: '0130.png' },
              ],
              count: 9,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '0080.png',
              tips_x: 9,
              tips_y: 95,
              tips_width: 101,
              tips_margin: 19,
            });

            const editType_6 = editGroup_6.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_6) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 351,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0119.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_6_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 380,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_6_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 380,
                  center_y: 232,
                  start_angle: 502,
                  end_angle: 217,
                  radius: 48,
                  line_width: 13,
                  corner_flag: 0,
                  color: 0xFF464646,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 357,
                  y: 247,
                  src: '0121.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 337,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0133.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 239,
                  src: '0038.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_6_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 380,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_6_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 380,
                  center_y: 232,
                  start_angle: 502,
                  end_angle: 217,
                  radius: 48,
                  line_width: 13,
                  corner_flag: 0,
                  color: 0xFF464646,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 347,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0123.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 359,
                  y: 242,
                  src: '0125.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_6_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 380,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_6_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 380,
                  center_y: 232,
                  start_angle: 502,
                  end_angle: 217,
                  radius: 48,
                  line_width: 13,
                  corner_flag: 0,
                  color: 0xFF464646,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 354,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0083.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 354,
                  y: 239,
                  src: '0022.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 355,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0127.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 240,
                  src: '0033.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_6_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 380,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_6_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 380,
                    center_y: 232,
                    start_angle: 502,
                    end_angle: 217,
                    radius: 48,
                    line_width: 13,
                    corner_flag: 0,
                    color: 0xFF464646,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 347,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_6_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0123.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 362,
                  y: 241,
                  src: '0131.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_6_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 380,
                  // center_y: 232,
                  // start_angle: 217,
                  // end_angle: 502,
                  // radius: 54,
                  // line_width: 13,
                  // line_cap: Rounded,
                  // color: 0xFF464646,
                  // mirror: False,
                  // inversion: True,
                  // alpha: 255,
                  // type: hmUI.data_type.STAND,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_6_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 380,
                    center_y: 232,
                    start_angle: 502,
                    end_angle: 217,
                    radius: 48,
                    line_width: 13,
                    corner_flag: 0,
                    color: 0xFF464646,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0008.png',
              center_x: 380,
              center_y: 232,
              x: 7,
              y: 55,
              start_angle: 227,
              end_angle: 495,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 364,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0083.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 353,
                  y: 239,
                  src: '0072.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 20,
                  y: 53,
                  start_angle: 237,
                  end_angle: 494,
                  invalid_visible: false,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 351,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: '0026.png',
                  unit_tc: '0026.png',
                  unit_en: '0026.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0114.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 354,
                  y: 239,
                  src: '0031.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 361,
                  y: 220,
                  font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 327,
                  y: 180,
                  src: '0114.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 354,
                  y: 234,
                  src: '0074.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '0008.png',
                  center_x: 380,
                  center_y: 232,
                  x: 7,
                  y: 55,
                  start_angle: 227,
                  end_angle: 495,
                  invalid_visible: false,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

hmUI.deleteWidget(normal_analog_clock_pro_hour_pointer_img)
hmUI.deleteWidget(normal_analog_clock_pro_minute_pointer_img)
hmUI.deleteWidget(normal_analog_clock_pro_second_pointer_img)

          normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 18,
              pos_y: 240 - 144,
              center_x: 240,
              center_y: 240,
              src: '0005.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 18,
              pos_y: 240 - 221,
              center_x: 240,
              center_y: 240,
              src: '0006.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 10,
              pos_y: 240 - 230,
              center_x: 240,
              center_y: 240,
              src: '0007.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_5_calorie = 1 - progressCalories;

                if (editableZone_5_calorie_circle_scale) {

                  // editableZone_5_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_5_calorie * 100);
                  if (editableZone_5_calorie_circle_scale) {
                    editableZone_5_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 108,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_5_step = 1 - progressStep;

                if (editableZone_5_step_circle_scale) {

                  // editableZone_5_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_5_step * 100);
                  if (editableZone_5_step_circle_scale) {
                    editableZone_5_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 108,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_editableZone_5_pai = 1 - progressPAI;

                if (editableZone_5_pai_circle_scale) {

                  // editableZone_5_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_5_pai * 100);
                  if (editableZone_5_pai_circle_scale) {
                    editableZone_5_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 108,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_editableZone_5_stand = 1 - progressStand;

                if (editableZone_5_stand_circle_scale) {

                  // editableZone_5_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_5_stand * 100);
                  if (editableZone_5_stand_circle_scale) {
                    editableZone_5_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 108,
                      center_y: 232,
                      start_angle: 501,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_editableZone_5_battery = 1 - progressBattery;

                if (editableZone_5_battery_circle_scale) {

                  // editableZone_5_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_5_battery * 100);
                  if (editableZone_5_battery_circle_scale) {
                    editableZone_5_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 108,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_6_battery = 1 - progressBattery;

                if (editableZone_6_battery_circle_scale) {

                  // editableZone_6_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_6_battery * 100);
                  if (editableZone_6_battery_circle_scale) {
                    editableZone_6_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 380,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_6_step = 1 - progressStep;

                if (editableZone_6_step_circle_scale) {

                  // editableZone_6_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_6_step * 100);
                  if (editableZone_6_step_circle_scale) {
                    editableZone_6_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 380,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_6_calorie = 1 - progressCalories;

                if (editableZone_6_calorie_circle_scale) {

                  // editableZone_6_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_6_calorie * 100);
                  if (editableZone_6_calorie_circle_scale) {
                    editableZone_6_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 380,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STAND');
                let progress_cs_editableZone_6_stand = 1 - progressStand;

                if (editableZone_6_stand_circle_scale) {

                  // editableZone_6_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_6_stand * 100);
                  if (editableZone_6_stand_circle_scale) {
                    editableZone_6_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 380,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_6_pai = 1 - progressPAI;

                if (editableZone_6_pai_circle_scale) {

                  // editableZone_6_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_6_pai * 100);
                  if (editableZone_6_pai_circle_scale) {
                    editableZone_6_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 380,
                      center_y: 232,
                      start_angle: 502,
                      end_angle: 217,
                      radius: 48,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF464646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/25;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}