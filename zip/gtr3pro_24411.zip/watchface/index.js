﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_distance_text_text_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 237,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Weather_Font_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 81,
              font_array: ["Action_Font_01.png","Action_Font_02.png","Action_Font_03.png","Action_Font_04.png","Action_Font_05.png","Action_Font_06.png","Action_Font_07.png","Action_Font_08.png","Action_Font_09.png","Action_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 81,
              font_array: ["Action_Font_01.png","Action_Font_02.png","Action_Font_03.png","Action_Font_04.png","Action_Font_05.png","Action_Font_06.png","Action_Font_07.png","Action_Font_08.png","Action_Font_09.png","Action_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 136,
              day_sc_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              day_tc_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              day_en_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 124,
              font_array: ["Action_Font_01.png","Action_Font_02.png","Action_Font_03.png","Action_Font_04.png","Action_Font_05.png","Action_Font_06.png","Action_Font_07.png","Action_Font_08.png","Action_Font_09.png","Action_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 125,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 302,
              y: 229,
              w: 101,
              h: 35,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 237,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Font_12.png',
              unit_tc: 'Weather_Font_12.png',
              unit_en: 'Weather_Font_12.png',
              negative_image: 'Weather_Font_11.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 233,
              image_array: ["Weather_ICONS_01.png","Weather_ICONS_02.png","Weather_ICONS_03.png","Weather_ICONS_04.png","Weather_ICONS_05.png","Weather_ICONS_06.png","Weather_ICONS_07.png","Weather_ICONS_08.png","Weather_ICONS_09.png","Weather_ICONS_10.png","Weather_ICONS_11.png","Weather_ICONS_12.png","Weather_ICONS_13.png","Weather_ICONS_14.png","Weather_ICONS_15.png","Weather_ICONS_16.png","Weather_ICONS_17.png","Weather_ICONS_18.png","Weather_ICONS_19.png","Weather_ICONS_20.png","Weather_ICONS_21.png","Weather_ICONS_22.png","Weather_ICONS_23.png","Weather_ICONS_24.png","Weather_ICONS_25.png","Weather_ICONS_26.png","Weather_ICONS_27.png","Weather_ICONS_28.png","Weather_ICONS_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 338,
              src: 'SYSTEM_BT_DISCONNECT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 71,
              y: 277,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 419,
              font_array: ["Battery_Fon_01.png","Battery_Fon_02.png","Battery_Fon_03.png","Battery_Fon_04.png","Battery_Fon_05.png","Battery_Fon_06.png","Battery_Fon_07.png","Battery_Fon_08.png","Battery_Fon_09.png","Battery_Fon_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 416,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 181,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 64,
              am_y: 309,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 64,
              pm_y: 309,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 274,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 274,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 373,
              second_startY: 278,
              second_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 369,
              y: 274,
              w: 53,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 225,
              y: 308,
              w: 32,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 269,
              w: 44,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 233,
              w: 125,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 235,
              w: 70,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 118,
              w: 40,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 121,
              w: 152,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 73,
              w: 96,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 237,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Weather_Font_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 81,
              font_array: ["Action_Font_01.png","Action_Font_02.png","Action_Font_03.png","Action_Font_04.png","Action_Font_05.png","Action_Font_06.png","Action_Font_07.png","Action_Font_08.png","Action_Font_09.png","Action_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 81,
              font_array: ["Action_Font_01.png","Action_Font_02.png","Action_Font_03.png","Action_Font_04.png","Action_Font_05.png","Action_Font_06.png","Action_Font_07.png","Action_Font_08.png","Action_Font_09.png","Action_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 136,
              day_sc_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              day_tc_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              day_en_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 124,
              font_array: ["Action_Font_01.png","Action_Font_02.png","Action_Font_03.png","Action_Font_04.png","Action_Font_05.png","Action_Font_06.png","Action_Font_07.png","Action_Font_08.png","Action_Font_09.png","Action_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 125,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 302,
              y: 229,
              w: 101,
              h: 35,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 237,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Font_12.png',
              unit_tc: 'Weather_Font_12.png',
              unit_en: 'Weather_Font_12.png',
              negative_image: 'Weather_Font_11.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 233,
              image_array: ["Weather_ICONS_01.png","Weather_ICONS_02.png","Weather_ICONS_03.png","Weather_ICONS_04.png","Weather_ICONS_05.png","Weather_ICONS_06.png","Weather_ICONS_07.png","Weather_ICONS_08.png","Weather_ICONS_09.png","Weather_ICONS_10.png","Weather_ICONS_11.png","Weather_ICONS_12.png","Weather_ICONS_13.png","Weather_ICONS_14.png","Weather_ICONS_15.png","Weather_ICONS_16.png","Weather_ICONS_17.png","Weather_ICONS_18.png","Weather_ICONS_19.png","Weather_ICONS_20.png","Weather_ICONS_21.png","Weather_ICONS_22.png","Weather_ICONS_23.png","Weather_ICONS_24.png","Weather_ICONS_25.png","Weather_ICONS_26.png","Weather_ICONS_27.png","Weather_ICONS_28.png","Weather_ICONS_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 338,
              src: 'SYSTEM_BT_DISCONNECT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 71,
              y: 277,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 419,
              font_array: ["Battery_Fon_01.png","Battery_Fon_02.png","Battery_Fon_03.png","Battery_Fon_04.png","Battery_Fon_05.png","Battery_Fon_06.png","Battery_Fon_07.png","Battery_Fon_08.png","Battery_Fon_09.png","Battery_Fon_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 416,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 181,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 64,
              am_y: 309,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 64,
              pm_y: 309,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 274,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 274,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 373,
              second_startY: 278,
              second_array: ["Time_Seconds_Font_01.png","Time_Seconds_Font_02.png","Time_Seconds_Font_03.png","Time_Seconds_Font_04.png","Time_Seconds_Font_05.png","Time_Seconds_Font_06.png","Time_Seconds_Font_07.png","Time_Seconds_Font_08.png","Time_Seconds_Font_09.png","Time_Seconds_Font_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 239,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  