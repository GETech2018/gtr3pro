﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_current_text_font = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FREE192.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 277,
              y: 319,
              w: 150,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 154,
              y: 4,
              w: 150,
              h: 42,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 281,
              image_array: ["meteo-01.png","meteo-02.png","meteo-03.png","meteo-04.png","meteo-05.png","meteo-06.png","meteo-07.png","meteo-08.png","meteo-09.png","meteo-10.png","meteo-11.png","meteo-12.png","meteo-13.png","meteo-14.png","meteo-15.png","meteo-16.png","meteo-17.png","meteo-18.png","meteo-19.png","meteo-20.png","meteo-21.png","meteo-22.png","meteo-23.png","meteo-24.png","meteo-25.png","meteo-26.png","meteo-27.png","meteo-28.png","meteo-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 288,
              font_array: ["NI00.png","NI01.png","NI02.png","NI03.png","NI04.png","NI05.png","NI06.png","NI07.png","NI08.png","NI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NI14.png',
              unit_tc: 'NI14.png',
              unit_en: 'NI14.png',
              negative_image: 'NI12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 286,
              font_array: ["WW00.png","WW01.png","WW02.png","WW03.png","WW04.png","WW05.png","WW06.png","WW07.png","WW08.png","WW09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'WW10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 309,
              font_array: ["WW00.png","WW01.png","WW02.png","WW03.png","WW04.png","WW05.png","WW06.png","WW07.png","WW08.png","WW09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'WW10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img.setAlpha(150);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 307,
              font_array: ["WW00.png","WW01.png","WW02.png","WW03.png","WW04.png","WW05.png","WW06.png","WW07.png","WW08.png","WW09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'WW15.png',
              unit_tc: 'WW15.png',
              unit_en: 'WW15.png',
              dot_image: 'WW10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 285,
              font_array: ["WW00.png","WW01.png","WW02.png","WW03.png","WW04.png","WW05.png","WW06.png","WW07.png","WW08.png","WW09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 339,
              font_array: ["NI00.png","NI01.png","NI02.png","NI03.png","NI04.png","NI05.png","NI06.png","NI07.png","NI08.png","NI09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 339,
              font_array: ["NI00.png","NI01.png","NI02.png","NI03.png","NI04.png","NI05.png","NI06.png","NI07.png","NI08.png","NI09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 433,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 436,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 394,
              font_array: ["NI00.png","NI01.png","NI02.png","NI03.png","NI04.png","NI05.png","NI06.png","NI07.png","NI08.png","NI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NI13.png',
              unit_tc: 'NI13.png',
              unit_en: 'NI13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 149,
              y: 385,
              image_array: ["ENE00.png","ENE01.png","ENE02.png","ENE03.png","ENE04.png","ENE05.png","ENE06.png","ENE07.png","ENE08.png","ENE09.png","ENE10.png","ENE11.png","ENE12.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 315,
              month_startY: 45,
              month_sc_array: ["K_01.png","K_02.png","K_03.png","K_04.png","K_05.png","K_06.png","K_07.png","K_08.png","K_09.png","K_10.png"],
              month_tc_array: ["K_01.png","K_02.png","K_03.png","K_04.png","K_05.png","K_06.png","K_07.png","K_08.png","K_09.png","K_10.png"],
              month_en_array: ["K_01.png","K_02.png","K_03.png","K_04.png","K_05.png","K_06.png","K_07.png","K_08.png","K_09.png","K_10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'K_11.png',
              month_unit_tc: 'K_11.png',
              month_unit_en: 'K_11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 262,
              day_startY: 46,
              day_sc_array: ["I_01.png","I_02.png","I_03.png","I_04.png","I_05.png","I_06.png","I_07.png","I_08.png","I_09.png","I_10.png"],
              day_tc_array: ["I_01.png","I_02.png","I_03.png","I_04.png","I_05.png","I_06.png","I_07.png","I_08.png","I_09.png","I_10.png"],
              day_en_array: ["I_01.png","I_02.png","I_03.png","I_04.png","I_05.png","I_06.png","I_07.png","I_08.png","I_09.png","I_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'I_11.png',
              day_unit_tc: 'I_11.png',
              day_unit_en: 'I_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 108,
              y: 42,
              week_en: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_tc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_sc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 139,
              hour_array: ["G_01.png","G_02.png","G_03.png","G_04.png","G_05.png","G_06.png","G_07.png","G_08.png","G_09.png","G_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 288,
              minute_startY: 142,
              minute_array: ["H_01.png","H_02.png","H_03.png","H_04.png","H_05.png","H_06.png","H_07.png","H_08.png","H_09.png","H_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 326,
              second_startY: 228,
              second_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 256,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 260,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 45,
              month_sc_array: ["K_01.png","K_02.png","K_03.png","K_04.png","K_05.png","K_06.png","K_07.png","K_08.png","K_09.png","K_10.png"],
              month_tc_array: ["K_01.png","K_02.png","K_03.png","K_04.png","K_05.png","K_06.png","K_07.png","K_08.png","K_09.png","K_10.png"],
              month_en_array: ["K_01.png","K_02.png","K_03.png","K_04.png","K_05.png","K_06.png","K_07.png","K_08.png","K_09.png","K_10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'K_11.png',
              month_unit_tc: 'K_11.png',
              month_unit_en: 'K_11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 46,
              day_sc_array: ["I_01.png","I_02.png","I_03.png","I_04.png","I_05.png","I_06.png","I_07.png","I_08.png","I_09.png","I_10.png"],
              day_tc_array: ["I_01.png","I_02.png","I_03.png","I_04.png","I_05.png","I_06.png","I_07.png","I_08.png","I_09.png","I_10.png"],
              day_en_array: ["I_01.png","I_02.png","I_03.png","I_04.png","I_05.png","I_06.png","I_07.png","I_08.png","I_09.png","I_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'I_11.png',
              day_unit_tc: 'I_11.png',
              day_unit_en: 'I_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 139,
              hour_array: ["G_01.png","G_02.png","G_03.png","G_04.png","G_05.png","G_06.png","G_07.png","G_08.png","G_09.png","G_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 139,
              minute_array: ["F_01.png","F_02.png","F_03.png","F_04.png","F_05.png","F_06.png","F_07.png","F_08.png","F_09.png","F_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 312,
              second_startY: 228,
              second_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'SUPERIEUR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 275,
              w: 140,
              h: 53,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 336,
              w: 100,
              h: 35,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 275,
              w: 125,
              h: 58,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 280,
              w: 165,
              h: 75,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 433,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 347,
              y: 333,
              w: 100,
              h: 35,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}