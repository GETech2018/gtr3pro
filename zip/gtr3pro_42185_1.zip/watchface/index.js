﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 19,
              src: '02.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 19,
              src: '01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 154,
              month_startY: 59,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 310,
              year_startY: 61,
              year_sc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              year_tc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              year_en_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 97,
              day_startY: 61,
              day_sc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              day_tc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              day_en_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 61,
              src: 'Minuti_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 401,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Minuti_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 436,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 327,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 327,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Minuti_11.png',
              unit_tc: 'Minuti_11.png',
              unit_en: 'Minuti_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 363,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 103,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 330,
              y: 355,
              image_array: ["weathera_00.png","weathera_01.png","weathera_02.png","weathera_03.png","weathera_04.png","weathera_05.png","weathera_06.png","weathera_07.png","weathera_08.png","weathera_09.png","weathera_10.png","weathera_11.png","weathera_12.png","weathera_13.png","weathera_14.png","weathera_15.png","weathera_16.png","weathera_17.png","weathera_18.png","weathera_19.png","weathera_20.png","weathera_21.png","weathera_22.png","weathera_23.png","weathera_24.png","weathera_25.png","weathera_26.png","weathera_27.png","weathera_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 326,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Minuti_15.png',
              unit_tc: 'Minuti_15.png',
              unit_en: 'Minuti_15.png',
              negative_image: 'Minuti_13.png',
              invalid_image: 'Minuti_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Secondi.png',
              // center_x: 240,
              // center_y: 240,
              // x: 5,
              // y: 241,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 5,
              pos_y: 240 - 241,
              center_x: 240,
              center_y: 240,
              src: 'Secondi.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 156,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 270,
              minute_startY: 156,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 156,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 154,
              month_startY: 59,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 310,
              year_startY: 61,
              year_sc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              year_tc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              year_en_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 97,
              day_startY: 61,
              day_sc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              day_tc_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              day_en_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 61,
              src: 'Minuti_12.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 401,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Minuti_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 436,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 327,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 327,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Minuti_11.png',
              unit_tc: 'Minuti_11.png',
              unit_en: 'Minuti_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 363,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 103,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 330,
              y: 355,
              image_array: ["weathera_00.png","weathera_01.png","weathera_02.png","weathera_03.png","weathera_04.png","weathera_05.png","weathera_06.png","weathera_07.png","weathera_08.png","weathera_09.png","weathera_10.png","weathera_11.png","weathera_12.png","weathera_13.png","weathera_14.png","weathera_15.png","weathera_16.png","weathera_17.png","weathera_18.png","weathera_19.png","weathera_20.png","weathera_21.png","weathera_22.png","weathera_23.png","weathera_24.png","weathera_25.png","weathera_26.png","weathera_27.png","weathera_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 326,
              font_array: ["Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png","Minuti_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Minuti_15.png',
              unit_tc: 'Minuti_15.png',
              unit_en: 'Minuti_15.png',
              negative_image: 'Minuti_13.png',
              invalid_image: 'Minuti_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 156,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 270,
              minute_startY: 156,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 156,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}