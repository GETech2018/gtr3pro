
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright � CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF00FFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


let screenType = hmSetting.getScreenType(); // Cuidado, debe hacerse el let solo una vez
            // animate
            if (screenType != hmSetting.screen_type.AOD) {

               let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "kolo",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: 8,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	           });
       	    }


            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 407,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0044.png',
              unit_tc: '0044.png',
              unit_en: '0044.png',
              dot_image: '0045.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 0,
              src: 'text_0127.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 365,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 365,
              src: 'text_0126.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 314,
              font_array: ["text_0043.png","text_0044.png","text_0045.png","text_0046.png","text_0047.png","text_0048.png","text_0049.png","text_0050.png","text_0051.png","text_0052.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'text_0111.png',
              unit_tc: 'text_0111.png',
              unit_en: 'text_0111.png',
              negative_image: 'text_0110.png',
              invalid_image: 'text_0109.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 228,
              y: 300,
              image_array: ["poc_0039.png","poc_0040.png","poc_0041.png","poc_0042.png","poc_0043.png","poc_0044.png","poc_0045.png","poc_0046.png","poc_0047.png","poc_0048.png","poc_0049.png","poc_0050.png","poc_0051.png","poc_0052.png","poc_0053.png","poc_0054.png","poc_0055.png","poc_0056.png","poc_0057.png","poc_0058.png","poc_0059.png","poc_0060.png","poc_0061.png","poc_0062.png","poc_0063.png","poc_0064.png","poc_0065.png","poc_0066.png","poc_0067.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 95,
              week_en: ["cz_0069.png","cz_0070.png","cz_0071.png","cz_0072.png","cz_0073.png","cz_0074.png","cz_0075.png"],
              week_tc: ["cz_0069.png","cz_0070.png","cz_0071.png","cz_0072.png","cz_0073.png","cz_0074.png","cz_0075.png"],
              week_sc: ["cz_0069.png","cz_0070.png","cz_0071.png","cz_0072.png","cz_0073.png","cz_0074.png","cz_0075.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 165,
              year_startY: 305,
              year_sc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              year_tc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              year_en_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 116,
              month_startY: 305,
              month_sc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              month_tc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              month_en_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0045.png',
              month_unit_tc: '0045.png',
              month_unit_en: '0045.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 305,
              day_sc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              day_tc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              day_en_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0045.png',
              day_unit_tc: '0045.png',
              day_unit_en: '0045.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 103,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 84,
              image_array: ["SR_001.png","SR_002.png","SR_003.png","SR_004.png","SR_005.png","SR_006.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 45,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0046.png',
              unit_tc: '0046.png',
              unit_en: '0046.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 45,
              image_array: ["bat_001.png","bat_002.png","bat_003.png","bat_004.png","bat_005.png","bat_006.png","bat_007.png","bat_008.png","bat_009.png","bat_010.png","bat_011.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 150,
              hour_array: ["cis_00.png","cis_01.png","cis_02.png","cis_03.png","cis_04.png","cis_05.png","cis_06.png","cis_07.png","cis_08.png","cis_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 261,
              minute_startY: 150,
              minute_array: ["cis_00.png","cis_01.png","cis_02.png","cis_03.png","cis_04.png","cis_05.png","cis_06.png","cis_07.png","cis_08.png","cis_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 440,
              second_startY: 261,
              second_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 152,
              src: 'cis_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 150,
              hour_array: ["cis_00.png","cis_01.png","cis_02.png","cis_03.png","cis_04.png","cis_05.png","cis_06.png","cis_07.png","cis_08.png","cis_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 261,
              minute_startY: 150,
              minute_array: ["cis_00.png","cis_01.png","cis_02.png","cis_03.png","cis_04.png","cis_05.png","cis_06.png","cis_07.png","cis_08.png","cis_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 152,
              src: 'cis_10.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  