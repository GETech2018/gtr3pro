﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stress_icon_img = ''
        let normal_stress_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 434,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batunit.png',
              unit_tc: 'batunit.png',
              unit_en: 'batunit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 434,
              image_array: ["batterij01.png","batterij02.png","batterij03.png","batterij04.png","batterij05.png","batterij06.png","batterij07.png","batterij08.png","batterij09.png","batterij10.png","batterij11.png","batterij12.png","batterij13.png","batterij14.png","batterij15.png"],
              image_length: 15,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 363,
              src: 'screen_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 248,
              src: 'Bluetooth_uit.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 312,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 50,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              negative_image: 'min.png',
              invalid_image: 'no data.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 293,
              y: 41,
              image_array: ["weer0.png","weer01.png","weer02.png","weer03.png","weer04.png","weer05.png","weer06.png","weer07.png","weer08.png","weer09.png","weer10.png","weer11.png","weer12.png","weer13.png","weer14.png","weer15.png","weer16.png","weer17.png","weer18.png","weer19.png","weer20.png","weer21.png","weer22.png","weer23.png","weer24.png","weer25.png","weer26.png","weer27.png","weer28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 370,
              src: 'Stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 340,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 340,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'Mi.png',
              imperial_unit_tc: 'Mi.png',
              imperial_unit_en: 'Mi.png',
              dot_image: 'punt.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 370,
              src: 'Afstand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 290,
              src: 'hartslag.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 260,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'no data.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 290,
              src: 'Stappen.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 260,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 28,
              y: 201,
              week_en: ["dag1.png","dag2.png","dag3.png","dag4.png","dag5.png","dag6.png","dag7.png"],
              week_tc: ["dag1.png","dag2.png","dag3.png","dag4.png","dag5.png","dag6.png","dag7.png"],
              week_sc: ["dag1.png","dag2.png","dag3.png","dag4.png","dag5.png","dag6.png","dag7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 265,
              month_startY: 200,
              month_sc_array: ["maand01.png","maand02.png","maand03.png","maand04.png","maand05.png","maand06.png","maand07.png","maand08.png","maand09.png","maand10.png","maand11.png","maand12.png"],
              month_tc_array: ["maand01.png","maand02.png","maand03.png","maand04.png","maand05.png","maand06.png","maand07.png","maand08.png","maand09.png","maand10.png","maand11.png","maand12.png"],
              month_en_array: ["maand01.png","maand02.png","maand03.png","maand04.png","maand05.png","maand06.png","maand07.png","maand08.png","maand09.png","maand10.png","maand11.png","maand12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 100,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 253,
              minute_startY: 100,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 384,
              second_startY: 160,
              second_array: ["sec0.png","sec1.png","sec2.png","sec3.png","sec4.png","sec5.png","sec6.png","sec7.png","sec8.png","sec9.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 200,
              day_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 95,
              w: 180,
              h: 100,
              src: 'dummy.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 95,
              w: 180,
              h: 100,
              src: 'dummy.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 300,
              w: 61,
              h: 64,
              src: 'dummy.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 28,
              w: 215,
              h: 63,
              src: 'dummy.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 330,
              w: 90,
              h: 81,
              src: 'dummy.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 244,
              w: 100,
              h: 75,
              src: 'dummy.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 252,
              w: 137,
              h: 156,
              src: 'dummy.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 434,
              font_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batunit.png',
              unit_tc: 'batunit.png',
              unit_en: 'batunit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 434,
              image_array: ["batterij01.png","batterij02.png","batterij03.png","batterij04.png","batterij05.png","batterij06.png","batterij07.png","batterij08.png","batterij09.png","batterij10.png","batterij11.png","batterij12.png","batterij13.png","batterij14.png","batterij15.png"],
              image_length: 15,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 28,
              y: 201,
              week_en: ["dag1.png","dag2.png","dag3.png","dag4.png","dag5.png","dag6.png","dag7.png"],
              week_tc: ["dag1.png","dag2.png","dag3.png","dag4.png","dag5.png","dag6.png","dag7.png"],
              week_sc: ["dag1.png","dag2.png","dag3.png","dag4.png","dag5.png","dag6.png","dag7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 265,
              month_startY: 200,
              month_sc_array: ["maand01.png","maand02.png","maand03.png","maand04.png","maand05.png","maand06.png","maand07.png","maand08.png","maand09.png","maand10.png","maand11.png","maand12.png"],
              month_tc_array: ["maand01.png","maand02.png","maand03.png","maand04.png","maand05.png","maand06.png","maand07.png","maand08.png","maand09.png","maand10.png","maand11.png","maand12.png"],
              month_en_array: ["maand01.png","maand02.png","maand03.png","maand04.png","maand05.png","maand06.png","maand07.png","maand08.png","maand09.png","maand10.png","maand11.png","maand12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 200,
              day_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 100,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 100,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 384,
              second_startY: 160,
              second_array: ["sec0.png","sec1.png","sec2.png","sec3.png","sec4.png","sec5.png","sec6.png","sec7.png","sec8.png","sec9.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 121,
              src: 'anim00.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  