﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let timer_anim_rotate_3_mirror = false;
        let normal_rotate_animation_param_3_mirror = null;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let timer_anim_rotate_4_mirror = false;
        let normal_rotate_animation_param_4_mirror = null;
        let normal_rotate_animation_count_4 = 0;
        let normal_rotate_animation_img_5 = '';
        let normal_rotate_animation_param_5 = null;
        let normal_rotate_animation_lastTime_5 = 0;
        let timer_anim_rotate_5;
        let normal_rotate_animation_count_5 = 0;
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let normal_motion_animation_count_1 = 0;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 223,
              pos_y: 177,
              center_x: 259,
              center_y: 213,
              angle: 0,
              src: 'animation/anim_204.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 8000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
                normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
                normal_rotate_animation_lastTime_1 = now.utc;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 36,
              // pos_y: 36,
              // center_x: 259,
              // center_y: 213,
              // src: 'anim_204.png',
              // anim_fps: 15,
              // anim_duration: 8000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 174,
              pos_y: 250,
              center_x: 229,
              center_y: 305,
              angle: 0,
              src: 'animation/anim_205.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 30000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
                normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
                normal_rotate_animation_lastTime_2 = now.utc;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 55,
              // pos_y: 55,
              // center_x: 229,
              // center_y: 305,
              // src: 'anim_205.png',
              // anim_fps: 15,
              // anim_duration: 30000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 163,
              pos_y: 163,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/anim_206.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 0,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 0,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_3_mirror() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3_mirror);              normal_rotate_animation_lastTime_3 = now.utc;
            };

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
                normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
                normal_rotate_animation_lastTime_3 = now.utc;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 0,
              // pos_x: 77,
              // pos_y: 77,
              // center_x: 240,
              // center_y: 240,
              // src: 'anim_206.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 174,
              pos_y: 174,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/anim_207.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_rate: 'linear',
              anim_duration: 500,
              anim_from: 0,
              anim_to: 400,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_4_mirror = {
              anim_rate: 'linear',
              anim_duration: 500,
              anim_from: 400,
              anim_to: 0,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_4_mirror() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4_mirror);              normal_rotate_animation_lastTime_4 = now.utc;
            };

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
                normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
                normal_rotate_animation_lastTime_4 = now.utc;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 400,
              // pos_x: 66,
              // pos_y: 66,
              // center_x: 240,
              // center_y: 240,
              // src: 'anim_207.png',
              // anim_fps: 15,
              // anim_duration: 500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 194,
              pos_y: 169,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/anim_208.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_5 = {
              anim_rate: 'linear',
              anim_duration: 30000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_5_complete_call() {
              normal_rotate_animation_count_5 = normal_rotate_animation_count_5 - 1;
              if(normal_rotate_animation_count_5 < -1) normal_rotate_animation_count_5 = - 1;
                normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5);
                normal_rotate_animation_lastTime_5 = now.utc;
              if(normal_rotate_animation_count_5 == 0) stop_anim_rotate_5();
            }; // end animation callback function
            
            function stop_anim_rotate_5() {
              if (timer_anim_rotate_5) {
                timer.stopTimer(timer_anim_rotate_5);
                timer_anim_rotate_5 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_5 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 46,
              // pos_y: 71,
              // center_x: 240,
              // center_y: 240,
              // src: 'anim_208.png',
              // anim_fps: 15,
              // anim_duration: 30000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 147,
              pos_y: 147,
              src: 'animation/anim_209.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 147,
              anim_to: 147,
              anim_fps: 5,
              anim_key: "pos_x",
            };

            normal_motion_animation_paramY_1 = {
              anim_rate: 'linear',
              anim_duration: 3000,
              anim_from: 147,
              anim_to: 147,
              anim_fps: 5,
              anim_key: "pos_y",
            };

            function anim_motion_1_complete_call() {
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
                normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
                normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 147,
              // y_start: 147,
              // x_end: 147,
              // y_end: 147,
              // src: 'anim_209.png',
              // anim_fps: 5,
              // anim_duration: 3000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 98,
              src: '118.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 141,
              y: 98,
              src: '119.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 303,
              // start_angle: 181,
              // end_angle: 269,
              // radius: 112,
              // line_width: 6,
              // color: 0xFFFCBD29,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '200.png',
              center_x: 159,
              center_y: 305,
              x: 16,
              y: 94,
              start_angle: 181,
              end_angle: 269,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 71,
              y: 205,
              image_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 122,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 335,
              y: 222,
              w: 74,
              h: 30,
              text_size: 24,
              char_space: 1,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 161,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 2,
              unit_sc: '117.png',
              unit_tc: '117.png',
              unit_en: '117.png',
              negative_image: '116.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 321,
              y: 72,
              image_array: ["86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 130,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 355,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 321,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 2,
              dot_image: '115.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 285,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 384,
              day_startY: 152,
              day_sc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_tc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_en_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 318,
              y: 149,
              week_en: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_tc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_sc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 338,
              month_startY: 183,
              month_sc_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              month_tc_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              month_en_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 248,
              hour_startY: 397,
              hour_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 302,
              minute_startY: 398,
              minute_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 157,
              w: 100,
              h: 54,
              src: '5.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 86,
              w: 100,
              h: 66,
              src: '5.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 259,
              w: 100,
              h: 62,
              src: '5.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 122,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 195,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 248,
              hour_startY: 397,
              hour_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 302,
              minute_startY: 398,
              minute_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 91;
                  let end_angle_normal_battery = 179;
                  let center_x_normal_battery = 160;
                  let center_y_normal_battery = 303;
                  let radius_normal_battery = 112;
                  let line_width_cs_normal_battery = 6;
                  let color_cs_normal_battery = 0xFFFCBD29;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 8000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 30000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 10000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3*2) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    if(timer_anim_rotate_3_mirror) {
                      anim_rotate_3_mirror()
                    } else {
                      anim_rotate_3_complete_call()
                    };
                    timer_anim_rotate_3_mirror = !timer_anim_rotate_3_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 500;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4*2) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    if(timer_anim_rotate_4_mirror) {
                      anim_rotate_4_mirror()
                    } else {
                      anim_rotate_4_complete_call()
                    };
                    timer_anim_rotate_4_mirror = !timer_anim_rotate_4_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_5 = 0;
                let repeat_anim_rotate_5 = 30000;
                delay_anim_rotate_5 = repeat_anim_rotate_5 - (nawAnimationTime - normal_rotate_animation_lastTime_5);
                if(delay_anim_rotate_5 < 0) delay_anim_rotate_5 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_5) > repeat_anim_rotate_5) {
                  normal_rotate_animation_count_5 = 0;
                  timer_anim_rotate_5_mirror = false;
                };

                if (!timer_anim_rotate_5) {
                  timer_anim_rotate_5 = timer.createTimer(delay_anim_rotate_5, repeat_anim_rotate_5, (function (option) {
                    anim_rotate_5_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 3000;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    anim_motion_1_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                stop_anim_rotate_5();
                stop_anim_motion_1();

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  