﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'clock_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 350,
              font_array: ["battery-0.png","battery-1.png","battery-2.png","battery-3.png","battery-4.png","battery-5.png","battery-6.png","battery-7.png","battery-8.png","battery-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery-percent.png',
              unit_tc: 'battery-percent.png',
              unit_en: 'battery-percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 247,
              font_array: ["temp-0.png","temp-1.png","temp-2.png","temp-3.png","temp-4.png","temp-5.png","temp-6.png","temp-7.png","temp-8.png","temp-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-degree.png',
              unit_tc: 'temp-degree.png',
              unit_en: 'temp-degree.png',
              negative_image: 'temp-minus.png',
              invalid_image: 'temp-error.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 129,
              image_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 316,
              font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 358,
              font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 312,
              year_startY: 328,
              year_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              year_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              year_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 301,
              month_startY: 261,
              month_sc_array: ["month-0.png","month-1.png","month-2.png","month-3.png","month-4.png","month-5.png","month-6.png","month-7.png","month-8.png","month-9.png","month-10.png","month-11.png"],
              month_tc_array: ["month-0.png","month-1.png","month-2.png","month-3.png","month-4.png","month-5.png","month-6.png","month-7.png","month-8.png","month-9.png","month-10.png","month-11.png"],
              month_en_array: ["month-0.png","month-1.png","month-2.png","month-3.png","month-4.png","month-5.png","month-6.png","month-7.png","month-8.png","month-9.png","month-10.png","month-11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 342,
              day_startY: 232,
              day_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 299,
              y: 200,
              week_en: ["weekday-0.png","weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png"],
              week_tc: ["weekday-0.png","weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png"],
              week_sc: ["weekday-0.png","weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'clock_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 238,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'clock_minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 243,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'clock_second.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 239,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'clock_bg_aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 301,
              month_startY: 261,
              month_sc_array: ["month-0.png","month-1.png","month-2.png","month-3.png","month-4.png","month-5.png","month-6.png","month-7.png","month-8.png","month-9.png","month-10.png","month-11.png"],
              month_tc_array: ["month-0.png","month-1.png","month-2.png","month-3.png","month-4.png","month-5.png","month-6.png","month-7.png","month-8.png","month-9.png","month-10.png","month-11.png"],
              month_en_array: ["month-0.png","month-1.png","month-2.png","month-3.png","month-4.png","month-5.png","month-6.png","month-7.png","month-8.png","month-9.png","month-10.png","month-11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 342,
              day_startY: 232,
              day_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 299,
              y: 200,
              week_en: ["weekday-0.png","weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png"],
              week_tc: ["weekday-0.png","weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png"],
              week_sc: ["weekday-0.png","weekday-1.png","weekday-2.png","weekday-3.png","weekday-4.png","weekday-5.png","weekday-6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'clock_hour_aod.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 238,
              hour_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'clock_minute_aod.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 243,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  