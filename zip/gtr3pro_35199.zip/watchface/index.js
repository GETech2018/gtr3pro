﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BackgroundTH1+.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 103,
              font_array: ["0TH1+.png","1TH1+.png","2TH1+.png","3TH1+.png","4TH1+.png","5TH1+.png","6TH1+.png","7TH1+.png","8TH1+.png","9TH1+.png"],
              padding: false,
              h_space: -30,
              unit_sc: '%TH1+.png',
              unit_tc: '%TH1+.png',
              unit_en: '%TH1+.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 347,
              day_startY: 262,
              day_sc_array: ["0TH1+.png","1TH1+.png","2TH1+.png","3TH1+.png","4TH1+.png","5TH1+.png","6TH1+.png","7TH1+.png","8TH1+.png","9TH1+.png"],
              day_tc_array: ["0TH1+.png","1TH1+.png","2TH1+.png","3TH1+.png","4TH1+.png","5TH1+.png","6TH1+.png","7TH1+.png","8TH1+.png","9TH1+.png"],
              day_en_array: ["0TH1+.png","1TH1+.png","2TH1+.png","3TH1+.png","4TH1+.png","5TH1+.png","6TH1+.png","7TH1+.png","8TH1+.png","9TH1+.png"],
              day_zero: 1,
              day_space: -25,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 248,
              week_en: ["AA1LUNTH1+.png","AA2MARTH1+.png","AA3MIETH1+.png","AA4JUETH1+.png","AA5VIETH1+.png","AA6SABTH1+.png","AA7DOMTH1+.png"],
              week_tc: ["AA1LUNTH1+.png","AA2MARTH1+.png","AA3MIETH1+.png","AA4JUETH1+.png","AA5VIETH1+.png","AA6SABTH1+.png","AA7DOMTH1+.png"],
              week_sc: ["AA1LUNTH1+.png","AA2MARTH1+.png","AA3MIETH1+.png","AA4JUETH1+.png","AA5VIETH1+.png","AA6SABTH1+.png","AA7DOMTH1+.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 360,
              font_array: ["0TH1+.png","1TH1+.png","2TH1+.png","3TH1+.png","4TH1+.png","5TH1+.png","6TH1+.png","7TH1+.png","8TH1+.png","9TH1+.png"],
              padding: false,
              h_space: -25,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'AgujaChicaTH1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 5,
              minute_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'AgujaGrandeTH1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 13,
              hour_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
