﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'digi2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 356,
              image_array: ["MoonPhase0001.png","MoonPhase0002.png","MoonPhase0003.png","MoonPhase0004.png","MoonPhase0005.png","MoonPhase0006.png","MoonPhase0007.png","MoonPhase0008.png","MoonPhase0009.png","MoonPhase0010.png","MoonPhase0011.png","MoonPhase0012.png","MoonPhase0013.png","MoonPhase0014.png","MoonPhase0015.png","MoonPhase0016.png","MoonPhase0017.png","MoonPhase0018.png","MoonPhase0019.png","MoonPhase0020.png","MoonPhase0021.png","MoonPhase0022.png","MoonPhase0023.png","MoonPhase0024.png","MoonPhase0025.png","MoonPhase0026.png","MoonPhase0027.png","MoonPhase0028.png","MoonPhase0029.png","MoonPhase0030.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 130,
              y: 96,
              week_en: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_tc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              week_sc: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 59,
              y: 366,
              src: '0246.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 366,
              src: '0247.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 401,
              font_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png"],
              padding: false,
              h_space: 5,
              angle: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 109,
              y: 372,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 317,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              unit_sc: '0019.png',
              unit_tc: '0019.png',
              unit_en: '0019.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 317,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 317,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 137,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 137,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 137,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              dot_image: 'data_raz.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 5,
              month_startY: 4,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 64,
              font_array: ["vz_00.png","vz_01.png","vz_02.png","vz_03.png","vz_04.png","vz_05.png","vz_06.png","vz_07.png","vz_08.png","vz_09.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              dot_image: 'vz_raz.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 64,
              font_array: ["vz_00.png","vz_01.png","vz_02.png","vz_03.png","vz_04.png","vz_05.png","vz_06.png","vz_07.png","vz_08.png","vz_09.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              dot_image: 'vz_raz.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 43,
              day_sc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              day_tc_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              day_en_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 216,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 184,
              minute_startY: 216,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 321,
              second_startY: 216,
              second_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'digi3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 59,
              y: 366,
              src: '0246.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 366,
              src: '0247.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 317,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: 7,
              angle: 0,
              unit_sc: '0019.png',
              unit_tc: '0019.png',
              unit_en: '0019.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AODblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 216,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 184,
              minute_startY: 216,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 321,
              second_startY: 216,
              second_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AODblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}