﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_frame_animation_1 = ''
        let normal_stand_icon_img = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 219,
              src: '0406.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 446,
              y: 219,
              src: '0405.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 115,
              y: 57,
              week_en: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png"],
              week_tc: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png"],
              week_sc: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 158,
              y: 386,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "test_anim",
              anim_fps: 15,
              anim_size: 30,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 148,
              src: 'A-STAND.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 150,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 148,
              src: 'A-CAL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 150,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 148,
              src: 'A-STEP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 150,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 440,
              font_array: ["A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'P_Symbol.png',
              unit_tc: 'P_Symbol.png',
              unit_en: 'P_Symbol.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 436,
              image_array: ["BAT1_(1).png","BAT1_(10).png","BAT1_(2).png","BAT1_(3).png","BAT1_(4).png","BAT1_(5).png","BAT1_(6).png","BAT1_(7).png","BAT1_(8).png","BAT1_(9).png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 196,
              y: 97,
              image_array: ["weather00.png","weather01.png","weather02.png","weather03.png","weather04.png","weather05.png","weather06.png","weather07.png","weather08.png","weather09.png","weather10.png","weather11.png","weather12.png","weather13.png","weather14.png","weather15.png","weather16.png","weather17.png","weather18.png","weather19.png","weather20.png","weather21.png","weather22.png","weather23.png","weather24.png","weather25.png","weather26.png","weather27.png","weather28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 101,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'A100_126.png',
              unit_tc: 'A100_126.png',
              unit_en: 'A100_126.png',
              imperial_unit_sc: 'A100_126.png',
              imperial_unit_tc: 'A100_126.png',
              imperial_unit_en: 'A100_126.png',
              negative_image: 'A100_124.png',
              invalid_image: 'A100_125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 103,
              y: 270,
              src: '0154.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 284,
              font_array: ["A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'A100_078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 20,
              day_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 23,
              src: 'A100_101.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 250,
              month_startY: 20,
              month_sc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_tc_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_en_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 340,
              src: 'A100_143.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 346,
              font_array: ["A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png","A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_127.png',
              unit_tc: 'A100_127.png',
              unit_en: 'A100_127.png',
              invalid_image: 'A100_112.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 206,
              hour_array: ["A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_042.png',
              hour_unit_tc: 'A100_042.png',
              hour_unit_en: 'A100_042.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'A100_042.png',
              minute_unit_tc: 'A100_042.png',
              minute_unit_en: 'A100_042.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 0,
              second_startY: 0,
              second_array: ["A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 206,
              hour_array: ["A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_042.png',
              hour_unit_tc: 'A100_042.png',
              hour_unit_en: 'A100_042.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'A100_042.png',
              minute_unit_tc: 'A100_042.png',
              minute_unit_en: 'A100_042.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 0,
              second_startY: 0,
              second_array: ["A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}