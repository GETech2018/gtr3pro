﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'IMG_20221001_191530_539[1].png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 280,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: -2,
              dot_image: '1_naverno_(36).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 280,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: -2,
              dot_image: '1_naverno_(36).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 261,
              image_array: ["1_naverno_(38).png","1_naverno_(39).png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 184,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 341,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 285,
              y: 310,
              src: '0080.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 175,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 175,
              image_array: ["BATT_01.png","BATT_02.png","BATT_03.png","BATT_04.png","BATT_05.png","BATT_06.png","BATT_07.png","BATT_08.png","BATT_09.png","BATT_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 109,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 109,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 144,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 317,
              day_startY: 109,
              day_sc_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              day_tc_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              day_en_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 311,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 328,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 372,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 372,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 207,
              hour_startY: 220,
              hour_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 316,
              minute_startY: 220,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 363,
              second_startY: 281,
              second_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              second_zero: 0,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'IMG_20221001_191530_539[1].png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 280,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: -2,
              dot_image: '1_naverno_(36).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 280,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: -2,
              dot_image: '1_naverno_(36).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 261,
              image_array: ["1_naverno_(38).png","1_naverno_(39).png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 184,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 341,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 285,
              y: 310,
              src: '0080.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 175,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 175,
              image_array: ["BATT_01.png","BATT_02.png","BATT_03.png","BATT_04.png","BATT_05.png","BATT_06.png","BATT_07.png","BATT_08.png","BATT_09.png","BATT_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 109,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 109,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 144,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 317,
              day_startY: 109,
              day_sc_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              day_tc_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              day_en_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 311,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 328,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 372,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 372,
              font_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 207,
              hour_startY: 220,
              hour_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 316,
              minute_startY: 220,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 363,
              second_startY: 281,
              second_array: ["000000000001_(46).png","000000000001_(47).png","000000000001_(48).png","000000000001_(49).png","000000000001_(50).png","000000000001_(51).png","000000000001_(52).png","000000000001_(53).png","000000000001_(54).png","000000000001_(55).png"],
              second_zero: 0,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  