﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 269,
              year_startY: 140,
              year_sc_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              year_tc_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              year_en_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 140,
              month_sc_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              month_tc_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              month_en_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digital15_10.png',
              month_unit_tc: 'digital15_10.png',
              month_unit_en: 'digital15_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 140,
              day_sc_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              day_tc_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              day_en_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital15_10.png',
              day_unit_tc: 'digital15_10.png',
              day_unit_en: 'digital15_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 207,
              y: 116,
              week_en: ["digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png"],
              week_tc: ["digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png"],
              week_sc: ["digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 210,
              font_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'digital11_11.png',
              unit_tc: 'digital11_11.png',
              unit_en: 'digital11_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital2_00.png","digital2_01.png","digital2_02.png","digital2_03.png","digital2_04.png","digital2_05.png","digital2_06.png","digital2_07.png","digital2_08.png","digital2_09.png","digital2_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 247,
              font_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital4_0.png","digital4_1.png","digital4_2.png","digital4_3.png","digital4_4.png","digital4_5.png","digital4_6.png","digital4_7.png","digital4_8.png","digital4_9.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 247,
              font_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 210,
              font_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 285,
              font_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital16_11.png',
              unit_tc: 'digital16_11.png',
              unit_en: 'digital16_11.png',
              negative_image: 'digital16_10.png',
              invalid_image: 'digital16_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 324,
              image_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 103,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'image3.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 35,
              hour_posY: 120,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'image4.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 31,
              minute_posY: 194,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'image5.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 234,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 210,
              font_array: ["digital11_00.png","digital11_01.png","digital11_02.png","digital11_03.png","digital11_04.png","digital11_05.png","digital11_06.png","digital11_07.png","digital11_08.png","digital11_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'digital11_11.png',
              unit_tc: 'digital11_11.png',
              unit_en: 'digital11_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 103,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'image3.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 35,
              hour_posY: 120,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'image4.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 31,
              minute_posY: 194,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  