﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 46;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_date_img_date_week_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg017.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 31,
              month_sc_array: ["chars_A6172BD7_000.png","chars_A6172BD7_001.png","chars_A6172BD7_002.png","chars_A6172BD7_003.png","chars_A6172BD7_004.png","chars_A6172BD7_005.png","chars_A6172BD7_006.png","chars_A6172BD7_007.png","chars_A6172BD7_008.png","chars_A6172BD7_009.png","chars_A6172BD7_010.png","chars_A6172BD7_011.png"],
              month_tc_array: ["chars_A6172BD7_000.png","chars_A6172BD7_001.png","chars_A6172BD7_002.png","chars_A6172BD7_003.png","chars_A6172BD7_004.png","chars_A6172BD7_005.png","chars_A6172BD7_006.png","chars_A6172BD7_007.png","chars_A6172BD7_008.png","chars_A6172BD7_009.png","chars_A6172BD7_010.png","chars_A6172BD7_011.png"],
              month_en_array: ["chars_A6172BD7_000.png","chars_A6172BD7_001.png","chars_A6172BD7_002.png","chars_A6172BD7_003.png","chars_A6172BD7_004.png","chars_A6172BD7_005.png","chars_A6172BD7_006.png","chars_A6172BD7_007.png","chars_A6172BD7_008.png","chars_A6172BD7_009.png","chars_A6172BD7_010.png","chars_A6172BD7_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 298,
              src: 'custom_icon_1784272456173_48x48.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 383,
              y: 120,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 131,
              hour_array: ["chars_6B5A5637_000.png","chars_6B5A5637_001.png","chars_6B5A5637_002.png","chars_6B5A5637_003.png","chars_6B5A5637_004.png","chars_6B5A5637_005.png","chars_6B5A5637_006.png","chars_6B5A5637_007.png","chars_6B5A5637_008.png","chars_6B5A5637_009.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 186,
              minute_startY: 131,
              minute_array: ["chars_6B5A5637_000.png","chars_6B5A5637_001.png","chars_6B5A5637_002.png","chars_6B5A5637_003.png","chars_6B5A5637_004.png","chars_6B5A5637_005.png","chars_6B5A5637_006.png","chars_6B5A5637_007.png","chars_6B5A5637_008.png","chars_6B5A5637_009.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 354,
              second_startY: 155,
              second_array: ["chars_235A431D_000.png","chars_235A431D_001.png","chars_235A431D_002.png","chars_235A431D_003.png","chars_235A431D_004.png","chars_235A431D_005.png","chars_235A431D_006.png","chars_235A431D_007.png","chars_235A431D_008.png","chars_235A431D_009.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 116,
              day_startY: 36,
              day_sc_array: ["chars_89A8754B_000.png","chars_89A8754B_001.png","chars_89A8754B_002.png","chars_89A8754B_003.png","chars_89A8754B_004.png","chars_89A8754B_005.png","chars_89A8754B_006.png","chars_89A8754B_007.png","chars_89A8754B_008.png","chars_89A8754B_009.png"],
              day_tc_array: ["chars_89A8754B_000.png","chars_89A8754B_001.png","chars_89A8754B_002.png","chars_89A8754B_003.png","chars_89A8754B_004.png","chars_89A8754B_005.png","chars_89A8754B_006.png","chars_89A8754B_007.png","chars_89A8754B_008.png","chars_89A8754B_009.png"],
              day_en_array: ["chars_89A8754B_000.png","chars_89A8754B_001.png","chars_89A8754B_002.png","chars_89A8754B_003.png","chars_89A8754B_004.png","chars_89A8754B_005.png","chars_89A8754B_006.png","chars_89A8754B_007.png","chars_89A8754B_008.png","chars_89A8754B_009.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 253,
              font_array: ["chars_B008D927_000.png","chars_B008D927_001.png","chars_B008D927_002.png","chars_B008D927_003.png","chars_B008D927_004.png","chars_B008D927_005.png","chars_B008D927_006.png","chars_B008D927_007.png","chars_B008D927_008.png","chars_B008D927_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 285,
              image_array: ["set_4_195x25_h204s200b42_img_level_1.png","set_4_195x25_h204s200b42_img_level_2.png","set_4_195x25_h204s200b42_img_level_3.png","set_4_195x25_h204s200b42_img_level_4.png","set_4_195x25_h204s200b42_img_level_5.png","set_4_195x25_h204s200b42_img_level_6.png","set_4_195x25_h204s200b42_img_level_7.png","set_4_195x25_h204s200b42_img_level_8.png","set_4_195x25_h204s200b42_img_level_9.png","set_4_195x25_h204s200b42_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 412,
              font_array: ["chars_955F042C_000.png","chars_955F042C_001.png","chars_955F042C_002.png","chars_955F042C_003.png","chars_955F042C_004.png","chars_955F042C_005.png","chars_955F042C_006.png","chars_955F042C_007.png","chars_955F042C_008.png","chars_955F042C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 422,
              src: 'hearticon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 355,
              font_array: ["chars_955F042C_000.png","chars_955F042C_001.png","chars_955F042C_002.png","chars_955F042C_003.png","chars_955F042C_004.png","chars_955F042C_005.png","chars_955F042C_006.png","chars_955F042C_007.png","chars_955F042C_008.png","chars_955F042C_009.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 348,
              src: 'step_3_26x50.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 254,
              src: 'i01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 254,
              image_array: ["i02.png","i03.png","i04.png","i05.png","i06.png","i07.png","i08.png","i09.png","i10.png","i11.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 297,
              font_array: ["chars_955F042C_000.png","chars_955F042C_001.png","chars_955F042C_002.png","chars_955F042C_003.png","chars_955F042C_004.png","chars_955F042C_005.png","chars_955F042C_006.png","chars_955F042C_007.png","chars_955F042C_008.png","chars_955F042C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 292,
              src: 'cal_1_25x50.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 370,
              font_array: ["chars_DF0BCB80_000.png","chars_DF0BCB80_001.png","chars_DF0BCB80_002.png","chars_DF0BCB80_003.png","chars_DF0BCB80_004.png","chars_DF0BCB80_005.png","chars_DF0BCB80_006.png","chars_DF0BCB80_007.png","chars_DF0BCB80_008.png","chars_DF0BCB80_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_DF0BCB80_011.png',
              unit_tc: 'chars_DF0BCB80_011.png',
              unit_en: 'chars_DF0BCB80_011.png',
              negative_image: 'chars_DF0BCB80_010.png',
              invalid_image: 'chars_DF0BCB80_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 353,
              image_array: ["set_5_71x71_meteo_1.png","set_5_71x71_meteo_2.png","set_5_71x71_meteo_3.png","set_5_71x71_meteo_4.png","set_5_71x71_meteo_5.png","set_5_71x71_meteo_6.png","set_5_71x71_meteo_7.png","set_5_71x71_meteo_8.png","set_5_71x71_meteo_9.png","set_5_71x71_meteo_10.png","set_5_71x71_meteo_11.png","set_5_71x71_meteo_12.png","set_5_71x71_meteo_13.png","set_5_71x71_meteo_14.png","set_5_71x71_meteo_15.png","set_5_71x71_meteo_16.png","set_5_71x71_meteo_17.png","set_5_71x71_meteo_18.png","set_5_71x71_meteo_19.png","set_5_71x71_meteo_20.png","set_5_71x71_meteo_21.png","set_5_71x71_meteo_22.png","set_5_71x71_meteo_23.png","set_5_71x71_meteo_24.png","set_5_71x71_meteo_25.png","set_5_71x71_meteo_26.png","set_5_71x71_meteo_27.png","set_5_71x71_meteo_28.png","set_5_71x71_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 305,
              y: 312,
              w: 145,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 260,
              y: 74,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg017.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 31,
              month_sc_array: ["chars_A6172BD7_000.png","chars_A6172BD7_001.png","chars_A6172BD7_002.png","chars_A6172BD7_003.png","chars_A6172BD7_004.png","chars_A6172BD7_005.png","chars_A6172BD7_006.png","chars_A6172BD7_007.png","chars_A6172BD7_008.png","chars_A6172BD7_009.png","chars_A6172BD7_010.png","chars_A6172BD7_011.png"],
              month_tc_array: ["chars_A6172BD7_000.png","chars_A6172BD7_001.png","chars_A6172BD7_002.png","chars_A6172BD7_003.png","chars_A6172BD7_004.png","chars_A6172BD7_005.png","chars_A6172BD7_006.png","chars_A6172BD7_007.png","chars_A6172BD7_008.png","chars_A6172BD7_009.png","chars_A6172BD7_010.png","chars_A6172BD7_011.png"],
              month_en_array: ["chars_A6172BD7_000.png","chars_A6172BD7_001.png","chars_A6172BD7_002.png","chars_A6172BD7_003.png","chars_A6172BD7_004.png","chars_A6172BD7_005.png","chars_A6172BD7_006.png","chars_A6172BD7_007.png","chars_A6172BD7_008.png","chars_A6172BD7_009.png","chars_A6172BD7_010.png","chars_A6172BD7_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 298,
              src: 'custom_icon_1784272456173_48x48.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 383,
              y: 120,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 131,
              hour_array: ["chars_6B5A5637_000.png","chars_6B5A5637_001.png","chars_6B5A5637_002.png","chars_6B5A5637_003.png","chars_6B5A5637_004.png","chars_6B5A5637_005.png","chars_6B5A5637_006.png","chars_6B5A5637_007.png","chars_6B5A5637_008.png","chars_6B5A5637_009.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 186,
              minute_startY: 131,
              minute_array: ["chars_6B5A5637_000.png","chars_6B5A5637_001.png","chars_6B5A5637_002.png","chars_6B5A5637_003.png","chars_6B5A5637_004.png","chars_6B5A5637_005.png","chars_6B5A5637_006.png","chars_6B5A5637_007.png","chars_6B5A5637_008.png","chars_6B5A5637_009.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 354,
              // y: 155,
              // font_array: ["chars_235A431D_000.png","chars_235A431D_001.png","chars_235A431D_002.png","chars_235A431D_003.png","chars_235A431D_004.png","chars_235A431D_005.png","chars_235A431D_006.png","chars_235A431D_007.png","chars_235A431D_008.png","chars_235A431D_009.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = 'chars_235A431D_000.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = 'chars_235A431D_001.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = 'chars_235A431D_002.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = 'chars_235A431D_003.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = 'chars_235A431D_004.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = 'chars_235A431D_005.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = 'chars_235A431D_006.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = 'chars_235A431D_007.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = 'chars_235A431D_008.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = 'chars_235A431D_009.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 354,
                center_y: 155,
                pos_x: 354,
                pos_y: 155,
                angle: 0,
                src: 'chars_235A431D_000.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 116,
              day_startY: 36,
              day_sc_array: ["chars_89A8754B_000.png","chars_89A8754B_001.png","chars_89A8754B_002.png","chars_89A8754B_003.png","chars_89A8754B_004.png","chars_89A8754B_005.png","chars_89A8754B_006.png","chars_89A8754B_007.png","chars_89A8754B_008.png","chars_89A8754B_009.png"],
              day_tc_array: ["chars_89A8754B_000.png","chars_89A8754B_001.png","chars_89A8754B_002.png","chars_89A8754B_003.png","chars_89A8754B_004.png","chars_89A8754B_005.png","chars_89A8754B_006.png","chars_89A8754B_007.png","chars_89A8754B_008.png","chars_89A8754B_009.png"],
              day_en_array: ["chars_89A8754B_000.png","chars_89A8754B_001.png","chars_89A8754B_002.png","chars_89A8754B_003.png","chars_89A8754B_004.png","chars_89A8754B_005.png","chars_89A8754B_006.png","chars_89A8754B_007.png","chars_89A8754B_008.png","chars_89A8754B_009.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 253,
              font_array: ["chars_B008D927_000.png","chars_B008D927_001.png","chars_B008D927_002.png","chars_B008D927_003.png","chars_B008D927_004.png","chars_B008D927_005.png","chars_B008D927_006.png","chars_B008D927_007.png","chars_B008D927_008.png","chars_B008D927_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 285,
              image_array: ["set_4_195x25_h204s200b42_img_level_1.png","set_4_195x25_h204s200b42_img_level_2.png","set_4_195x25_h204s200b42_img_level_3.png","set_4_195x25_h204s200b42_img_level_4.png","set_4_195x25_h204s200b42_img_level_5.png","set_4_195x25_h204s200b42_img_level_6.png","set_4_195x25_h204s200b42_img_level_7.png","set_4_195x25_h204s200b42_img_level_8.png","set_4_195x25_h204s200b42_img_level_9.png","set_4_195x25_h204s200b42_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 412,
              font_array: ["chars_955F042C_000.png","chars_955F042C_001.png","chars_955F042C_002.png","chars_955F042C_003.png","chars_955F042C_004.png","chars_955F042C_005.png","chars_955F042C_006.png","chars_955F042C_007.png","chars_955F042C_008.png","chars_955F042C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 422,
              src: 'hearticon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 355,
              font_array: ["chars_955F042C_000.png","chars_955F042C_001.png","chars_955F042C_002.png","chars_955F042C_003.png","chars_955F042C_004.png","chars_955F042C_005.png","chars_955F042C_006.png","chars_955F042C_007.png","chars_955F042C_008.png","chars_955F042C_009.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 348,
              src: 'step_3_26x50.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 254,
              src: 'i01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 254,
              image_array: ["i02.png","i03.png","i04.png","i05.png","i06.png","i07.png","i08.png","i09.png","i10.png","i11.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 297,
              font_array: ["chars_955F042C_000.png","chars_955F042C_001.png","chars_955F042C_002.png","chars_955F042C_003.png","chars_955F042C_004.png","chars_955F042C_005.png","chars_955F042C_006.png","chars_955F042C_007.png","chars_955F042C_008.png","chars_955F042C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 292,
              src: 'cal_1_25x50.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 370,
              font_array: ["chars_DF0BCB80_000.png","chars_DF0BCB80_001.png","chars_DF0BCB80_002.png","chars_DF0BCB80_003.png","chars_DF0BCB80_004.png","chars_DF0BCB80_005.png","chars_DF0BCB80_006.png","chars_DF0BCB80_007.png","chars_DF0BCB80_008.png","chars_DF0BCB80_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_DF0BCB80_011.png',
              unit_tc: 'chars_DF0BCB80_011.png',
              unit_en: 'chars_DF0BCB80_011.png',
              negative_image: 'chars_DF0BCB80_010.png',
              invalid_image: 'chars_DF0BCB80_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 353,
              image_array: ["set_5_71x71_meteo_1.png","set_5_71x71_meteo_2.png","set_5_71x71_meteo_3.png","set_5_71x71_meteo_4.png","set_5_71x71_meteo_5.png","set_5_71x71_meteo_6.png","set_5_71x71_meteo_7.png","set_5_71x71_meteo_8.png","set_5_71x71_meteo_9.png","set_5_71x71_meteo_10.png","set_5_71x71_meteo_11.png","set_5_71x71_meteo_12.png","set_5_71x71_meteo_13.png","set_5_71x71_meteo_14.png","set_5_71x71_meteo_15.png","set_5_71x71_meteo_16.png","set_5_71x71_meteo_17.png","set_5_71x71_meteo_18.png","set_5_71x71_meteo_19.png","set_5_71x71_meteo_20.png","set_5_71x71_meteo_21.png","set_5_71x71_meteo_22.png","set_5_71x71_meteo_23.png","set_5_71x71_meteo_24.png","set_5_71x71_meteo_25.png","set_5_71x71_meteo_26.png","set_5_71x71_meteo_27.png","set_5_71x71_meteo_28.png","set_5_71x71_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 305,
              y: 312,
              w: 145,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 260,
              y: 74,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 345,
              w: 150,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 405,
              w: 115,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 285,
              w: 160,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 345,
              w: 70,
              h: 70,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 345,
              w: 80,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 238,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 130,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 155,
              w: 100,
              h: 55,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 80,
              w: 70,
              h: 70,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 5,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 215,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 354 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}