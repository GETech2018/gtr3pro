    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_step_current_text_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 400,
              y: 320,
              src: '0213.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 443,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 3,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 437,
              day_startY: 220,
              day_sc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_tc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_en_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 407,
              y: 170,
              week_en: ["GD001.png","GD002.png","GD003.png","GD004.png","GD005.png","GD006.png","GD007.png"],
              week_tc: ["GD001.png","GD002.png","GD003.png","GD004.png","GD005.png","GD006.png","GD007.png"],
              week_sc: ["GD001.png","GD002.png","GD003.png","GD004.png","GD005.png","GD006.png","GD007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 45,
              hour_array: ["o000.png","o001.png","o002.png","o003.png","o004.png","o005.png","o006.png","o007.png","o008.png","o009.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 86,
              minute_startY: 236,
              minute_array: ["l000.png","l001.png","l002.png","l003.png","l004.png","l005.png","l006.png","l007.png","l008.png","l009.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 400,
              y: 320,
              src: '0213.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 443,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 3,
              font_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 437,
              day_startY: 220,
              day_sc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_tc_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_en_array: ["D000.png","D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 407,
              y: 170,
              week_en: ["GD001.png","GD002.png","GD003.png","GD004.png","GD005.png","GD006.png","GD007.png"],
              week_tc: ["GD001.png","GD002.png","GD003.png","GD004.png","GD005.png","GD006.png","GD007.png"],
              week_sc: ["GD001.png","GD002.png","GD003.png","GD004.png","GD005.png","GD006.png","GD007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 45,
              hour_array: ["oaod000.png","oaod001.png","oaod002.png","oaod003.png","oaod004.png","oaod005.png","oaod006.png","oaod007.png","oaod008.png","oaod009.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_align: hmUI.align.LEFT,

              minute_startX: 86,
              minute_startY: 236,
              minute_array: ["laod000.png","laod001.png","laod002.png","laod003.png","laod004.png","laod005.png","laod006.png","laod007.png","laod008.png","laod009.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // required variables
            const valueImg = new Array(5);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY[i] = "number_" + i + ".png";  // set of images with numbers
            }
            let units_img = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const X = 480/2;                // X coordinate of the top left corner of the inscription
            const Y = 480/2;                // Y coordinate of the top left corner of the inscription. The point specified by the coordinates is on the top edge of the displayed symbols.
            const Angle = 90;               // The angle of the inscription, 0 degrees corresponds to the horizontal position of the inscription
            const CharSpace = 0;            // Space between characters
            const ImageWidht = 30;          // Width of character image
            const ImageHeight = 35;         // Height of character image
            const UnitsWidht = 50;          // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
            const Aligment = 0;            // -1=Left aligment; 0=Centr aligment; 1=Right aligment.
            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            const Diagonal = Math.hypot(ImageWidht, ImageHeight);
            const DiagonalUnits = Math.hypot(UnitsWidht, ImageHeight);
            let WI_size = Diagonal * 2;                    // Widget hight and widht
            let WI_units_size = DiagonalUnits * 2;         // Widget units hight and widht
            // *******************************************************************
            let char_delta_x = Math.cos(toRadian(Angle)) * ( ImageWidht + CharSpace );  // Change the x-coordinate for each subsequent character.
		        let char_delta_y = Math.sin(toRadian(Angle)) * ( ImageWidht + CharSpace );  // Change the y-coordinate for each subsequent character.
            let StartPosX = 62;
            let StartPosY = 135;
            // *******************************************************************
            // Auxiliary functions
            function toRadian(degree) {
                return degree * (Math.PI / 180);
            };
            // *******************************************************************

            for ( let i = 0; i < 5; i++ ){
              valueImg[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            
            units_img = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() { text_rotate() });  // Should update the text on the AOD screen if the data has changed
            
            
            function text_rotate() {  //  Get the parameter value and display it

              console.log('update STEP');
              
              let stepCurrent=step.current;
              let stepString = String(stepCurrent);
              let index = 0;
              valueImg[0].setProperty(hmUI.prop.SRC, "error.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(stepCurrent) && stepString.length>0 && stepString.length<6) {  // display data if it was possible to get it
                switch(Aligment)
                {
                  case -1:
                    console.log('Left aligment');
                    StartPosX = 62;
                    StartPosY = 135;
                    break;
                  case 0:
                    console.log('Centr aligment');
                    StartPosX = 62 - Math.cos(toRadian(Angle)) * ( ImageWidht*stepString.length/2 + CharSpace*(stepString.length-1)/2 );
                    StartPosY = 235 - Math.sin(toRadian(Angle)) * ( ImageWidht*stepString.length/2 + CharSpace*(stepString.length-1)/2 );
                    break;
                  case 1:
                    console.log('Right aligment');
                    StartPosX = 20 - Math.cos(toRadian(Angle)) * ( ImageWidht*stepString.length + CharSpace*(stepString.length-1) );
                    StartPosY = 170 - Math.sin(toRadian(Angle)) * ( ImageWidht*stepString.length + CharSpace*(stepString.length-1) );
                    break;
                }

                for (let char of stepString) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  if(charCode >= 0 && charCode < 10) valueImg[index].setProperty(hmUI.prop.MORE, {  
                    x: StartPosX - Diagonal + char_delta_x * index,
                    y: StartPosY - Diagonal + char_delta_y * index,
                    w: WI_size,
                    h: WI_size,
                    pos_x: Diagonal,
                    pos_y: Diagonal,
                    center_x: Diagonal,
                    center_y:  Diagonal,
                    angle: Angle,
                    src: ASCIIARRAY[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  
                  units_img.setProperty(hmUI.prop.VISIBLE, true);
                  units_img.setProperty(hmUI.prop.MORE, {  // calculate the position of the unit image
                    x: StartPosX - DiagonalUnits + char_delta_x * stepString.length,
                    y: StartPosY - DiagonalUnits + char_delta_y * stepString.length,
                    w: WI_units_size,
                    h: WI_units_size,
                    pos_x: DiagonalUnits,
                    pos_y: DiagonalUnits,
                    center_x: DiagonalUnits,
                    center_y:  DiagonalUnits,
                    angle: Angle,
                    src: "steps.png",  // unit image
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                switch(Aligment)
                {
                  case -1:
                    StartPosX = 62;
                    StartPosY = 135;
                    break;
                  case 0:
                    StartPosX = 62 - Math.cos(toRadian(Angle)) * ( ImageWidht*0.5 );
                    StartPosY = 135 - Math.sin(toRadian(Angle)) * ( ImageWidht*0.5 );
                    break;
                  case 1:
                    StartPosX = 62 - Math.cos(toRadian(Angle)) * ( ImageWidht );
                    StartPosY = 135 - Math.sin(toRadian(Angle)) * ( ImageWidht );
                    break;
                }
                valueImg[0].setProperty(hmUI.prop.MORE, {  
                  x: StartPosX - Diagonal + char_delta_x * index,
                  y: StartPosY - Diagonal + char_delta_y * index,
                  w: WI_size,
                  h: WI_size,
                  pos_x: Diagonal,
                  pos_y: Diagonal,
                  center_x: Diagonal,
                  center_y:  Diagonal,
                  angle: Angle,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            }; 
       
         const widgetDelegate =             hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_rotate();  // update text when screen turns off
              }),
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 1,
              w: 122,
              h: 35,
              src: 'transparent_img.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 163,
              w: 58,
              h: 156,
              src: 'transparent_img.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
