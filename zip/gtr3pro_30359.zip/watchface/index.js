﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'b0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 153,
              font_array: ["u0.png","u1.png","u2.png","u3.png","u4.png","u5.png","u6.png","u7.png","u8.png","u9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'vtch.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 304,
              font_array: ["u0.png","u1.png","u2.png","u3.png","u4.png","u5.png","u6.png","u7.png","u8.png","u9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'vprc.png',
              unit_tc: 'vprc.png',
              unit_en: 'vprc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 153,
              font_array: ["u0.png","u1.png","u2.png","u3.png","u4.png","u5.png","u6.png","u7.png","u8.png","u9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 122,
              month_sc_array: ["k001.png","k002.png","k003.png","k004.png","k005.png","k006.png","k007.png","k008.png","k009.png","k010.png","k011.png","k012.png"],
              month_tc_array: ["k001.png","k002.png","k003.png","k004.png","k005.png","k006.png","k007.png","k008.png","k009.png","k010.png","k011.png","k012.png"],
              month_en_array: ["k001.png","k002.png","k003.png","k004.png","k005.png","k006.png","k007.png","k008.png","k009.png","k010.png","k011.png","k012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 71,
              day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 363,
              font_array: ["j0007.png","j0008.png","j0009.png","j0010.png","j0011.png","j0012.png","j0013.png","j0014.png","j0015.png","j0016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 363,
              font_array: ["j0007.png","j0008.png","j0009.png","j0010.png","j0011.png","j0012.png","j0013.png","j0014.png","j0015.png","j0016.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 364,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gr.png',
              unit_tc: 'gr.png',
              unit_en: 'gr.png',
              negative_image: 'mn.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0017.png',
              center_x: 240,
              center_y: 243,
              x: 18,
              y: 239,
              start_angle: 800,
              end_angle: 61,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 401,
              y: 169,
              src: 'y3.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 61,
              y: 169,
              src: 'y2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 295,
              src: 'y4.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 63,
              y: 296,
              src: 'y1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 420,
              y: 140,
              image_array: ["0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              image_length: 7,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 224,
              font_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 130,
              image_array: ["0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 224,
              font_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0017.png',
              center_x: 240,
              center_y: 240,
              posX: 18,
              posY: 239,
              start_angle: 308,
              end_angle: 401,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 137,
              hour_startY: 203,
              hour_array: ["w0.png","w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png","w8.png","w9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 203,
              minute_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 285,
              second_startY: 304,
              second_array: ["u0.png","u1.png","u2.png","u3.png","u4.png","u5.png","u6.png","u7.png","u8.png","u9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 58,
              w: 106,
              h: 106,
              src: 'pst.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 335,
              w: 106,
              h: 106,
              src: 'pst.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 26,
              y: 185,
              w: 106,
              h: 106,
              src: 'pst.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 181,
              w: 106,
              h: 106,
              src: 'pst.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0160.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 155,
              week_en: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
              week_tc: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
              week_sc: ["0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 344,
              month_sc_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              month_tc_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              month_en_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              month_zero: 0,
              month_space: 4,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 64,
              day_sc_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              day_tc_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              day_en_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              day_zero: 0,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 204,
              hour_array: ["w0.png","w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png","w8.png","w9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 334,
              minute_startY: 204,
              minute_array: ["w0.png","w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png","w8.png","w9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0161.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 28,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0162.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 26,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0163.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 228,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  