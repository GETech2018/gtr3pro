﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_icon_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Casio_1500_C.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 145,
              // center_y: 117,
              // start_angle: 0,
              // end_angle: 361,
              // radius: 42,
              // line_width: 14,
              // color: 0xFF001100,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 359,
              src: '0266.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 364,
              src: '0255.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 111,
              src: 'Pro0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 372,
              y: 111,
              image_array: ["Pro0001.png","Pro0002.png","Pro0003.png","Pro0004.png","Pro0005.png","Pro0006.png","Pro0007.png","Pro0008.png","Pro0009.png","Pro0010.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 175,
              hour_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 235,
              minute_startY: 175,
              minute_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 209,
              second_startY: 337,
              second_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 317,
              am_y: 317,
              am_sc_path: 'PM0000.png',
              am_en_path: 'PM0000.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'PM0000.png',
              pm_en_path: 'PM0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 98,
              month_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 98,
              day_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 165,
              w: 165,
              h: 157,
              src: 'Dig0001.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 164,
              w: 149,
              h: 156,
              src: 'Dig0001.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 46,
              y: 335,
              w: 173,
              h: 155,
              src: 'Dig0001.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 0,
              w: 187,
              h: 155,
              src: 'Dig0001.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 253,
              y: 2,
              w: 160,
              h: 155,
              src: 'Dig0001.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 392,
              y: 164,
              w: 103,
              h: 159,
              src: 'Dig0001.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 332,
              w: 205,
              h: 151,
              src: 'Dig0001.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Casio_1500_C.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 145,
              // center_y: 117,
              // start_angle: 0,
              // end_angle: 361,
              // radius: 42,
              // line_width: 14,
              // color: 0xFF001100,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 359,
              src: '0266.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 364,
              src: '0255.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 111,
              src: 'Pro0000.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 372,
              y: 111,
              image_array: ["Pro0001.png","Pro0002.png","Pro0003.png","Pro0004.png","Pro0005.png","Pro0006.png","Pro0007.png","Pro0008.png","Pro0009.png","Pro0010.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 175,
              hour_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 235,
              minute_startY: 175,
              minute_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 209,
              second_startY: 337,
              second_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 317,
              am_y: 317,
              am_sc_path: 'PM0000.png',
              am_en_path: 'PM0000.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'PM0000.png',
              pm_en_path: 'PM0000.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 98,
              month_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 98,
              day_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 271;
                  let center_x_normal_battery = 145;
                  let center_y_normal_battery = 117;
                  let radius_normal_battery = 42;
                  let line_width_cs_normal_battery = 14;
                  let color_cs_normal_battery = 0xFF001100;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -90;
                  let end_angle_idle_battery = 271;
                  let center_x_idle_battery = 145;
                  let center_y_idle_battery = 117;
                  let radius_idle_battery = 42;
                  let line_width_cs_idle_battery = 14;
                  let color_cs_idle_battery = 0xFF001100;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  