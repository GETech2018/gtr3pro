﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
		
		/**
     * SMOOTH SECONDS SCRIPTS
     */
    let now;
    let lastTime = 0;
    let animTimer;
    let widgetDelegate;
    const animDuration = 5000;
    const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion

    function setSec() {
      const screenType = hmSetting.getScreenType();
      if (screenType === hmSetting.screen_type.AOD) {
        return stopSecAnim();
      }
      if (!now) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
      }
      if (widgetDelegate) return;

      widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
          console.log('ui resume');

          if (animTimer) return;

          let duration = 0;
          const diffTime = now.utc - lastTime;
          if (diffTime < animDuration) {
            duration = animDuration - diffTime;
          }

          animTimer = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim(now.second * 6);
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
          stopSecAnim();
        }),
      });
    }

    function startSecAnim(sec) {
      const secAnim = {
        anim_rate: 'linear',
        anim_duration: animDuration,
        anim_from: sec,
        anim_to: sec + animDuration * 6 / 1000,
        repeat_count: 1,
        anim_fps: animFps,
        anim_key: "angle",
        anim_status: 1,
      }

      normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()
     */
    function stopSecAnim() {
      if (animTimer) {
        timer.stopTimer(animTimer);
        animTimer = undefined;
      }
    }

    /** END SMOOTH SECOND SCRIPTS */

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 348,
              day_startY: 223,
              day_sc_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              day_tc_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              day_en_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 293,
              month_startY: 223,
              month_sc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_tc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_en_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 160,
              font_array: ["nu00.png","nu01.png","nu02.png","nu03.png","nu04.png","nu05.png","nu06.png","nu07.png","nu08.png","nu09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nu12.png',
              unit_tc: 'nu12.png',
              unit_en: 'nu12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 85,
              image_array: ["ba01.png","ba02.png","ba03.png","ba04.png","ba05.png","ba06.png","ba07.png","ba08.png","ba09.png","ba10.png","ba11.png","ba12.png","ba13.png","ba14.png","ba15.png","ba16.png","ba17.png","ba18.png","ba19.png","ba20.png","ba21.png","ba22.png","ba23.png","ba24.png","ba25.png","ba26.png","ba27.png","ba28.png","ba29.png","ba30.png","ba31.png"],
              image_length: 31,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 288,
              y: 198,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 253,
              font_array: ["nu00.png","nu01.png","nu02.png","nu03.png","nu04.png","nu05.png","nu06.png","nu07.png","nu08.png","nu09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nu11.png',
              unit_tc: 'nu11.png',
              unit_en: 'nu11.png',
              negative_image: 'nu13.png',
              invalid_image: 'nu14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 203,
              image_array: ["w001.png","w002.png","w003.png","w004.png","w005.png","w006.png","w007.png","w008.png","w009.png","w010.png","w011.png","w012.png","w013.png","w014.png","w015.png","w016.png","w017.png","w018.png","w019.png","w020.png","w021.png","w022.png","w023.png","w024.png","w025.png","w026.png","w027.png","w028.png","w029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 125,
              font_array: ["nu00.png","nu01.png","nu02.png","nu03.png","nu04.png","nu05.png","nu06.png","nu07.png","nu08.png","nu09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nu16.png',
              unit_tc: 'nu16.png',
              unit_en: 'nu16.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 183,
              y: 85,
              image_array: ["hr01.png","hr02.png","hr03.png","hr04.png","hr05.png","hr06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 292,
              font_array: ["nu00.png","nu01.png","nu02.png","nu03.png","nu04.png","nu05.png","nu06.png","nu07.png","nu08.png","nu09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nu15.png',
              unit_tc: 'nu15.png',
              unit_en: 'nu15.png',
              dot_image: 'nu10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 330,
              font_array: ["nu00.png","nu01.png","nu02.png","nu03.png","nu04.png","nu05.png","nu06.png","nu07.png","nu08.png","nu09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 183,
              y: 282,
              image_array: ["step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png","step10.png","step11.png","step12.png","step13.png","step14.png","step15.png","step16.png","step17.png","step18.png","step19.png","step20.png","step21.png","step22.png","step23.png","step24.png","step25.png","step26.png","step27.png","step28.png","step29.png","step30.png","step31.png","step32.png","step33.png","step34.png","step35.png","step36.png","step37.png","step38.png","step39.png","step40.png","step41.png"],
              image_length: 41,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't01.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't02.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			// Smooth Seconds
        normal_analog_clock_time_pointer_second = normal_analog_clock_time_pointer_second || hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          pos_x: 480 / 2 - 240,
          pos_y: 480 / 2 - 240,
          center_x: 240,
          center_y: 240,
          src: "t03.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        setSec();

           // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //  second_path: 't03.png',
            //  second_centerX: 240,
            //  second_centerY: 240,
            //  second_posX: 240,
           //   second_posY: 240,
            //  show_level: hmUI.show_level.ONLY_NORMAL,
           // });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 288,
              y: 198,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't01_aod.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't02_aod.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

     // onDestory() { // found typo. Added method below just in case
      //  console.log('index page.js on destory invoke')
      //  stopSecAnim();
     // },

      onDestroy() {
        console.log('index page.js on destroy invoke')
        stopSecAnim();
      },
    });

      })()
    } catch (e) {
      console.log(e)
    }
  