﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_stress_icon_img = ''

//Start Change content (press infield)
        let btnchangecontent = ''
        let contentnumber = 0
        let totalcontent = 6

        function click_Changecontent() {
          contentnumber=contentnumber+1;
          switch (contentnumber) {
            case 1:
              Changecontent(1); break;
            case 2:
              Changecontent(2); break;
            case 3:
              Changecontent(3); break;
			case 4:
              Changecontent(4); break;
			case 5:
              Changecontent(5); break;
			case 6:
              Changecontent(6); break;
            default:
              Changecontent(0); contentnumber=0;
          }
          if(contentnumber==1) hmUI.showToast({text: 'Heart Rate'});
          if(contentnumber==2) hmUI.showToast({text: 'Steps'});
          if(contentnumber==3) hmUI.showToast({text: 'Calories'});
		  if(contentnumber==4) hmUI.showToast({text: 'Sunset - Sunrise'});
          if(contentnumber==5) hmUI.showToast({text: 'Temperature'});
		  if(contentnumber==6) hmUI.showToast({text: 'Battery'});
		  if(contentnumber==0) hmUI.showToast({text: 'Date'});
        }

	// Give contentnumber. Must exist
        function Changecontent(number) {
           if(number==1) {
                  UpdatecontentPulse();
             } else if(number==2) {
                  UpdatecontentSteps();
             } else if(number==3) {
                  UpdatecontentCal();
			 } else if(number==4) {
                  UpdatecontentSun();
			 } else if(number==5) {
                  UpdatecontentWea();
			 } else if(number==6) {
                  UpdatecontentBatt();
             } else {
                  UpdatecontentDate();
             }
        }
		
        function UpdatecontentPulse(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdatecontentSteps(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdatecontentCal(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        }

       function UpdatecontentSun(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        } 
		
		function UpdatecontentWea(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        } 
		
		function UpdatecontentBatt(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        } 
		
		function UpdatecontentDate(){
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
				normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        } 
//END Change content (press infield)
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 199,
              y: 358,
              src: 'status_icon.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 284,
              y: 358,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 358,
              src: 'status_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 336,
              am_y: 307,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 336,
              pm_y: 307,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 248,
              hour_startY: 324,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: 'num_10.png',
              hour_unit_tc: 'num_10.png',
              hour_unit_en: 'num_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer.png',
              center_x: 108,
              center_y: 240,
              posX: 25,
              posY: 50,
              start_angle: -13,
              end_angle: 166,
              scale_sc: 'overlay.png',
              scale_tc: 'overlay.png',
              scale_en: 'overlay.png',
              scale_x: 0,
              scale_y: 0,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 335,
              month_startY: 280,
              month_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'num_11.png',
              month_unit_tc: 'num_11.png',
              month_unit_en: 'num_11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 292,
              day_startY: 280,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'num_11.png',
              day_unit_tc: 'num_11.png',
              day_unit_en: 'num_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 280,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'num_16.png',
              dot_image: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 267,
              src: 'icon_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 280,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_14.png',
              unit_tc: 'num_14.png',
              unit_en: 'num_14.png',
              negative_image: 'num_15.png',
              invalid_image: 'num_16.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 267,
              src: 'icon_temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 280,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 267,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 280,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'num_16.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 267,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 280,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 267,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 280,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_17.png',
              unit_tc: 'num_17.png',
              unit_en: 'num_17.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 267,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'time_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'time_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'time_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_cover_path: 'time_overlay.png',
              second_cover_x: 1,
              second_cover_y: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 16,
              w: 148,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 355,
              w: 57,
              h: 57,
              src: 'blank.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 355,
              w: 57,
              h: 57,
              src: 'blank.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 170,
              w: 124,
              h: 142,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
		hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });
//END Calendar Shortcut

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 199,
              y: 358,
              src: 'status_icon.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 284,
              y: 358,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 358,
              src: 'status_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 336,
              am_y: 307,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 336,
              pm_y: 307,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 248,
              hour_startY: 324,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: 'num_10.png',
              hour_unit_tc: 'num_10.png',
              hour_unit_en: 'num_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer.png',
              center_x: 108,
              center_y: 240,
              posX: 25,
              posY: 50,
              start_angle: -13,
              end_angle: 166,
              scale_sc: 'overlay.png',
              scale_tc: 'overlay.png',
              scale_en: 'overlay.png',
              scale_x: 0,
              scale_y: 0,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 335,
              month_startY: 280,
              month_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'num_11.png',
              month_unit_tc: 'num_11.png',
              month_unit_en: 'num_11.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 292,
              day_startY: 280,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'num_11.png',
              day_unit_tc: 'num_11.png',
              day_unit_en: 'num_11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'time_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'time_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_path: 'time_overlay.png',
              minute_cover_x: 1,
              minute_cover_y: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

// Change content shortcut start
            btnchangecontent = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 240,
              text: '',
              w: 160,
              h: 100,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Changecontent();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnchangecontent.setProperty(hmUI.prop.VISIBLE, true);
// Change content shortcut end

//dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  