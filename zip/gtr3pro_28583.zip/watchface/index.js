﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFAEBD8',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'weekday.png',
              center_x: 359,
              center_y: 240,
              posX: 75,
              posY: 75,
              start_angle: 0,
              end_angle: -360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day.png',
              center_x: 120,
              center_y: 240,
              posX: 75,
              posY: 75,
              start_angle: 0,
              end_angle: -360,
              cover_path: 'overlay.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 260,
              font_array: ["bright_01.png","bright_02.png","bright_03.png","bright_04.png","bright_05.png","bright_06.png","bright_07.png","bright_08.png","bright_09.png","bright_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_02.png',
              center_x: 120,
              center_y: 240,
              x: 76,
              y: 75,
              start_angle: 105,
              end_angle: -75,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_01.png',
              center_x: 240,
              center_y: 121,
              posX: 75,
              posY: 75,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_02.png',
              center_x: 357,
              center_y: 240,
              x: 76,
              y: 75,
              start_angle: 0,
              end_angle: -360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 392,
              font_array: ["dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png","dark_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dark_12.png',
              unit_tc: 'dark_12.png',
              unit_en: 'dark_12.png',
              imperial_unit_sc: 'dark_13.png',
              imperial_unit_tc: 'dark_13.png',
              imperial_unit_en: 'dark_13.png',
              dot_image: 'dark_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 314,
              font_array: ["dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png","dark_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_01.png',
              center_x: 240,
              center_y: 358,
              x: 75,
              y: 75,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 239,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFAEBD8',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'weekday.png',
              center_x: 359,
              center_y: 240,
              posX: 75,
              posY: 75,
              start_angle: 0,
              end_angle: -360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day.png',
              center_x: 120,
              center_y: 240,
              posX: 75,
              posY: 75,
              start_angle: 0,
              end_angle: -360,
              cover_path: 'overlay.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 260,
              font_array: ["bright_01.png","bright_02.png","bright_03.png","bright_04.png","bright_05.png","bright_06.png","bright_07.png","bright_08.png","bright_09.png","bright_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_02.png',
              center_x: 120,
              center_y: 240,
              x: 76,
              y: 75,
              start_angle: 105,
              end_angle: -75,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_01.png',
              center_x: 240,
              center_y: 121,
              posX: 75,
              posY: 75,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_02.png',
              center_x: 357,
              center_y: 240,
              x: 76,
              y: 75,
              start_angle: 0,
              end_angle: -360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 392,
              font_array: ["dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png","dark_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dark_12.png',
              unit_tc: 'dark_12.png',
              unit_en: 'dark_12.png',
              imperial_unit_sc: 'dark_13.png',
              imperial_unit_tc: 'dark_13.png',
              imperial_unit_en: 'dark_13.png',
              dot_image: 'dark_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 314,
              font_array: ["dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png","dark_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_01.png',
              center_x: 240,
              center_y: 358,
              x: 75,
              y: 75,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 239,
              second_posY: 239,
              second_cover_path: 'aod_overlay.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  