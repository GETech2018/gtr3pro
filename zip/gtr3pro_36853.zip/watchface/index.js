﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		let element_index = 1;
        let element_count = 3;
		
		function click_Content() {
              element_index++;
              if(element_index > element_count) element_index = 1;
			  
			  normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_city_name_text.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_1.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_2.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_3.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_4.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_5.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_6.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_7.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_8.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_9.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
              if (element_index == 1) {
                 hmUI.showToast({text: 'TIME & MOON'});
               };
              if (element_index == 2) {
                 hmUI.showToast({text: 'ACTIVITY'});
               };
			  if (element_index == 3) {
                 hmUI.showToast({text: 'WEATHER'});
               };
        };
		
		let colornumber_main = 1
        let totalcolors_main = 9
        let namecolor_main = ''
		let secstring = 'hand_sec1.png'
		let datestring = 'hand_wd1.png'
		let monthstring = 'hand_month1.png'
		let stepstring = 'hand_step1.png'

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "CYAN STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}


			if ( colornumber_main == 2) { namecolor_main = "RED STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 3) { namecolor_main = "YELLOW STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 4) { namecolor_main = "BLUE STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 5) { namecolor_main = "ORANGE STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 6) { namecolor_main = "PURPLE STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 7) { namecolor_main = "GREEN STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}
			
			if ( colornumber_main == 8) { namecolor_main = "FUCHSIA STYLE"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}
			
			if ( colornumber_main == 9) { namecolor_main = "COLORLESS"
				secstring = 'hand_sec' +colornumber_main+ '.png'
				datestring = "hand_wd" + parseInt(colornumber_main) + ".png"
				monthstring = "hand_month" + parseInt(colornumber_main) + ".png"
				stepstring = "hand_step" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main <= 9) { 
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: datestring,
              center_x: 150,
              center_y: 395,
              posX: 120,
              posY: 122,
              start_angle: -20,
              end_angle: 150,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: monthstring,
              center_x: 149,
              center_y: 395,
              posX: 116,
              posY: 118,
              start_angle: -18,
              end_angle: 152,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: stepstring,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 0,
              end_angle: -70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			}

			hmUI.showToast({text: namecolor_main });
            normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "time_min" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "time_sec" + parseInt(colornumber_main) + ".png");
			normal_system_clock_img.setProperty(hmUI.prop.SRC, "status_al1" + parseInt(colornumber_main) + ".png");
		}
		
		let handsnumber_main = 1
        let totalhands_main = 3
		let hourstring = 'hand_hour1.png'
		let minstring = 'hand_min1.png'

        function click_Hands() {
            if(handsnumber_main>=totalhands_main) {
            handsnumber_main=1;
                }
            else {
                handsnumber_main=handsnumber_main+1;
            }

			if ( handsnumber_main == 1) { namecolor_main = "HAND STYLE 1"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring = 'hand_min' +handsnumber_main+ '.png'
			}

			if ( handsnumber_main == 2) { namecolor_main = "HAND STYLE 2"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring = 'hand_min' +handsnumber_main+ '.png'
			}

			if ( handsnumber_main == 3) { namecolor_main = "HAND STYLE 3"
				hourstring = 'hand_hour' +handsnumber_main+ '.png'
				minstring = 'hand_min' +handsnumber_main+ '.png'
			}

			if ( handsnumber_main <= 3) { 
			
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minstring,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			hmUI.showToast({text: namecolor_main });
        }
        // end user_functions.js

        let normal_background_bg = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_image_img = ''
		let normal_step_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_city_name_text = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
		let normal_battery_pointer_progress_img_pointer_2 = ''
        let normal_stress_icon_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_stand_icon_img = ''
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 14;
        let normal_timerTextUpdate = undefined;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 22;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_sun_icon_img = ''
        let idle_sun_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_year_TextRotate = new Array(4);
        let idle_year_TextRotate_ASCIIARRAY = new Array(10);
        let idle_year_TextRotate_img_width = 14;
        let idle_timerTextUpdate = undefined;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 22;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF282828',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'time_hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 238,
              // y: 237,
              // start_angle: 1,
              // end_angle: 151,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 238,
              pos_y: 240 - 237,
              center_x: 240,
              center_y: 240,
              src: 'time_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'time_min1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 238,
              // y: 238,
              // start_angle: 2,
              // end_angle: 152,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 238,
              pos_y: 240 - 238,
              center_x: 240,
              center_y: 240,
              src: 'time_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'time_sec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: -152,
              // end_angle: -3,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'time_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_step1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 0,
              end_angle: -70,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_act.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 330,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 380,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 275,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 298,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_tim.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 267,
              y: 368,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 351,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 285,
              hour_startY: 310,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'big_10.png',
              hour_unit_tc: 'big_10.png',
              hour_unit_en: 'big_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 285,
              y: 277,
              w: 140,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_we.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 341,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_14.png',
              unit_tc: 'num_14.png',
              unit_en: 'num_14.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 341,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_14.png',
              unit_tc: 'num_14.png',
              unit_en: 'num_14.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 341,
              src: 'num_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 302,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'big_13.png',
              unit_tc: 'big_13.png',
              unit_en: 'big_13.png',
              negative_image: 'big_12.png',
              invalid_image: 'big_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 273,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 363,
              // center_y: 240,
              // start_angle: -101,
              // end_angle: 100,
              // radius: 83,
              // line_width: 53,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 363,
              center_y: 240,
              start_angle: 100,
              end_angle: -101,
              radius: 57,
              line_width: 53,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 388,
              y: 254,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_16.png',
              unit_tc: 'num_16.png',
              unit_en: 'num_16.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_batt1.png',
              center_x: 362,
              center_y: 240,
              x: 82,
              y: 80,
              start_angle: -9,
              end_angle: 191,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
			normal_battery_pointer_progress_img_pointer_2 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_batt.png',
              center_x: 363,
              center_y: 239,
              x: 119,
              y: 107,
              start_angle: -110,
              end_angle: 90,
              invalid_visible: false,
              cover_path: 'hand_batt_top.png',
              cover_x: 245,
              cover_y: 117,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'date_bck.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_wd1.png',
              center_x: 150,
              center_y: 395,
              posX: 120,
              posY: 122,
              start_angle: -20,
              end_angle: 150,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_month1.png',
              center_x: 149,
              center_y: 395,
              posX: 116,
              posY: 118,
              start_angle: -18,
              end_angle: 152,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'date_for.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 125,
              // y: 383,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 125,
                center_y: 383,
                pos_x: 125,
                pos_y: 383,
                angle: 30,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 166,
              // y: 366,
              // font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 30,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'big_00.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'big_01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'big_02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'big_03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'big_04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'big_05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'big_06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'big_07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'big_08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'big_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 166,
                center_y: 366,
                pos_x: 166,
                pos_y: 366,
                angle: 30,
                src: 'big_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_al1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color9.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel_tim.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 351,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 285,
              hour_startY: 310,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'big_10.png',
              hour_unit_tc: 'big_10.png',
              hour_unit_en: 'big_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 390,
              y: 254,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_16.png',
              unit_tc: 'num_16.png',
              unit_en: 'num_16.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'batt_bck.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hand_batt.png',
              center_x: 363,
              center_y: 239,
              x: 119,
              y: 107,
              start_angle: -110,
              end_angle: 90,
              invalid_visible: false,
              cover_path: 'hand_batt_top.png',
              cover_x: 245,
              cover_y: 117,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_wd9.png',
              center_x: 150,
              center_y: 395,
              posX: 120,
              posY: 122,
              start_angle: -20,
              end_angle: 150,
              scale_sc: 'date_bck.png',
              scale_tc: 'date_bck.png',
              scale_en: 'date_bck.png',
              scale_x: 0,
              scale_y: 0,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'hand_month9.png',
              center_x: 149,
              center_y: 395,
              posX: 116,
              posY: 118,
              start_angle: -18,
              end_angle: 152,
              cover_path: 'date_for.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 125,
              // y: 383,
              // font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextRotate_ASCIIARRAY[0] = 'num_00.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[1] = 'num_01.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[2] = 'num_02.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[3] = 'num_03.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[4] = 'num_04.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[5] = 'num_05.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[6] = 'num_06.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[7] = 'num_07.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[8] = 'num_08.png';  // set of images with numbers
            idle_year_TextRotate_ASCIIARRAY[9] = 'num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 125,
                center_y: 383,
                pos_x: 125,
                pos_y: 383,
                angle: 30,
                src: 'num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 166,
              // y: 366,
              // font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 30,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'big_00.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'big_01.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'big_02.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'big_03.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'big_04.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'big_05.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'big_06.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'big_07.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'big_08.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'big_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 166,
                center_y: 366,
                pos_x: 166,
                pos_y: 366,
                angle: 30,
                src: 'big_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_al9.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              minute_cover_path: 'aod_top.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 300,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 300,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 340,
              w: 105,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 380,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 375,
              w: 80,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 325,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 275,
              w: 75,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 285,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 285,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 210,
              w: 50,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 5,
              w: 80,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 45,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 355,
              y: 45,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 94,
              y: 350,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 325,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 215,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Hands();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 430,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Content();
                				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
		let cc = 0
		if (cc ==0 ){
		normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);  
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		Button_5.setProperty(hmUI.prop.VISIBLE, false);  
		Button_6.setProperty(hmUI.prop.VISIBLE, false);  
		Button_7.setProperty(hmUI.prop.VISIBLE, false);  
			  
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 
		Button_8.setProperty(hmUI.prop.VISIBLE, false);  
		Button_9	.setProperty(hmUI.prop.VISIBLE, false);  
		cc = 1;
		}
            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 150;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 1 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 150;
                let normal_angle_minute = 2 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 149;
              let normal_angle_second = -152 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 125 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + 2 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 166 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate year_TIME');
              let idle_year_rotate_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_rotate_string.length > 0 && idle_year_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 125 + img_offset);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.SRC, idle_year_TextRotate_ASCIIARRAY[charCode]);
                      idle_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  idle_day_TextRotate_posOffset = idle_day_TextRotate_posOffset + 2 * (idle_day_rotate_string.length - 1);
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 166 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 363,
                      center_y: 240,
                      start_angle: 100,
                      end_angle: -101,
                      radius: 57,
                      line_width: 53,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}