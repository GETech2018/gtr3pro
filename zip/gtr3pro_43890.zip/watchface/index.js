﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 90,
              y: 130,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 269,
              y: 130,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 278,
              month_startY: 72,
              month_sc_array: ["mon01.png","mon02.png","mon03.png","mon04.png","mon05.png","mon06.png","mon07.png","mon08.png","mon09.png","mon10.png","mon11.png","mon12.png"],
              month_tc_array: ["mon01.png","mon02.png","mon03.png","mon04.png","mon05.png","mon06.png","mon07.png","mon08.png","mon09.png","mon10.png","mon11.png","mon12.png"],
              month_en_array: ["mon01.png","mon02.png","mon03.png","mon04.png","mon05.png","mon06.png","mon07.png","mon08.png","mon09.png","mon10.png","mon11.png","mon12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 278,
              y: 96,
              week_en: ["0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              week_tc: ["0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              week_sc: ["0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 77,
              day_sc_array: ["Nr.Temp_00.png","Nr.Temp_01.png","Nr.Temp_02.png","Nr.Temp_03.png","Nr.Temp_04.png","Nr.Temp_05.png","Nr.Temp_06.png","Nr.Temp_07.png","Nr.Temp_08.png","Nr.Temp_09.png"],
              day_tc_array: ["Nr.Temp_00.png","Nr.Temp_01.png","Nr.Temp_02.png","Nr.Temp_03.png","Nr.Temp_04.png","Nr.Temp_05.png","Nr.Temp_06.png","Nr.Temp_07.png","Nr.Temp_08.png","Nr.Temp_09.png"],
              day_en_array: ["Nr.Temp_00.png","Nr.Temp_01.png","Nr.Temp_02.png","Nr.Temp_03.png","Nr.Temp_04.png","Nr.Temp_05.png","Nr.Temp_06.png","Nr.Temp_07.png","Nr.Temp_08.png","Nr.Temp_09.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 8,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 18,
              font_array: ["Nr.Temp_00.png","Nr.Temp_01.png","Nr.Temp_02.png","Nr.Temp_03.png","Nr.Temp_04.png","Nr.Temp_05.png","Nr.Temp_06.png","Nr.Temp_07.png","Nr.Temp_08.png","Nr.Temp_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr.Temp_11.png',
              unit_tc: 'Nr.Temp_11.png',
              unit_en: 'Nr.Temp_11.png',
              imperial_unit_sc: 'Nr.Temp_11.png',
              imperial_unit_tc: 'Nr.Temp_11.png',
              imperial_unit_en: 'Nr.Temp_11.png',
              negative_image: 'Nr.Temp_10.png',
              invalid_image: 'Nr.Temp_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 426,
              font_array: ["Nr.Temp_00.png","Nr.Temp_01.png","Nr.Temp_02.png","Nr.Temp_03.png","Nr.Temp_04.png","Nr.Temp_05.png","Nr.Temp_06.png","Nr.Temp_07.png","Nr.Temp_08.png","Nr.Temp_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 370,
              font_array: ["Nr.Temp_00.png","Nr.Temp_01.png","Nr.Temp_02.png","Nr.Temp_03.png","Nr.Temp_04.png","Nr.Temp_05.png","Nr.Temp_06.png","Nr.Temp_07.png","Nr.Temp_08.png","Nr.Temp_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Temp_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 86,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_11.png',
              unit_tc: 'Nr.Sist_11.png',
              unit_en: 'Nr.Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 62,
              y: 60,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 160,
              hour_array: ["Nr.Ore_00.png","Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 160,
              minute_array: ["Nr.Ore_00.png","Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 326,
              second_startY: 352,
              second_array: ["Nr.Sec_00.png","Nr.Sec_01.png","Nr.Sec_02.png","Nr.Sec_03.png","Nr.Sec_04.png","Nr.Sec_05.png","Nr.Sec_06.png","Nr.Sec_07.png","Nr.Sec_08.png","Nr.Sec_09.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg026.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ana_hor-aod.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 34,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'ana_min-aod.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 34,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'ana_seg.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 34,
              second_posY: 240,
              second_cover_path: 'bg_fill_20.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}