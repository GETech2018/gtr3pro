﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_pai_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_temperature_icon_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF111111',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -150,
              y: -39,
              src: 'BackPictureB.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -39,
              hour_startY: 20,
              hour_array: ["dotum_84_hr_0001.png","dotum_84_hr_0002.png","dotum_84_hr_0003.png","dotum_84_hr_0004.png","dotum_84_hr_0005.png","dotum_84_hr_0006.png","dotum_84_hr_0007.png","dotum_84_hr_0008.png","dotum_84_hr_0009.png","dotum_84_hr_0010.png"],
              hour_zero: 1,
              hour_space: -102,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 273,
              minute_startY: -41,
              minute_array: ["mins_dotum_hr_set_0001.png","mins_dotum_hr_set_0002.png","mins_dotum_hr_set_0003.png","mins_dotum_hr_set_0004.png","mins_dotum_hr_set_0005.png","mins_dotum_hr_set_0006.png","mins_dotum_hr_set_0007.png","mins_dotum_hr_set_0008.png","mins_dotum_hr_set_0009.png","mins_dotum_hr_set_0010.png"],
              minute_zero: 1,
              minute_space: -42,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 412,
              second_startY: 198,
              second_array: ["zstats_dotum_hr_set_0001.png","zstats_dotum_hr_set_0002.png","zstats_dotum_hr_set_0003.png","zstats_dotum_hr_set_0004.png","zstats_dotum_hr_set_0005.png","zstats_dotum_hr_set_0006.png","zstats_dotum_hr_set_0007.png","zstats_dotum_hr_set_0008.png","zstats_dotum_hr_set_0009.png","zstats_dotum_hr_set_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: -15,
              src: 'Picture54.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 411,
              am_y: 177,
              am_sc_path: 'DAY_am.png',
              am_en_path: 'DAY_am.png',
              pm_x: 411,
              pm_y: 177,
              pm_sc_path: 'DAY_pm.png',
              pm_en_path: 'DAY_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 308,
              month_startY: 236,
              month_sc_array: ["months_dotum_hr_set_0001.png","months_dotum_hr_set_0002.png","months_dotum_hr_set_0003.png","months_dotum_hr_set_0004.png","months_dotum_hr_set_0005.png","months_dotum_hr_set_0006.png","months_dotum_hr_set_0007.png","months_dotum_hr_set_0008.png","months_dotum_hr_set_0009.png","months_dotum_hr_set_0010.png","months_dotum_hr_set_0011.png","months_dotum_hr_set_0012.png"],
              month_tc_array: ["months_dotum_hr_set_0001.png","months_dotum_hr_set_0002.png","months_dotum_hr_set_0003.png","months_dotum_hr_set_0004.png","months_dotum_hr_set_0005.png","months_dotum_hr_set_0006.png","months_dotum_hr_set_0007.png","months_dotum_hr_set_0008.png","months_dotum_hr_set_0009.png","months_dotum_hr_set_0010.png","months_dotum_hr_set_0011.png","months_dotum_hr_set_0012.png"],
              month_en_array: ["months_dotum_hr_set_0001.png","months_dotum_hr_set_0002.png","months_dotum_hr_set_0003.png","months_dotum_hr_set_0004.png","months_dotum_hr_set_0005.png","months_dotum_hr_set_0006.png","months_dotum_hr_set_0007.png","months_dotum_hr_set_0008.png","months_dotum_hr_set_0009.png","months_dotum_hr_set_0010.png","months_dotum_hr_set_0011.png","months_dotum_hr_set_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 350,
              font_array: ["zstats_dotum_hr_set_0001.png","zstats_dotum_hr_set_0002.png","zstats_dotum_hr_set_0003.png","zstats_dotum_hr_set_0004.png","zstats_dotum_hr_set_0005.png","zstats_dotum_hr_set_0006.png","zstats_dotum_hr_set_0007.png","zstats_dotum_hr_set_0008.png","zstats_dotum_hr_set_0009.png","zstats_dotum_hr_set_0010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 306,
              y: 364,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "tats_fishing",
              anim_fps: 7,
              anim_size: 5,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 329,
              src: 'ICON_Picture140.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 321,
              font_array: ["xstats_dotum_hr_set_0001.png","xstats_dotum_hr_set_0002.png","xstats_dotum_hr_set_0003.png","xstats_dotum_hr_set_0004.png","xstats_dotum_hr_set_0005.png","xstats_dotum_hr_set_0006.png","xstats_dotum_hr_set_0007.png","xstats_dotum_hr_set_0008.png","xstats_dotum_hr_set_0009.png","xstats_dotum_hr_set_0010.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 290,
              src: 'ICONs_dotum_hr_set_0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 290,
              font_array: ["zstats_dotum_hr_set_0001.png","zstats_dotum_hr_set_0002.png","zstats_dotum_hr_set_0003.png","zstats_dotum_hr_set_0004.png","zstats_dotum_hr_set_0005.png","zstats_dotum_hr_set_0006.png","zstats_dotum_hr_set_0007.png","zstats_dotum_hr_set_0008.png","zstats_dotum_hr_set_0009.png","zstats_dotum_hr_set_0010.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ICON_Batt141.png',
              unit_tc: 'ICON_Batt141.png',
              unit_en: 'ICON_Batt141.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 298,
              src: 'ICON_Picture140.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 309,
              y: 225,
              week_en: ["days_dotum_hr_set_0001.png","days_dotum_hr_set_0002.png","days_dotum_hr_set_0003.png","days_dotum_hr_set_0004.png","days_dotum_hr_set_0005.png","days_dotum_hr_set_0006.png","days_dotum_hr_set_0007.png"],
              week_tc: ["days_dotum_hr_set_0001.png","days_dotum_hr_set_0002.png","days_dotum_hr_set_0003.png","days_dotum_hr_set_0004.png","days_dotum_hr_set_0005.png","days_dotum_hr_set_0006.png","days_dotum_hr_set_0007.png"],
              week_sc: ["days_dotum_hr_set_0001.png","days_dotum_hr_set_0002.png","days_dotum_hr_set_0003.png","days_dotum_hr_set_0004.png","days_dotum_hr_set_0005.png","days_dotum_hr_set_0006.png","days_dotum_hr_set_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 28,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 58,
              font_array: ["xstats_dotum_hr_set_0001.png","xstats_dotum_hr_set_0002.png","xstats_dotum_hr_set_0003.png","xstats_dotum_hr_set_0004.png","xstats_dotum_hr_set_0005.png","xstats_dotum_hr_set_0006.png","xstats_dotum_hr_set_0007.png","xstats_dotum_hr_set_0008.png","xstats_dotum_hr_set_0009.png","xstats_dotum_hr_set_0010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ICONs_dotum_hr_set_0001.png',
              unit_tc: 'ICONs_dotum_hr_set_0001.png',
              unit_en: 'ICONs_dotum_hr_set_0001.png',
              negative_image: 'ICON_Picture143.png',
              invalid_image: 'ICON_Picture144.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 295,
              y: 64,
              image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 390,
              day_startY: 236,
              day_sc_array: ["stats_dotum_hr_set_0001.png","stats_dotum_hr_set_0002.png","stats_dotum_hr_set_0003.png","stats_dotum_hr_set_0004.png","stats_dotum_hr_set_0005.png","stats_dotum_hr_set_0006.png","stats_dotum_hr_set_0007.png","stats_dotum_hr_set_0008.png","stats_dotum_hr_set_0009.png","stats_dotum_hr_set_0010.png"],
              day_tc_array: ["stats_dotum_hr_set_0001.png","stats_dotum_hr_set_0002.png","stats_dotum_hr_set_0003.png","stats_dotum_hr_set_0004.png","stats_dotum_hr_set_0005.png","stats_dotum_hr_set_0006.png","stats_dotum_hr_set_0007.png","stats_dotum_hr_set_0008.png","stats_dotum_hr_set_0009.png","stats_dotum_hr_set_0010.png"],
              day_en_array: ["stats_dotum_hr_set_0001.png","stats_dotum_hr_set_0002.png","stats_dotum_hr_set_0003.png","stats_dotum_hr_set_0004.png","stats_dotum_hr_set_0005.png","stats_dotum_hr_set_0006.png","stats_dotum_hr_set_0007.png","stats_dotum_hr_set_0008.png","stats_dotum_hr_set_0009.png","stats_dotum_hr_set_0010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -22,
              hour_startY: 20,
              hour_array: ["aod_dotum_48_hr_0002.png","aod_dotum_48_hr_0003.png","aod_dotum_48_hr_0004.png","aod_dotum_48_hr_0005.png","aod_dotum_48_hr_0006.png","aod_dotum_48_hr_0007.png","aod_dotum_48_hr_0008.png","aod_dotum_48_hr_0009.png","aod_dotum_48_hr_0010.png","aod_dotum_48_hr_0011.png"],
              hour_zero: 1,
              hour_space: -94,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 209,
              minute_startY: 20,
              minute_array: ["aod_dotum_48_hr_0002.png","aod_dotum_48_hr_0003.png","aod_dotum_48_hr_0004.png","aod_dotum_48_hr_0005.png","aod_dotum_48_hr_0006.png","aod_dotum_48_hr_0007.png","aod_dotum_48_hr_0008.png","aod_dotum_48_hr_0009.png","aod_dotum_48_hr_0010.png","aod_dotum_48_hr_0011.png"],
              minute_zero: 1,
              minute_space: -80,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: -15,
              src: 'aod_dotum_48_hr_0012.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 6,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -44,
              y: -36,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}