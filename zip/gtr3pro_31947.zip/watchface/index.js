﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_pai_icon_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''

                // aod changer start

                let btn_aod = ''

                let curAODmode = 0;			// 0 - пусто
                                        // 1 - минимальный

                let AODmodes = ["пустой", "минимальный", "аналоговый"];
                let AODmodeCaption;
        
                function toggleAODmode() {
                    curAODmode = (curAODmode + 1) % AODmodes.length;
                    hmFS.SysProSetInt('parkur_aod', curAODmode);
        
                    switch (curAODmode) {
                        case 0:
                            AODmodeCaption = "пустой";
                            break;
                        case 1:
                            AODmodeCaption = "минимальный";
                            break;
                        case 2:
                            AODmodeCaption = "аналоговый";
                            break;
                        default:
                            AODmodeCaption = "";
                            break;
                    }
        
                    hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
                }
        
                function makeAOD() {
        
                    let mode = hmFS.SysProGetInt('parkur_aod');
        
                    if (mode == 1) {    // минимальный
        
                      idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                        x: 218,
                        y: 411,
                        src: 'A100_024.png',
                        type: hmUI.system_status.DISCONNECT,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 120,
                        hour_startY: 186,
                        hour_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
                        hour_zero: 1,
                        hour_space: 0,
                        hour_align: hmUI.align.CENTER_H,
          
                        minute_startX: 262,
                        minute_startY: 186,
                        minute_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
                        minute_zero: 1,
                        minute_space: 0,
                        minute_follow: 0,
                        minute_align: hmUI.align.CENTER_H,
          
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 231,
                        y: 193,
                        src: 'dots.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
                    }
                  if (mode == 2) {    // аналоговый
        
                    idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                      x: 0,
                      y: 0,
                      w: 480,
                      h: 480,
                      src: 'aod_1.png',
                      show_level: hmUI.show_level.ONLY_AOD,
                    });
        
                    idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                      x: 216,
                      y: 384,
                      src: 'A100_024.png',
                      type: hmUI.system_status.DISCONNECT,
                      show_level: hmUI.show_level.ONLY_AOD,
                    });
        
                    idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                      hour_path: '1.png',
                      hour_centerX: 240,
                      hour_centerY: 240,
                      hour_posX: 20,
                      hour_posY: 218,
                      show_level: hmUI.show_level.ONLY_AOD,
                    });
        
                    idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                      minute_path: '2.png',
                      minute_centerX: 240,
                      minute_centerY: 240,
                      minute_posX: 20,
                      minute_posY: 218,
                      show_level: hmUI.show_level.ONLY_AOD,
                    });
        
                    idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                      second_path: '3.png',
                      second_centerX: 240,
                      second_centerY: 240,
                      second_posX: 28,
                      second_posY: 227,
                      show_level: hmUI.show_level.ONLY_AOD,
                    });
                  }
                }

                function loadSettings() {
                  if (hmFS.SysProGetInt('parkur_aod') === undefined) {
                      curAODmode = 1;
                      hmFS.SysProSetInt('parkur_aod', curAODmode);
                  } else {
                      curAODmode = hmFS.SysProGetInt('parkur_aod');
                  }
              }
              
        // aod changer end \\

        let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
    
        function click_zona1() {
          zona1_num = (zona1_num + 1) % (zona1_all + 1);

          if (zona1_num == 0) {
            normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
            hmUI.showToast({
              text: 'Активность'
            });
          };

          if (zona1_num == 1) {
            normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({
              text: 'Погода'
            });
          };
        }

        let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
    
        function click_zona2() {
          zona2_num = (zona2_num + 1) % (zona2_all + 1);

          if (zona2_num == 0) {
            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({
              text: 'Время'
            });
          };

          if (zona2_num == 1) {
            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            hmUI.showToast({
              text: 'Без времени'
            });
          };
        }

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'minr_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: -360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'minr_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 106,
              y: 290,
              src: 'wz_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 312,
              font_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 139,
              y: 300,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 376,
              src: '0075.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 376,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 326,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 47,
              font_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 391,
              src: 'A100_015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 375,
              font_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 296,
              y: 394,
              image_array: ["pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png","pu_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 312,
              font_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              padding: false,
              h_space: -2,
              dot_image: 'A100_036.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 106,
              y: 290,
              src: 'A100_038rus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 312,
              font_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 122,
              month_sc_array: ["A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png"],
              month_tc_array: ["A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png"],
              month_en_array: ["A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 118,
              day_sc_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_tc_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_en_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 103,
              y: 122,
              week_en: ["A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              week_tc: ["A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              week_sc: ["A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 176,
              src: 'ntime.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 186,
              hour_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 308,
              minute_startY: 186,
              minute_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '3.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

      // календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 108,
			  y: 122,
			  text: '',
			  w: 272,
			  h: 58,
			  normal_src: 'null.png',
			  press_src: 'null.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

          // Смена АОД
          btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 195,
            y: 0,
            text: '',
            w: 100,
            h: 70,
            normal_src: 'null.png',
            press_src: 'null.png',
            click_func: () => {
                toggleAODmode();
                vibro(25);
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_aod.setProperty(hmUI.prop.VISIBLE, true);
        //buttons end

        btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 266, //x кнопки
          y: 293, //y кнопки
          text: '',
          w: 100, //ширина кнопки
          h: 80, //высота кнопки
          normal_src: 'null.png',
          press_src: 'mull.png',
          click_func: () => {
            click_zona1();
            vibro(9); //имя вызываемой функции
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
  
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        //normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 195, //x кнопки
          y: 190, //y кнопки
          text: '',
          w: 100, //ширина кнопки
          h: 95, //высота кнопки
          normal_src: 'null.png',
          press_src: 'mull.png',
          click_func: () => {
            click_zona2();
            vibro(9); //имя вызываемой функции
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
          btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Отключено,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Подключено,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Отключено"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Подключено"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 185,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 308,
              y: 185,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 287,
              w: 100,
              h: 80,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 372,
              w: 100,
              h: 100,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 287,
              w: 100,
              h: 80,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = -360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
              const currentScreenType = hmSetting.getScreenType();
              switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;

                  default:
                      break;
              }

                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
