﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_calorie_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 271,
              y: 393,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 393,
              day_sc_array: ["Nr.Giorni_01.png","Nr.Giorni_02.png","Nr.Giorni_03.png","Nr.Giorni_04.png","Nr.Giorni_05.png","Nr.Giorni_06.png","Nr.Giorni_07.png","Nr.Giorni_08.png","Nr.Giorni_09.png","Nr.Giorni_10.png"],
              day_tc_array: ["Nr.Giorni_01.png","Nr.Giorni_02.png","Nr.Giorni_03.png","Nr.Giorni_04.png","Nr.Giorni_05.png","Nr.Giorni_06.png","Nr.Giorni_07.png","Nr.Giorni_08.png","Nr.Giorni_09.png","Nr.Giorni_10.png"],
              day_en_array: ["Nr.Giorni_01.png","Nr.Giorni_02.png","Nr.Giorni_03.png","Nr.Giorni_04.png","Nr.Giorni_05.png","Nr.Giorni_06.png","Nr.Giorni_07.png","Nr.Giorni_08.png","Nr.Giorni_09.png","Nr.Giorni_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 121,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 67,
              image_array: ["weatherc_00.png","weatherc_01.png","weatherc_02.png","weatherc_03.png","weatherc_04.png","weatherc_05.png","weatherc_06.png","weatherc_07.png","weatherc_08.png","weatherc_09.png","weatherc_10.png","weatherc_11.png","weatherc_12.png","weatherc_13.png","weatherc_14.png","weatherc_15.png","weatherc_16.png","weatherc_17.png","weatherc_18.png","weatherc_19.png","weatherc_20.png","weatherc_21.png","weatherc_22.png","weatherc_23.png","weatherc_24.png","weatherc_25.png","weatherc_26.png","weatherc_27.png","weatherc_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 77,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Sist_14.png',
              unit_tc: 'Nr.Sist_14.png',
              unit_en: 'Nr.Sist_14.png',
              negative_image: 'Nr.Sist_13.png',
              invalid_image: 'Nr.Sist_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 121,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 144,
              month_startY: 393,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 357,
              // center_y: 241,
              // start_angle: -122,
              // end_angle: 123,
              // radius: 59,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFFAA42,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 357,
              center_y: 241,
              start_angle: -122,
              end_angle: 123,
              radius: 58,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFFAA42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 232,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 122,
              // center_y: 241,
              // start_angle: -120,
              // end_angle: 123,
              // radius: 59,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFFAA42,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 122,
              center_y: 241,
              start_angle: -120,
              end_angle: 123,
              radius: 58,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFFAA42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 232,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 144,
              // start_angle: -136,
              // end_angle: 141,
              // radius: 49,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFFFFAA42,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 144,
              start_angle: -136,
              end_angle: 141,
              radius: 46,
              line_width: 6,
              corner_flag: 3,
              color: 0xFFFFAA42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 133,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 430,
              src: 'Blocco_01.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 267,
              y: 429,
              src: 'DND_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 266,
              src: 'BtOff_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 195,
              y: 265,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 322,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 322,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 340,
              second_startY: 326,
              second_array: ["NrSec_01.png","NrSec_02.png","NrSec_03.png","NrSec_04.png","NrSec_05.png","NrSec_06.png","NrSec_07.png","NrSec_08.png","NrSec_09.png","NrSec_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Ore_01.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 27,
              hour_posY: 165,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minuti_01.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Secondi_01.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 271,
              y: 393,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 393,
              day_sc_array: ["Nr.Giorni_01.png","Nr.Giorni_02.png","Nr.Giorni_03.png","Nr.Giorni_04.png","Nr.Giorni_05.png","Nr.Giorni_06.png","Nr.Giorni_07.png","Nr.Giorni_08.png","Nr.Giorni_09.png","Nr.Giorni_10.png"],
              day_tc_array: ["Nr.Giorni_01.png","Nr.Giorni_02.png","Nr.Giorni_03.png","Nr.Giorni_04.png","Nr.Giorni_05.png","Nr.Giorni_06.png","Nr.Giorni_07.png","Nr.Giorni_08.png","Nr.Giorni_09.png","Nr.Giorni_10.png"],
              day_en_array: ["Nr.Giorni_01.png","Nr.Giorni_02.png","Nr.Giorni_03.png","Nr.Giorni_04.png","Nr.Giorni_05.png","Nr.Giorni_06.png","Nr.Giorni_07.png","Nr.Giorni_08.png","Nr.Giorni_09.png","Nr.Giorni_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 121,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 67,
              image_array: ["weatherc_00.png","weatherc_01.png","weatherc_02.png","weatherc_03.png","weatherc_04.png","weatherc_05.png","weatherc_06.png","weatherc_07.png","weatherc_08.png","weatherc_09.png","weatherc_10.png","weatherc_11.png","weatherc_12.png","weatherc_13.png","weatherc_14.png","weatherc_15.png","weatherc_16.png","weatherc_17.png","weatherc_18.png","weatherc_19.png","weatherc_20.png","weatherc_21.png","weatherc_22.png","weatherc_23.png","weatherc_24.png","weatherc_25.png","weatherc_26.png","weatherc_27.png","weatherc_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 77,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Sist_14.png',
              unit_tc: 'Nr.Sist_14.png',
              unit_en: 'Nr.Sist_14.png',
              negative_image: 'Nr.Sist_13.png',
              invalid_image: 'Nr.Sist_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 121,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 144,
              month_startY: 393,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 357,
              // center_y: 241,
              // start_angle: -122,
              // end_angle: 123,
              // radius: 59,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFFAA42,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 357,
              center_y: 241,
              start_angle: -122,
              end_angle: 123,
              radius: 58,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFFAA42,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 232,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 122,
              // center_y: 241,
              // start_angle: -120,
              // end_angle: 123,
              // radius: 59,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFFAA42,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 122,
              center_y: 241,
              start_angle: -120,
              end_angle: 123,
              radius: 58,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFFAA42,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 232,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 144,
              // start_angle: -136,
              // end_angle: 141,
              // radius: 49,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFFFFAA42,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 144,
              start_angle: -136,
              end_angle: 141,
              radius: 46,
              line_width: 6,
              corner_flag: 3,
              color: 0xFFFFAA42,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 133,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 430,
              src: 'Blocco_01.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 267,
              y: 429,
              src: 'DND_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 266,
              src: 'BtOff_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 195,
              y: 265,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 322,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 322,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 340,
              second_startY: 326,
              second_array: ["NrSec_01.png","NrSec_02.png","NrSec_03.png","NrSec_04.png","NrSec_05.png","NrSec_06.png","NrSec_07.png","NrSec_08.png","NrSec_09.png","NrSec_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Ore_01.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 27,
              hour_posY: 165,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minuti_01.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Secondi_01.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 357,
                      center_y: 241,
                      start_angle: -122,
                      end_angle: 123,
                      radius: 58,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFFFFAA42,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 122,
                      center_y: 241,
                      start_angle: -120,
                      end_angle: 123,
                      radius: 58,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFFFFAA42,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 144,
                      start_angle: -136,
                      end_angle: 141,
                      radius: 46,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFFFFAA42,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 357,
                      center_y: 241,
                      start_angle: -122,
                      end_angle: 123,
                      radius: 58,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFFFFAA42,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 122,
                      center_y: 241,
                      start_angle: -120,
                      end_angle: 123,
                      radius: 58,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFFFFAA42,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 144,
                      start_angle: -136,
                      end_angle: 141,
                      radius: 46,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFFFFAA42,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}