/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_analog_clock_time_pointer_second = '';
		let normal_digital_clock_img_second = '';
		let normal_digital_clock_img_hour = '';
		let normal_digital_clock_img_minute = '';
		let normal_battery_current_circle = '';
		let normal_background_bg_img2 = '';
		let normal_steps_current_circle = '';
		let normal_background_bg_img3 = '';
		let normal_date_current_date_monthday = '';
		let normal_background_bg_img4 = '';
		let normal_date_current_date_month = '';
		let normal_date_img_date_week_img = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -720,
					y: -270,
					w: 0,
					h: 0,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 4,
					w: 480,
					h: 480,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0004.png',
					second_centerX: 240,
					second_centerY: 242,
					second_posX: 7,
					second_posY: 237,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 423,
					second_startY: 273,
					second_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 157,
					hour_startY: 67,
					hour_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 157,
					minute_startY: 184,
					minute_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_current_circle = hmUI.createWidget(hmUI.widget.ARC);
				}

				const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
				battery.addEventListener(hmSensor.event.CHANGE, function() {
					updateScales('battery');
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 131,
					y: 68,
					w: 291,
					h: 291,
					src: '0035.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_steps_current_circle = hmUI.createWidget(hmUI.widget.ARC);
				}

				const step = hmSensor.createSensor(hmSensor.id.STEP);
				step.addEventListener(hmSensor.event.CHANGE, function() {
					updateScales('step');
				});

				normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 37,
					y: 95,
					w: 292,
					h: 292,
					src: '0036.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 182,
					day_startY: 385,
					day_sc_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					day_tc_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					day_en_array: ["0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 233,
					y: 385,
					w: 14,
					h: 40,
					src: '0047.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 251,
					month_startY: 385,
					month_sc_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					month_tc_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					month_en_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					month_zero: true,
					month_space: 0,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 168,
					y: 354,
					week_en: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					week_tc: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					week_sc: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateScales() {
					let valueBattery = battery.current;
					let targetBattery = 100;
					let progressBattery = valueBattery / targetBattery;

					if (progressBattery > 1) {
						progressBattery = 1;
					}

					let progress_cs_normal_battery = progressBattery;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						let start_angle_normal_battery = -87;
						let end_angle_normal_battery = -1;
						let center_x_normal_battery = 240;
						let center_y_normal_battery = 241;
						let radius_normal_battery = 213;
						let line_width_cs_normal_battery = 14;
						let color_cs_normal_battery = 0xFFFFFFFF;

						// calculated parameters
						let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
						let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
						let CircleWidth_normal_battery = 2 * radius_normal_battery;
						let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
						angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
						let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;

						normal_battery_current_circle.setProperty(hmUI.prop.MORE, {
							x: arcX_normal_battery,
							y: arcY_normal_battery,
							w: CircleWidth_normal_battery,
							h: CircleWidth_normal_battery,
							start_angle: start_angle_normal_battery,
							end_angle: end_angle_normal_battery_draw,
							color: color_cs_normal_battery,
							line_width: line_width_cs_normal_battery,
						});
					};

					let valueStep = step.current;
					let targetStep = step.target;
					let progressStep = valueStep / targetStep;

					if (progressStep > 1) {
						progressStep = 1;
					}

					let progress_cs_normal_step = progressStep;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						let start_angle_normal_step = 31;
						let end_angle_normal_step = 261;
						let center_x_normal_step = 239;
						let center_y_normal_step = 242;
						let radius_normal_step = 215;
						let line_width_cs_normal_step = 14;
						let color_cs_normal_step = 0xFFCC3333;

						// calculated parameters
						let arcX_normal_step = center_x_normal_step - radius_normal_step;
						let arcY_normal_step = center_y_normal_step - radius_normal_step;
						let CircleWidth_normal_step = 2 * radius_normal_step;
						let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
						angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
						let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;

						normal_steps_current_circle.setProperty(hmUI.prop.MORE, {
							x: arcX_normal_step,
							y: arcY_normal_step,
							w: CircleWidth_normal_step,
							h: CircleWidth_normal_step,
							start_angle: start_angle_normal_step,
							end_angle: end_angle_normal_step_draw,
							color: color_cs_normal_step,
							line_width: line_width_cs_normal_step,
						});
					};

				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateScales();

					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}