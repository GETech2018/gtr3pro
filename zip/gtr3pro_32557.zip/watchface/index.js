﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'back_blackblue_001a.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 451,
              src: 'batt -Picture4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 220,
              // start_y: 452,
              // color: 0xFF000000,
              // lenght: 41,
              // line_width: 19,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 414,
              font_array: ["ndays_black_white_digi_0001.png","ndays_black_white_digi_0002.png","ndays_black_white_digi_0003.png","ndays_black_white_digi_0004.png","ndays_black_white_digi_0005.png","ndays_black_white_digi_0006.png","ndays_black_white_digi_0007.png","ndays_black_white_digi_0008.png","ndays_black_white_digi_0009.png","ndays_black_white_digi_0010.png"],
              padding: false,
              h_space: -29,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 449,
              src: 'batt -Picture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 46,
              day_sc_array: ["ndays_black_white_digi_0001.png","ndays_black_white_digi_0002.png","ndays_black_white_digi_0003.png","ndays_black_white_digi_0004.png","ndays_black_white_digi_0005.png","ndays_black_white_digi_0006.png","ndays_black_white_digi_0007.png","ndays_black_white_digi_0008.png","ndays_black_white_digi_0009.png","ndays_black_white_digi_0010.png"],
              day_tc_array: ["ndays_black_white_digi_0001.png","ndays_black_white_digi_0002.png","ndays_black_white_digi_0003.png","ndays_black_white_digi_0004.png","ndays_black_white_digi_0005.png","ndays_black_white_digi_0006.png","ndays_black_white_digi_0007.png","ndays_black_white_digi_0008.png","ndays_black_white_digi_0009.png","ndays_black_white_digi_0010.png"],
              day_en_array: ["ndays_black_white_digi_0001.png","ndays_black_white_digi_0002.png","ndays_black_white_digi_0003.png","ndays_black_white_digi_0004.png","ndays_black_white_digi_0005.png","ndays_black_white_digi_0006.png","ndays_black_white_digi_0007.png","ndays_black_white_digi_0008.png","ndays_black_white_digi_0009.png","ndays_black_white_digi_0010.png"],
              day_zero: 1,
              day_space: -28,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 28,
              week_en: ["days_black_white_digi_0001.png","days_black_white_digi_0002.png","days_black_white_digi_0003.png","days_black_white_digi_0004.png","days_black_white_digi_0005.png","days_black_white_digi_0006.png","days_black_white_digi_0007.png"],
              week_tc: ["days_black_white_digi_0001.png","days_black_white_digi_0002.png","days_black_white_digi_0003.png","days_black_white_digi_0004.png","days_black_white_digi_0005.png","days_black_white_digi_0006.png","days_black_white_digi_0007.png"],
              week_sc: ["days_black_white_digi_0001.png","days_black_white_digi_0002.png","days_black_white_digi_0003.png","days_black_white_digi_0004.png","days_black_white_digi_0005.png","days_black_white_digi_0006.png","days_black_white_digi_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 22,
              hour_array: ["black_white_digi_0001.png","black_white_digi_0002.png","black_white_digi_0003.png","black_white_digi_0004.png","black_white_digi_0005.png","black_white_digi_0006.png","black_white_digi_0007.png","black_white_digi_0008.png","black_white_digi_0009.png","black_white_digi_0010.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 29,
              second_startY: 24,
              second_array: ["circl_shad_0001.png","circl_shad_0002.png","circl_shad_0003.png","circl_shad_0004.png","circl_shad_0005.png","circl_shad_0006.png","circl_shad_0007.png","circl_shad_0008.png","circl_shad_0009.png","circl_shad_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 190,
              minute_startY: 160,
              minute_array: ["zblack_white_digi_0001.png","zblack_white_digi_0002.png","zblack_white_digi_0003.png","zblack_white_digi_0004.png","zblack_white_digi_0005.png","zblack_white_digi_0006.png","zblack_white_digi_0007.png","zblack_white_digi_0008.png","zblack_white_digi_0009.png","zblack_white_digi_0010.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 216,
              hour_array: ["ndays_black_white_digi_0001.png","ndays_black_white_digi_0002.png","ndays_black_white_digi_0003.png","ndays_black_white_digi_0004.png","ndays_black_white_digi_0005.png","ndays_black_white_digi_0006.png","ndays_black_white_digi_0007.png","ndays_black_white_digi_0008.png","ndays_black_white_digi_0009.png","ndays_black_white_digi_0010.png"],
              hour_zero: 1,
              hour_space: -23,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 231,
              minute_startY: 216,
              minute_array: ["ndays_black_white_digi_0001.png","ndays_black_white_digi_0002.png","ndays_black_white_digi_0003.png","ndays_black_white_digi_0004.png","ndays_black_white_digi_0005.png","ndays_black_white_digi_0006.png","ndays_black_white_digi_0007.png","ndays_black_white_digi_0008.png","ndays_black_white_digi_0009.png","ndays_black_white_digi_0010.png"],
              minute_zero: 1,
              minute_space: -25,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 212,
              src: 'Picture76.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -25,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 261;
                  let start_y_normal_battery = 452;
                  let lenght_ls_normal_battery = -41;
                  let line_width_ls_normal_battery = 19;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}