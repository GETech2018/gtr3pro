﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg019.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 230,
              y: 62,
              week_en: ["0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
              week_tc: ["0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
              week_sc: ["0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 325,
              year_startY: 100,
              year_sc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              year_tc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              year_en_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 100,
              month_sc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              month_tc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              month_en_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Dot.png',
              month_unit_tc: 'Dot.png',
              month_unit_en: 'Dot.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 225,
              day_startY: 100,
              day_sc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              day_tc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              day_en_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Dot.png',
              day_unit_tc: 'Dot.png',
              day_unit_en: 'Dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 375,
              src: '0136.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 365,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 230,
              y: 375,
              image_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 410,
              y: 215,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 210,
              src: 'Stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 315,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 310,
              src: 'Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 265,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 260,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 390,
              y: 265,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 260,
              src: 'Calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 215,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 210,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 438,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 20,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 76,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 365,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Degree.png',
              unit_tc: 'Degree.png',
              unit_en: 'Degree.png',
              negative_image: 'Minus.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Hour.png',
              hour_centerX: 118,
              hour_centerY: 240,
              hour_posX: 88,
              hour_posY: 88,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Minute.png',
              minute_centerX: 118,
              minute_centerY: 240,
              minute_posX: 88,
              minute_posY: 88,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Sec.png',
              second_centerX: 118,
              second_centerY: 240,
              second_posX: 88,
              second_posY: 88,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 225,
              hour_startY: 150,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'special_11.png',
              hour_unit_tc: 'special_11.png',
              hour_unit_en: 'special_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'special_11.png',
              minute_unit_tc: 'special_11.png',
              minute_unit_en: 'special_11.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg020.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 60,
              week_en: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              week_tc: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              week_sc: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 100,
              year_sc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              year_tc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              year_en_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 100,
              month_sc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              month_tc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              month_en_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Dot.png',
              month_unit_tc: 'Dot.png',
              month_unit_en: 'Dot.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 100,
              day_sc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              day_tc_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              day_en_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Dot.png',
              day_unit_tc: 'Dot.png',
              day_unit_en: 'Dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 405,
              src: '0136.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 395,
              font_array: ["Battery_digit_01.png","Battery_digit_02.png","Battery_digit_03.png","Battery_digit_04.png","Battery_digit_05.png","Battery_digit_06.png","Battery_digit_07.png","Battery_digit_08.png","Battery_digit_09.png","Battery_digit_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 405,
              image_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 438,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 20,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 88,
              hour_posY: 88,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 88,
              minute_posY: 88,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 88,
              second_posY: 88,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 147,
              hour_startY: 340,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'special_11.png',
              hour_unit_tc: 'special_11.png',
              hour_unit_en: 'special_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'special_11.png',
              minute_unit_tc: 'special_11.png',
              minute_unit_en: 'special_11.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 225,
              y: 150,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 225,
              y: 259,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 70,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 310,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 355,
              y: 205,
              w: 100,
              h: 100,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 355,
              y: 137,
              w: 100,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 5,
              w: 100,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 230,
              y: 65,
              w: 175,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'butt.png',
              normal_src: 'butt.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 225,
              y: 367,
              w: 160,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'butt.png',
              normal_src: 'butt.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}