﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_day_pointer_progress_date_pointer = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_icon_img = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
		let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
		
// Start color change
        let btncolor = ''
        let colornumber = 0
        let totalcolors = 6

        function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=0;
                }
            else {
                colornumber=colornumber+1;
            }
            hmUI.showToast({text: "Color " + parseInt(colornumber) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber) + ".png");
            call_change_Hands();
        }

// Change hands called by backgroundcolor (default color with background)
        function call_change_Hands() {
              if(colornumber==1) {
                ChangeHands(1);
              } else if(colornumber==2) {
                ChangeHands(2);
              } else if(colornumber==3) {
                ChangeHands(3);
              } else if(colornumber==4) {
                ChangeHands(4);
			  } else if(colornumber==5) {
                ChangeHands(5);
              } else if(colornumber==6) {
                ChangeHands(6);
              } else if(colornumber==0) {
                ChangeHands(0);
              }
        }

// Start Change hands color (press button hour1)
        let btnchangehands = ''
        let handsnumber = 0
        let totalhands = 6

        function click_Changehands() {
          handsnumber=handsnumber+1;
          switch (handsnumber) {
            case 1:
              ChangeHands(1); break;
            case 2:
              ChangeHands(2); break;
            case 3:
              ChangeHands(3); break;
            case 4:
              ChangeHands(4); break;
            case 5:
              ChangeHands(5); break;
			case 6:
              ChangeHands(6); break;
            default:
              ChangeHands(0); handsnumber=0;
          }
          hmUI.showToast({text: "Date-Color " + parseInt(handsnumber) });
        }

// Give handsnumber. Must exist
        function ChangeHands(number) {
           if(number==1) {
                  daystring='day1.png';
                  monthstring='month1.png';
				  weekdaystring='weekday1.png';
             } else if(number==2) {
                  daystring='day2.png';
                  monthstring='month2.png';
				  weekdaystring='weekday2.png';
             } else if(number==3) {
                  daystring='day3.png';
                  monthstring='month3.png';
				  weekdaystring='weekday3.png';
             } else if(number==4) {
                  daystring='day4.png';
                  monthstring='month4.png';
				  weekdaystring='weekday4.png';
             } else if(number==5) {
                  daystring='day5.png';
                  monthstring='month5.png';
				  weekdaystring='weekday5.png';
			 } else if(number==6) {
                  daystring='day6.png';
                  monthstring='month6.png';
				  weekdaystring='weekday6.png';
             } else {
                  daystring='day0.png';
                  monthstring='month0.png';
				  weekdaystring='weekday0.png';
             }
			 
              normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: weekdaystring,
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: -100,
              end_angle: 71,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			  normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: monthstring,
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: 185,
              end_angle: 343,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			  normal_day_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: daystring,
              center_x: 240,
              center_y: 240,
              posX: 238,
              posY: 240,
              start_angle: 10,
              end_angle: 166,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

// Start Change content (press infield)
        let btnchangecontent = ''
        let contentnumber = 0
        let totalcontent = 3

        function click_Changecontent() {
          contentnumber=contentnumber+1;
          switch (contentnumber) {
            case 1:
              Changecontent(1); break;
            case 2:
              Changecontent(2); break;
            case 3:
              Changecontent(3); break;
            default:
              Changecontent(0); contentnumber=0;
          }
          if(contentnumber==1) hmUI.showToast({text: 'Health'});
          if(contentnumber==2) hmUI.showToast({text: 'Temperature'});
          if(contentnumber==3) hmUI.showToast({text: 'Sun'});
		  if(contentnumber==0) hmUI.showToast({text: 'Activity'});
        }

	// Give contentnumber. Must exist
        function Changecontent(number) {
           if(number==1) {
                  UpdatecontentHealth();
             } else if(number==2) {
                  UpdatecontentTemp();
             } else if(number==3) {
                  UpdatecontentSun();
             } else {
                  UpdatecontentAct();
             }
        }

        function UpdatecontentHealth(){
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdatecontentTemp(){
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatecontentSun(){
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        }

		function UpdatecontentAct(){
                normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        }
//END Change content (press infield)
//Analog Clock on-off START
       
		let btnanaclock = ''
        let clocknumber = 0
        let totalclock = 1

        function click_anaclock() {
          clocknumber=clocknumber+1;
          switch (clocknumber) {
            case 1:
              Changeclock(1); break;
            default:
              Changeclock(0); clocknumber=0;
          }
          if(clocknumber==1) hmUI.showToast({text: 'Analog: Off'});
          if(clocknumber==0) hmUI.showToast({text: 'Analog: On'});
        }

	// Give contentnumber. Must exist
        function Changeclock(number) {
           if(number==1) {
                  UpdateClockOff();
             } else {
                  UpdateClockOn();
             }
        }
		
	let screenType = hmSetting.getScreenType();
        if (screenType != hmSetting.screen_type.AOD) {
				
        function UpdateClockOff(){
                editableTimePointers.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdateClockOn(){
                editableTimePointers.setProperty(hmUI.prop.VISIBLE, true);
        }
	};
//Analog Clock on-off END
//dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
//dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'weekday0.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: -100,
              end_angle: 71,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month0.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: 185,
              end_angle: 343,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 360,
              src: 'animation/anim_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 360,
              anim_to: 0,
              anim_fps: 25,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
                normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
                normal_rotate_animation_lastTime_1 = now.utc;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'anim_0.png',
              // anim_fps: 25,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day0.png',
              center_x: 240,
              center_y: 240,
              posX: 238,
              posY: 240,
              start_angle: 10,
              end_angle: 166,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 103,
              // end_angle: 265,
              // radius: 176,
              // line_width: 34,
              // color: 0xFF555555,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 358,
              font_array: ["light_num_00.png","light_num_01.png","light_num_02.png","light_num_03.png","light_num_04.png","light_num_05.png","light_num_06.png","light_num_07.png","light_num_08.png","light_num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'light_num_10.png',
              unit_tc: 'light_num_10.png',
              unit_en: 'light_num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 268,
              src: 'icon_uvi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			
            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 271,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dark_10.png',
              dot_image: 'dark_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 325,
              src: 'icon_sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dark_10.png',
              dot_image: 'dark_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 327,
              src: 'icon_sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 328,
              src: 'icon_o2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 329,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 271,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 268,
              src: 'icon_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 271,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'dark_15.png',
              unit_tc: 'dark_15.png',
              unit_en: 'dark_15.png',
              imperial_unit_sc: 'dark_16.png',
              imperial_unit_tc: 'dark_16.png',
              imperial_unit_en: 'dark_16.png',
              dot_image: 'dark_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 328,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 329,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 216,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 175,
              y: 264,
              w: 130,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 291,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dark_11.png',
              unit_tc: 'dark_11.png',
              unit_en: 'dark_11.png',
              negative_image: 'dark_12.png',
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 323,
              src: 'icon_temp_max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 291,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dark_11.png',
              unit_tc: 'dark_11.png',
              unit_en: 'dark_11.png',
              negative_image: 'dark_12.png',
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 323,
              src: 'icon_temp_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 308,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'dark_11.png',
              unit_tc: 'dark_11.png',
              unit_en: 'dark_11.png',
              negative_image: 'dark_12.png',
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 319,
              y: 216,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 119,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 107,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 120,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 316,
              am_y: 157,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 316,
              pm_y: 157,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 158,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 0,
              hour_space: 2,
              hour_unit_sc: 'big_10.png',
              hour_unit_tc: 'big_10.png',
              hour_unit_en: 'big_10.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 297,
              second_startY: 177,
              second_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//Set Activity first
             UpdatecontentAct();

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'weekday6.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: -100,
              end_angle: 71,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month6.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: 185,
              end_angle: 343,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day6.png',
              center_x: 240,
              center_y: 240,
              posX: 238,
              posY: 240,
              start_angle: 10,
              end_angle: 166,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 103,
              // end_angle: 265,
              // radius: 176,
              // line_width: 34,
              // color: 0xFF555555,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 358,
              font_array: ["light_num_00.png","light_num_01.png","light_num_02.png","light_num_03.png","light_num_04.png","light_num_05.png","light_num_06.png","light_num_07.png","light_num_08.png","light_num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'light_num_10.png',
              unit_tc: 'light_num_10.png',
              unit_en: 'light_num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 271,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'dark_15.png',
              unit_tc: 'dark_15.png',
              unit_en: 'dark_15.png',
              imperial_unit_sc: 'dark_16.png',
              imperial_unit_tc: 'dark_16.png',
              imperial_unit_en: 'dark_16.png',
              dot_image: 'dark_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 328,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 329,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 302,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 216,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 319,
              y: 216,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 119,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 107,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 120,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 316,
              am_y: 157,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 316,
              pm_y: 157,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 158,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 0,
              hour_space: 2,
              hour_unit_sc: 'big_10.png',
              hour_unit_tc: 'big_10.png',
              hour_unit_en: 'big_10.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 297,
              second_startY: 177,
              second_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'time_hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'time_min.png',
                  },
                  preview: 'Preview_01.png',
                },
                {
                  id: 2,
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'blank.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'blank.png',
                  },
                  preview: 'Preview_02.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 150,
              w: 100,
              h: 55,
              src: 'blank.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 150,
              w: 100,
              h: 55,
              src: 'blank.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 //START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 380,
              y: 190,
              w: 100,
              h: 100,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });
//END Calendar Shortcut

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 210,
              w: 60,
              h: 60,
              src: 'blank.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 210,
              w: 60,
              h: 60,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// START AOD Shortcut 
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 190,
              w: 100,
              h: 100,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'Settings_standbyHomeScreen', native: true })
            });
// END AOD Shortcut 
// START Battery Shortcut            
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 335,
              w: 100,
              h: 65,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
            });
// END Battery Shortcut			
// Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 0,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
// Change color background shortcut end			
// Changehands shortcut start
            btnchangehands = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 400,
              text: '',
              w: 100,
              h: 80,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Changehands();
              },			
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnchangehands.setProperty(hmUI.prop.VISIBLE, true);
// Changehands shortcut end			
// Analog Clock shortcut start
            btnanaclock = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 210,
              text: '',
              w: 60,
              h: 60,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_anaclock();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnanaclock.setProperty(hmUI.prop.VISIBLE, true);
// Analog Clock shortcut end																  
// Change content shortcut start
            btnchangecontent = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 270,
              text: '',
              w: 180,
              h: 65,
              normal_src: 'blank.png',
			  press_src: 'blank.png',
              click_func: () => {
               click_Changecontent();
              },
			show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnchangecontent.setProperty(hmUI.prop.VISIBLE, true);
// Change content shortcut end
			
			function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 175;
                  let end_angle_normal_battery = 13;
                  let center_x_normal_battery = 240;
                  let center_y_normal_battery = 240;
                  let radius_normal_battery = 176;
                  let line_width_cs_normal_battery = 34;
                  let color_cs_normal_battery = 0xFF555555;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = 175;
                  let end_angle_idle_battery = 13;
                  let center_x_idle_battery = 240;
                  let center_y_idle_battery = 240;
                  let radius_idle_battery = 176;
                  let line_width_cs_idle_battery = 34;
                  let color_cs_idle_battery = 0xFF555555;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                stop_anim_rotate_1();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
