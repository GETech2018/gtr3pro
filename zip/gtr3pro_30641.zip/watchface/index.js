﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'Preview1.png', path: '001.png' },
                { id: 2, preview: 'Preview2.png', path: '002.png' },
                { id: 3, preview: 'Preview3.png', path: '004.png' },
                { id: 4, preview: 'Preview04.png', path: '006.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tap.png',
              tips_x: 188,
              tips_y: 218,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 251,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 252,
              src: 'alrm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 420,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 227,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'set011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 227,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'set011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 190,
              y: 286,
              w: 154,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 397,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 397,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 323,
              font_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'wth12.png',
              unit_tc: 'wth12.png',
              unit_en: 'wth12.png',
              negative_image: 'min011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 54,
              y: 304,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 318,
              font_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0075.png',
              unit_tc: '0075.png',
              unit_en: '0075.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 356,
              y: 124,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 124,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 249,
              month_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 248,
              day_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 158,
              y: 211,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 88,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0076.png',
              unit_tc: '0076.png',
              unit_en: '0076.png',
              dot_image: '0077.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 53,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 223,
              am_y: 148,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 223,
              pm_y: 148,
              pm_sc_path: 'ampm.png',
              pm_en_path: 'ampm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 154,
              hour_startY: 162,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 162,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0094.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 18,
              second_posY: 249,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 221,
              w: 80,
              h: 80,
              src: '0100.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 400,
              w: 100,
              h: 100,
              src: '0100.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 297,
              w: 100,
              h: 100,
              src: '0100.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 118,
              w: 100,
              h: 100,
              src: '0100.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 42,
              w: 100,
              h: 100,
              src: '0100.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 250,
              month_startY: 218,
              month_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 394,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0102.png',
              unit_tc: '0102.png',
              unit_en: '0102.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 218,
              day_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 218,
              src: '0084.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 157,
              y: 179,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 220,
              am_y: 102,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 220,
              pm_y: 102,
              pm_sc_path: 'ampm.png',
              pm_en_path: 'ampm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 154,
              hour_startY: 125,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 125,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  