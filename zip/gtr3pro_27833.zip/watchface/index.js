﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_pai_day_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_pai_day_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
		
		/**
         * SMOOTH SECONDS SCRIPTS
         */
        let now;
        let lastTime = 0;
        let animTimer;
        let widgetDelegate;
        const animDuration = 5000;
        const animFps = 10; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion

        function setSec() {
          const screenType = hmSetting.getScreenType();
          if (screenType === hmSetting.screen_type.AOD) {
           return stopSecAnim();
          }
          if (!now) {
            now = hmSensor.createSensor(hmSensor.id.TIME);
          }
          if (widgetDelegate) return;

          widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: (function () {
              console.log('ui resume');

              if (animTimer) return;

              let duration = 0;
              const diffTime = now.utc - lastTime;
              if (diffTime < animDuration) {
                duration = animDuration - diffTime;
              }

              animTimer = timer.createTimer(duration, animDuration, (function (option) {
                lastTime = now.utc;
                startSecAnim(now.second * 6);
              }));
            }),
            pause_call: (function () {
              console.log('ui pause');
              stopSecAnim();
            }),
          });
        }

        function startSecAnim(sec) {
          const secAnim = {
            anim_rate: 'linear',
            anim_duration: animDuration,
            anim_from: sec,
            anim_to: sec + animDuration * 6 / 1000,
            repeat_count: 1,
            anim_fps: animFps,
            anim_key: "angle",
            anim_status: 1,
          }

          normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()
         */
        function stopSecAnim() {
          if (animTimer) {
            timer.stopTimer(animTimer);
            animTimer = undefined;
          }
        }

        
	    /** END SMOOTH SECOND SCRIPTS */			
		
        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1003,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: '0001.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: '0031.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: '0032.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: '0033.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '0034.png',
              tips_bg: '0035.png',
              tips_x: 190,
              tips_y: 350,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 350,
              src: '0028.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 110,
              src: '0030.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 350,
              src: '0027.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 110,
              src: '0029.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 283,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 240,
              center_y: 352,
              x: 12,
              y: 69,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 170,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 170,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 128,
              center_y: 240,
              x: 12,
              y: 69,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 352,
              center_y: 240,
              x: 12,
              y: 69,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 74,
              day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0005.png',
              center_x: 240,
              center_y: 128,
              posX: 12,
              posY: 69,
              start_angle: 0,
              end_angle: 315,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //24h
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              pos_x: 240-20,
              pos_y: 240-51,
              center_x: 240,
              center_y: 240,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			// 24h end

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = normal_analog_clock_time_pointer_second || hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              pos_x: 480 / 2 - 12,
              pos_y: 480 / 2 - 240,
              center_x: 240,
              center_y: 240,
              src: "0004.png",
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            setSec();

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 190,
              w: 100,
              h: 100,
              src: '0006.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 350,
              w: 100,
              h: 100,
              src: '0006.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 30,
              w: 100,
              h: 100,
              src: '0006.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 190,
              w: 100,
              h: 100,
              src: '0006.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 350,
              src: '0028.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 110,
              src: '0030.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 350,
              src: '0027.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 110,
              src: '0029.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 283,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 240,
              center_y: 352,
              x: 12,
              y: 69,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 170,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 170,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 128,
              center_y: 240,
              x: 12,
              y: 69,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 352,
              center_y: 240,
              x: 12,
              y: 69,
              start_angle: 30,
              end_angle: 330,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 74,
              day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0005.png',
              center_x: 240,
              center_y: 128,
              posX: 12,
              posY: 69,
              start_angle: 0,
              end_angle: 315,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //24h
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              pos_x: 240-20,
              pos_y: 240-51,
              center_x: 240,
              center_y: 240,
              src: '0002',
              show_level: hmUI.show_level.ONAL_AOD,
            });
			// 24h end

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_AOD,
            });

	            // 24h
			let now = hmSensor.createSensor(hmSensor.id.TIME);
			let screenType = hmSetting.getScreenType();

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				if (screenType == hmSetting.screen_type.AOD) {
					idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, 360*now.hour/24 + 15*now.minute/60 + 180);
						
					if (!timer_hour_hend) {
					  timer_hour_hend = timer.createTimer(0, 60*1000, (function (option) {
						let nawAnimationTime = now.utc;
						let hour = now.hour;
						let minute = now.minute;
						let angle = 360*hour/24 + 15*minute/60 + 180;
						idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, angle);
					  })); // end timer create
					};
				} else {
					let nawAnimationTime = now.utc;
					let hour = now.hour;
					let minute = now.minute;
					let angle = 360*hour/24 + 15*minute/60 + 180;
					normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, angle);
				}

              }),
              pause_call: (function () {
				if (timer_hour_hend) {
					timer.stopTimer(timer_hour_hend);
					timer_hour_hend = undefined;
				};
              }),
            });
			// 24h end		

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  