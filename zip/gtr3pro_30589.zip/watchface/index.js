﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0079.png',
              center_x: 240,
              center_y: 240,
              posX: 16,
              posY: 219,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 207,
              y: 319,
              week_en: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              week_tc: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              week_sc: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 287,
              day_sc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_tc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_en_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 226,
              src: 'blck.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 407,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 226,
              src: 'blal.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 302,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'up011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 302,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'up011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 164,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'up012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 164,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 62,
              font_array: ["HPA001.png","HPA002.png","HPA003.png","HPA004.png","HPA005.png","HPA006.png","HPA007.png","HPA008.png","HPA009.png","HPA010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 95,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'down012.png',
              unit_tc: 'down012.png',
              unit_en: 'down012.png',
              negative_image: 'down011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 95,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'down012.png',
              unit_tc: 'down012.png',
              unit_en: 'down012.png',
              negative_image: 'down011.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 93,
              font_array: ["dwnBLCK001.png","dwnBLCK002.png","dwnBLCK003.png","dwnBLCK004.png","dwnBLCK005.png","dwnBLCK006.png","dwnBLCK007.png","dwnBLCK008.png","dwnBLCK009.png","dwnBLCK010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dwnBLCK012.png',
              unit_tc: 'dwnBLCK012.png',
              unit_en: 'dwnBLCK012.png',
              negative_image: 'dwnBLCK011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 117,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 374,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 374,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 374,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0002.png',
              second_centerX: 241,
              second_centerY: 241,
              second_posX: 25,
              second_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 218,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 265,
              minute_startY: 218,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 219,
              second_startY: 204,
              second_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 201,
              w: 165,
              h: 80,
              src: '150.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 91,
              w: 128,
              h: 108,
              src: '150.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 201,
              w: 169,
              h: 80,
              src: '150.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 283,
              w: 333,
              h: 59,
              src: '150.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 33,
              w: 106,
              h: 163,
              src: '150.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 345,
              w: 141,
              h: 106,
              src: '150.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 93,
              w: 128,
              h: 106,
              src: '150.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0079.png',
              center_x: 240,
              center_y: 240,
              posX: 16,
              posY: 203,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 207,
              y: 382,
              week_en: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              week_tc: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              week_sc: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 349,
              day_sc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_tc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_en_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 218,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 265,
              minute_startY: 218,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 219,
              second_startY: 204,
              second_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 82,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0002.png',
              second_centerX: 241,
              second_centerY: 241,
              second_posX: 25,
              second_posY: 223,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  