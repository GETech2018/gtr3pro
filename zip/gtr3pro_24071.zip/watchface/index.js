﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 204,
              y: 53,
              src: 'System_Bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 271,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 78,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 322,
              day_startY: 177,
              day_sc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_tc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_en_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 314,
              y: 145,
              week_en: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_tc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_sc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 173,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_14.png',
              unit_tc: 'ACT_14.png',
              unit_en: 'ACT_14.png',
              dot_image: 'ACT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 131,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 85,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_13.png',
              unit_tc: 'ACT_13.png',
              unit_en: 'ACT_13.png',
              negative_image: 'ACT_11.png',
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 88,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 352,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_Battery.png',
              center_x: 240,
              center_y: 240,
              x: 15,
              y: 211,
              start_angle: 209,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 405,
              font_array: ["Batt_font_01.png","Batt_font_02.png","Batt_font_03.png","Batt_font_04.png","Batt_font_05.png","Batt_font_06.png","Batt_font_07.png","Batt_font_08.png","Batt_font_09.png","Batt_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 217,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 224,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 75,
              am_y: 292,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 75,
              pm_y: 292,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 293,
              hour_array: ["Time-HM_01.png","Time-HM_02.png","Time-HM_03.png","Time-HM_04.png","Time-HM_05.png","Time-HM_06.png","Time-HM_07.png","Time-HM_08.png","Time-HM_09.png","Time-HM_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 293,
              minute_array: ["Time-HM_01.png","Time-HM_02.png","Time-HM_03.png","Time-HM_04.png","Time-HM_05.png","Time-HM_06.png","Time-HM_07.png","Time-HM_08.png","Time-HM_09.png","Time-HM_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 371,
              second_startY: 282,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 51,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 303,
              w: 25,
              h: 73,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 278,
              w: 63,
              h: 52,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 263,
              y: 256,
              w: 45,
              h: 38,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 344,
              w: 40,
              h: 41,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 137,
              y: 87,
              w: 116,
              h: 38,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 217,
              w: 55,
              h: 44,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 217,
              w: 82,
              h: 43,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 134,
              w: 147,
              h: 36,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 204,
              y: 53,
              src: 'System_Bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 271,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 78,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 322,
              day_startY: 177,
              day_sc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_tc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_en_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 314,
              y: 145,
              week_en: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_tc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_sc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 173,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_14.png',
              unit_tc: 'ACT_14.png',
              unit_en: 'ACT_14.png',
              dot_image: 'ACT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 131,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 85,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_13.png',
              unit_tc: 'ACT_13.png',
              unit_en: 'ACT_13.png',
              negative_image: 'ACT_11.png',
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 88,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 352,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_Battery.png',
              center_x: 240,
              center_y: 240,
              x: 15,
              y: 211,
              start_angle: 209,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 405,
              font_array: ["Batt_font_01.png","Batt_font_02.png","Batt_font_03.png","Batt_font_04.png","Batt_font_05.png","Batt_font_06.png","Batt_font_07.png","Batt_font_08.png","Batt_font_09.png","Batt_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 217,
              font_array: ["ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png","ACT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 224,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 75,
              am_y: 292,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 75,
              pm_y: 292,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 293,
              hour_array: ["Time-HM_01.png","Time-HM_02.png","Time-HM_03.png","Time-HM_04.png","Time-HM_05.png","Time-HM_06.png","Time-HM_07.png","Time-HM_08.png","Time-HM_09.png","Time-HM_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 293,
              minute_array: ["Time-HM_01.png","Time-HM_02.png","Time-HM_03.png","Time-HM_04.png","Time-HM_05.png","Time-HM_06.png","Time-HM_07.png","Time-HM_08.png","Time-HM_09.png","Time-HM_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 371,
              second_startY: 282,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 51,
              second_posY: 239,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  