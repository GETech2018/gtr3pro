    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg1.png', 'bg2.png', 'bg3.png', 'bg4.png', 'bg5.png', 'bg7.png'];
        let backgroundToastList = ['Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        //------------------------ автозамена иконок погоды -----------------------------------
        
        let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// время восхода
        let sunsetMins_def = 20 * 60;			// и заката по умолчанию
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;
        }
        } else {
        if(isDayIcons){
          for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;
        }
        }
        }
        
        //------------------------ автозамена иконок погоды ----------------------------------- \\	
		
		let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - day, 1 - night
        let hands_smoth_state_txt = ''

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 425,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 57,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 70,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_C.png',
              unit_tc: 'Temp_C.png',
              unit_en: 'Temp_C.png',
              negative_image: 'Temp_error.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 13,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 244,
              // start_y: 223,
              // color: 0xFF000000,
              // lenght: 225,
              // line_width: 36,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 293,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 350,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 385,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 433,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 356,
              day_startY: 163,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 255,
              y: 183,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 12,
              am_y: 232,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 12,
              pm_y: 232,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 261,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 79,
              minute_startY: 332,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 163,
              second_startY: 433,
              second_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 149,
              // center_y: 149,
              // x: 17,
              // y: 106,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 149 - 17,
              pos_y: 149 - 106,
              center_x: 149,
              center_y: 149,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 149,
              // center_y: 149,
              // x: 17,
              // y: 106,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 149 - 17,
              pos_y: 149 - 106,
              center_x: 149,
              center_y: 149,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S7.png',
              // center_x: 149,
              // center_y: 149,
              // x: 17,
              // y: 106,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 149 - 17,
              pos_y: 149 - 106,
              center_x: 149,
              center_y: 149,
              src: 'Hand_S7.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 152,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 65,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 142,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 255,
              y: 183,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 232,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 300,
              minute_startY: 232,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 13,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 226,
              y: 67,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 309,
              y: 115,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 309,
              y: 168,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 309,
              y: 285,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 334,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 382,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 434,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: -22,
              // y: 276,
              // w: 100,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // bg_list: bg1|bg2|bg3|bg4|bg5|bg7,
              // toast_list: Background %s|Background %s|Background %s|Background %s|Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -22,
              y: 276,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 469;
                  let start_y_normal_step = 223;
                  let lenght_ls_normal_step = -225;
                  let line_width_ls_normal_step = 36;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 18,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
				autoToggleWeatherIcons();
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}