﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 369,
              src: '0091.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 369,
              src: '0094.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 132,
              month_sc_array: ["2024.png","2025.png","2026.png","2027.png","2028.png","2029.png","2030.png","2031.png","2032.png","2033.png","2034.png","2035.png"],
              month_tc_array: ["2024.png","2025.png","2026.png","2027.png","2028.png","2029.png","2030.png","2031.png","2032.png","2033.png","2034.png","2035.png"],
              month_en_array: ["2024.png","2025.png","2026.png","2027.png","2028.png","2029.png","2030.png","2031.png","2032.png","2033.png","2034.png","2035.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 116,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 388,
              font_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              padding: false,
              h_space: 2,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              negative_image: '0087.png',
              invalid_image: '0088.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 292,
              image_array: ["w052.png","w053.png","w054.png","w055.png","w056.png","w057.png","w058.png","w059.png","w060.png","w061.png","w062.png","w063.png","w064.png","w065.png","w066.png","w067.png","w068.png","w069.png","w070.png","w071.png","w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 348,
              font_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 348,
              font_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 116,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 251,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              dot_image: '0075.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 248,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 192,
              y: 93,
              week_en: ["t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png"],
              week_tc: ["t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png"],
              week_sc: ["t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 242,
              day_startY: 96,
              day_sc_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              day_tc_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              day_en_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0077.png',
              hour_centerX: 239,
              hour_centerY: 239,
              hour_posX: 27,
              hour_posY: 166,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0078.png',
              minute_centerX: 239,
              minute_centerY: 239,
              minute_posX: 27,
              minute_posY: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 239,
              second_centerY: 239,
              second_posX: 16,
              second_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 369,
              src: '0091.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 369,
              src: '0094.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 132,
              month_sc_array: ["2024.png","2025.png","2026.png","2027.png","2028.png","2029.png","2030.png","2031.png","2032.png","2033.png","2034.png","2035.png"],
              month_tc_array: ["2024.png","2025.png","2026.png","2027.png","2028.png","2029.png","2030.png","2031.png","2032.png","2033.png","2034.png","2035.png"],
              month_en_array: ["2024.png","2025.png","2026.png","2027.png","2028.png","2029.png","2030.png","2031.png","2032.png","2033.png","2034.png","2035.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 116,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 388,
              font_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              padding: false,
              h_space: 2,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              negative_image: '0087.png',
              invalid_image: '0088.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 292,
              image_array: ["w052.png","w053.png","w054.png","w055.png","w056.png","w057.png","w058.png","w059.png","w060.png","w061.png","w062.png","w063.png","w064.png","w065.png","w066.png","w067.png","w068.png","w069.png","w070.png","w071.png","w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 348,
              font_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 348,
              font_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 116,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 251,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 2,
              dot_image: '0075.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 248,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 192,
              y: 93,
              week_en: ["t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png"],
              week_tc: ["t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png"],
              week_sc: ["t007.png","t008.png","t009.png","t010.png","t011.png","t012.png","t013.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 242,
              day_startY: 96,
              day_sc_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              day_tc_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              day_en_array: ["l01.png","l02.png","l03.png","l04.png","l05.png","l06.png","l07.png","l08.png","l09.png","l10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0077.png',
              hour_centerX: 239,
              hour_centerY: 239,
              hour_posX: 27,
              hour_posY: 166,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0078.png',
              minute_centerX: 239,
              minute_centerY: 239,
              minute_posX: 27,
              minute_posY: 207,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 239,
              second_centerY: 239,
              second_posX: 16,
              second_posY: 221,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  