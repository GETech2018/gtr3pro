﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''

        let normal_g_heart = ''
        let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

   /////////////////////  Show graph heart rate  /////////////////////

             normal_g_heart=hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{

                              x: 168,
                              y: 389,
                              w: 145,
                              h: 23,
                              line_color:0xFF6600,
                              line_width:1,
            type:hmUI.data_type.HEART,
            show_level:hmUI.show_level.ONLY_NORMAL
          });


  ////////////////////////////////////////////////////////////////////

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 304,
              src: '69.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '70.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 197,
              font_array: ["digital3_0.png","digital3_1.png","digital3_2.png","digital3_3.png","digital3_4.png","digital3_5.png","digital3_6.png","digital3_7.png","digital3_8.png","digital3_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital3_11.png',
              unit_tc: 'digital3_11.png',
              unit_en: 'digital3_11.png',
              negative_image: 'digital3_10.png',
              invalid_image: 'digital3_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 161,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 260,
              month_sc_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png","digital13_10.png","digital13_11.png"],
              month_tc_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png","digital13_10.png","digital13_11.png"],
              month_en_array: ["digital13_0.png","digital13_1.png","digital13_2.png","digital13_3.png","digital13_4.png","digital13_5.png","digital13_6.png","digital13_7.png","digital13_8.png","digital13_9.png","digital13_10.png","digital13_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 167,
              week_en: ["71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              week_tc: ["71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              week_sc: ["71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 95,
              day_startY: 198,
              day_sc_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              day_tc_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              day_en_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 348,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 348,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 125,
              font_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital8_11.png',
              unit_tc: 'digital8_11.png',
              unit_en: 'digital8_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 33,
              image_array: ["59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 125,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 31,
              y: 31,
              image_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 97,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital7_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 43,
              font_array: ["digital10_0.png","digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png","digital10_8.png","digital10_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 81,
              image_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 162,
              hour_startY: 92,
              hour_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 162,
              minute_startY: 193,
              minute_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 318,
              second_startY: 230,
              second_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 379,
              y: 193,
              w: 100,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}