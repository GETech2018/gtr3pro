﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Ripp GTO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 144,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'KM1.png',
              unit_tc: 'KM1.png',
              unit_en: 'KM1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 97,
              src: '103.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 145,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 97,
              src: '252.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,
              y: 25,
              w: 155,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 70,
              font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              padding: false,
              h_space: 0,
              unit_sc: '62.png',
              unit_tc: '62.png',
              unit_en: '62.png',
              negative_image: '61.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 425,
              font_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat11.png',
              unit_tc: 'bat11.png',
              unit_en: 'bat11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 405,
              src: '138.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 318,
              year_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_zero: 1,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 160,
              month_startY: 318,
              month_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 340,
              src: 'q11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 318,
              day_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 340,
              src: 'q11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 190,
              hour_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              hour_zero: 1,
              hour_space: 20,
              hour_unit_sc: '31.png',
              hour_unit_tc: '31.png',
              hour_unit_en: '31.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '16.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 12,
              second_posY: 236,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Ripp GTO.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 145,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 0,
              dot_image: '125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 110,
              src: 'SUN_0090.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 145,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 0,
              dot_image: '125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 110,
              src: 'SUN_0091.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 320,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,
              y: 25,
              w: 155,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 65,
              font_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              padding: false,
              h_space: 0,
              unit_sc: '62.png',
              unit_tc: '62.png',
              unit_en: '62.png',
              negative_image: '61.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 115,
              image_array: ["w0035.png","w0036.png","w0037.png","w0038.png","w0039.png","w0040.png","w0041.png","w0042.png","w0043.png","w0044.png","w0045.png","w0046.png","w0047.png","w0048.png","w0049.png","w0050.png","w0051.png","w0052.png","w0053.png","w0054.png","w0055.png","w0056.png","w0057.png","w0058.png","w0059.png","w0060.png","w0061.png","w0062.png","w0063.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 425,
              font_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat11.png',
              unit_tc: 'bat11.png',
              unit_en: 'bat11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 405,
              src: '138.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 190,
              hour_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              hour_zero: 1,
              hour_space: 20,
              hour_unit_sc: '31.png',
              hour_unit_tc: '31.png',
              hour_unit_en: '31.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '16.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 12,
              second_posY: 236,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  