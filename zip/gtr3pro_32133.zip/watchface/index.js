﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'seconds-circle.png',
              // center_x: 240,
              // center_y: 238,
              // x: 158,
              // y: 158,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 158,
              pos_y: 238 - 158,
              center_x: 240,
              center_y: 238,
              src: 'seconds-circle.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 241,
              // center_y: 241,
              // start_angle: 5,
              // end_angle: 120,
              // radius: 225,
              // line_width: 17,
              // color: 0xFFFA9B53,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 306,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 401,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'zone1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 402,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 352,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 346,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 350,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_pointer.png',
              center_x: 343,
              center_y: 240,
              x: 11,
              y: 50,
              start_angle: 480,
              end_angle: 240,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 256,
              font_array: ["Battery_font_01.png","Battery_font_02.png","Battery_font_03.png","Battery_font_04.png","Battery_font_05.png","Battery_font_06.png","Battery_font_07.png","Battery_font_08.png","Battery_font_09.png","Battery_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 138,
              src: 'system_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 315,
              y: 140,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 46,
              y: 48,
              week_en: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              week_tc: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              week_sc: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month_pointer.png',
              center_x: 137,
              center_y: 239,
              posX: 22,
              posY: 82,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 111,
              day_startY: 213,
              day_sc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_tc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_en_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 320,
              am_y: 341,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 320,
              pm_y: 341,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 120,
              hour_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 120,
              minute_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 129,
              src: 'digital_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h1.png',
              hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 22,
              hour_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m1.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_s1.png',
              second_centerX: 239,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 241,
              // center_y: 241,
              // start_angle: 0,
              // end_angle: 120,
              // radius: 225,
              // line_width: 17,
              // color: 0xFFFA9B53,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 306,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 401,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'zone1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 402,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 352,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 346,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 350,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_pointer.png',
              center_x: 343,
              center_y: 240,
              x: 11,
              y: 50,
              start_angle: 480,
              end_angle: 240,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 256,
              font_array: ["Battery_font_01.png","Battery_font_02.png","Battery_font_03.png","Battery_font_04.png","Battery_font_05.png","Battery_font_06.png","Battery_font_07.png","Battery_font_08.png","Battery_font_09.png","Battery_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 138,
              src: 'system_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 315,
              y: 140,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 46,
              y: 48,
              week_en: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              week_tc: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              week_sc: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month_pointer.png',
              center_x: 137,
              center_y: 239,
              posX: 22,
              posY: 82,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 111,
              day_startY: 213,
              day_sc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_tc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_en_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 320,
              am_y: 341,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 320,
              pm_y: 341,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 120,
              hour_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 120,
              minute_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 129,
              src: 'digital_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h1.png',
              hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 22,
              hour_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m1.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 117,
              w: 70,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 117,
              w: 70,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 337,
              w: 55,
              h: 55,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 340,
              w: 100,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 395,
              w: 65,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 395,
              w: 70,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 290,
              w: 100,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 190,
              w: 110,
              h: 100,
              src: '0_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });
//END Calendar Shortcut 
//START Battery Shortcut            
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 190,
              w: 110,
              h: 100,
              src: '0_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
            });
//END Battery Shortcut
            
			function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -85;
                  let end_angle_normal_step = 30;
                  let center_x_normal_step = 241;
                  let center_y_normal_step = 241;
                  let radius_normal_step = 225;
                  let line_width_cs_normal_step = 17;
                  let color_cs_normal_step = 0xFFFA9B53;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 30;
                  let center_x_idle_step = 241;
                  let center_y_idle_step = 241;
                  let radius_idle_step = 225;
                  let line_width_cs_idle_step = 17;
                  let color_cs_idle_step = 0xFFFA9B53;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
