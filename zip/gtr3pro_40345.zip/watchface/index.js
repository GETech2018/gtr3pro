﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_calorie_current_text_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_image_progress_img_progress = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'back16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 321,
              month_startY: 233,
              month_sc_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png"],
              month_tc_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png"],
              month_en_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 111,
              font_array: ["AA00.png","AA01.png","AA01 Frame.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 110,
              font_array: ["AA00.png","AA01.png","AA01 Frame.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 276,
              font_array: ["AA00.png","AA01.png","AA01 Frame.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [141,141,141,141,141,141,141,141,141,141],
              y: [421,421,421,421,421,421,421,421,421,421],
              image_array: ["CC021.png","CC022.png","CC023.png","CC024.png","CC025.png","CC026.png","CC027.png","CC028.png","CC029.png","CC030.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 166,
              font_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              padding: false,
              h_space: -12,
              unit_sc: 'cel.png',
              unit_tc: 'cel.png',
              unit_en: 'cel.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 166,
              src: 'c.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 159,
              image_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 319,
              day_startY: 263,
              day_sc_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              day_tc_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              day_en_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              day_zero: 1,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 278,
              week_en: ["d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png"],
              week_tc: ["d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png"],
              week_sc: ["d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 327,
              hour_array: ["t000.png","t001.png","t002.png","t003.png","t004.png","t005.png","t006.png","t007.png","t008.png","t009.png"],
              hour_zero: 1,
              hour_space: -7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 210,
              minute_startY: 329,
              minute_array: ["t000.png","t001.png","t002.png","t003.png","t004.png","t005.png","t006.png","t007.png","t008.png","t009.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 295,
              second_startY: 328,
              second_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              second_zero: 1,
              second_space: -8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0086.png',
              hour_centerX: 238,
              hour_centerY: 238,
              hour_posX: 23,
              hour_posY: 148,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0087.png',
              minute_centerX: 238,
              minute_centerY: 238,
              minute_posX: 24,
              minute_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0088.png',
              second_centerX: 238,
              second_centerY: 238,
              second_posX: 17,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'back16.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 321,
              month_startY: 233,
              month_sc_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png"],
              month_tc_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png"],
              month_en_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 111,
              font_array: ["AA00.png","AA01.png","AA01 Frame.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 110,
              font_array: ["AA00.png","AA01.png","AA01 Frame.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 276,
              font_array: ["AA00.png","AA01.png","AA01 Frame.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [141,141,141,141,141,141,141,141,141,141],
              y: [421,421,421,421,421,421,421,421,421,421],
              image_array: ["CC021.png","CC022.png","CC023.png","CC024.png","CC025.png","CC026.png","CC027.png","CC028.png","CC029.png","CC030.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 166,
              font_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              padding: false,
              h_space: -12,
              unit_sc: 'cel.png',
              unit_tc: 'cel.png',
              unit_en: 'cel.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 166,
              src: 'c.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 159,
              image_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 319,
              day_startY: 263,
              day_sc_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              day_tc_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              day_en_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              day_zero: 1,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 278,
              week_en: ["d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png"],
              week_tc: ["d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png"],
              week_sc: ["d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 327,
              hour_array: ["t000.png","t001.png","t002.png","t003.png","t004.png","t005.png","t006.png","t007.png","t008.png","t009.png"],
              hour_zero: 1,
              hour_space: -7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 210,
              minute_startY: 329,
              minute_array: ["t000.png","t001.png","t002.png","t003.png","t004.png","t005.png","t006.png","t007.png","t008.png","t009.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 295,
              second_startY: 328,
              second_array: ["s000.png","s001.png","s002.png","s003.png","s004.png","s005.png","s006.png","s007.png","s008.png","s009.png"],
              second_zero: 1,
              second_space: -8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0086.png',
              hour_centerX: 238,
              hour_centerY: 238,
              hour_posX: 23,
              hour_posY: 148,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0087.png',
              minute_centerX: 238,
              minute_centerY: 238,
              minute_posX: 24,
              minute_posY: 200,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0088.png',
              second_centerX: 238,
              second_centerY: 238,
              second_posX: 17,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}