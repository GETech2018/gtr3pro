﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 19;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 24;
        let normal_battery_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 21;
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 62;
        let normal_timerTextUpdate = undefined;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 33;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 46;
        let normal_alarm_jumpable_img_click = ''

        let normal_g_heart = ''
        let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
        let min_heart = Math.min(...heartArr)
        let max_heart = Math.max(...heartArr)



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

   /////////////////////  Show graph heart rate  /////////////////////

             normal_g_heart=hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{

                              x: 65,
                              y: 100,
                              w: 350,
                              h: 100,
                              line_color:0xFF6600,
                              line_width:2,
            type:hmUI.data_type.HEART,
            show_level:hmUI.show_level.ONLY_NORMAL
          });


  ////////////////////////////////////////////////////////////////////


            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 79,
              y: 364,
              src: '56.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '57.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 165,
              // y: 416,
              // font_array: ["171.png","172.png","173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 90,
              // unit_en: '181.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '171.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '172.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '173.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '174.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '175.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '176.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '177.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '178.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '179.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '180.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 165,
                center_y: 416,
                pos_x: 165,
                pos_y: 416,
                angle: 90,
                src: '171.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 165,
              center_y: 416,
              pos_x: 165,
              pos_y: 416,
              angle: 90,
              src: '181.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -90,
              y: -24,
              image_array: ["109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 235,
              w: 150,
              h: 30,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFBA66,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 48,
              font_array: ["119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png"],
              padding: false,
              h_space: -2,
              unit_sc: '130.png',
              unit_tc: '130.png',
              unit_en: '130.png',
              negative_image: '129.png',
              invalid_image: '129.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 29,
              image_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 397,
              month_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              month_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              month_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 201,
              day_startY: 319,
              day_sc_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_tc_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_en_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 351,
              // y: 354,
              // font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 89,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = '34.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '35.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '36.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '37.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '38.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '39.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '40.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '41.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '42.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '43.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 351,
                center_y: 354,
                pos_x: 351,
                pos_y: 354,
                angle: 89,
                src: '34.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 55,
              font_array: ["171.png","172.png","173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png"],
              padding: false,
              h_space: 0,
              dot_image: '141.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 339,
              y: 292,
              font_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 207,
              src: '203.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 246,
              image_array: ["146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png"],
              image_length: 25,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 151,
              // y: 207,
              // font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '9.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 151,
                center_y: 207,
                pos_x: 151,
                pos_y: 207,
                angle: 0,
                src: '1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 324,
              // y: 321,
              // font_array: ["192.png","193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 6,
              // angle: 90,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = '192.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = '193.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = '194.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = '195.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = '196.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = '197.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = '198.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = '199.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = '200.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = '201.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 324,
                center_y: 321,
                pos_x: 324,
                pos_y: 321,
                angle: 90,
                src: '192.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 259,
              // y: 237,
              // font_array: ["182.png","183.png","184.png","185.png","186.png","187.png","188.png","189.png","190.png","191.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '182.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '183.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '184.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '185.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '186.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '187.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '188.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '189.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '190.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '191.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 259,
                center_y: 237,
                pos_x: 259,
                pos_y: 237,
                angle: 0,
                src: '182.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block



            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 400,
              y: 191,
              w: 100,
              h: 100,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    ///////////////////////  show value  main , max , min /////////////////////////

              let heart_num = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 123,
                                y: 202,
                                type: hmUI.data_type.HEART,
                                font_array:["131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png"],
                                h_space: 0,
                                align_h: hmUI.align.RIGHT,
                                padding: false,
                                isCharacter: true,
                                invalid_image: "131.png",
                                isCharacter: true,

                              });


               let maxText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 366,
                                y: 202,
                                text: max_heart,
                                type: hmUI.data_type.HEART,
                                font_array:["131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png"],
                                h_space: 0,
                                align_h: hmUI.align.RIGHT,
                                padding: false,
                                isCharacter: true,
                             });


                 let minText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                                x: 243,
                                y: 202,
                                text: min_heart,
                                type: hmUI.data_type.HEART,
                                font_array:["131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png"],
                                h_space: 2,
                                align_h: hmUI.align.RIGHT,
                                padding: false,
                                isCharacter: true,
                             });

     ////////////////// End /////////////////////////


            function text_update() {

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 165 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 165 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();
              normal_calorie_rotate_string = normal_calorie_rotate_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 351 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  img_offset -= normal_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 151 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeNaw.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_second_TextRotate_posOffset = normal_second_TextRotate_img_width * normal_second_rotate_string.length;
                  normal_second_TextRotate_posOffset = normal_second_TextRotate_posOffset + 6 * (normal_second_rotate_string.length - 1);
                  img_offset -= normal_second_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 324 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + 6;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  img_offset -= normal_minute_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 259 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

                                   let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
                                    let min_heart = Math.min(...heartArr)
                                    let max_heart = Math.max(...heartArr)
                                  
                                      heart_num.setProperty(hmUI.prop.MORE, {
                                        x: 123,
                                        y: 202,
                                        type: hmUI.data_type.HEART,
                             font_array:["131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png"],
                                        h_space: 2,
                                        align_h: hmUI.align.RIGHT,
                                        padding: false,
                                        isCharacter: true,
                                        invalid_image: "131.png",

                                    });


                                    maxText.setProperty(hmUI.prop.MORE, {
                                        x: 366,
                                        y: 202,
                                        text: max_heart,
                                        type: hmUI.data_type.HEART,
                              font_array:["131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png"],
                                        h_space: 0,
                                        align_h: hmUI.align.RIGHT,
                                        padding: false,
                                        isCharacter: true,
                                    });

                                    minText.setProperty(hmUI.prop.MORE, {
                                        x: 243,
                                        y: 202,
                                        text: min_heart,
                                        type: hmUI.data_type.HEART,
                               font_array:["131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png"],
                                        h_space: 0,
                                        align_h: hmUI.align.RIGHT,
                                        padding: false,
                                        isCharacter: true,
                                    });
                                    pause_call: (function () {
                                   console.log('ui pause');
                              }),
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}