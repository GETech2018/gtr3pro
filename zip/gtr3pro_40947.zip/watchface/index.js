﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_day_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 274,
              font_array: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png","0264.png","0265.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 228,
              src: '0406.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 315,
              y: 228,
              src: '0405.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 416,
              image_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 424,
              font_array: ["b_num_0.png","b_num_1.png","b_num_2.png","b_num_3.png","b_num_4.png","b_num_5.png","b_num_6.png","b_num_7.png","b_num_8.png","b_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradu.png',
              unit_tc: 'gradu.png',
              unit_en: 'gradu.png',
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 359,
              src: 's0139.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 403,
              font_array: ["b_num_0b.png","b_num_1b.png","b_num_2b.png","b_num_3b.png","b_num_4b.png","b_num_5b.png","b_num_6b.png","b_num_7b.png","b_num_8b.png","b_num_9b.png"],
              padding: false,
              h_space: 0,
              dot_image: 'hb_11b.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 222,
              font_array: ["01b_nr_1.png","01b_nr_2.png","01b_nr_3.png","01b_nr_4.png","01b_nr_5.png","01b_nr_6.png","01b_nr_7.png","01b_nr_8.png","01b_nr_9.png","01b_nr_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 420,
              y: 133,
              image_array: ["01_prr_1.png","01_prr_2.png","01_prr_3.png","01_prr_4.png","01_prr_5.png","01_prr_6.png","01_prr_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 222,
              font_array: ["01b_nr_1.png","01b_nr_2.png","01b_nr_3.png","01b_nr_4.png","01b_nr_5.png","01b_nr_6.png","01b_nr_7.png","01b_nr_8.png","01b_nr_9.png","01b_nr_10.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'error11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 132,
              image_array: ["01_prl_1.png","01_prl_2.png","01_prl_3.png","01_prl_4.png","01_prl_5.png","01_prl_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 132,
              year_startY: 111,
              year_sc_array: ["b_num_0.png","b_num_1.png","b_num_2.png","b_num_3.png","b_num_4.png","b_num_5.png","b_num_6.png","b_num_7.png","b_num_8.png","b_num_9.png"],
              year_tc_array: ["b_num_0.png","b_num_1.png","b_num_2.png","b_num_3.png","b_num_4.png","b_num_5.png","b_num_6.png","b_num_7.png","b_num_8.png","b_num_9.png"],
              year_en_array: ["b_num_0.png","b_num_1.png","b_num_2.png","b_num_3.png","b_num_4.png","b_num_5.png","b_num_6.png","b_num_7.png","b_num_8.png","b_num_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 80,
              day_sc_array: ["hb_1.png","hb_2.png","hb_3.png","hb_4.png","hb_5.png","hb_6.png","hb_7.png","hb_8.png","hb_9.png","hb_10.png"],
              day_tc_array: ["hb_1.png","hb_2.png","hb_3.png","hb_4.png","hb_5.png","hb_6.png","hb_7.png","hb_8.png","hb_9.png","hb_10.png"],
              day_en_array: ["hb_1.png","hb_2.png","hb_3.png","hb_4.png","hb_5.png","hb_6.png","hb_7.png","hb_8.png","hb_9.png","hb_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 280,
              month_startY: 106,
              month_sc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png"],
              month_tc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png"],
              month_en_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day.png',
              center_x: 240,
              center_y: 240,
              posX: 17,
              posY: 189,
              start_angle: -49,
              end_angle: 37,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 403,
              font_array: ["b_num_0b.png","b_num_1b.png","b_num_2b.png","b_num_3b.png","b_num_4b.png","b_num_5b.png","b_num_6b.png","b_num_7b.png","b_num_8b.png","b_num_9b.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 347,
              src: 's0126.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 141,
              y: 301,
              image_array: ["pb_1.png","pb_2.png","pb_3.png","pb_4.png","pb_5.png","pb_6.png","pb_7.png","pb_8.png","pb_9.png","pb_10.png","pb_11.png","pb_12.png","pb_13.png","pb_14.png"],
              image_length: 14,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 187,
              font_array: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png","0263.png","0264.png","0265.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0266.png',
              unit_tc: '0266.png',
              unit_en: '0266.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 141,
              y: 168,
              image_array: ["bt_1.png","bt_2.png","bt_3.png","bt_4.png","bt_5.png","bt_6.png","bt_7.png","bt_8.png","bt_9.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png"],
              image_length: 14,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 346,
              hour_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 252,
              minute_startY: 346,
              minute_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 227,
              second_startY: 396,
              second_array: ["b_num_0b.png","b_num_1b.png","b_num_2b.png","b_num_3b.png","b_num_4b.png","b_num_5b.png","b_num_6b.png","b_num_7b.png","b_num_8b.png","b_num_9b.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 342,
              src: 'hb_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'min.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 59,
              hour_posY: 198,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hr.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 59,
              minute_posY: 244,
              minute_cover_path: 's1.png',
              minute_cover_x: 181,
              minute_cover_y: 181,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 20,
              second_posY: 239,
              second_cover_path: 's2.png',
              second_cover_x: 215,
              second_cover_y: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 346,
              hour_array: ["03_ng_1.png","03_ng_2.png","03_ng_3.png","03_ng_4.png","03_ng_5.png","03_ng_6.png","03_ng_7.png","03_ng_8.png","03_ng_9.png","03_ng_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 252,
              minute_startY: 346,
              minute_array: ["03_ng_1.png","03_ng_2.png","03_ng_3.png","03_ng_4.png","03_ng_5.png","03_ng_6.png","03_ng_7.png","03_ng_8.png","03_ng_9.png","03_ng_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 342,
              src: 'AODhb_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'min.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 59,
              hour_posY: 198,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hr.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 59,
              minute_posY: 244,
              minute_cover_path: 's1.png',
              minute_cover_x: 181,
              minute_cover_y: 181,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}