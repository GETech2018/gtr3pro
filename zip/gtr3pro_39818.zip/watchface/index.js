﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_wind_text_text_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_uvi_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_year_TextCircle = new Array(4);
        let idle_year_TextCircle_ASCIIARRAY = new Array(10);
        let idle_year_TextCircle_img_width = 10;
        let idle_year_TextCircle_img_height = 8;
        let idle_timerTextUpdate = undefined;
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_group_ForecastWeather = ''
        let idle_forecast_date_week_img = new Array(5);
        let idle_forecast_date_week_img_array = ['day_mini_1.png', 'day_mini_2.png', 'day_mini_3.png', 'day_mini_4.png', 'day_mini_5.png', 'day_mini_6.png', 'day_mini_7.png'];
        let idle_forecast_average_text_font = new Array(5);
        let idle_forecast_image_progress_img_level = new Array(5);
        let idle_forecast_image_array = ['wea_1.png', 'wea_2.png', 'wea_3.png', 'wea_4.png', 'wea_5.png', 'wea_6.png', 'wea_7.png', 'wea_8.png', 'wea_9.png', 'wea_10.png', 'wea_11.png', 'wea_12.png', 'wea_13.png', 'wea_14.png', 'wea_15.png', 'wea_16.png', 'wea_17.png', 'wea_18.png', 'wea_19.png', 'wea_20.png', 'wea_21.png', 'wea_22.png', 'wea_23.png', 'wea_24.png', 'wea_25.png', 'wea_26.png', 'wea_27.png', 'wea_28.png', 'wea_29.png'];
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 174,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'img_altitude.png',
              unit_tc: 'img_altitude.png',
              unit_en: 'img_altitude.png',
              negative_image: 'pointer_5.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 174,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'img_barometer.png',
              unit_tc: 'img_barometer.png',
              unit_en: 'img_barometer.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 143,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 321,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_4.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 384,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 49,
              image_array: ["img_wind_1.png","img_wind_2.png","img_wind_3.png","img_wind_4.png","img_wind_5.png","img_wind_6.png","img_wind_7.png","img_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'option_0.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 238,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 50,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'img_forcewind.png',
              unit_tc: 'img_forcewind.png',
              unit_en: 'img_forcewind.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'option_1.png',
              // center_x: 114,
              // center_y: 298,
              // x: 16,
              // y: 51,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 114 - 16,
              pos_y: 298 - 51,
              center_x: 114,
              center_y: 298,
              src: 'option_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 375,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_0.png',
              unit_tc: 'pointer_0.png',
              unit_en: 'pointer_0.png',
              negative_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 235,
              y: 231,
              image_array: ["img_uv_1.png","img_uv_2.png","img_uv_3.png","img_uv_4.png","img_uv_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              // radius: 220,
              // angle: 47,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextCircle_ASCIIARRAY[0] = 'small_0.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[1] = 'small_1.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[2] = 'small_2.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[3] = 'small_3.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[4] = 'small_4.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[5] = 'small_5.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[6] = 'small_6.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[7] = 'small_7.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[8] = 'small_8.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[9] = 'small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_year_TextCircle_img_width / 2,
                pos_y: 240 - 228,
                src: 'small_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 428,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 438,
              font_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              imperial_unit_sc: 'pointer_2.png',
              imperial_unit_tc: 'pointer_2.png',
              imperial_unit_en: 'pointer_2.png',
              negative_image: 'pointer_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 46,
              font_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 106,
              font_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 106,
              font_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 353,
              day_startY: 308,
              day_sc_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              day_tc_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              day_en_array: ["act_aod_0.png","act_aod_1.png","act_aod_2.png","act_aod_3.png","act_aod_4.png","act_aod_5.png","act_aod_6.png","act_aod_7.png","act_aod_8.png","act_aod_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 72,
              y: 301,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 51,
              // DaysCount: 5,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_forecast_date_week_img = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 120,
              // y: 386,
              // image_array: ["day_mini_1.png","day_mini_2.png","day_mini_3.png","day_mini_4.png","day_mini_5.png","day_mini_6.png","day_mini_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_date_week_img[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 120 + i*51,
                  y: 386,
                  src: idle_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            // idle_forecast_average_text_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 63,
              // y: 398,
              // w: 150,
              // h: 30,
              // text_size: 14,
              // char_space: 1,
              // line_space: 0,
              // color: 0xFFC8C8C8,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_average_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_average_text_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 63 + i*51,
                  y: 398,
                  w: 150,
                  h: 30,
                  text_size: 14,
                  char_space: 1,
                  line_space: 0,
                  color: 0xFFC8C8C8,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 126,
              // y: 359,
              // image_array: ["wea_1.png","wea_2.png","wea_3.png","wea_4.png","wea_5.png","wea_6.png","wea_7.png","wea_8.png","wea_9.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png","wea_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 126 + i*51,
                  y: 359,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 170,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: 'pointer_3.png',
              hour_unit_tc: 'pointer_3.png',
              hour_unit_en: 'pointer_3.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 190,
              minute_startY: 170,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_3.png',
              minute_unit_tc: 'pointer_3.png',
              minute_unit_en: 'pointer_3.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 333,
              second_startY: 170,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 63,
              y: 248,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 128,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 235,
              y: 378,
              w: 140,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 235,
              y: 308,
              w: 180,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 99,
              w: 60,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 333,
              y: 112,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, idle_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_Font_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle year_TIME');
              let valueYear = timeSensor.year;
              let idle_year_circle_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 47;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_circle_string.length > 0 && idle_year_circle_string.length <= 4) {  // display data if it was possible to get it
                  let idle_year_TextCircle_img_angle = 0;
                  let idle_year_TextCircle_dot_img_angle = 0;
                  idle_year_TextCircle_img_angle = toDegree(Math.atan2(idle_year_TextCircle_img_width/2, 220));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_year_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_year_TextCircle_img_width / 2);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.SRC, idle_year_TextCircle_ASCIIARRAY[charCode]);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_year_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}