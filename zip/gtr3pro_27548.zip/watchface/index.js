﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_distance_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BackGround.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 377,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 386,
              font_array: ["SSSilverN0.png","SSSilverN1.png","SSSilverN2.png","SSSilverN3.png","SSSilverN4.png","SSSilverN5.png","SSSilverN6.png","SSSilverN7.png","SSSilverN8.png","SSSilverN9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 84,
              y: 383,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 388,
              month_sc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              month_tc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              month_en_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 388,
              day_sc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              day_tc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              day_en_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              day_zero: 1,
              day_space: -4,
              day_unit_sc: 'SmSilverNM.png',
              day_unit_tc: 'SmSilverNM.png',
              day_unit_en: 'SmSilverNM.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 343,
              font_array: ["SSSilverN0.png","SSSilverN1.png","SSSilverN2.png","SSSilverN3.png","SSSilverN4.png","SSSilverN5.png","SSSilverN6.png","SSSilverN7.png","SSSilverN8.png","SSSilverN9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'SSSilverNKm.png',
              unit_tc: 'SSSilverNKm.png',
              unit_en: 'SSSilverNKm.png',
              dot_image: 'SSSilverNDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 342,
              src: 'StepIC.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 343,
              font_array: ["SSSilverN0.png","SSSilverN1.png","SSSilverN2.png","SSSilverN3.png","SSSilverN4.png","SSSilverN5.png","SSSilverN6.png","SSSilverN7.png","SSSilverN8.png","SSSilverN9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 176,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 412,
              y: 284,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 60,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 77,
              font_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'SmSilverNDeg.png',
              unit_tc: 'SmSilverNDeg.png',
              unit_en: 'SmSilverNDeg.png',
              negative_image: 'SmSilverNM.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 187,
              y: 33,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 330,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 164,
              hour_array: ["SilverN0.png","SilverN1.png","SilverN2.png","SilverN3.png","SilverN4.png","SilverN5.png","SilverN6.png","SilverN7.png","SilverN8.png","SilverN9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_unit_sc: 'SilverNS.png',
              hour_unit_tc: 'SilverNS.png',
              hour_unit_en: 'SilverNS.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 230,
              minute_startY: 164,
              minute_array: ["SilverN0.png","SilverN1.png","SilverN2.png","SilverN3.png","SilverN4.png","SilverN5.png","SilverN6.png","SilverN7.png","SilverN8.png","SilverN9.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 216,
              second_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              second_zero: 1,
              second_space: -6,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BackGround.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 377,
              src: 'heart.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 386,
              font_array: ["SSSilverN0.png","SSSilverN1.png","SSSilverN2.png","SSSilverN3.png","SSSilverN4.png","SSSilverN5.png","SSSilverN6.png","SSSilverN7.png","SSSilverN8.png","SSSilverN9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 84,
              y: 383,
              week_en: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_tc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              week_sc: ["dia0.png","dia1.png","dia2.png","dia3.png","dia4.png","dia5.png","dia6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 388,
              month_sc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              month_tc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              month_en_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 388,
              day_sc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              day_tc_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              day_en_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              day_zero: 1,
              day_space: -4,
              day_unit_sc: 'SmSilverNM.png',
              day_unit_tc: 'SmSilverNM.png',
              day_unit_en: 'SmSilverNM.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 343,
              font_array: ["SSSilverN0.png","SSSilverN1.png","SSSilverN2.png","SSSilverN3.png","SSSilverN4.png","SSSilverN5.png","SSSilverN6.png","SSSilverN7.png","SSSilverN8.png","SSSilverN9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'SSSilverNKm.png',
              unit_tc: 'SSSilverNKm.png',
              unit_en: 'SSSilverNKm.png',
              dot_image: 'SSSilverNDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 342,
              src: 'StepIC.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 343,
              font_array: ["SSSilverN0.png","SSSilverN1.png","SSSilverN2.png","SSSilverN3.png","SSSilverN4.png","SSSilverN5.png","SSSilverN6.png","SSSilverN7.png","SSSilverN8.png","SSSilverN9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 176,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 412,
              y: 284,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 60,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 77,
              font_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'SmSilverNDeg.png',
              unit_tc: 'SmSilverNDeg.png',
              unit_en: 'SmSilverNDeg.png',
              negative_image: 'SmSilverNM.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 187,
              y: 33,
              image_array: ["Weather_00.png","Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 330,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png","Bat6.png","Bat7.png","Bat8.png","Bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 164,
              hour_array: ["SilverN0.png","SilverN1.png","SilverN2.png","SilverN3.png","SilverN4.png","SilverN5.png","SilverN6.png","SilverN7.png","SilverN8.png","SilverN9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_unit_sc: 'SilverNS.png',
              hour_unit_tc: 'SilverNS.png',
              hour_unit_en: 'SilverNS.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 230,
              minute_startY: 164,
              minute_array: ["SilverN0.png","SilverN1.png","SilverN2.png","SilverN3.png","SilverN4.png","SilverN5.png","SilverN6.png","SilverN7.png","SilverN8.png","SilverN9.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 216,
              second_array: ["SmSilverN0.png","SmSilverN1.png","SmSilverN2.png","SmSilverN3.png","SmSilverN4.png","SmSilverN5.png","SmSilverN6.png","SmSilverN7.png","SmSilverN8.png","SmSilverN9.png"],
              second_zero: 1,
              second_space: -6,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  