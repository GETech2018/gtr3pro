﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start
let colornumber_main = 1
        let totalcolors_main = 15
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");																											 
         
        }
        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_sun_current_text_img = ''
        let normal_sun_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -2,
              y: 130,
              src: 'bt_off2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 427,
              y: 128,
              src: 'alarm_on2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 440,
              font_array: ["bbig_00.png","bbig_01.png","bbig_02.png","bbig_03.png","bbig_04.png","bbig_05.png","bbig_06.png","bbig_07.png","bbig_08.png","bbig_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'bbig_proc.png',
              unit_tc: 'bbig_proc.png',
              unit_en: 'bbig_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 404,
              src: 'i_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 408,
              font_array: ["sgd_00.png","sgd_01.png","sgd_02.png","sgd_03.png","sgd_04.png","sgd_05.png","sgd_06.png","sgd_07.png","sgd_08.png","sgd_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 372,
              src: 'icon_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 372,
              font_array: ["sgd_00.png","sgd_01.png","sgd_02.png","sgd_03.png","sgd_04.png","sgd_05.png","sgd_06.png","sgd_07.png","sgd_08.png","sgd_09.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sgd_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 372,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 372,
              font_array: ["sgd_00.png","sgd_01.png","sgd_02.png","sgd_03.png","sgd_04.png","sgd_05.png","sgd_06.png","sgd_07.png","sgd_08.png","sgd_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 171,
              y: 86,
              week_en: ["dw_en_00.png","dw_en_01.png","dw_en_02.png","dw_en_03.png","dw_en_04.png","dw_en_05.png","dw_en_06.png"],
              week_tc: ["dw_en_00.png","dw_en_01.png","dw_en_02.png","dw_en_03.png","dw_en_04.png","dw_en_05.png","dw_en_06.png"],
              week_sc: ["dw_en_00.png","dw_en_01.png","dw_en_02.png","dw_en_03.png","dw_en_04.png","dw_en_05.png","dw_en_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 13,
              day_sc_array: ["di_00.png","di_01.png","di_02.png","di_03.png","di_04.png","di_05.png","di_06.png","di_07.png","di_08.png","di_09.png"],
              day_tc_array: ["di_00.png","di_01.png","di_02.png","di_03.png","di_04.png","di_05.png","di_06.png","di_07.png","di_08.png","di_09.png"],
              day_en_array: ["di_00.png","di_01.png","di_02.png","di_03.png","di_04.png","di_05.png","di_06.png","di_07.png","di_08.png","di_09.png"],
              day_zero: 0,
              day_space: -20,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 61,
              month_sc_array: ["mth_00.png","mth_01.png","mth_02.png","mth_03.png","mth_04.png","mth_05.png","mth_06.png","mth_07.png","mth_08.png","mth_09.png","mth_10.png","mth_11.png"],
              month_tc_array: ["mth_00.png","mth_01.png","mth_02.png","mth_03.png","mth_04.png","mth_05.png","mth_06.png","mth_07.png","mth_08.png","mth_09.png","mth_10.png","mth_11.png"],
              month_en_array: ["mth_00.png","mth_01.png","mth_02.png","mth_03.png","mth_04.png","mth_05.png","mth_06.png","mth_07.png","mth_08.png","mth_09.png","mth_10.png","mth_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 130,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 170,
              minute_startY: 263,
              minute_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 216,
              second_startY: 344,
              second_array: ["bbig_00.png","bbig_01.png","bbig_02.png","bbig_03.png","bbig_04.png","bbig_05.png","bbig_06.png","bbig_07.png","bbig_08.png","bbig_09.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 53,
              am_y: 112,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 383,
              pm_y: 112,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 67,
              font_array: ["sd_00.png","sd_01.png","sd_02.png","sd_03.png","sd_04.png","sd_05.png","sd_06.png","sd_07.png","sd_08.png","sd_09.png"],
              padding: false,
              h_space: -1,
              dot_image: 'sd_dots.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 38,
              src: 'i_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 67,
              font_array: ["sd_00.png","sd_01.png","sd_02.png","sd_03.png","sd_04.png","sd_05.png","sd_06.png","sd_07.png","sd_08.png","sd_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'sym_2.png',
              unit_tc: 'sym_2.png',
              unit_en: 'sym_2.png',
              negative_image: 'sym_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 35,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 229,
              y: 115,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 328,
              y: 405,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 408,
              font_array: ["sgd_00.png","sgd_01.png","sgd_02.png","sgd_03.png","sgd_04.png","sgd_05.png","sgd_06.png","sgd_07.png","sgd_08.png","sgd_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg14.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -2,
              y: 130,
              src: 'bt_off2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 427,
              y: 128,
              src: 'alarm_on2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 440,
              font_array: ["bbig_00.png","bbig_01.png","bbig_02.png","bbig_03.png","bbig_04.png","bbig_05.png","bbig_06.png","bbig_07.png","bbig_08.png","bbig_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'bbig_proc.png',
              unit_tc: 'bbig_proc.png',
              unit_en: 'bbig_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 171,
              y: 86,
              week_en: ["dw_en_00.png","dw_en_01.png","dw_en_02.png","dw_en_03.png","dw_en_04.png","dw_en_05.png","dw_en_06.png"],
              week_tc: ["dw_en_00.png","dw_en_01.png","dw_en_02.png","dw_en_03.png","dw_en_04.png","dw_en_05.png","dw_en_06.png"],
              week_sc: ["dw_en_00.png","dw_en_01.png","dw_en_02.png","dw_en_03.png","dw_en_04.png","dw_en_05.png","dw_en_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 13,
              day_sc_array: ["di_00.png","di_01.png","di_02.png","di_03.png","di_04.png","di_05.png","di_06.png","di_07.png","di_08.png","di_09.png"],
              day_tc_array: ["di_00.png","di_01.png","di_02.png","di_03.png","di_04.png","di_05.png","di_06.png","di_07.png","di_08.png","di_09.png"],
              day_en_array: ["di_00.png","di_01.png","di_02.png","di_03.png","di_04.png","di_05.png","di_06.png","di_07.png","di_08.png","di_09.png"],
              day_zero: 0,
              day_space: -20,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 61,
              month_sc_array: ["mth_00.png","mth_01.png","mth_02.png","mth_03.png","mth_04.png","mth_05.png","mth_06.png","mth_07.png","mth_08.png","mth_09.png","mth_10.png","mth_11.png"],
              month_tc_array: ["mth_00.png","mth_01.png","mth_02.png","mth_03.png","mth_04.png","mth_05.png","mth_06.png","mth_07.png","mth_08.png","mth_09.png","mth_10.png","mth_11.png"],
              month_en_array: ["mth_00.png","mth_01.png","mth_02.png","mth_03.png","mth_04.png","mth_05.png","mth_06.png","mth_07.png","mth_08.png","mth_09.png","mth_10.png","mth_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 130,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 170,
              minute_startY: 263,
              minute_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 53,
              am_y: 112,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 383,
              pm_y: 112,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 404,
              w: 138,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 404,
              w: 138,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 353,
              w: 138,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 22,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 309,
              y: 33,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 33,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 281,
              w: 250,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}