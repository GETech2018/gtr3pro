﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'moto360-bck.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'moto360-sec01.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_cover_path: 'moto-secadd.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 214,
              font_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 204,
              src: 'moto-batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 350,
              day_startY: 213,
              day_sc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_tc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_en_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 380,
              y: 210,
              week_en: ["gie-0001.png","gie-0002.png","gie-0003.png","gie-0004.png","gie-0005.png","gie-0006.png","gie-0007.png"],
              week_tc: ["gie-0001.png","gie-0002.png","gie-0003.png","gie-0004.png","gie-0005.png","gie-0006.png","gie-0007.png"],
              week_sc: ["gie-0001.png","gie-0002.png","gie-0003.png","gie-0004.png","gie-0005.png","gie-0006.png","gie-0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 135,
              hour_startY: 313,
              hour_array: ["ore-0000.png","ore-0001.png","ore-0002.png","ore-0003.png","ore-0004.png","ore-0005.png","ore-0006.png","ore-0007.png","ore-0008.png","ore-0009.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 310,
              minute_array: ["ore-0000.png","ore-0001.png","ore-0002.png","ore-0003.png","ore-0004.png","ore-0005.png","ore-0006.png","ore-0007.png","ore-0008.png","ore-0009.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 212,
              second_startY: 214,
              second_array: ["sec-0000.png","sec-0001.png","sec-0002.png","sec-0003.png","sec-0004.png","sec-0005.png","sec-0006.png","sec-0007.png","sec-0008.png","sec-0009.png"],
              second_zero: 1,
              second_space: 6,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ore-0010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 331,
              src: 'ore-0010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  