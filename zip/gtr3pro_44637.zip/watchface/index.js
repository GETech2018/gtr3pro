﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg66.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 78,
              src: 'btoff36.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 78,
              src: 'alon36.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 358,
              y: 245,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 195,
              font_array: ["chars_4F61D3DD_000.png","chars_4F61D3DD_001.png","chars_4F61D3DD_002.png","chars_4F61D3DD_003.png","chars_4F61D3DD_004.png","chars_4F61D3DD_005.png","chars_4F61D3DD_006.png","chars_4F61D3DD_007.png","chars_4F61D3DD_008.png","chars_4F61D3DD_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'MF_Medium_Deg.png',
              unit_tc: 'MF_Medium_Deg.png',
              unit_en: 'MF_Medium_Deg.png',
              negative_image: 'MF_Medium_Minus.png',
              invalid_image: 'MF_Medium_Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 359,
              y: 134,
              image_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 308,
              font_array: ["chars_4F61D3DD_000.png","chars_4F61D3DD_001.png","chars_4F61D3DD_002.png","chars_4F61D3DD_003.png","chars_4F61D3DD_004.png","chars_4F61D3DD_005.png","chars_4F61D3DD_006.png","chars_4F61D3DD_007.png","chars_4F61D3DD_008.png","chars_4F61D3DD_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 307,
              src: 'hearticon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec7.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 20,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 125,
              hour_array: ["chars_D77D3DB2_000.png","chars_D77D3DB2_001.png","chars_D77D3DB2_002.png","chars_D77D3DB2_003.png","chars_D77D3DB2_004.png","chars_D77D3DB2_005.png","chars_D77D3DB2_006.png","chars_D77D3DB2_007.png","chars_D77D3DB2_008.png","chars_D77D3DB2_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 158,
              minute_startY: 285,
              minute_array: ["chars_4C09054B_000.png","chars_4C09054B_001.png","chars_4C09054B_002.png","chars_4C09054B_003.png","chars_4C09054B_004.png","chars_4C09054B_005.png","chars_4C09054B_006.png","chars_4C09054B_007.png","chars_4C09054B_008.png","chars_4C09054B_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 360,
              second_startY: 335,
              second_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 334,
              src: 'element_custom_icon_1767311393163_82x53_a191.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 67,
              week_en: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 33,
              day_sc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              day_tc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              day_en_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'chars_959572A5_000.png',
              day_unit_tc: 'chars_959572A5_000.png',
              day_unit_en: 'chars_959572A5_000.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 26,
              src: 'mask2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 246,
              month_startY: 33,
              month_sc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              month_tc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              month_en_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 26,
              src: 'mask2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 257,
              font_array: ["chars_4F61D3DD_000.png","chars_4F61D3DD_001.png","chars_4F61D3DD_002.png","chars_4F61D3DD_003.png","chars_4F61D3DD_004.png","chars_4F61D3DD_005.png","chars_4F61D3DD_006.png","chars_4F61D3DD_007.png","chars_4F61D3DD_008.png","chars_4F61D3DD_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 225,
              src: 'i01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 226,
              image_array: ["i02.png","i03.png","i04.png","i05.png","i06.png","i07.png","i08.png","i09.png","i10.png","i11.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 195,
              font_array: ["chars_4F61D3DD_000.png","chars_4F61D3DD_001.png","chars_4F61D3DD_002.png","chars_4F61D3DD_003.png","chars_4F61D3DD_004.png","chars_4F61D3DD_005.png","chars_4F61D3DD_006.png","chars_4F61D3DD_007.png","chars_4F61D3DD_008.png","chars_4F61D3DD_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'chars_4F61D3DD_010.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 257,
              src: '0498.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 354,
              image_array: ["set_12_35x20_img_level_1.png","set_12_35x20_img_level_2.png","set_12_35x20_img_level_3.png","set_12_35x20_img_level_4.png","set_12_35x20_img_level_5.png","set_12_35x20_img_level_6.png","set_12_35x20_img_level_7.png","set_12_35x20_img_level_8.png","set_12_35x20_img_level_9.png","set_12_35x20_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 380,
              font_array: ["chars_EB3B6BF2_000.png","chars_EB3B6BF2_001.png","chars_EB3B6BF2_002.png","chars_EB3B6BF2_003.png","chars_EB3B6BF2_004.png","chars_EB3B6BF2_005.png","chars_EB3B6BF2_006.png","chars_EB3B6BF2_007.png","chars_EB3B6BF2_008.png","chars_EB3B6BF2_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'proce.png',
              unit_tc: 'proce.png',
              unit_en: 'proce.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 144,
              font_array: ["chars_4F61D3DD_000.png","chars_4F61D3DD_001.png","chars_4F61D3DD_002.png","chars_4F61D3DD_003.png","chars_4F61D3DD_004.png","chars_4F61D3DD_005.png","chars_4F61D3DD_006.png","chars_4F61D3DD_007.png","chars_4F61D3DD_008.png","chars_4F61D3DD_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 142,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 78,
              src: 'btoff36.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 78,
              src: 'alon36.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 158,
              hour_startY: 125,
              hour_array: ["chars_4C09054B_000.png","chars_4C09054B_001.png","chars_4C09054B_002.png","chars_4C09054B_003.png","chars_4C09054B_004.png","chars_4C09054B_005.png","chars_4C09054B_006.png","chars_4C09054B_007.png","chars_4C09054B_008.png","chars_4C09054B_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 158,
              minute_startY: 285,
              minute_array: ["chars_4C09054B_000.png","chars_4C09054B_001.png","chars_4C09054B_002.png","chars_4C09054B_003.png","chars_4C09054B_004.png","chars_4C09054B_005.png","chars_4C09054B_006.png","chars_4C09054B_007.png","chars_4C09054B_008.png","chars_4C09054B_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 360,
              second_startY: 335,
              second_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 334,
              src: 'element_custom_icon_1767311393163_82x53_a191.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 67,
              week_en: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_tc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              week_sc: ["d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 33,
              day_sc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              day_tc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              day_en_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'chars_959572A5_000.png',
              day_unit_tc: 'chars_959572A5_000.png',
              day_unit_en: 'chars_959572A5_000.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 26,
              src: 'mask2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 246,
              month_startY: 33,
              month_sc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              month_tc_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              month_en_array: ["chars_580B3A04_000.png","chars_580B3A04_001.png","chars_580B3A04_002.png","chars_580B3A04_003.png","chars_580B3A04_004.png","chars_580B3A04_005.png","chars_580B3A04_006.png","chars_580B3A04_007.png","chars_580B3A04_008.png","chars_580B3A04_009.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 26,
              src: 'mask2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 325,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 50,
              w: 80,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 115,
              w: 100,
              h: 100,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 50,
              w: 80,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 230,
              w: 100,
              h: 90,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 429,
              w: 100,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 135,
              w: 100,
              h: 90,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 220,
              w: 100,
              h: 100,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 135,
              w: 100,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 325,
              w: 100,
              h: 100,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 293,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 345,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'buttons.png',
              normal_src: 'buttons.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 5,
              w: 100,
              h: 105,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'buttons.png',
              normal_src: 'buttons.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}