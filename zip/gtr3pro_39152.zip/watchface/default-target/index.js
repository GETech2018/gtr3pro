try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '4.png',
                            'preview': '5.png'
                        },
                        {
                            'id': 2,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 3,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 4,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 5,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 6,
                            'path': '14.png',
                            'preview': '15.png'
                        }
                    ],
                    count: 6,
                    default_id: 1,
                    fg: '3.png',
                    tips_x: 166,
                    tips_y: 265,
                    tips_bg: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 211,
                    y: 311,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '27.png',
                    unit_tc: '27.png',
                    unit_en: '27.png',
                    invalid_image: '26.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 220,
                    y: 331,
                    w: 40,
                    h: 14,
                    src: '28.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: '29.png',
                    center_x: 240,
                    center_y: 356,
                    x: 11,
                    y: 67,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 0,
                    end_angle: 360,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 208,
                    y: 45,
                    image_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 210,
                    y: 112,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '71.png',
                    unit_tc: '71.png',
                    unit_en: '71.png',
                    negative_image: '70.png',
                    invalid_image: '69.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 349,
                    day_startY: 358,
                    day_sc_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    day_tc_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    day_en_array: [
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png'
                    ],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 0,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 224,
                    y: 2,
                    src: '82.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 66,
                    y: 108,
                    w: 147,
                    h: 147,
                    select_image: '83.png',
                    un_select_image: '84.png',
                    default_type: hmUI.edit_type.STEP,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '86.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '87.png'
                        },
                        {
                            'type': hmUI.edit_type.TRAINING_LOAD,
                            'preview': '88.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '89.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '90.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '91.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '92.png'
                        }
                    ],
                    count: 7,
                    tips_BG: '85.png',
                    tips_x: 0,
                    tips_y: 157,
                    tips_width: 147,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 102,
                        y: 130,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 107,
                        y: 152,
                        w: 67,
                        h: 17,
                        src: '93.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '94.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.STEP,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 117,
                        y: 130,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '95.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 116,
                        y: 152,
                        w: 46,
                        h: 16,
                        src: '96.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '97.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.HEART,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 109,
                        y: 130,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 113,
                        y: 152,
                        w: 54,
                        h: 17,
                        src: '98.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '99.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.CAL,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 117,
                        y: 130,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 125,
                        y: 152,
                        w: 29,
                        h: 16,
                        src: '100.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '101.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.PAI_DAILY,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 117,
                        y: 130,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '102.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 113,
                        y: 152,
                        w: 53,
                        h: 20,
                        src: '103.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '104.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.SPO2,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 117,
                        y: 130,
                        type: hmUI.data_type.TRAINING_LOAD,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 112,
                        y: 152,
                        w: 55,
                        h: 16,
                        src: '105.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '106.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.TRAINING_LOAD,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.TRAINING_LOAD,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 117,
                        y: 130,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '107.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 119,
                        y: 152,
                        w: 42,
                        h: 16,
                        src: '108.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '109.png',
                        center_x: 140,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.VO2MAX,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 0,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 66,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 267,
                    y: 108,
                    w: 147,
                    h: 147,
                    select_image: '83.png',
                    un_select_image: '84.png',
                    default_type: hmUI.edit_type.CAL,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '90.png'
                        },
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '87.png'
                        },
                        {
                            'type': hmUI.edit_type.TRAINING_LOAD,
                            'preview': '88.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '89.png'
                        },
                        {
                            'type': hmUI.edit_type.STEP,
                            'preview': '86.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '91.png'
                        },
                        {
                            'type': hmUI.edit_type.PAI_DAILY,
                            'preview': '92.png'
                        }
                    ],
                    count: 7,
                    tips_BG: '85.png',
                    tips_x: 0,
                    tips_y: 157,
                    tips_width: 147,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 303,
                        y: 130,
                        type: hmUI.data_type.STEP,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 308,
                        y: 152,
                        w: 67,
                        h: 17,
                        src: '93.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '94.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.STEP,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 318,
                        y: 130,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '95.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 317,
                        y: 152,
                        w: 46,
                        h: 16,
                        src: '96.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '97.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.HEART,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 310,
                        y: 130,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 314,
                        y: 152,
                        w: 54,
                        h: 17,
                        src: '98.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '99.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.CAL,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 318,
                        y: 130,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 326,
                        y: 152,
                        w: 29,
                        h: 16,
                        src: '100.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '101.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.PAI_DAILY,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.PAI_DAILY,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 318,
                        y: 130,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '102.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 314,
                        y: 152,
                        w: 53,
                        h: 20,
                        src: '103.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '104.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.SPO2,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 318,
                        y: 130,
                        type: hmUI.data_type.TRAINING_LOAD,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 313,
                        y: 152,
                        w: 55,
                        h: 16,
                        src: '105.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '106.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.TRAINING_LOAD,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.TRAINING_LOAD,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 318,
                        y: 130,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '59.png',
                            '60.png',
                            '61.png',
                            '62.png',
                            '63.png',
                            '64.png',
                            '65.png',
                            '66.png',
                            '67.png',
                            '68.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '110.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 320,
                        y: 152,
                        w: 42,
                        h: 16,
                        src: '108.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        src: '109.png',
                        center_x: 341,
                        center_y: 182,
                        x: 11,
                        y: 71,
                        type: hmUI.data_type.VO2MAX,
                        start_angle: 0,
                        end_angle: 360,
                        cover_x: 201,
                        cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 267,
                        y: 108,
                        w: 147,
                        h: 147,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 21,
                    hour_posY: 131,
                    hour_path: '111.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 15,
                    minute_posY: 218,
                    minute_path: '112.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 13,
                    second_posY: 215,
                    second_path: '113.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '114.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '115.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 21,
                    hour_posY: 131,
                    hour_path: '116.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 15,
                    minute_posY: 219,
                    minute_path: '117.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 174,
                    y: 290,
                    w: 132,
                    h: 132,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 208,
                    y: 45,
                    w: 64,
                    h: 85,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}